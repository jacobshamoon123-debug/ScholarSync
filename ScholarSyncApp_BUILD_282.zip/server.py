import argparse
import base64
import binascii
import csv
import io
import hashlib
import hmac
import html
import json
import os
import re
import secrets
import shutil
import traceback
from datetime import datetime, timedelta, timezone, date
import socket
import sqlite3
import sys
import threading
import smtplib
from email.message import EmailMessage
import time
import webbrowser
import zipfile
import xml.etree.ElementTree as ET
from http import cookies
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlparse



def _nth_sunday_date(year, month, n):
    """Return the date of the nth Sunday in month without relying on tzdata."""
    d = datetime(year, month, 1)
    days = (6 - d.weekday()) % 7 + (n - 1) * 7
    return (d + timedelta(days=days)).date()


def _us_zone_offset_hours(tzname, utc_now):
    """Current UTC offset for common US school zones, including DST, using stdlib only."""
    fixed = {
        'America/Phoenix': -7,
        'Pacific/Honolulu': -10,
    }
    if tzname in fixed:
        return fixed[tzname]
    rules = {
        'America/New_York': (-5, -4),
        'America/Chicago': (-6, -5),
        'America/Denver': (-7, -6),
        'America/Los_Angeles': (-8, -7),
        'America/Anchorage': (-9, -8),
    }
    if tzname not in rules:
        return None
    std, dst = rules[tzname]
    year = utc_now.year
    # Since 2007, US DST starts at 2:00 local standard time on second Sunday in March
    # and ends at 2:00 local daylight time on first Sunday in November.
    start_day = _nth_sunday_date(year, 3, 2)
    end_day = _nth_sunday_date(year, 11, 1)
    start_utc = datetime(year, 3, start_day.day, 2, 0, tzinfo=timezone.utc) - timedelta(hours=std)
    end_utc = datetime(year, 11, end_day.day, 2, 0, tzinfo=timezone.utc) - timedelta(hours=dst)
    return dst if start_utc <= utc_now < end_utc else std


def school_now(tzname='America/Chicago'):
    """Return an aware school-local datetime without requiring the optional Windows tzdata package."""
    tzname = (tzname or 'America/Chicago').strip()
    utc_now = datetime.now(timezone.utc)
    offset = _us_zone_offset_hours(tzname, utc_now)
    if offset is not None:
        return utc_now.astimezone(timezone(timedelta(hours=offset))), tzname
    # Unknown/custom zones: fall back safely to the computer's configured local zone.
    local = datetime.now().astimezone()
    return local, tzname

ROOT = os.path.dirname(os.path.abspath(__file__))
DEFAULT_DATA_DIR = os.path.join(ROOT, "data")
STATIC = os.path.join(ROOT, "static")
ROLES = {"admin", "teacher", "student", "parent", "counselor", "nurse", "finance", "transportation", "food", "coach", "substitute"}
ROLE_PORTS = {
    "admin": 8991,
    "teacher": 8992,
    "student": 8993,
    "parent": 8994,
    "counselor": 8995,
    "nurse": 8996,
    "finance": 8997,
    "transportation": 8998,
    "food": 8999,
    "coach": 9000,
    "substitute": 9001,
    "": 8990,
}

PORTAL_LOCK = ""
PORT = ROLE_PORTS[""]
DB = os.environ.get("SCHOLARSYNC_DB") or os.environ.get("DATABASE_PATH") or os.path.join(DEFAULT_DATA_DIR, "scholarsync.db")
PRODUCTION = str(os.environ.get("SCHOLARSYNC_PRODUCTION", "")).strip().lower() in {"1","true","yes","on"}
PUBLIC_URL = str(os.environ.get("SCHOLARSYNC_PUBLIC_URL", "")).strip().rstrip("/")
COOKIE_NAME = "scholarsync_session_general"


def db_connect():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    c = sqlite3.connect(DB, timeout=10)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA busy_timeout=10000")
    return c


def rows(sql, args=()):
    c = db_connect()
    try:
        return [dict(x) for x in c.execute(sql, args).fetchall()]
    finally:
        c.close()


def one(sql, args=()):
    data = rows(sql, args)
    return data[0] if data else None


def run(sql, args=()):
    c = db_connect()
    try:
        cur = c.execute(sql, args)
        c.commit()
        return cur.lastrowid
    finally:
        c.close()




def normalize_course_import_row(raw):
    aliases = {
        "code": ["code", "course code", "course_code", "course id", "course number"],
        "name": ["name", "course name", "course_name", "title"],
        "department": ["department", "dept", "subject"],
        "credits": ["credits", "credit", "credit hours"],
        "course_level": ["course level", "course_level", "level", "type"],
        "gpa_multiplier": ["gpa multiplier", "gpa_multiplier", "weight", "gpa weight"],
        "grade_levels": ["grade levels", "grade_levels", "grades", "grade"],
        "requestable": ["requestable", "student requests", "available for registration", "registration"],
    }
    lowered = {str(k).strip().lower(): v for k, v in (raw or {}).items()}
    out = {}
    for target, names in aliases.items():
        value = ""
        for name in names:
            if name in lowered and lowered[name] is not None:
                value = str(lowered[name]).strip()
                break
        out[target] = value
    raw_level = (out["course_level"] or "Regular").strip()
    out["course_level"] = raw_level
    try: out["credits"] = float(out["credits"] or 1)
    except Exception: out["credits"] = 1
    defaults = {
        "Level 1 — O’Shaughnessy":1.0,
        "Level 3 — College Preparatory":1.0,
        "Level 6 — Accelerated College Preparatory":1.0,
        "Level 9 — Honors":1.05,
        "Advanced Placement":1.08,
        "Advanced Placement — Dual Credit":1.08,
        "College-Level — AP Weight":1.08,
        "Formation — Pass/Fail":1.0,
        "O’Shaughnessy Enrichment — Non-Credit":1.0,
    }
    try: out["gpa_multiplier"] = float(out["gpa_multiplier"] or defaults.get(out["course_level"],1.0))
    except Exception: out["gpa_multiplier"] = defaults.get(out["course_level"],1.0)
    val = str(out["requestable"] or "1").strip().lower()
    out["requestable"] = 0 if val in {"0","false","no","n","not requestable"} else 1
    return out


def parse_xlsx_rows(blob):
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        ns = {"m":"http://schemas.openxmlformats.org/spreadsheetml/2006/main", "r":"http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
        shared=[]
        if "xl/sharedStrings.xml" in z.namelist():
            root=ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root.findall("m:si",ns):
                shared.append("".join(t.text or "" for t in si.iterfind(".//m:t",ns)))
        sheet_name=next((n for n in z.namelist() if n.startswith("xl/worksheets/sheet") and n.endswith(".xml")),None)
        if not sheet_name: return []
        root=ET.fromstring(z.read(sheet_name)); matrix=[]
        for row in root.findall(".//m:sheetData/m:row",ns):
            vals={}; maxcol=-1
            for c in row.findall("m:c",ns):
                ref=c.get("r",""); letters="".join(ch for ch in ref if ch.isalpha())
                col=0
                for ch in letters: col=col*26+(ord(ch.upper())-64)
                col-=1; maxcol=max(maxcol,col)
                typ=c.get("t"); v=c.find("m:v",ns); val="" if v is None else (v.text or "")
                if typ=="s" and val.isdigit() and int(val)<len(shared): val=shared[int(val)]
                elif typ=="inlineStr": val="".join(t.text or "" for t in c.iterfind(".//m:t",ns))
                vals[col]=val
            if maxcol>=0: matrix.append([vals.get(i,"") for i in range(maxcol+1)])
    if not matrix: return []
    headers=[str(x).strip() for x in matrix[0]]
    return [dict(zip(headers, r+[""]*(len(headers)-len(r)))) for r in matrix[1:] if any(str(x).strip() for x in r)]


def parse_course_import(filename, blob):
    lower=(filename or "").lower()
    if lower.endswith(".xlsx"):
        raw=parse_xlsx_rows(blob)
    elif lower.endswith(".json"):
        parsed=json.loads(blob.decode("utf-8-sig")); raw=parsed if isinstance(parsed,list) else parsed.get("courses",[])
    else:
        text=blob.decode("utf-8-sig")
        sample=text[:4096]
        try: dialect=csv.Sniffer().sniff(sample, delimiters=",\t;|")
        except Exception: dialect=csv.excel
        raw=list(csv.DictReader(io.StringIO(text), dialect=dialect))
    return [normalize_course_import_row(r) for r in raw]



def normalize_student_import_row(raw):
    aliases = {
        "student_number": ["student id", "student_id", "student number", "student_number", "id", "sis id"],
        "first_name": ["first name", "first_name", "firstname", "given name"],
        "last_name": ["last name", "last_name", "lastname", "surname", "family name"],
        "grade": ["grade", "grade level", "grade_level"],
        "birth_date": ["birth date", "birth_date", "date of birth", "dob", "birthday"],
        "gender": ["gender", "sex"],
        "email": ["email", "student email", "email address"],
        "phone": ["phone", "phone number", "telephone"],
        "address": ["address", "home address", "street address"],
        "homeroom": ["homeroom", "home room", "advisor"],
        "status": ["status", "enrollment status"],
    }
    lowered = {str(k).strip().lower(): v for k, v in (raw or {}).items()}
    out = {}
    for target, names in aliases.items():
        value = ""
        for name in names:
            if name in lowered and lowered[name] is not None:
                value = str(lowered[name]).strip()
                break
        out[target] = value
    out["status"] = out["status"] or "Active"
    return out


def parse_student_import(filename, blob):
    lower=(filename or "").lower()
    if lower.endswith(".xlsx"):
        raw=parse_xlsx_rows(blob)
    elif lower.endswith(".json"):
        parsed=json.loads(blob.decode("utf-8-sig")); raw=parsed if isinstance(parsed,list) else parsed.get("students",[])
    else:
        text=blob.decode("utf-8-sig")
        sample=text[:4096]
        try: dialect=csv.Sniffer().sniff(sample, delimiters=",\t;|")
        except Exception: dialect=csv.excel
        raw=list(csv.DictReader(io.StringIO(text), dialect=dialect))
    return [normalize_student_import_row(r) for r in raw]

def column_names(table):
    return {x["name"] for x in rows(f"PRAGMA table_info({table})")}


def ensure_column(table, definition):
    name = definition.split()[0]
    if name in column_names(table):
        return
    try:
        run(f"ALTER TABLE {table} ADD COLUMN {definition}")
    except sqlite3.OperationalError as exc:
        # Multiple role-specific portal servers may start together on first launch.
        # If another process completed the same migration first, the database is fine.
        if "duplicate column name" not in str(exc).lower():
            raise


def init_db():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    c = db_connect()
    try:
        c.execute("PRAGMA journal_mode=WAL")
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS students(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              student_number TEXT UNIQUE,
              first_name TEXT NOT NULL,
              last_name TEXT NOT NULL,
              grade TEXT,
              birth_date TEXT,
              gender TEXT,
              email TEXT,
              phone TEXT,
              address TEXT,
              homeroom TEXT,
              status TEXT DEFAULT 'Active',
              created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS staff(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              employee_number TEXT,
              name TEXT NOT NULL,
              role TEXT,
              email TEXT,
              phone TEXT,
              school TEXT,
              status TEXT DEFAULT 'Active'
            );
            CREATE TABLE IF NOT EXISTS courses(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              code TEXT,
              name TEXT NOT NULL,
              department TEXT,
              credits REAL DEFAULT 1,
              grade_levels TEXT
            );
            CREATE TABLE IF NOT EXISTS gpa_settings(
              id INTEGER PRIMARY KEY CHECK(id=1),
              regular_multiplier REAL DEFAULT 1.00,
              honors_multiplier REAL DEFAULT 1.05,
              ap_multiplier REAL DEFAULT 1.08,
              dual_credit_multiplier REAL DEFAULT 1.00,
              gpa_divisor REAL DEFAULT 25.0,
              updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            INSERT OR IGNORE INTO gpa_settings(id,regular_multiplier,honors_multiplier,ap_multiplier,dual_credit_multiplier,gpa_divisor)
            VALUES(1,1.00,1.05,1.08,1.00,25.0);
            CREATE TABLE IF NOT EXISTS classes(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              course_id INTEGER,
              name TEXT NOT NULL,
              section TEXT,
              period TEXT,
              room TEXT,
              teacher_id INTEGER,
              term TEXT,
              capacity INTEGER DEFAULT 30,
              school TEXT,
              generated INTEGER DEFAULT 0,
              published INTEGER DEFAULT 0,
              FOREIGN KEY(course_id) REFERENCES courses(id),
              FOREIGN KEY(teacher_id) REFERENCES staff(id)
            );
            CREATE TABLE IF NOT EXISTS enrollments(
              class_id INTEGER,
              student_id INTEGER,
              status TEXT DEFAULT 'Active',
              start_date TEXT,
              end_date TEXT,
              PRIMARY KEY(class_id,student_id),
              FOREIGN KEY(class_id) REFERENCES classes(id),
              FOREIGN KEY(student_id) REFERENCES students(id)
            );
            CREATE TABLE IF NOT EXISTS assignments(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              class_id INTEGER,
              title TEXT NOT NULL,
              category TEXT DEFAULT 'Assignments',
              points REAL DEFAULT 100,
              weight REAL DEFAULT 1,
              due_date TEXT,
              visible INTEGER DEFAULT 1,
              description TEXT,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP,
              attachment_name TEXT, attachment_type TEXT, attachment_data TEXT,
              accept_submissions INTEGER DEFAULT 0, allow_any_file INTEGER DEFAULT 1, lock_after_due INTEGER DEFAULT 0,
              FOREIGN KEY(class_id) REFERENCES classes(id)
            );
            CREATE TABLE IF NOT EXISTS assignment_submissions(
              assignment_id INTEGER, student_id INTEGER, file_name TEXT, file_type TEXT, file_data TEXT, submitted_at TEXT DEFAULT CURRENT_TIMESTAMP, status TEXT DEFAULT 'Submitted',
              PRIMARY KEY(assignment_id,student_id)
            );
            CREATE TABLE IF NOT EXISTS grades(
              assignment_id INTEGER,
              student_id INTEGER,
              score REAL,
              status TEXT DEFAULT '',
              comment TEXT,
              updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
              PRIMARY KEY(assignment_id,student_id),
              FOREIGN KEY(assignment_id) REFERENCES assignments(id),
              FOREIGN KEY(student_id) REFERENCES students(id)
            );
            CREATE TABLE IF NOT EXISTS attendance(
              class_id INTEGER,
              student_id INTEGER,
              date TEXT,
              status TEXT,
              minutes_late INTEGER DEFAULT 0,
              note TEXT,
              updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
              PRIMARY KEY(class_id,student_id,date),
              FOREIGN KEY(class_id) REFERENCES classes(id),
              FOREIGN KEY(student_id) REFERENCES students(id)
            );

            CREATE TABLE IF NOT EXISTS hall_passes(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              student_id INTEGER NOT NULL,
              requested_by_user_id INTEGER,
              origin TEXT,
              destination TEXT NOT NULL,
              reason TEXT,
              status TEXT DEFAULT 'Requested',
              requested_at TEXT DEFAULT CURRENT_TIMESTAMP,
              approved_at TEXT,
              activated_at TEXT,
              returned_at TEXT,
              expires_at TEXT,
              approved_by INTEGER,
              notes TEXT,
              FOREIGN KEY(student_id) REFERENCES students(id)
            );
            CREATE TABLE IF NOT EXISTS behavior_referrals(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              student_id INTEGER NOT NULL,
              class_id INTEGER,
              referred_by INTEGER,
              incident_at TEXT,
              category TEXT,
              severity TEXT DEFAULT 'Minor',
              location TEXT,
              description TEXT NOT NULL,
              status TEXT DEFAULT 'Submitted',
              assigned_admin INTEGER,
              consequence TEXT,
              parent_contacted INTEGER DEFAULT 0,
              resolution TEXT,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP,
              updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY(student_id) REFERENCES students(id),
              FOREIGN KEY(class_id) REFERENCES classes(id)
            );
            CREATE INDEX IF NOT EXISTS idx_hall_passes_student_status ON hall_passes(student_id,status);
            CREATE INDEX IF NOT EXISTS idx_hall_passes_requested_at ON hall_passes(requested_at);
            CREATE INDEX IF NOT EXISTS idx_behavior_referrals_student ON behavior_referrals(student_id);
            CREATE INDEX IF NOT EXISTS idx_behavior_referrals_status ON behavior_referrals(status);
            CREATE TABLE IF NOT EXISTS school_forms(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              title TEXT NOT NULL,
              description TEXT,
              audience TEXT DEFAULT 'Students',
              status TEXT DEFAULT 'Draft',
              open_date TEXT,
              close_date TEXT,
              require_signature INTEGER DEFAULT 0,
              created_by INTEGER,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP,
              updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS school_form_questions(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              form_id INTEGER NOT NULL,
              question_text TEXT NOT NULL,
              question_type TEXT DEFAULT 'short',
              options_json TEXT DEFAULT '[]',
              required INTEGER DEFAULT 0,
              sort_order INTEGER DEFAULT 0,
              FOREIGN KEY(form_id) REFERENCES school_forms(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS school_form_responses(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              form_id INTEGER NOT NULL,
              student_id INTEGER,
              user_id INTEGER,
              answers_json TEXT DEFAULT '{}',
              signature_name TEXT,
              status TEXT DEFAULT 'Submitted',
              submitted_at TEXT DEFAULT CURRENT_TIMESTAMP,
              updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
              UNIQUE(form_id,student_id),
              FOREIGN KEY(form_id) REFERENCES school_forms(id) ON DELETE CASCADE,
              FOREIGN KEY(student_id) REFERENCES students(id)
            );
            CREATE TABLE IF NOT EXISTS devices(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              asset_tag TEXT UNIQUE NOT NULL,
              serial_number TEXT,
              device_type TEXT DEFAULT 'Chromebook',
              model TEXT,
              status TEXT DEFAULT 'Available',
              assigned_student_id INTEGER,
              condition TEXT DEFAULT 'Good',
              notes TEXT,
              assigned_at TEXT,
              returned_at TEXT,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP,
              updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY(assigned_student_id) REFERENCES students(id)
            );
            CREATE TABLE IF NOT EXISTS device_history(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              device_id INTEGER NOT NULL,
              student_id INTEGER,
              action TEXT NOT NULL,
              condition TEXT,
              notes TEXT,
              actor_user_id INTEGER,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS lockers(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              locker_number TEXT UNIQUE NOT NULL,
              location TEXT,
              combination TEXT,
              status TEXT DEFAULT 'Available',
              assigned_student_id INTEGER,
              notes TEXT,
              assigned_at TEXT,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP,
              updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY(assigned_student_id) REFERENCES students(id)
            );
            CREATE TABLE IF NOT EXISTS locker_history(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              locker_id INTEGER NOT NULL,
              student_id INTEGER,
              action TEXT NOT NULL,
              notes TEXT,
              actor_user_id INTEGER,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS idx_forms_status ON school_forms(status);
            CREATE INDEX IF NOT EXISTS idx_form_responses_form ON school_form_responses(form_id);
            CREATE INDEX IF NOT EXISTS idx_devices_student ON devices(assigned_student_id);
            CREATE INDEX IF NOT EXISTS idx_lockers_student ON lockers(assigned_student_id);
            CREATE TABLE IF NOT EXISTS module_records(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              module TEXT NOT NULL,
              title TEXT NOT NULL,
              student_id INTEGER,
              staff_id INTEGER,
              status TEXT DEFAULT 'Active',
              record_date TEXT,
              data TEXT DEFAULT '{}',
              created_at TEXT DEFAULT CURRENT_TIMESTAMP,
              updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS messages(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              audience TEXT,
              title TEXT,
              body TEXT,
              channel TEXT DEFAULT 'Portal',
              send_at TEXT,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS audit_log(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              actor TEXT,
              action TEXT,
              module TEXT,
              record_id TEXT,
              details TEXT,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS users(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              username TEXT UNIQUE NOT NULL,
              password_hash TEXT NOT NULL,
              salt TEXT NOT NULL,
              role TEXT NOT NULL,
              display_name TEXT,
              active INTEGER DEFAULT 1,
              student_id INTEGER,
              staff_id INTEGER,
              must_change_password INTEGER DEFAULT 0,
              failed_attempts INTEGER DEFAULT 0,
              locked_until INTEGER DEFAULT 0,
              last_login TEXT
            );
            CREATE TABLE IF NOT EXISTS parent_students(
              user_id INTEGER,
              student_id INTEGER,
              PRIMARY KEY(user_id,student_id),
              FOREIGN KEY(user_id) REFERENCES users(id),
              FOREIGN KEY(student_id) REFERENCES students(id)
            );
            CREATE TABLE IF NOT EXISTS sessions(
              token TEXT PRIMARY KEY,
              user_id INTEGER NOT NULL,
              expires_at INTEGER NOT NULL,
              FOREIGN KEY(user_id) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS district_settings(
              setting_key TEXT PRIMARY KEY,
              setting_value TEXT,
              updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS automation_rules(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL,
              trigger_type TEXT NOT NULL,
              condition_json TEXT DEFAULT '{}',
              action_type TEXT NOT NULL,
              action_json TEXT DEFAULT '{}',
              active INTEGER DEFAULT 1,
              last_run_at TEXT,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS import_history(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              import_type TEXT NOT NULL,
              file_name TEXT,
              actor TEXT,
              created_count INTEGER DEFAULT 0,
              updated_count INTEGER DEFAULT 0,
              skipped_count INTEGER DEFAULT 0,
              failed_count INTEGER DEFAULT 0,
              details TEXT DEFAULT '{}',
              undo_payload TEXT DEFAULT '{}',
              undone_at TEXT,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS report_definitions(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL,
              data_source TEXT NOT NULL,
              columns_json TEXT DEFAULT '[]',
              filters_json TEXT DEFAULT '{}',
              sort_json TEXT DEFAULT '[]',
              created_by TEXT,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP,
              updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS security_events(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              username TEXT,
              event_type TEXT,
              ip_address TEXT,
              details TEXT,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS schedule_periods(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL,
              start_time TEXT,
              end_time TEXT,
              sort_order INTEGER DEFAULT 0,
              active INTEGER DEFAULT 1
            );
            CREATE TABLE IF NOT EXISTS schedule_rooms(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL UNIQUE,
              capacity INTEGER DEFAULT 30,
              school TEXT,
              active INTEGER DEFAULT 1
            );
            CREATE TABLE IF NOT EXISTS course_requests(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              student_id INTEGER NOT NULL,
              course_id INTEGER NOT NULL,
              priority INTEGER DEFAULT 1,
              status TEXT DEFAULT 'Requested',
              created_at TEXT DEFAULT CURRENT_TIMESTAMP,
              UNIQUE(student_id,course_id),
              FOREIGN KEY(student_id) REFERENCES students(id),
              FOREIGN KEY(course_id) REFERENCES courses(id)
            );
            CREATE TABLE IF NOT EXISTS schedule_runs(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              term TEXT,
              status TEXT,
              sections_created INTEGER DEFAULT 0,
              students_scheduled INTEGER DEFAULT 0,
              conflicts INTEGER DEFAULT 0,
              details TEXT,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS schedule_locks(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              class_id INTEGER UNIQUE,
              lock_period INTEGER DEFAULT 1,
              lock_room INTEGER DEFAULT 1,
              lock_teacher INTEGER DEFAULT 1,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS schedule_versions(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              term TEXT,
              name TEXT,
              snapshot TEXT NOT NULL,
              sections INTEGER DEFAULT 0,
              placements INTEGER DEFAULT 0,
              conflicts INTEGER DEFAULT 0,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS schedule_rotation_settings(
              id INTEGER PRIMARY KEY CHECK(id=1),
              day_a_date TEXT,
              day_b_date TEXT,
              skip_weekends INTEGER DEFAULT 1,
              updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS course_request_window(
              id INTEGER PRIMARY KEY CHECK(id=1),
              is_open INTEGER DEFAULT 0,
              opened_by INTEGER,
              opened_at TEXT,
              closed_at TEXT,
              updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS student_free_period_requests(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              student_id INTEGER NOT NULL UNIQUE,
              requested_count INTEGER DEFAULT 1,
              approved_count INTEGER DEFAULT 0,
              status TEXT DEFAULT 'Pending',
              reviewer_note TEXT,
              updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY(student_id) REFERENCES students(id)
            );
            """
        )
        c.commit()
    finally:
        c.close()

    # Safe upgrades for databases made by earlier ScholarSync builds.
    ensure_column("classes", "generated INTEGER DEFAULT 0")
    ensure_column("assignments", "visible INTEGER DEFAULT 1")
    ensure_column("assignments", "description TEXT")
    ensure_column("assignments", "created_at TEXT")
    ensure_column("grades", "status TEXT DEFAULT ''")
    ensure_column("grades", "comment TEXT")
    ensure_column("attendance", "minutes_late INTEGER DEFAULT 0")
    ensure_column("attendance", "note TEXT")
    ensure_column("students", "registration_blocked_courses TEXT")
    ensure_column("students", "registration_departments TEXT")
    ensure_column("course_request_window", "departments TEXT")
    ensure_column("users", "student_id INTEGER")
    ensure_column("users", "staff_id INTEGER")
    ensure_column("users", "must_change_password INTEGER DEFAULT 0")
    ensure_column("users", "failed_attempts INTEGER DEFAULT 0")
    ensure_column("users", "locked_until INTEGER DEFAULT 0")
    ensure_column("users", "last_login TEXT")
    ensure_column("courses", "created_by_staff_id INTEGER")
    ensure_column("courses", "requestable INTEGER DEFAULT 0")
    ensure_column("courses", "course_level TEXT DEFAULT 'Regular'")
    ensure_column("courses", "gpa_multiplier REAL DEFAULT 1.00")
    ensure_column("course_requests", "reviewer_note TEXT")
    ensure_column("course_requests", "reviewed_by INTEGER")
    ensure_column("course_requests", "reviewed_at TEXT")
    ensure_column("course_requests", "approval_status TEXT")
    ensure_column("course_requests", "scheduling_status TEXT")
    # Keep approval and scheduling as separate states. Older builds stored both in status.
    run("""UPDATE course_requests SET approval_status=CASE
        WHEN status IN ('Approved','Scheduled','Conflict') THEN 'Approved'
        WHEN status='Denied' THEN 'Denied' ELSE 'Pending' END
        WHERE approval_status IS NULL OR approval_status=''""")
    run("""UPDATE course_requests SET scheduling_status=CASE
        WHEN status IN ('Scheduled','Conflict') THEN status ELSE 'Pending' END
        WHERE scheduling_status IS NULL OR scheduling_status=''""")
    ensure_column("schedule_periods", "cycle_day INTEGER DEFAULT 1")
    ensure_column("schedule_periods", "day_label TEXT DEFAULT 'Day A'")
    ensure_column("schedule_periods", "is_lunch INTEGER DEFAULT 0")
    ensure_column("classes", "published INTEGER DEFAULT 0")
    ensure_column("assignments", "attachment_name TEXT")
    ensure_column("assignments", "attachment_type TEXT")
    ensure_column("assignments", "attachment_data TEXT")
    ensure_column("assignments", "accept_submissions INTEGER DEFAULT 0")
    ensure_column("assignments", "allow_any_file INTEGER DEFAULT 1")
    ensure_column("assignments", "lock_after_due INTEGER DEFAULT 0")
    ensure_column("assignments", "instructions TEXT")
    ensure_column("assignments", "links_json TEXT DEFAULT '[]'")
    ensure_column("assignments", "rubric_text TEXT")
    ensure_column("assignments", "extra_credit INTEGER DEFAULT 0")
    ensure_column("assignments", "allow_late INTEGER DEFAULT 1")
    ensure_column("assignments", "grading_period_key TEXT DEFAULT ''")
    ensure_column("assignments", "is_final_exam INTEGER DEFAULT 0")
    ensure_column("assignments", "include_in_gradebook INTEGER DEFAULT 1")
    ensure_column("assignment_submissions", "reviewed_at TEXT")
    ensure_column("assignment_submissions", "reviewed_by INTEGER")
    ensure_column("assignment_submissions", "teacher_note TEXT")
    ensure_column("staff", "eligible_course_ids TEXT DEFAULT '[]'")
    # Seed teaching eligibility from existing class assignments only when a teacher
    # has not been configured yet. This keeps current schools working after upgrade.
    for _t in rows("SELECT id,COALESCE(eligible_course_ids,'[]') eligible_course_ids FROM staff WHERE lower(COALESCE(role,'')) LIKE '%teacher%'"):
        try:
            _existing=json.loads(_t.get("eligible_course_ids") or "[]")
        except Exception:
            _existing=[]
        if not _existing:
            _course_ids=[int(x["course_id"]) for x in rows("SELECT DISTINCT course_id FROM classes WHERE teacher_id=? AND course_id IS NOT NULL",(_t["id"],))]
            if _course_ids:
                run("UPDATE staff SET eligible_course_ids=? WHERE id=?",(json.dumps(_course_ids),_t["id"]))

    run("""CREATE TABLE IF NOT EXISTS class_grading_config(
        class_id INTEGER PRIMARY KEY,
        mode TEXT DEFAULT 'separate_semesters',
        config_json TEXT DEFAULT '{}',
        updated_by INTEGER,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run("""CREATE TABLE IF NOT EXISTS finalized_grades(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        class_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        grading_key TEXT NOT NULL,
        grading_name TEXT NOT NULL,
        component_grades_json TEXT DEFAULT '{}',
        final_exam_grade REAL,
        calculated_grade REAL,
        final_grade REAL,
        letter_grade TEXT,
        status TEXT DEFAULT 'Draft',
        finalized_by INTEGER,
        finalized_at TEXT,
        reopened_by INTEGER,
        reopened_at TEXT,
        reopen_reason TEXT,
        UNIQUE(class_id,student_id,grading_key)
    )""")
    run("""CREATE TABLE IF NOT EXISTS district_grading_scale(
        id INTEGER PRIMARY KEY CHECK(id=1),
        name TEXT DEFAULT 'A-F with +/-',
        mode TEXT DEFAULT 'plus_minus',
        scale_json TEXT DEFAULT '[]',
        updated_by INTEGER,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run("""CREATE TABLE IF NOT EXISTS seating_charts(
        class_id INTEGER PRIMARY KEY,
        rows_count INTEGER DEFAULT 5,
        columns_count INTEGER DEFAULT 6,
        layout_json TEXT DEFAULT '[]',
        updated_by INTEGER,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run("""CREATE TABLE IF NOT EXISTS gradebook_settings(
        class_id INTEGER PRIMARY KEY,
        category_weights TEXT DEFAULT '{}',
        drop_lowest INTEGER DEFAULT 0,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run("""CREATE TABLE IF NOT EXISTS grade_history(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        assignment_id INTEGER,
        student_id INTEGER,
        old_score REAL,
        new_score REAL,
        old_status TEXT,
        new_status TEXT,
        old_comment TEXT,
        new_comment TEXT,
        changed_by INTEGER,
        changed_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    ensure_column("classes", "cycle_day INTEGER DEFAULT 1")
    ensure_column("schedule_rotation_settings", "rotation_count INTEGER DEFAULT 2")
    ensure_column("schedule_rotation_settings", "day_labels TEXT DEFAULT '[\"Day A\",\"Day B\"]'")

    run("""CREATE TABLE IF NOT EXISTS graduation_requirements(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        subject_area TEXT NOT NULL UNIQUE,
        credits_required REAL NOT NULL DEFAULT 0,
        sort_order INTEGER NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1
    )""")
    run("""CREATE TABLE IF NOT EXISTS academic_plan_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        grade_level INTEGER NOT NULL,
        school_year TEXT DEFAULT '',
        course_id INTEGER,
        course_name TEXT NOT NULL,
        subject_area TEXT DEFAULT '',
        credits REAL NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'Planned',
        counselor_note TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(student_id,grade_level,course_name)
    )""")
    run("""CREATE TABLE IF NOT EXISTS college_readiness_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        category TEXT NOT NULL,
        item TEXT NOT NULL,
        due_date TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'Not Started',
        notes TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    if one("SELECT COUNT(*) n FROM graduation_requirements")["n"] == 0:
        defaults=[('English','English',4,1),('Mathematics','Math',3,2),('Science','Science',3,3),('Social Studies','Social Studies',3,4),('Physical Education','PE',2,5),('Fine Arts / CTE / World Language','Electives',2,6),('Additional Electives','Additional',7,7)]
        for item in defaults:
            run("INSERT INTO graduation_requirements(name,subject_area,credits_required,sort_order) VALUES(?,?,?,?)",item)



    # ScholarSync real-time scheduling, activities, and class-page upgrades.
    run("""CREATE TABLE IF NOT EXISTS school_calendar_days(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL UNIQUE,
        title TEXT NOT NULL,
        day_type TEXT NOT NULL DEFAULT 'School Day',
        rotation_day INTEGER,
        details TEXT DEFAULT '',
        start_time TEXT DEFAULT '',
        end_time TEXT DEFAULT '',
        created_by INTEGER,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run("""CREATE TABLE IF NOT EXISTS sports_programs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        season TEXT DEFAULT '',
        description TEXT DEFAULT '',
        registration_open INTEGER DEFAULT 1,
        form_json TEXT DEFAULT '[]',
        teams_json TEXT DEFAULT '[]',
        start_date TEXT DEFAULT '',
        end_date TEXT DEFAULT '',
        active INTEGER DEFAULT 1,
        created_by INTEGER,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run("""CREATE TABLE IF NOT EXISTS sports_registrations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sport_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        response TEXT DEFAULT 'Yes',
        answers_json TEXT DEFAULT '{}',
        status TEXT DEFAULT 'Registered',
        team_name TEXT DEFAULT '',
        submitted_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(sport_id,student_id)
    )""")
    run("""CREATE TABLE IF NOT EXISTS sports_events(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sport_id INTEGER NOT NULL,
        team_name TEXT DEFAULT '',
        event_date TEXT NOT NULL,
        start_time TEXT DEFAULT '',
        end_time TEXT DEFAULT '',
        title TEXT DEFAULT '',
        opponent TEXT DEFAULT '',
        location TEXT DEFAULT '',
        details TEXT DEFAULT '',
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run("""CREATE TABLE IF NOT EXISTS class_pages(
        class_id INTEGER PRIMARY KEY,
        page_title TEXT DEFAULT '',
        welcome_text TEXT DEFAULT '',
        bulletin TEXT DEFAULT '',
        topics_json TEXT DEFAULT '[]',
        links_json TEXT DEFAULT '[]',
        theme TEXT DEFAULT 'Clean',
        updated_by INTEGER,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run("""CREATE TABLE IF NOT EXISTS sports_coaches(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sport_id INTEGER NOT NULL,
        team_name TEXT DEFAULT '',
        user_id INTEGER NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(sport_id,team_name,user_id)
    )""")
    ensure_column("class_pages", "settings_json TEXT DEFAULT '{}'")


    # ScholarSync parent-teacher conferences + clubs and activities.
    run("""CREATE TABLE IF NOT EXISTS conference_slots(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        staff_id INTEGER NOT NULL,
        start_at TEXT NOT NULL,
        end_at TEXT NOT NULL,
        location TEXT DEFAULT '',
        mode TEXT DEFAULT 'In Person',
        notes TEXT DEFAULT '',
        status TEXT DEFAULT 'Open',
        created_by INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run("""CREATE TABLE IF NOT EXISTS conference_bookings(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        slot_id INTEGER NOT NULL UNIQUE,
        student_id INTEGER NOT NULL,
        parent_user_id INTEGER,
        family_note TEXT DEFAULT '',
        status TEXT DEFAULT 'Booked',
        booked_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run("""CREATE TABLE IF NOT EXISTS clubs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT DEFAULT '',
        advisor_staff_id INTEGER,
        registration_open INTEGER DEFAULT 1,
        form_json TEXT DEFAULT '[]',
        meeting_info TEXT DEFAULT '',
        active INTEGER DEFAULT 1,
        created_by INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run("""CREATE TABLE IF NOT EXISTS club_registrations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        club_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        answers_json TEXT DEFAULT '{}',
        status TEXT DEFAULT 'Registered',
        submitted_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(club_id,student_id)
    )""")
    run("""CREATE TABLE IF NOT EXISTS club_events(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        club_id INTEGER NOT NULL,
        event_date TEXT NOT NULL,
        start_time TEXT DEFAULT '',
        end_time TEXT DEFAULT '',
        title TEXT NOT NULL,
        location TEXT DEFAULT '',
        details TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")

    # ScholarSync Emergency Management + Student Reunification.
    run("""CREATE TABLE IF NOT EXISTS emergency_incidents(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        incident_type TEXT NOT NULL,
        title TEXT NOT NULL,
        status TEXT DEFAULT 'Active',
        instructions TEXT DEFAULT '',
        assembly_location TEXT DEFAULT '',
        notes TEXT DEFAULT '',
        started_by INTEGER,
        started_at TEXT DEFAULT CURRENT_TIMESTAMP,
        ended_by INTEGER,
        ended_at TEXT,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    ensure_column('emergency_incidents', 'is_drill INTEGER DEFAULT 0')
    run("""CREATE TABLE IF NOT EXISTS emergency_accountability(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        incident_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        status TEXT DEFAULT 'Unaccounted',
        location TEXT DEFAULT '',
        note TEXT DEFAULT '',
        checked_by INTEGER,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(incident_id,student_id)
    )""")
    run("""CREATE TABLE IF NOT EXISTS emergency_staff_checkins(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        incident_id INTEGER NOT NULL,
        staff_id INTEGER NOT NULL,
        status TEXT DEFAULT 'Safe',
        location TEXT DEFAULT '',
        note TEXT DEFAULT '',
        checked_by INTEGER,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(incident_id,staff_id)
    )""")
    run("""CREATE TABLE IF NOT EXISTS reunification_releases(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        incident_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        pickup_name TEXT NOT NULL,
        relationship TEXT DEFAULT '',
        id_verified INTEGER DEFAULT 0,
        authorization_verified INTEGER DEFAULT 0,
        released_by INTEGER,
        released_at TEXT DEFAULT CURRENT_TIMESTAMP,
        notes TEXT DEFAULT '',
        UNIQUE(incident_id,student_id)
    )""")
    # All-day attendance declarations and parent absence requests.
    run("""CREATE TABLE IF NOT EXISTS daily_absences(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        absence_date TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'AU',
        reason TEXT DEFAULT '',
        note TEXT DEFAULT '',
        source TEXT DEFAULT 'Admin',
        request_id INTEGER,
        created_by INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(student_id,absence_date)
    )""")
    run("""CREATE TABLE IF NOT EXISTS absence_requests(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        parent_user_id INTEGER NOT NULL,
        absence_date TEXT NOT NULL,
        reason TEXT NOT NULL,
        details TEXT DEFAULT '',
        status TEXT DEFAULT 'Pending',
        decision_note TEXT DEFAULT '',
        reviewed_by INTEGER,
        reviewed_at TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run("CREATE INDEX IF NOT EXISTS idx_daily_absences_date ON daily_absences(absence_date,student_id)")
    run("CREATE INDEX IF NOT EXISTS idx_absence_requests_status ON absence_requests(status,absence_date)")
    ensure_column("absence_requests", "attendance_decision TEXT DEFAULT ''")
    run("""CREATE TABLE IF NOT EXISTS absence_request_attachments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        request_id INTEGER NOT NULL UNIQUE,
        file_name TEXT NOT NULL,
        file_type TEXT DEFAULT 'application/octet-stream',
        file_base64 TEXT NOT NULL,
        uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")

    # ScholarSync Substitute Teacher Mode. Assignments are date-bounded and every
    # substitute API re-validates assignment/class/date scope server-side.
    run("""CREATE TABLE IF NOT EXISTS substitute_assignments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        substitute_staff_id INTEGER NOT NULL,
        teacher_staff_id INTEGER NOT NULL,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        status TEXT DEFAULT 'Active',
        reason TEXT DEFAULT '',
        admin_notes TEXT DEFAULT '',
        created_by INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run("""CREATE TABLE IF NOT EXISTS substitute_coverage(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        assignment_id INTEGER NOT NULL,
        class_id INTEGER NOT NULL,
        coverage_date TEXT NOT NULL,
        lesson_plan TEXT DEFAULT '',
        lesson_links TEXT DEFAULT '',
        teacher_notes TEXT DEFAULT '',
        substitute_notes TEXT DEFAULT '',
        attendance_completed INTEGER DEFAULT 0,
        updated_by INTEGER,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(assignment_id,class_id,coverage_date)
    )""")
    ensure_column("substitute_assignments", "coverage_mode TEXT DEFAULT 'all'")
    ensure_column("substitute_assignments", "selected_class_ids TEXT DEFAULT '[]'")
    run("CREATE INDEX IF NOT EXISTS idx_sub_assign_dates ON substitute_assignments(start_date,end_date,status)")
    run("CREATE INDEX IF NOT EXISTS idx_sub_assign_staff ON substitute_assignments(substitute_staff_id,teacher_staff_id)")
    run("CREATE INDEX IF NOT EXISTS idx_sub_coverage ON substitute_coverage(assignment_id,coverage_date,class_id)")

def hash_pw(password, salt=None):
    raw = salt or secrets.token_bytes(16)
    raw = base64.b64decode(raw) if isinstance(raw, str) else raw
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), raw, 200_000)
    return base64.b64encode(digest).decode(), base64.b64encode(raw).decode()


def verify(password, user):
    # Treat malformed legacy/corrupted credential material as an authentication
    # failure rather than letting base64/PBKDF parsing escape as HTTP 500.
    try:
        digest, _ = hash_pw(password, user["salt"])
        return hmac.compare_digest(digest, user["password_hash"])
    except (TypeError, ValueError, binascii.Error):
        return False


def safe_user(user):
    if not user:
        return None
    return {k: user.get(k) for k in ["id", "username", "role", "display_name", "student_id", "staff_id", "must_change_password"]}


def audit(user, action, module, record_id="", details=""):
    actor = "System" if not user else f"{user.get('display_name') or user.get('username','Unknown')} ({user.get('role','system')})"
    if not isinstance(details, str):
        details = json.dumps(details, default=str)
    run(
        "INSERT INTO audit_log(actor,action,module,record_id,details) VALUES(?,?,?,?,?)",
        (actor, action, module, str(record_id), details),
    )


def student_scope(user):
    if user["role"] in {"admin", "counselor", "nurse", "finance", "transportation", "food"}:
        return None
    if user["role"] == "student":
        return [user["student_id"]] if user.get("student_id") else []
    if user["role"] == "parent":
        ids = [x["student_id"] for x in rows("SELECT student_id FROM parent_students WHERE user_id=?", (user["id"],))]
        if user.get("student_id") and user["student_id"] not in ids:
            ids.append(user["student_id"])
        return ids
    if user["role"] == "teacher":
        if not user.get("staff_id"):
            return []
        return [
            x["student_id"]
            for x in rows(
                "SELECT DISTINCT e.student_id FROM enrollments e JOIN classes c ON c.id=e.class_id WHERE c.teacher_id=?",
                (user["staff_id"],),
            )
        ]
    return []


def class_scope(user):
    if user["role"] in {"admin", "counselor", "nurse", "finance", "transportation", "food"}:
        return None
    if user["role"] == "teacher":
        if not user.get("staff_id"):
            return []
        own=[int(x["id"]) for x in rows("SELECT id FROM classes WHERE teacher_id=?", (user["staff_id"],))]
        # A teacher acting as a substitute receives normal class/gradebook/attendance
        # scope only for the covered classes on the current school-local date.
        tzrec=one("SELECT setting_value FROM district_settings WHERE setting_key='school_timezone'")
        today=school_now((tzrec or {}).get("setting_value") or "America/Chicago")[0].strftime("%Y-%m-%d")
        covers=rows("SELECT * FROM substitute_assignments WHERE substitute_staff_id=? AND status='Active' AND ? BETWEEN start_date AND end_date",(user["staff_id"],today))
        for a in covers:
            selected=substitute_selected_class_ids(a)
            q=rows("SELECT id FROM classes WHERE teacher_id=?",(a["teacher_staff_id"],))
            for rec in q:
                cid=int(rec["id"])
                if selected is None or cid in selected:
                    own.append(cid)
        return list(dict.fromkeys(own))
    sids = student_scope(user) or []
    if not sids:
        return []
    placeholders = ",".join("?" * len(sids))
    return [x["class_id"] for x in rows(f"SELECT DISTINCT class_id FROM enrollments WHERE student_id IN ({placeholders})", sids)]


def allowed(value, scope):
    return scope is None or int(value) in {int(x) for x in scope}

def teacher_eligible_for_course(staff_id, course_id):
    if not staff_id or not course_id:
        return True
    rec=one("SELECT eligible_course_ids FROM staff WHERE id=?",(staff_id,))
    if not rec:
        return False
    try:
        ids={int(x) for x in json.loads(rec.get("eligible_course_ids") or "[]")}
    except Exception:
        ids=set()
    return int(course_id) in ids


def letter_grade(percent):
    if percent is None:
        return "—"
    if percent >= 90:
        return "A"
    if percent >= 80:
        return "B"
    if percent >= 70:
        return "C"
    if percent >= 60:
        return "D"
    return "F"


def parse_boolish(value, default=True):
    """Parse HTML/JSON boolean-ish values such as 0, "0", false, and "false" safely."""
    if value is None:
        return bool(default)
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    text=str(value).strip().lower()
    if text in {"0","false","no","off","exclude","excluded"}:
        return False
    if text in {"1","true","yes","on","include","included"}:
        return True
    return bool(default)

def normalize_grade_status(value):
    status = (value or "").strip().upper()
    return status if status in {"", "MISSING", "EXCUSED", "DROPPED"} else ""


def grading_letter(percent):
    if percent is None:
        return ''
    try:
        value=float(percent)
    except Exception:
        return ''
    default=[
        {"letter":"A+","min":97,"gpa":4.0},{"letter":"A","min":93,"gpa":4.0},{"letter":"A-","min":90,"gpa":3.7},
        {"letter":"B+","min":87,"gpa":3.3},{"letter":"B","min":83,"gpa":3.0},{"letter":"B-","min":80,"gpa":2.7},
        {"letter":"C+","min":77,"gpa":2.3},{"letter":"C","min":73,"gpa":2.0},{"letter":"C-","min":70,"gpa":1.7},
        {"letter":"D+","min":67,"gpa":1.3},{"letter":"D","min":63,"gpa":1.0},{"letter":"D-","min":60,"gpa":0.7},
        {"letter":"F","min":0,"gpa":0.0}
    ]
    rec=one("SELECT scale_json FROM district_grading_scale WHERE id=1")
    try:
        scale=json.loads(rec.get('scale_json') or '[]') if rec else default
        if not isinstance(scale,list) or not scale: scale=default
    except Exception:
        scale=default
    scale=sorted(scale,key=lambda x:float(x.get('min',0)),reverse=True)
    for item in scale:
        if value>=float(item.get('min',0)):
            return str(item.get('letter') or '')
    return str(scale[-1].get('letter') or 'F')

def normalize_attendance_status(value):
    status = (value or "").strip().upper()
    # Late and tardy are the same attendance concept in ScholarSync. Legacy late
    # records are preserved but surfaced as the matching tardy status everywhere.
    legacy = {"A": "AU", "E": "AE", "T": "TU", "L": "TU", "LE": "TE", "LU": "TU"}
    status = legacy.get(status, status)
    valid = {"P", "TE", "TU", "AE", "AU", "SA", "N"}
    return status if status in valid else ""


def school_rotation_for_date(date_string):
    """Return the configured rotation day for a school date, or None when classes do not meet."""
    special=one("SELECT * FROM school_calendar_days WHERE date=?",(date_string,))
    try: target=datetime.strptime(date_string,'%Y-%m-%d').date()
    except Exception: return None
    if special and str(special.get('day_type') or '').lower() in {'no school','holiday','closed','school closure'}: return None
    if target.weekday()>=5 and not special: return None
    if special and special.get('rotation_day'): return int(special['rotation_day'])
    rot=one("SELECT * FROM schedule_rotation_settings WHERE id=1") or {"day_a_date":"","rotation_count":2,"day_labels":"[]"}
    try: count=max(1,int(rot.get('rotation_count') or 2))
    except Exception: count=2
    anchor=rot.get('day_a_date') or rot.get('day_b_date') or ''
    if not anchor: return 1
    try: start=datetime.strptime(anchor,'%Y-%m-%d').date()
    except Exception: return 1
    if target<start: return 1
    idx=0; cur=start
    while cur<target:
        cur=cur.fromordinal(cur.toordinal()+1)
        if cur.weekday()>=5: continue
        rec=one("SELECT day_type FROM school_calendar_days WHERE date=?",(cur.isoformat(),))
        if rec and str(rec.get('day_type') or '').lower() in {'no school','holiday','closed','school closure'}: continue
        idx+=1
    return (idx%count)+1

def teacher_classes_for_date(staff_id,date_string):
    """Return only the classes a teacher actually teaches on a specific school-local date."""
    try:
        target=datetime.strptime(date_string,'%Y-%m-%d').date()
    except Exception:
        return []
    out=[]
    try:
        a,b=_ss_school_window(target)
    except Exception:
        a,b=date(target.year,1,1),date(target.year,12,31)
    special=one("SELECT * FROM school_calendar_days WHERE date=?",(date_string,))
    if a<=target<=b:
        custom=rows("SELECT * FROM special_schedule_periods WHERE calendar_day_id=? ORDER BY sort_order,start_time,id",(special['id'],)) if special and str(special.get('day_type') or '').lower()=='special schedule' else []
        if custom:
            for cp in custom:
                found=rows("""SELECT c.id,c.name,c.section,c.period,c.room,c.cycle_day,COALESCE(co.code,'') course_code,COALESCE(co.name,'') course_name,
                    ? start_time,? end_time,? special_schedule_label,? special_schedule_order,0 summer_school,
                    (SELECT COUNT(*) FROM enrollments e WHERE e.class_id=c.id AND COALESCE(e.status,'Active')='Active') enrolled
                    FROM classes c LEFT JOIN courses co ON co.id=c.course_id
                    WHERE c.teacher_id=? AND COALESCE(c.published,0)=1 AND COALESCE(c.cycle_day,1)=? AND c.period=?""",
                    (cp['start_time'],cp['end_time'],cp.get('custom_label') or cp['period_name'],cp['sort_order'],staff_id,cp['source_cycle_day'],cp['period_name']))
                out.extend(found)
        else:
            cycle=school_rotation_for_date(date_string)
            if cycle:
                out.extend(rows("""SELECT c.id,c.name,c.section,c.period,c.room,c.cycle_day,COALESCE(co.code,'') course_code,COALESCE(co.name,'') course_name,
                    COALESCE(sp.start_time,'') start_time,COALESCE(sp.end_time,'') end_time,COALESCE(sp.sort_order,999) special_schedule_order,0 summer_school,
                    (SELECT COUNT(*) FROM enrollments e WHERE e.class_id=c.id AND COALESCE(e.status,'Active')='Active') enrolled
                    FROM classes c LEFT JOIN courses co ON co.id=c.course_id
                    LEFT JOIN schedule_periods sp ON sp.cycle_day=c.cycle_day AND sp.name=c.period
                    WHERE c.teacher_id=? AND COALESCE(c.published,0)=1 AND COALESCE(c.cycle_day,1)=?
                    ORDER BY COALESCE(sp.sort_order,999),sp.start_time,c.period""",(staff_id,cycle)))
    # De-duplicate defensively and keep chronological order.
    seen=set(); clean=[]
    for c in out:
        key=(int(c.get('id') or 0),int(c.get('summer_school') or 0))
        if key in seen: continue
        seen.add(key); clean.append(c)
    clean.sort(key=lambda c:(str(c.get('start_time') or '99:99'),int(c.get('special_schedule_order') or 999),str(c.get('period') or ''),str(c.get('name') or '')))
    return clean


def substitute_selected_class_ids(assignment):
    if str((assignment or {}).get('coverage_mode') or 'all').lower() != 'selected':
        return None
    try:
        vals=json.loads((assignment or {}).get('selected_class_ids') or '[]')
        return {int(x) for x in vals if str(x).strip()}
    except Exception:
        return set()

def substitute_class_allowed(assignment,class_id):
    selected=substitute_selected_class_ids(assignment)
    return selected is None or int(class_id) in selected

def student_class_ids_for_date(student_id,date_string):
    special=one("SELECT * FROM school_calendar_days WHERE date=?",(date_string,))
    custom=rows("SELECT source_cycle_day,period_name FROM special_schedule_periods WHERE calendar_day_id=? ORDER BY sort_order",(special['id'],)) if special and str(special.get('day_type') or '').lower()=='special schedule' else []
    if custom:
        out=[]
        for cp in custom:
            out += [r['id'] for r in rows("""SELECT c.id FROM enrollments e JOIN classes c ON c.id=e.class_id WHERE e.student_id=? AND COALESCE(e.status,'Active')='Active' AND COALESCE(c.published,0)=1 AND COALESCE(c.cycle_day,1)=? AND c.period=?""",(student_id,cp['source_cycle_day'],cp['period_name']))]
        return list(dict.fromkeys(out))
    cycle=school_rotation_for_date(date_string)
    if not cycle: return []
    return [r['id'] for r in rows("""SELECT c.id FROM enrollments e JOIN classes c ON c.id=e.class_id
        WHERE e.student_id=? AND COALESCE(e.status,'Active')='Active' AND COALESCE(c.published,0)=1 AND COALESCE(c.cycle_day,1)=?""",(student_id,cycle))]

def apply_daily_absence(student_id,date_string,status,reason='',note='',source='Admin',request_id=None,created_by=None):
    status='AE' if str(status).upper()=='AE' else 'AU'
    run("""INSERT INTO daily_absences(student_id,absence_date,status,reason,note,source,request_id,created_by,updated_at)
        VALUES(?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(student_id,absence_date) DO UPDATE SET
        status=excluded.status,reason=excluded.reason,note=excluded.note,source=excluded.source,request_id=excluded.request_id,created_by=excluded.created_by,updated_at=CURRENT_TIMESTAMP""",
        (student_id,date_string,status,reason,note,source,request_id,created_by))
    class_ids=student_class_ids_for_date(student_id,date_string)
    for cid in class_ids:
        run("""INSERT INTO attendance(class_id,student_id,date,status,minutes_late,note,updated_at) VALUES(?,?,?,?,0,?,CURRENT_TIMESTAMP)
            ON CONFLICT(class_id,student_id,date) DO UPDATE SET status=excluded.status,minutes_late=0,note=excluded.note,updated_at=CURRENT_TIMESTAMP""",
            (cid,student_id,date_string,status,(note or reason or ('All-day '+('excused' if status=='AE' else 'unexcused')+' absence'))))
    return len(class_ids)


def calculate_class_grades(student_id, class_rows, assignment_rows):
    by_class = {c["id"]: {"earned": 0.0, "possible": 0.0, "missing": 0, "graded": 0} for c in class_rows}
    for assignment in assignment_rows:
        bucket = by_class.setdefault(assignment["class_id"], {"earned": 0.0, "possible": 0.0, "missing": 0, "graded": 0})
        if int(assignment.get("include_in_gradebook") if assignment.get("include_in_gradebook") is not None else 1)==0:
            continue
        status = normalize_grade_status(assignment.get("grade_status"))
        if status in {"EXCUSED", "DROPPED"}:
            continue
        points = float(assignment.get("points") or 0)
        weight = float(assignment.get("weight") or 1)
        if status == "MISSING":
            bucket["possible"] += points * weight
            bucket["missing"] += 1
            bucket["graded"] += 1
        elif assignment.get("score") is not None:
            bucket["earned"] += float(assignment["score"]) * weight
            bucket["possible"] += points * weight
            bucket["graded"] += 1
    for class_row in class_rows:
        bucket = by_class.get(class_row["id"], {})
        possible = bucket.get("possible", 0)
        average = round(bucket.get("earned", 0) / possible * 100, 1) if possible else None
        class_row["average"] = average
        class_row["letter"] = letter_grade(average)
        class_row["missing"] = bucket.get("missing", 0)
        class_row["graded_assignments"] = bucket.get("graded", 0)
    return class_rows


def get_gpa_settings():
    return one("SELECT * FROM gpa_settings WHERE id=1") or {
        "regular_multiplier": 1.0, "honors_multiplier": 1.05, "ap_multiplier": 1.08,
        "dual_credit_multiplier": 1.0, "gpa_divisor": 25.0
    }


def course_multiplier(course_row, settings=None):
    settings = settings or get_gpa_settings()
    explicit = course_row.get("gpa_multiplier")
    if explicit not in (None, ""):
        try:
            return float(explicit)
        except (TypeError, ValueError):
            pass
    level = str(course_row.get("course_level") or "Regular").strip().lower()
    key = {"honors":"honors_multiplier", "ap":"ap_multiplier", "advanced placement":"ap_multiplier",
           "dual credit":"dual_credit_multiplier", "dual-credit":"dual_credit_multiplier"}.get(level, "regular_multiplier")
    return float(settings.get(key) or 1.0)


def calculate_gpas(class_rows):
    settings = get_gpa_settings()
    divisor = float(settings.get("gpa_divisor") or 25.0)
    completed = [c for c in class_rows if c.get("average") is not None]
    if not completed:
        return {"unweighted_average": None, "weighted_average": None, "unweighted_gpa": None, "weighted_gpa": None, "course_count": 0}
    raw = [float(c["average"]) for c in completed]
    weighted = []
    for c in completed:
        mult = course_multiplier(c, settings)
        c["gpa_multiplier"] = mult
        c["weighted_average"] = round(float(c["average"]) * mult, 2)
        weighted.append(c["weighted_average"])
    ua = round(sum(raw) / len(raw), 2)
    wa = round(sum(weighted) / len(weighted), 2)
    return {
        "unweighted_average": ua, "weighted_average": wa,
        "unweighted_gpa": round(ua / divisor, 3), "weighted_gpa": round(wa / divisor, 3),
        "course_count": len(completed), "gpa_divisor": divisor
    }


def student_profile_data(student_id, user):
    student = one("SELECT *,first_name||' '||last_name name FROM students WHERE id=?", (student_id,))
    if not student:
        return None
    class_rows = rows(
        """
        SELECT c.*,COALESCE(sf.name,'Unassigned') teacher,COALESCE(co.code,'') course_code,
               COALESCE(co.credits,0) credits,COALESCE(co.course_level,'Regular') course_level,COALESCE(co.gpa_multiplier,1.0) gpa_multiplier
        FROM enrollments e
        JOIN classes c ON c.id=e.class_id
        LEFT JOIN staff sf ON sf.id=c.teacher_id
        LEFT JOIN courses co ON co.id=c.course_id
        WHERE e.student_id=? AND COALESCE(e.status,'Active')='Active' AND (?=0 OR COALESCE(c.published,0)=1)
        ORDER BY CASE WHEN c.period GLOB '[0-9]*' THEN CAST(c.period AS INTEGER) ELSE 999 END,c.period,c.name
        """,
        (student_id, 1 if user['role'] in {'student','parent'} else 0),
    )
    assignment_rows = rows(
        """
        SELECT a.id,a.class_id,a.title,a.category,a.points,a.weight,a.due_date,a.description,a.instructions,a.links_json,a.rubric_text,a.extra_credit,a.allow_late,a.visible,a.attachment_name,a.attachment_type,a.attachment_data,a.accept_submissions,a.allow_any_file,a.lock_after_due,
               c.name class_name,c.section,c.period,c.term,
               g.score,COALESCE(g.status,'') grade_status,COALESCE(g.comment,'') comment,
               COALESCE(g.updated_at,'') updated_at,COALESCE(sub.status,'') submission_status,COALESCE(sub.file_name,'') submission_file
        FROM assignments a
        JOIN classes c ON c.id=a.class_id
        JOIN enrollments e ON e.class_id=c.id AND e.student_id=?
        LEFT JOIN grades g ON g.assignment_id=a.id AND g.student_id=?
        LEFT JOIN assignment_submissions sub ON sub.assignment_id=a.id AND sub.student_id=e.student_id
        WHERE a.visible=1 AND (?=0 OR COALESCE(c.published,0)=1)
        ORDER BY COALESCE(a.due_date,''),a.id
        """,
        (student_id, student_id, 1 if user['role'] in {'student','parent'} else 0),
    )
    calculate_class_grades(student_id, class_rows, assignment_rows)
    attendance = rows(
        """
        SELECT at.date,at.status,at.minutes_late,at.note,at.class_id,c.name class_name,c.section,c.period
        FROM attendance at JOIN classes c ON c.id=at.class_id
        WHERE at.student_id=? ORDER BY at.date DESC,at.class_id
        """,
        (student_id,),
    )
    records = rows(
        """
        SELECT r.*,COALESCE(sf.name,'') staff_name
        FROM module_records r LEFT JOIN staff sf ON sf.id=r.staff_id
        WHERE r.student_id=? ORDER BY COALESCE(r.record_date,r.created_at) DESC,r.id DESC
        """,
        (student_id,),
    )
    if user["role"] == "teacher":
        records = [r for r in records if r["module"] not in {"health", "finance", "studentNotes"}]
    elif user["role"] in {"student", "parent"}:
        records = [r for r in records if r["module"] in {"registration", "transportation", "food", "finance"}]

    gpa_data = calculate_gpas(class_rows)
    current_average = gpa_data["unweighted_average"]

    present_codes = {"P", "LE", "LU", "TE", "TU", "SA", "N"}
    normalized_attendance = [normalize_attendance_status(x.get("status")) for x in attendance]
    total_attendance = len(normalized_attendance)
    present_count = sum(1 for x in normalized_attendance if x in present_codes)
    attendance_rate = round(present_count / total_attendance * 100, 1) if total_attendance else None
    credits = round(sum(float(c.get("credits") or 0) for c in class_rows), 2)

    activity = []
    for assignment in assignment_rows:
        status = normalize_grade_status(assignment.get("grade_status"))
        if assignment.get("score") is not None or status:
            value = status.title() if status else f"{assignment['score']}/{assignment['points']}"
            activity.append(
                {
                    "date": assignment.get("updated_at") or assignment.get("due_date") or "",
                    "type": "Grade",
                    "title": f"{assignment['title']} — {value}",
                    "detail": assignment["class_name"],
                }
            )
    attendance_labels = {
        "P": "Present",
        "LE": "Late — Excused",
        "LU": "Late — Unexcused",
        "TE": "Tardy — Excused",
        "TU": "Tardy — Unexcused",
        "AE": "Absent — Excused",
        "AU": "Absent — Unexcused",
        "SA": "School Activity",
        "N": "Nurse / Health Office",
    }
    for entry in attendance[:20]:
        code = normalize_attendance_status(entry.get("status"))
        activity.append(
            {
                "date": entry.get("date") or "",
                "type": "Attendance",
                "title": attendance_labels.get(code, code or "Unmarked"),
                "detail": entry["class_name"],
            }
        )
    for record in records[:20]:
        activity.append(
            {
                "date": record.get("record_date") or record.get("created_at") or "",
                "type": record["module"].title(),
                "title": record["title"],
                "detail": record.get("status", ""),
            }
        )
    activity = sorted(activity, key=lambda x: x.get("date") or "", reverse=True)[:25]

    final_grade_rows = rows("""
        SELECT fg.*,c.name class_name,c.section,c.term,COALESCE(sf.name,'Unassigned') teacher
        FROM finalized_grades fg JOIN classes c ON c.id=fg.class_id
        LEFT JOIN staff sf ON sf.id=c.teacher_id
        WHERE fg.student_id=? AND fg.status='Final'
        ORDER BY c.term,c.name,fg.grading_key
    """,(student_id,))
    for fg in final_grade_rows:
        try: fg["component_grades"] = json.loads(fg.get("component_grades_json") or "{}")
        except Exception: fg["component_grades"] = {}

    return {
        "student": student,
        "classes": class_rows,
        "report_card": class_rows,
        "assignments": assignment_rows,
        "attendance": attendance,
        "records": records,
        "activity": activity,
        "rotation": one("SELECT * FROM schedule_rotation_settings WHERE id=1") or {},
        "final_grades": final_grade_rows,
        "metrics": {
            "current_average": current_average,
            "gpa_estimate": gpa_data["unweighted_gpa"],
            "unweighted_gpa": gpa_data["unweighted_gpa"],
            "weighted_gpa": gpa_data["weighted_gpa"],
            "weighted_average": gpa_data["weighted_average"],
            "gpa_course_count": gpa_data["course_count"],
            "gpa_divisor": gpa_data.get("gpa_divisor", 25.0),
            "attendance_rate": attendance_rate,
            "credits": credits,
            "missing": sum(c.get("missing", 0) for c in class_rows),
        },
    }



def academic_snapshot(student_id):
    """Build one student's academic planning snapshot without N+1 assignment queries."""
    student=one("SELECT *,first_name||' '||last_name name FROM students WHERE id=?",(student_id,))
    if not student: return None
    classes=rows("""SELECT cl.id,cl.name,cl.section,cl.term,cl.period,co.code course_code,co.name course_name,
        COALESCE(co.department,'Other') subject_area,COALESCE(co.credits,0) credits
        FROM enrollments e JOIN classes cl ON cl.id=e.class_id LEFT JOIN courses co ON co.id=cl.course_id
        WHERE e.student_id=? AND COALESCE(e.status,'Active')='Active' ORDER BY cl.term,cl.name""",(student_id,))
    class_ids=[int(c['id']) for c in classes]
    grades_by_class={cid:[] for cid in class_ids}
    if class_ids:
        ph=','.join('?'*len(class_ids))
        all_grades=rows(f"""SELECT a.class_id,g.score,g.status,a.points,a.extra_credit
            FROM assignments a LEFT JOIN grades g ON g.assignment_id=a.id AND g.student_id=?
            WHERE a.class_id IN ({ph}) AND COALESCE(a.visible,1)=1""", tuple([student_id]+class_ids))
        for g in all_grades: grades_by_class.setdefault(int(g['class_id']),[]).append(g)
    total_points=total_possible=0.0
    class_results=[]; earned_by={}
    for c in classes:
        pts=poss=0.0
        for g in grades_by_class.get(int(c['id']),[]):
            st=(g.get('status') or '').upper()
            if st in {'EXCUSED','DROPPED'}: continue
            if g.get('score') is not None: pts+=float(g['score'])
            if not g.get('extra_credit'): poss+=float(g.get('points') or 0)
        pct=round(pts/poss*100,2) if poss>0 else None
        letter=grading_letter(pct) if pct is not None else '—'
        quality=None if pct is None else (4 if pct>=90 else 3 if pct>=80 else 2 if pct>=70 else 1 if pct>=60 else 0)
        credits=float(c.get('credits') or 0); earned=credits if pct is not None and pct>=60 else 0
        if earned: earned_by[c['subject_area']]=earned_by.get(c['subject_area'],0)+earned
        if quality is not None and credits>0: total_points+=quality*credits; total_possible+=credits
        class_results.append({**c,'percent':pct,'letter':letter,'credits_earned':earned})
    reqs=rows("SELECT * FROM graduation_requirements WHERE active=1 ORDER BY sort_order,name")
    audit=[]
    for r in reqs:
        area=r['subject_area']; earned=earned_by.get(area,0)
        if area=='Electives': earned=sum(v for k,v in earned_by.items() if k not in {'English','Math','Science','Social Studies','PE'})
        if area=='Additional': earned=sum(earned_by.values())
        need=float(r['credits_required'] or 0)
        audit.append({**r,'credits_earned':round(earned,2),'remaining':round(max(0,need-earned),2),'complete':earned>=need})
    gpa=round(total_points/total_possible,3) if total_possible else None
    total_required=sum(float(r['credits_required'] or 0) for r in reqs)
    total_earned=sum(float(x['credits_earned']) for x in audit if x['subject_area']!='Additional')
    progress=round(min(100,total_earned/total_required*100),1) if total_required else 0
    plans=rows("""SELECT p.*,COALESCE(c.code,'') course_code FROM academic_plan_items p LEFT JOIN courses c ON c.id=p.course_id
                 WHERE p.student_id=? ORDER BY p.grade_level,p.course_name""",(student_id,))
    readiness=rows("SELECT * FROM college_readiness_items WHERE student_id=? ORDER BY due_date,category,item",(student_id,))
    return {'student':student,'classes':class_results,'requirements':audit,'gpa':gpa,'credits_earned':round(sum(x['credits_earned'] for x in class_results),2),'progress':progress,'on_track':all(x['complete'] for x in audit),'plans':plans,'readiness':readiness}



def backup_dir():
    path=os.path.join(os.path.dirname(DB),'backups')
    os.makedirs(path,exist_ok=True)
    return path

def create_database_backup(label='Manual', actor='System'):
    if not os.path.exists(DB):
        raise FileNotFoundError('ScholarSync database does not exist yet')
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
    safe=''.join(ch for ch in str(label) if ch.isalnum() or ch in ('-','_'))[:40] or 'Backup'
    name=f'scholarsync_{stamp}_{safe}.db'
    target=os.path.join(backup_dir(),name)
    src=sqlite3.connect(DB); dst=sqlite3.connect(target)
    try: src.backup(dst)
    finally: dst.close(); src.close()
    audit({'username':actor,'role':'admin'},'Created database backup','Enterprise',name,{'label':label})
    return {'name':name,'size':os.path.getsize(target),'created_at':datetime.fromtimestamp(os.path.getmtime(target)).isoformat(timespec='seconds')}

def list_database_backups():
    out=[]
    for name in sorted(os.listdir(backup_dir()),reverse=True):
        path=os.path.join(backup_dir(),name)
        if os.path.isfile(path) and name.lower().endswith('.db'):
            out.append({'name':name,'size':os.path.getsize(path),'created_at':datetime.fromtimestamp(os.path.getmtime(path)).isoformat(timespec='seconds')})
    return out

def data_quality_snapshot():
    checks=[]
    def add(key,label,count,severity,detail): checks.append({'key':key,'label':label,'count':int(count or 0),'severity':severity,'detail':detail})
    add('duplicate_emails','Duplicate student emails',one("SELECT COUNT(*) n FROM (SELECT lower(email) e FROM students WHERE trim(COALESCE(email,''))<>'' GROUP BY lower(email) HAVING COUNT(*)>1)")['n'],'warning','Students sharing the same email address.')
    add('missing_birth_date','Missing birth dates',one("SELECT COUNT(*) n FROM students WHERE COALESCE(status,'Active')='Active' AND trim(COALESCE(birth_date,''))=''")['n'],'warning','Active students without a birth date.')
    add('missing_guardian','Students without linked parent',one("SELECT COUNT(*) n FROM students s WHERE COALESCE(s.status,'Active')='Active' AND NOT EXISTS(SELECT 1 FROM parent_students ps WHERE ps.student_id=s.id)")['n'],'info','Active students without a parent portal link.')
    add('unlinked_users','Unlinked portal accounts',one("SELECT COUNT(*) n FROM users WHERE role IN ('student','teacher','counselor','nurse') AND student_id IS NULL AND staff_id IS NULL")['n'],'warning','Portal users that are not linked to a student or staff record.')
    add('classes_no_teacher','Sections without teachers',one("SELECT COUNT(*) n FROM classes WHERE teacher_id IS NULL")['n'],'error','Class sections missing a teacher assignment.')
    add('classes_no_room','Sections without rooms',one("SELECT COUNT(*) n FROM classes WHERE trim(COALESCE(room,''))=''")['n'],'warning','Class sections missing a room.')
    add('invalid_grade','Invalid or missing grades',one("SELECT COUNT(*) n FROM students WHERE trim(COALESCE(grade,''))='' OR CAST(grade AS INTEGER) NOT BETWEEN 1 AND 12")['n'],'warning','Student grade values outside 1–12 or blank.')
    add('orphan_enrollments','Broken enrollment links',one("SELECT COUNT(*) n FROM enrollments e LEFT JOIN students s ON s.id=e.student_id LEFT JOIN classes c ON c.id=e.class_id WHERE s.id IS NULL OR c.id IS NULL")['n'],'error','Enrollment records pointing to missing records.')
    return checks

def report_sources():
    return {
      'students': {'label':'Students','columns':['student_number','first_name','last_name','grade','birth_date','gender','email','homeroom','status'], 'sql':'SELECT student_number,first_name,last_name,grade,birth_date,gender,email,homeroom,status FROM students'},
      'staff': {'label':'Staff','columns':['employee_number','name','role','email','phone','school','status'], 'sql':'SELECT employee_number,name,role,email,phone,school,status FROM staff'},
      'courses': {'label':'Courses','columns':['code','name','department','credits','grade_levels'], 'sql':'SELECT code,name,department,credits,grade_levels FROM courses'},
      'classes': {'label':'Classes','columns':['course_code','class_name','section','period','cycle_day','room','teacher','term','capacity','published'], 'sql':"SELECT COALESCE(co.code,'') course_code,cl.name class_name,cl.section,cl.period,COALESCE(cl.cycle_day,1) cycle_day,cl.room,COALESCE(st.name,'') teacher,cl.term,cl.capacity,cl.published FROM classes cl LEFT JOIN courses co ON co.id=cl.course_id LEFT JOIN staff st ON st.id=cl.teacher_id"},
      'attendance': {'label':'Attendance','columns':['student_number','student_name','class_name','date','status','minutes_late','note'], 'sql':"SELECT s.student_number,s.first_name||' '||s.last_name student_name,c.name class_name,a.date,a.status,a.minutes_late,a.note FROM attendance a JOIN students s ON s.id=a.student_id JOIN classes c ON c.id=a.class_id"},
      'course_requests': {'label':'Course Requests','columns':['student_number','student_name','course_code','course_name','approval_status','scheduling_status','priority'], 'sql':"SELECT s.student_number,s.first_name||' '||s.last_name student_name,c.code course_code,c.name course_name,COALESCE(cr.approval_status,cr.status) approval_status,COALESCE(cr.scheduling_status,'') scheduling_status,cr.priority FROM course_requests cr JOIN students s ON s.id=cr.student_id JOIN courses c ON c.id=cr.course_id"}
    }

class Handler(SimpleHTTPRequestHandler):
    server_version = "ScholarSync/2026.7"

    def translate_path(self, path):
        route = unquote(urlparse(path).path)
        if route == "/":
            route = "/index.html"
        clean = os.path.normpath(route.lstrip("/"))
        if clean.startswith(".."):
            clean = "index.html"
        return os.path.join(STATIC, clean)

    def log_message(self, fmt, *args):
        print(fmt % args)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "SAMEORIGIN")
        self.send_header("Referrer-Policy", "same-origin")
        super().end_headers()

    def send_json(self, obj, status=200, headers=None):
        body = json.dumps(obj, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def read_body(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
            return json.loads(self.rfile.read(length) or b"{}")
        except Exception:
            return {}

    def session_token(self):
        jar = cookies.SimpleCookie()
        jar.load(self.headers.get("Cookie", ""))
        morsel = jar.get(COOKIE_NAME)
        return morsel.value if morsel else None

    def current_user(self):
        token = self.session_token()
        if not token:
            return None
        user = one(
            "SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires_at>? AND u.active=1",
            (token, int(time.time())),
        )
        if user and PORTAL_LOCK and user["role"] != PORTAL_LOCK:
            return None
        return user

    def require_user(self, roles=None):
        user = self.current_user()
        if not user:
            self.send_json({"error": "Authentication required"}, 401)
            return None
        if roles and user["role"] not in roles:
            self.send_json({"error": "Permission denied"}, 403)
            return None
        return user

    def login_success(self, user_id):
        token = secrets.token_urlsafe(32)
        expires = int(time.time()) + 28_800
        run("INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,?)", (token, user_id, expires))
        user = one("SELECT * FROM users WHERE id=?", (user_id,))
        cookie = f"{COOKIE_NAME}={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=28800" + ("; Secure" if PRODUCTION or self.headers.get("X-Forwarded-Proto", "").lower()=="https" else "")
        self.send_json({"ok": 1, "user": safe_user(user), "portal": PORTAL_LOCK}, headers={"Set-Cookie": cookie})

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        if path == "/api/health":
            return self.send_json({"ok": 1, "service": "ScholarSync", "build": 282, "portal": PORTAL_LOCK, "port": PORT, "production": PRODUCTION})
        if path == "/api/auth/status":
            user = self.current_user()
            count = one("SELECT COUNT(*) n FROM users")["n"]
            return self.send_json(
                {
                    "authenticated": bool(user),
                    "bootstrap_required": count == 0,
                    "bootstrap_allowed": PORTAL_LOCK in {"", "admin"},
                    "portal": PORTAL_LOCK,
                    "port": PORT,
                    "user": safe_user(user),
                }
            )
        if not path.startswith("/api/"):
            return super().do_GET()

        user = self.require_user()
        if not user:
            return
        sids = student_scope(user)
        cids = class_scope(user)
        role = user["role"]

        try:
            if path == "/api/summary":
                def scoped_count(table, key, scope):
                    if scope is None:
                        return one(f"SELECT COUNT(*) n FROM {table}")["n"]
                    if not scope:
                        return 0
                    ph = ",".join("?" * len(scope))
                    return one(f"SELECT COUNT(*) n FROM {table} WHERE {key} IN ({ph})", scope)["n"]

                if cids is None:
                    assignment_count = one("SELECT COUNT(*) n FROM assignments")["n"]
                    attendance_today = one("SELECT COUNT(*) n FROM attendance WHERE date=date('now')")["n"]
                elif cids:
                    ph = ",".join("?" * len(cids))
                    assignment_count = one(f"SELECT COUNT(*) n FROM assignments WHERE class_id IN ({ph})", cids)["n"]
                    attendance_today = one(f"SELECT COUNT(*) n FROM attendance WHERE date=date('now') AND class_id IN ({ph})", cids)["n"]
                else:
                    assignment_count = 0
                    attendance_today = 0
                return self.send_json(
                    {
                        "students": scoped_count("students", "id", sids),
                        "staff": one("SELECT COUNT(*) n FROM staff")["n"] if role == "admin" else (1 if user.get("staff_id") else 0),
                        "courses": one("SELECT COUNT(*) n FROM courses")["n"],
                        "classes": scoped_count("classes", "id", cids),
                        "assignments": assignment_count,
                        "messages": one("SELECT COUNT(*) n FROM messages")["n"],
                        "module_records": one("SELECT COUNT(*) n FROM module_records")["n"] if role == "admin" else 0,
                        "attendance_today": attendance_today,
                    }
                )

            if path == "/api/academic-planning":
                sid=int(query.get("student_id",["0"])[0] or 0)
                if role in {"student"}: sid=int(user.get("student_id") or 0)
                if role=="parent" and sid not in (sids or []): return self.send_json({"error":"Permission denied"},403)
                if role not in {"admin","counselor","student","parent"}: return self.send_json({"error":"Permission denied"},403)
                if role in {"admin","counselor"} and not sid:
                    # Fast district counselor dashboard. The old code called academic_snapshot()
                    # once per student (hundreds of queries for a 500-student test roster).
                    # This performs the same dashboard summary in one grouped grade query.
                    reqs=rows("SELECT * FROM graduation_requirements WHERE active=1 ORDER BY sort_order,name")
                    students=rows("SELECT id,first_name||' '||last_name name,student_number,grade FROM students WHERE status='Active' ORDER BY last_name,first_name")
                    summary_rows=rows("""
                        SELECT e.student_id,cl.id class_id,COALESCE(co.department,'Other') subject_area,COALESCE(co.credits,0) credits,
                               SUM(CASE WHEN UPPER(COALESCE(g.status,'')) NOT IN ('EXCUSED','DROPPED') AND g.score IS NOT NULL THEN g.score ELSE 0 END) earned_points,
                               SUM(CASE WHEN UPPER(COALESCE(g.status,'')) NOT IN ('EXCUSED','DROPPED') AND COALESCE(a.extra_credit,0)=0 THEN COALESCE(a.points,0) ELSE 0 END) possible_points
                        FROM enrollments e
                        JOIN students st ON st.id=e.student_id AND COALESCE(st.status,'Active')='Active'
                        JOIN classes cl ON cl.id=e.class_id
                        LEFT JOIN courses co ON co.id=cl.course_id
                        LEFT JOIN assignments a ON a.class_id=cl.id AND COALESCE(a.visible,1)=1
                        LEFT JOIN grades g ON g.assignment_id=a.id AND g.student_id=e.student_id
                        WHERE COALESCE(e.status,'Active')='Active'
                        GROUP BY e.student_id,cl.id
                    """)
                    by_student={}
                    for r in summary_rows:
                        sid2=int(r['student_id']); b=by_student.setdefault(sid2,{'quality':0.0,'gpa_credits':0.0,'earned':{},'credits':0.0})
                        poss=float(r.get('possible_points') or 0); pts=float(r.get('earned_points') or 0); cr=float(r.get('credits') or 0)
                        if poss<=0: continue
                        pct=pts/poss*100.0
                        quality=4 if pct>=90 else 3 if pct>=80 else 2 if pct>=70 else 1 if pct>=60 else 0
                        if cr>0: b['quality']+=quality*cr; b['gpa_credits']+=cr
                        if pct>=60 and cr>0:
                            area=r.get('subject_area') or 'Other'; b['earned'][area]=b['earned'].get(area,0.0)+cr; b['credits']+=cr
                    total_required=sum(float(r.get('credits_required') or 0) for r in reqs if r.get('subject_area')!='Additional')
                    data=[]
                    for st in students:
                        b=by_student.get(int(st['id']),{'quality':0.0,'gpa_credits':0.0,'earned':{},'credits':0.0})
                        gpa=round(b['quality']/b['gpa_credits'],3) if b['gpa_credits'] else None
                        completed=0; required_count=0
                        for rq in reqs:
                            area=rq.get('subject_area'); need=float(rq.get('credits_required') or 0)
                            if area=='Additional': continue
                            required_count+=1
                            if area=='Electives': earned=sum(v for k,v in b['earned'].items() if k not in {'English','Math','Science','Social Studies','PE'})
                            else: earned=b['earned'].get(area,0.0)
                            if earned>=need: completed+=1
                        progress=round(min(100,b['credits']/total_required*100),1) if total_required else 0
                        data.append({**st,'gpa':gpa,'credits_earned':round(b['credits'],2),'progress':progress,'on_track':bool(required_count and completed==required_count)})
                    return self.send_json({'students':data,'requirements':reqs})
                snap=academic_snapshot(sid)
                if not snap:return self.send_json({"error":"Student not found"},404)
                return self.send_json(snap)

            if path == "/api/graduation-requirements":
                return self.send_json(rows("SELECT * FROM graduation_requirements ORDER BY sort_order,name"))

            if path == "/api/students":
                sql = "SELECT *,first_name||' '||last_name name FROM students"
                args = []
                if sids is not None:
                    if not sids:
                        return self.send_json([])
                    ph = ",".join("?" * len(sids))
                    sql += f" WHERE id IN ({ph})"
                    args = sids
                return self.send_json(rows(sql + " ORDER BY last_name,first_name", args))

            if path == "/api/staff":
                if role == "admin":
                    return self.send_json(rows("SELECT * FROM staff ORDER BY name"))
                if user.get("staff_id"):
                    return self.send_json(rows("SELECT * FROM staff WHERE id=?", (user["staff_id"],)))
                return self.send_json([])

            if path == "/api/gpa-settings":
                if role not in {"admin","teacher","counselor"}:
                    return self.send_json({"error":"Permission denied"},403)
                return self.send_json(get_gpa_settings())

            if path == "/api/courses":
                return self.send_json(rows("SELECT * FROM courses ORDER BY code,name"))

            if path == "/api/classes":
                sql = """
                    SELECT c.*,COALESCE(s.name,'Unassigned') teacher,COALESCE(co.code,'') course_code,
                           (SELECT COUNT(*) FROM enrollments e WHERE e.class_id=c.id AND COALESCE(e.status,'Active')='Active') enrolled
                    FROM classes c LEFT JOIN staff s ON s.id=c.teacher_id LEFT JOIN courses co ON co.id=c.course_id
                """
                args = []
                if cids is not None:
                    if not cids:
                        return self.send_json([])
                    ph = ",".join("?" * len(cids))
                    sql += f" WHERE c.id IN ({ph})"
                    args = cids
                return self.send_json(rows(sql + " ORDER BY c.term,c.period,c.name,c.section", args))

            if path == "/api/roster":
                class_id = int(query.get("class_id", ["0"])[0])
                if not allowed(class_id, cids):
                    return self.send_json({"error": "Permission denied"}, 403)
                sql = """
                    SELECT s.*,s.first_name||' '||s.last_name name
                    FROM students s JOIN enrollments e ON e.student_id=s.id
                    WHERE e.class_id=? AND COALESCE(e.status,'Active')='Active'
                """
                args = [class_id]
                if role in {"student", "parent"}:
                    if not sids:
                        return self.send_json([])
                    ph = ",".join("?" * len(sids))
                    sql += f" AND s.id IN ({ph})"
                    args += sids
                return self.send_json(rows(sql + " ORDER BY s.last_name,s.first_name", args))

            if path == "/api/grading-config":
                class_id=int(query.get("class_id",["0"])[0])
                if not allowed(class_id,cids): return self.send_json({"error":"Permission denied"},403)
                cfg=one("SELECT * FROM class_grading_config WHERE class_id=?",(class_id,))
                if not cfg:
                    cfg={"class_id":class_id,"mode":"separate_semesters","config_json":json.dumps({"semesters":[{"key":"s1","name":"Semester 1","weight":50,"components":[{"key":"q1","name":"Quarter 1","weight":40},{"key":"q2","name":"Quarter 2","weight":40},{"key":"final_exam","name":"Final Exam","weight":20}]},{"key":"s2","name":"Semester 2","weight":50,"components":[{"key":"q3","name":"Quarter 3","weight":40},{"key":"q4","name":"Quarter 4","weight":40},{"key":"final_exam","name":"Final Exam","weight":20}]}]})}
                try: cfg["config"]=json.loads(cfg.get("config_json") or "{}")
                except Exception: cfg["config"]={}
                return self.send_json(cfg)

            if path == "/api/grading-scale":
                rec=one("SELECT * FROM district_grading_scale WHERE id=1")
                if not rec:
                    rec={"id":1,"name":"A-F with +/-","mode":"plus_minus","scale_json":json.dumps([
                        {"letter":"A+","min":97,"gpa":4.0},{"letter":"A","min":93,"gpa":4.0},{"letter":"A-","min":90,"gpa":3.7},
                        {"letter":"B+","min":87,"gpa":3.3},{"letter":"B","min":83,"gpa":3.0},{"letter":"B-","min":80,"gpa":2.7},
                        {"letter":"C+","min":77,"gpa":2.3},{"letter":"C","min":73,"gpa":2.0},{"letter":"C-","min":70,"gpa":1.7},
                        {"letter":"D+","min":67,"gpa":1.3},{"letter":"D","min":63,"gpa":1.0},{"letter":"D-","min":60,"gpa":0.7},
                        {"letter":"F","min":0,"gpa":0.0}])}
                try: rec["scale"]=json.loads(rec.get("scale_json") or "[]")
                except Exception: rec["scale"]=[]
                return self.send_json(rec)

            if path == "/api/seating-chart":
                class_id=int(query.get("class_id",["0"])[0])
                if role not in {"admin","teacher"} or not allowed(class_id,cids): return self.send_json({"error":"Permission denied"},403)
                chart=one("SELECT * FROM seating_charts WHERE class_id=?",(class_id,)) or {"class_id":class_id,"rows_count":5,"columns_count":6,"layout_json":"[]"}
                try: chart["layout"]=json.loads(chart.get("layout_json") or "[]")
                except Exception: chart["layout"]=[]
                return self.send_json(chart)

            if path == "/api/final-grades":
                class_id=int(query.get("class_id",["0"])[0])
                if role not in {"admin","teacher","counselor","student","parent"}:
                    return self.send_json({"error":"Permission denied"},403)
                if not allowed(class_id,cids): return self.send_json({"error":"Permission denied"},403)
                sql="SELECT fg.*,s.first_name||' '||s.last_name student_name,s.student_number,u.display_name finalized_by_name FROM finalized_grades fg JOIN students s ON s.id=fg.student_id LEFT JOIN users u ON u.id=fg.finalized_by WHERE fg.class_id=?"
                args=[class_id]
                if role in {"student","parent"}:
                    if not sids: return self.send_json([])
                    ph=",".join("?"*len(sids)); sql+=f" AND fg.student_id IN ({ph})"; args+=sids
                out=rows(sql+" ORDER BY s.last_name,s.first_name,fg.grading_key",args)
                for x in out:
                    try:x["component_grades"]=json.loads(x.get("component_grades_json") or "{}")
                    except Exception:x["component_grades"]={}
                return self.send_json(out)


            if path == "/api/assignments":
                if role not in {"admin", "teacher", "counselor", "student", "parent"}:
                    return self.send_json({"error": "Permission denied"}, 403)
                class_id = int(query.get("class_id", ["0"])[0])
                if not allowed(class_id, cids):
                    return self.send_json({"error": "Permission denied"}, 403)
                # Students and parents must never receive draft/hidden assignments.
                # Staff retain the complete assignment list for authoring and grading.
                visibility = " AND COALESCE(a.visible,1)=1" if role in {"student", "parent"} else ""
                return self.send_json(
                    rows(
                        f"""
                        SELECT a.*,(SELECT COUNT(*) FROM grades g WHERE g.assignment_id=a.id) grade_count,(SELECT COUNT(*) FROM assignment_submissions s WHERE s.assignment_id=a.id) submission_count
                        FROM assignments a WHERE a.class_id=?{visibility} ORDER BY COALESCE(a.due_date,''),a.id
                        """,
                        (class_id,),
                    )
                )

            if path == "/api/gradebook-settings":
                if role not in {"admin", "teacher", "counselor", "student", "parent"}:
                    return self.send_json({"error": "Permission denied"}, 403)
                class_id = int(query.get("class_id", ["0"])[0])
                if not allowed(class_id, cids):
                    return self.send_json({"error": "Permission denied"}, 403)
                setting = one("SELECT * FROM gradebook_settings WHERE class_id=?", (class_id,)) or {"class_id":class_id,"category_weights":"{}","drop_lowest":0}
                try: setting["category_weights"] = json.loads(setting.get("category_weights") or "{}")
                except Exception: setting["category_weights"] = {}
                return self.send_json(setting)

            if path == "/api/missing-work":
                # This endpoint is a whole-class intervention list. It must not be
                # exposed to a student/parent merely because they belong to the class.
                if role not in {"admin", "teacher", "counselor"}:
                    return self.send_json({"error":"Permission denied"},403)
                class_id = int(query.get("class_id", ["0"])[0])
                if not allowed(class_id, cids): return self.send_json({"error":"Permission denied"},403)
                return self.send_json(rows("""
                    SELECT s.id student_id,s.first_name||' '||s.last_name student_name,s.student_number,
                           a.id assignment_id,a.title,a.due_date,a.points,COALESCE(g.status,'') status,
                           COALESCE(sub.status,'') submission_status
                    FROM enrollments e JOIN students s ON s.id=e.student_id
                    JOIN assignments a ON a.class_id=e.class_id AND COALESCE(a.visible,1)=1
                    LEFT JOIN grades g ON g.assignment_id=a.id AND g.student_id=s.id
                    LEFT JOIN assignment_submissions sub ON sub.assignment_id=a.id AND sub.student_id=s.id
                    WHERE e.class_id=? AND COALESCE(e.status,'Active')='Active'
                      AND (UPPER(COALESCE(g.status,''))='MISSING' OR (g.score IS NULL AND COALESCE(sub.status,'')=''))
                    ORDER BY s.last_name,s.first_name,COALESCE(a.due_date,''),a.title
                """,(class_id,)))

            if path == "/api/grade-history":
                assignment_id=int(query.get("assignment_id",["0"])[0]); student_id=int(query.get("student_id",["0"])[0])
                a=one("SELECT class_id FROM assignments WHERE id=?",(assignment_id,))
                if not a or not allowed(a["class_id"],cids): return self.send_json({"error":"Permission denied"},403)
                if role in {"student","parent"} and (not student_id or not allowed(student_id,sids)):
                    return self.send_json({"error":"Permission denied"},403)
                if role not in {"admin","teacher","counselor","student","parent"}:
                    return self.send_json({"error":"Permission denied"},403)
                return self.send_json(rows("SELECT gh.*,u.display_name changed_by_name FROM grade_history gh LEFT JOIN users u ON u.id=gh.changed_by WHERE gh.assignment_id=? AND gh.student_id=? ORDER BY gh.changed_at DESC,gh.id DESC",(assignment_id,student_id)))

            if path == "/api/grades":
                if role not in {"admin", "teacher", "counselor", "student", "parent"}:
                    return self.send_json({"error": "Permission denied"}, 403)
                class_id = int(query.get("class_id", ["0"])[0])
                if not allowed(class_id, cids):
                    return self.send_json({"error": "Permission denied"}, 403)
                sql = "SELECT g.* FROM grades g JOIN assignments a ON a.id=g.assignment_id WHERE a.class_id=?"
                args = [class_id]
                if role in {"student", "parent"}:
                    if not sids:
                        return self.send_json([])
                    ph = ",".join("?" * len(sids))
                    sql += f" AND g.student_id IN ({ph})"
                    args += sids
                return self.send_json(rows(sql, args))

            if path == "/api/attendance":
                # The roster attendance endpoint is staff-only. Students/parents read
                # their own attendance through /api/student-profile instead. This
                # prevents the teacher Attendance Center from being usable even if
                # a student manually calls the endpoint.
                if role not in {"admin", "teacher"}:
                    return self.send_json({"error": "Permission denied"}, 403)
                class_id = int(query.get("class_id", ["0"])[0])
                if not allowed(class_id, cids):
                    return self.send_json({"error": "Permission denied"}, 403)
                date = query.get("date", [""])[0]
                return self.send_json(rows("""SELECT a.*,da.status all_day_status,da.reason all_day_reason,da.note all_day_note,da.source all_day_source
                    FROM attendance a LEFT JOIN daily_absences da ON da.student_id=a.student_id AND da.absence_date=a.date
                    WHERE a.class_id=? AND a.date=?""", (class_id, date)))

            if path == "/api/student-profile" or path == "/api/report-card":
                student_id = int(query.get("id", ["0"])[0])
                if not student_id or not allowed(student_id, sids):
                    return self.send_json({"error": "Permission denied"}, 403)
                data = student_profile_data(student_id, user)
                if not data:
                    return self.send_json({"error": "Student not found"}, 404)
                return self.send_json(data if path == "/api/student-profile" else {"student": data["student"], "classes": data["report_card"], "metrics": data["metrics"]})


            if path == "/api/substitute/staff":
                if role != "admin":
                    return self.send_json({"error":"Permission denied"},403)
                return self.send_json(rows("SELECT id,employee_number,name,role,email,phone,school,status FROM staff WHERE (lower(COALESCE(role,'')) IN ('substitute','sub','substitute teacher') OR lower(COALESCE(role,'')) LIKE '%teacher%') AND COALESCE(status,'Active')='Active' ORDER BY name"))

            if path == "/api/substitute/teacher-day":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                teacher_id=int(query.get("teacher_staff_id",["0"])[0] or 0)
                day=(query.get("date",[""])[0] or '').strip()
                if not teacher_id or not day: return self.send_json({"error":"Teacher and date are required"},400)
                if not one("SELECT id FROM staff WHERE id=? AND COALESCE(status,'Active')='Active'",(teacher_id,)):
                    return self.send_json({"error":"Teacher not found"},404)
                return self.send_json({"date":day,"classes":teacher_classes_for_date(teacher_id,day)})


            if path == "/api/substitute/availability":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                sub=int(query.get("substitute_staff_id",["0"])[0] or 0); teacher=int(query.get("teacher_staff_id",["0"])[0] or 0)
                day=(query.get("date",[""])[0] or '').strip(); mode=(query.get("coverage_mode",["all"])[0] or 'all').strip().lower()
                raw=(query.get("class_ids",[""])[0] or '').strip(); selected={int(x) for x in raw.split(',') if x.strip().isdigit()}
                if not sub or not teacher or not day:return self.send_json({"available":False,"reason":"Choose a covering staff member, teacher, and date."})
                if sub==teacher:return self.send_json({"available":False,"reason":"A teacher cannot cover their own absence."})
                sf=one("SELECT id,role,name FROM staff WHERE id=? AND COALESCE(status,'Active')='Active'",(sub,))
                if not sf:return self.send_json({"available":False,"reason":"Covering staff member is not active."})
                covered=teacher_classes_for_date(teacher,day)
                if mode=='selected':covered=[x for x in covered if int(x.get('id') or 0) in selected]
                if 'teacher' not in str(sf.get('role') or '').lower():return self.send_json({"available":True})
                own=teacher_classes_for_date(sub,day)
                for oc in own:
                    for cc in covered:
                        os=str(oc.get('start_time') or ''); oe=str(oc.get('end_time') or '')
                        cs=str(cc.get('start_time') or ''); ce=str(cc.get('end_time') or '')
                        clash=bool(os and oe and cs and ce and os < ce and cs < oe)
                        if not (os and oe and cs and ce):clash=clash or (str(oc.get('period') or '') and str(oc.get('period') or '')==str(cc.get('period') or ''))
                        if clash:return self.send_json({"available":False,"reason":f"{sf.get('name') or 'This teacher'} is teaching {oc.get('name') or 'another class'} during that coverage period."})
                return self.send_json({"available":True})

            if path == "/api/substitute/assignments":
                if role not in {"admin","teacher","substitute"}:
                    return self.send_json({"error":"Permission denied"},403)
                qid=int(query.get("id",["0"])[0] or 0)
                sql="""SELECT sa.*,sub.name substitute_name,t.name teacher_name
                         FROM substitute_assignments sa JOIN staff sub ON sub.id=sa.substitute_staff_id JOIN staff t ON t.id=sa.teacher_staff_id WHERE 1=1"""
                args=[]
                if qid: sql+=" AND sa.id=?";args.append(qid)
                if role=="teacher":
                    sql+=" AND (sa.teacher_staff_id=? OR sa.substitute_staff_id=?)"
                    sid=int(user.get("staff_id") or 0); args.extend([sid,sid])
                elif role=="substitute": sql+=" AND sa.substitute_staff_id=?";args.append(int(user.get("staff_id") or 0))
                sql+=" ORDER BY sa.start_date DESC,sa.id DESC"
                result=rows(sql,args)
                tzrec=one("SELECT setting_value FROM district_settings WHERE setting_key='school_timezone'"); today_local=school_now((tzrec or {}).get('setting_value') or 'America/Chicago')[0].date().isoformat()
                for item in result:
                    item['effective_status']='Expired' if today_local>item['end_date'] else ('Upcoming' if today_local<item['start_date'] else item.get('status','Active'))
                return self.send_json((result[0] if qid and result else ({"error":"Not found"} if qid else result)),404 if qid and not result else 200)

            if path == "/api/substitute/day":
                if role not in {"admin","teacher","substitute"}: return self.send_json({"error":"Permission denied"},403)
                day=(query.get("date",[""])[0] or school_now()[0].date().isoformat()).strip()
                sql="""SELECT sa.*,sub.name substitute_name,t.name teacher_name FROM substitute_assignments sa JOIN staff sub ON sub.id=sa.substitute_staff_id JOIN staff t ON t.id=sa.teacher_staff_id WHERE sa.status='Active' AND ? BETWEEN sa.start_date AND sa.end_date"""
                args=[day]
                if role=="substitute": sql+=" AND sa.substitute_staff_id=?";args.append(int(user.get("staff_id") or 0))
                elif role=="teacher":
                    sql+=" AND (sa.teacher_staff_id=? OR sa.substitute_staff_id=?)"
                    sid=int(user.get("staff_id") or 0); args.extend([sid,sid])
                assignments=rows(sql,args)
                out=[]
                for a in assignments:
                    # Only expose classes that actually meet on the selected coverage date.
                    # This respects rotation days, closures, custom special schedules, the
                    # admin-defined school-year window, and Summer School.
                    scheduled=teacher_classes_for_date(int(a['teacher_staff_id']),day)
                    selected_ids=substitute_selected_class_ids(a)
                    if selected_ids is not None:
                        scheduled=[x for x in scheduled if int(x.get('id') or 0) in selected_ids]
                    classes=[]
                    for base in scheduled:
                        cid=int(base.get('id') or 0)
                        if not cid: continue
                        extra=one("""SELECT
                              (SELECT COUNT(*) FROM attendance at WHERE at.class_id=? AND at.date=?) attendance_marked,
                              sc.rows_count,sc.columns_count,COALESCE(sc.layout_json,'[]') layout_json,
                              COALESCE(cv.lesson_plan,'') lesson_plan,COALESCE(cv.lesson_links,'') lesson_links,COALESCE(cv.teacher_notes,'') teacher_notes,
                              COALESCE(cv.substitute_notes,'') substitute_notes,COALESCE(cv.attendance_completed,0) attendance_completed
                              FROM classes c LEFT JOIN seating_charts sc ON sc.class_id=c.id
                              LEFT JOIN substitute_coverage cv ON cv.assignment_id=? AND cv.class_id=c.id AND cv.coverage_date=?
                              WHERE c.id=?""",(cid,day,a['id'],day,cid)) or {}
                        c=dict(base); c.update(extra)
                        try:c['layout']=json.loads(c.get('layout_json') or '[]')
                        except Exception:c['layout']=[]
                        classes.append(c)
                    a['classes']=classes;out.append(a)
                return self.send_json({"date":day,"assignments":out})

            if path == "/api/substitute/class":
                if role not in {"admin","teacher","substitute"}: return self.send_json({"error":"Permission denied"},403)
                aid=int(query.get("assignment_id",["0"])[0] or 0);cid=int(query.get("class_id",["0"])[0] or 0);day=(query.get("date",[""])[0] or '').strip()
                a=one("SELECT * FROM substitute_assignments WHERE id=?",(aid,))
                if not a or not day or not (a['start_date']<=day<=a['end_date']) or a.get('status')!='Active': return self.send_json({"error":"Substitute assignment is not active for this date"},403)
                if role=="substitute" and int(a['substitute_staff_id'])!=int(user.get('staff_id') or 0): return self.send_json({"error":"Permission denied"},403)
                if role=="teacher" and int(user.get('staff_id') or 0) not in {int(a['teacher_staff_id']),int(a['substitute_staff_id'])}: return self.send_json({"error":"Permission denied"},403)
                cls=one("SELECT c.*,co.code course_code,co.name course_name FROM classes c LEFT JOIN courses co ON co.id=c.course_id WHERE c.id=? AND c.teacher_id=?",(cid,a['teacher_staff_id']))
                scheduled_ids={int(x.get('id') or 0) for x in teacher_classes_for_date(int(a['teacher_staff_id']),day)}
                if not cls or cid not in scheduled_ids:return self.send_json({"error":"This class does not meet on the selected coverage date"},403)
                if not substitute_class_allowed(a,cid): return self.send_json({"error":"This class is not included in the substitute assignment"},403)
                roster=rows("""SELECT s.id student_id,s.student_number,s.first_name||' '||s.last_name student_name,s.grade,s.homeroom,COALESCE(at.status,'') attendance_status,COALESCE(at.minutes_late,0) minutes_late,COALESCE(at.note,'') attendance_note
                              FROM enrollments e JOIN students s ON s.id=e.student_id LEFT JOIN attendance at ON at.class_id=e.class_id AND at.student_id=e.student_id AND at.date=? WHERE e.class_id=? AND COALESCE(e.status,'Active')='Active' ORDER BY s.last_name,s.first_name""",(day,cid))
                chart=one("SELECT rows_count,columns_count,layout_json FROM seating_charts WHERE class_id=?",(cid,)) or {"rows_count":5,"columns_count":6,"layout_json":"[]"}
                try:chart['layout']=json.loads(chart.get('layout_json') or '[]')
                except Exception:chart['layout']=[]
                coverage=one("SELECT * FROM substitute_coverage WHERE assignment_id=? AND class_id=? AND coverage_date=?",(aid,cid,day)) or {}
                return self.send_json({"assignment":a,"class":cls,"roster":roster,"seating_chart":chart,"coverage":coverage})

            if path == "/api/absence-requests":
                if role not in {"admin","parent"}: return self.send_json({"error":"Permission denied"},403)
                if role=="parent":
                    if not sids:return self.send_json([])
                    ph=','.join('?'*len(sids))
                    return self.send_json(rows(f"""SELECT ar.*,s.first_name||' '||s.last_name student_name,u.display_name reviewed_by_name,
                        CASE WHEN aa.id IS NULL THEN 0 ELSE 1 END has_attachment,aa.file_name attachment_name,aa.file_type attachment_type
                        FROM absence_requests ar JOIN students s ON s.id=ar.student_id LEFT JOIN users u ON u.id=ar.reviewed_by
                        LEFT JOIN absence_request_attachments aa ON aa.request_id=ar.id
                        WHERE ar.parent_user_id=? AND ar.student_id IN ({ph}) ORDER BY ar.absence_date DESC,ar.id DESC""",[user.get('id')]+sids))
                status=query.get('status',[''])[0]
                sql="""SELECT ar.*,s.first_name||' '||s.last_name student_name,s.student_number,u.display_name parent_name,rv.display_name reviewed_by_name,
                    CASE WHEN aa.id IS NULL THEN 0 ELSE 1 END has_attachment,aa.file_name attachment_name,aa.file_type attachment_type
                    FROM absence_requests ar JOIN students s ON s.id=ar.student_id JOIN users u ON u.id=ar.parent_user_id LEFT JOIN users rv ON rv.id=ar.reviewed_by
                    LEFT JOIN absence_request_attachments aa ON aa.request_id=ar.id WHERE 1=1""";args=[]
                if status:sql+=' AND ar.status=?';args.append(status)
                return self.send_json(rows(sql+" ORDER BY CASE ar.status WHEN 'Pending' THEN 0 ELSE 1 END,ar.absence_date DESC,ar.id DESC",args))

            if path == "/api/absence-requests/attachment":
                if role not in {"admin","parent"}: return self.send_json({"error":"Permission denied"},403)
                rid=int(query.get('id',['0'])[0] or 0)
                req=one("SELECT * FROM absence_requests WHERE id=?",(rid,))
                if not req:return self.send_json({"error":"Request not found"},404)
                if role=='parent' and (int(req.get('parent_user_id') or 0)!=int(user.get('id') or 0) or not allowed(int(req.get('student_id') or 0),sids)):
                    return self.send_json({"error":"Permission denied"},403)
                a=one("SELECT file_name,file_type,file_base64 FROM absence_request_attachments WHERE request_id=?",(rid,))
                if not a:return self.send_json({"error":"No attachment"},404)
                return self.send_json(a)

            if path == "/api/daily-absences":
                if role not in {"admin","teacher","parent","student"}:return self.send_json({"error":"Permission denied"},403)
                date=query.get('date',[''])[0];sid=int(query.get('student_id',['0'])[0] or 0)
                sql="""SELECT da.*,s.first_name||' '||s.last_name student_name,s.student_number FROM daily_absences da JOIN students s ON s.id=da.student_id WHERE 1=1""";args=[]
                if date:sql+=' AND da.absence_date=?';args.append(date)
                if sid:
                    if not allowed(sid,sids):return self.send_json({"error":"Permission denied"},403)
                    sql+=' AND da.student_id=?';args.append(sid)
                elif role in {'parent','student'}:
                    if not sids:return self.send_json([])
                    ph=','.join('?'*len(sids));sql+=f' AND da.student_id IN ({ph})';args+=sids
                elif role=='teacher':
                    scope=sids or []
                    if not scope:return self.send_json([])
                    ph=','.join('?'*len(scope));sql+=f' AND da.student_id IN ({ph})';args+=scope
                return self.send_json(rows(sql+' ORDER BY da.absence_date DESC,s.last_name,s.first_name',args))

            if path == "/api/admin-dashboard":
                if role!='admin':return self.send_json({"error":"Permission denied"},403)
                tzrec=one("SELECT setting_value FROM district_settings WHERE setting_key='school_timezone'");now,_=school_now((tzrec or {}).get('setting_value') or 'America/Chicago');today=now.strftime('%Y-%m-%d')
                def cnt(sql,args=()):
                    r=one(sql,args) or {};return int(next(iter(r.values()),0) or 0)
                data={
                    'date':today,'students':cnt("SELECT COUNT(*) n FROM students WHERE COALESCE(status,'Active')='Active'"),
                    'staff':cnt("SELECT COUNT(*) n FROM staff WHERE COALESCE(status,'Active')='Active'"),
                    'classes':cnt("SELECT COUNT(*) n FROM classes WHERE COALESCE(published,0)=1"),
                    'present':cnt("SELECT COUNT(*) n FROM attendance WHERE date=? AND status='P'",(today,)),
                    'absent':cnt("SELECT COUNT(*) n FROM attendance WHERE date=? AND status IN ('AE','AU')",(today,)),
                    'tardy':cnt("SELECT COUNT(*) n FROM attendance WHERE date=? AND status IN ('TE','TU')",(today,)),
                    'daily_absent':cnt("SELECT COUNT(*) n FROM daily_absences WHERE absence_date=?",(today,)),
                    'absence_pending':cnt("SELECT COUNT(*) n FROM absence_requests WHERE status='Pending'"),
                    'parking_pending':cnt("SELECT COUNT(*) n FROM parking_permits WHERE status='Pending'"),
                    'fees_open':cnt("SELECT COUNT(*) n FROM student_fees WHERE status='Open'"),
                    'library_overdue':cnt("SELECT COUNT(*) n FROM library_loans WHERE status='Checked Out' AND due_on<>'' AND due_on<?",(today,)),
                    'hallpasses_open':cnt("SELECT COUNT(*) n FROM hall_passes WHERE status IN ('Requested','Approved','Active')"),
                    'behavior_open':cnt("SELECT COUNT(*) n FROM behavior_referrals WHERE status NOT IN ('Resolved','Closed')"),
                    'emergency':one("SELECT id,incident_type,title,started_at,COALESCE(is_drill,0) is_drill FROM emergency_incidents WHERE status='Active' ORDER BY id DESC LIMIT 1"),
                    'recent_absence_requests':rows("""SELECT ar.id,ar.absence_date,ar.reason,ar.status,s.first_name||' '||s.last_name student_name FROM absence_requests ar JOIN students s ON s.id=ar.student_id ORDER BY CASE ar.status WHEN 'Pending' THEN 0 ELSE 1 END,ar.id DESC LIMIT 6"""),
                }
                return self.send_json(data)

            if path == "/api/emergency/incidents":
                if role not in {"admin","teacher","counselor","nurse","student","parent"}:
                    return self.send_json({"error":"Permission denied"},403)
                incident_id=int(query.get("id",["0"])[0] or 0)
                active_only=str(query.get("active",["0"])[0]).lower() in {"1","true","yes"}
                sql="""SELECT ei.*,u.display_name started_by_name,eu.display_name ended_by_name
                       FROM emergency_incidents ei
                       LEFT JOIN users u ON u.id=ei.started_by
                       LEFT JOIN users eu ON eu.id=ei.ended_by WHERE 1=1"""
                args=[]
                if incident_id: sql+=" AND ei.id=?";args.append(incident_id)
                if active_only: sql+=" AND ei.status='Active'"
                if role in {"student","parent"}: sql+=" AND ei.status IN ('Active','Resolved')"
                data=rows(sql+" ORDER BY CASE WHEN ei.status='Active' THEN 0 ELSE 1 END,ei.started_at DESC",args)
                return self.send_json(data[0] if incident_id and data else (data if not incident_id else {"error":"Incident not found"}))

            if path == "/api/emergency/accountability":
                if role not in {"admin","teacher","counselor","nurse","student","parent"}:
                    return self.send_json({"error":"Permission denied"},403)
                iid=int(query.get("incident_id",["0"])[0] or 0)
                if not iid:return self.send_json({"error":"incident_id is required"},400)
                inc=one("SELECT * FROM emergency_incidents WHERE id=?",(iid,))
                if not inc:return self.send_json({"error":"Incident not found"},404)
                sql="""SELECT ea.*,s.first_name||' '||s.last_name student_name,s.student_number,s.grade,s.homeroom,
                       u.display_name checked_by_name
                       FROM emergency_accountability ea JOIN students s ON s.id=ea.student_id
                       LEFT JOIN users u ON u.id=ea.checked_by WHERE ea.incident_id=?"""
                args=[iid]
                if role in {"student","parent","teacher"}:
                    scope=sids or []
                    if not scope:return self.send_json([])
                    ph=','.join('?'*len(scope));sql+=f" AND ea.student_id IN ({ph})";args+=scope
                sql+=" ORDER BY CASE ea.status WHEN 'Unaccounted' THEN 0 WHEN 'Missing' THEN 1 WHEN 'Medical' THEN 2 ELSE 3 END,s.last_name,s.first_name"
                return self.send_json(rows(sql,args))

            if path == "/api/emergency/staff-checkins":
                if role not in {"admin","teacher","counselor","nurse"}:return self.send_json({"error":"Permission denied"},403)
                iid=int(query.get("incident_id",["0"])[0] or 0)
                if not iid:return self.send_json({"error":"incident_id is required"},400)
                sql="""SELECT ec.*,st.name staff_name,st.employee_number,u.display_name checked_by_name
                       FROM emergency_staff_checkins ec JOIN staff st ON st.id=ec.staff_id
                       LEFT JOIN users u ON u.id=ec.checked_by WHERE ec.incident_id=?"""
                args=[iid]
                if role=="teacher":sql+=" AND ec.staff_id=?";args.append(int(user.get("staff_id") or 0))
                return self.send_json(rows(sql+" ORDER BY st.name",args))

            if path == "/api/reunification":
                if role not in {"admin","counselor","nurse","parent","student"}:return self.send_json({"error":"Permission denied"},403)
                iid=int(query.get("incident_id",["0"])[0] or 0)
                if not iid:return self.send_json({"error":"incident_id is required"},400)
                sql="""SELECT rr.*,s.first_name||' '||s.last_name student_name,s.student_number,s.grade,u.display_name released_by_name
                       FROM reunification_releases rr JOIN students s ON s.id=rr.student_id
                       LEFT JOIN users u ON u.id=rr.released_by WHERE rr.incident_id=?"""
                args=[iid]
                if role in {"student","parent"}:
                    scope=sids or []
                    if not scope:return self.send_json([])
                    ph=','.join('?'*len(scope));sql+=f" AND rr.student_id IN ({ph})";args+=scope
                return self.send_json(rows(sql+" ORDER BY rr.released_at DESC",args))

            if path == "/api/conferences":
                if role not in {"admin","teacher","parent"}: return self.send_json({"error":"Permission denied"},403)
                slot_id=int(query.get("id",["0"])[0] or 0)
                sql="""SELECT cs.*,st.name teacher_name,
                       cb.id booking_id,cb.student_id,cb.family_note,cb.status booking_status,
                       s.first_name||' '||s.last_name student_name,s.student_number
                       FROM conference_slots cs JOIN staff st ON st.id=cs.staff_id
                       LEFT JOIN conference_bookings cb ON cb.slot_id=cs.id
                       LEFT JOIN students s ON s.id=cb.student_id WHERE 1=1"""
                args=[]
                if role=="teacher": sql+=" AND cs.staff_id=?";args.append(int(user.get("staff_id") or 0))
                elif role=="parent":
                    if not sids:return self.send_json([])
                    ph=','.join('?'*len(sids));sql+=f" AND (cs.status='Open' OR cb.student_id IN ({ph}))";args+=sids
                if slot_id: sql+=" AND cs.id=?";args.append(slot_id)
                sql+=" ORDER BY cs.start_at,teacher_name"
                return self.send_json(rows(sql,args))

            if path == "/api/clubs":
                if role not in {"admin","teacher","student","parent","counselor"}:return self.send_json({"error":"Permission denied"},403)
                club_id=int(query.get("id",["0"])[0] or 0)
                sql="""SELECT c.*,st.name advisor_name,
                       (SELECT COUNT(*) FROM club_registrations cr WHERE cr.club_id=c.id AND cr.status IN ('Registered','Accepted')) member_count
                       FROM clubs c LEFT JOIN staff st ON st.id=c.advisor_staff_id WHERE 1=1"""
                args=[]
                if role not in {"admin","counselor"}: sql+=" AND c.active=1"
                if club_id:sql+=" AND c.id=?";args.append(club_id)
                data=rows(sql+" ORDER BY c.name",args)
                sid=int(user.get("student_id") or 0)
                for c in data:
                    try:c["form"]=json.loads(c.get("form_json") or "[]")
                    except:c["form"]=[]
                    if sid:c["my_registration"]=one("SELECT * FROM club_registrations WHERE club_id=? AND student_id=?",(c["id"],sid))
                return self.send_json(data[0] if club_id and data else (data if not club_id else {"error":"Club not found"}))

            if path == "/api/clubs/registrations":
                cid=int(query.get("club_id",["0"])[0] or 0)
                if role not in {"admin","counselor","teacher"}:return self.send_json({"error":"Permission denied"},403)
                if role=="teacher":
                    c=one("SELECT advisor_staff_id FROM clubs WHERE id=?",(cid,))
                    if not c or int(c.get("advisor_staff_id") or 0)!=int(user.get("staff_id") or 0):return self.send_json({"error":"Permission denied"},403)
                return self.send_json(rows("SELECT cr.*,s.first_name||' '||s.last_name student_name,s.student_number FROM club_registrations cr JOIN students s ON s.id=cr.student_id WHERE cr.club_id=? ORDER BY s.last_name,s.first_name",(cid,)))

            if path == "/api/clubs/events":
                cid=int(query.get("club_id",["0"])[0] or 0)
                return self.send_json(rows("SELECT * FROM club_events WHERE club_id=? ORDER BY event_date,start_time",(cid,)))

            if path == "/api/forms":
                form_id=int(query.get("id",["0"])[0] or 0)
                if form_id:
                    f=one("SELECT * FROM school_forms WHERE id=?",(form_id,))
                    if not f:return self.send_json({"error":"Form not found"},404)
                    if role not in {"admin","counselor","teacher"} and f.get("status")!="Published": return self.send_json({"error":"Permission denied"},403)
                    f["questions"]=rows("SELECT * FROM school_form_questions WHERE form_id=? ORDER BY sort_order,id",(form_id,))
                    for q in f["questions"]:
                        try:q["options"]=json.loads(q.get("options_json") or "[]")
                        except:q["options"]=[]
                    sid=int(user.get("student_id") or 0)
                    f["my_response"]=one("SELECT * FROM school_form_responses WHERE form_id=? AND student_id=?",(form_id,sid)) if sid else None
                    if f["my_response"]:
                        try:f["my_response"]["answers"]=json.loads(f["my_response"].get("answers_json") or "{}")
                        except:f["my_response"]["answers"]={}
                    return self.send_json(f)
                if role in {"admin","counselor","teacher"}:
                    data=rows("SELECT f.*,(SELECT COUNT(*) FROM school_form_responses r WHERE r.form_id=f.id) response_count FROM school_forms f ORDER BY f.created_at DESC")
                elif role=="student":
                    data=rows("SELECT f.*,(SELECT COUNT(*) FROM school_form_responses r WHERE r.form_id=f.id AND r.student_id=?) my_count FROM school_forms f WHERE f.status='Published' AND f.audience IN ('Students','Students & Parents','All') ORDER BY COALESCE(f.close_date,'9999-12-31'),f.created_at DESC",(user.get("student_id") or 0,))
                elif role=="parent":
                    data=rows("SELECT f.* FROM school_forms f WHERE f.status='Published' AND f.audience IN ('Parents','Students & Parents','All') ORDER BY COALESCE(f.close_date,'9999-12-31'),f.created_at DESC")
                else:return self.send_json({"error":"Permission denied"},403)
                return self.send_json(data)

            if path == "/api/forms/responses":
                if role not in {"admin","counselor","teacher"}:return self.send_json({"error":"Permission denied"},403)
                fid=int(query.get("form_id",["0"])[0] or 0)
                return self.send_json(rows("SELECT r.*,s.first_name||' '||s.last_name student_name,s.student_number FROM school_form_responses r LEFT JOIN students s ON s.id=r.student_id WHERE r.form_id=? ORDER BY r.submitted_at DESC",(fid,)))

            if path == "/api/devices":
                if role in {"admin","counselor"}:
                    return self.send_json(rows("SELECT d.*,s.first_name||' '||s.last_name student_name,s.student_number FROM devices d LEFT JOIN students s ON s.id=d.assigned_student_id ORDER BY d.asset_tag"))
                if role=="student":
                    return self.send_json(rows("SELECT d.*,s.first_name||' '||s.last_name student_name FROM devices d LEFT JOIN students s ON s.id=d.assigned_student_id WHERE d.assigned_student_id=? ORDER BY d.asset_tag",(user.get("student_id") or 0,)))
                return self.send_json({"error":"Permission denied"},403)

            if path == "/api/lockers":
                if role in {"admin","counselor"}:
                    return self.send_json(rows("SELECT l.*,s.first_name||' '||s.last_name student_name,s.student_number FROM lockers l LEFT JOIN students s ON s.id=l.assigned_student_id ORDER BY l.location,l.locker_number"))
                if role=="student":
                    return self.send_json(rows("SELECT l.*,s.first_name||' '||s.last_name student_name FROM lockers l LEFT JOIN students s ON s.id=l.assigned_student_id WHERE l.assigned_student_id=? ORDER BY l.locker_number",(user.get("student_id") or 0,)))
                return self.send_json({"error":"Permission denied"},403)

            if path == "/api/hall-passes":
                # Students can only see their own passes. Teachers/admins see passes relevant to their scope.
                sql = """
                    SELECT hp.*, s.first_name||' '||s.last_name student_name, s.student_number,
                           COALESCE(u.display_name,u.username,'') approved_by_name
                    FROM hall_passes hp
                    JOIN students s ON s.id=hp.student_id
                    LEFT JOIN users u ON u.id=hp.approved_by
                """
                args=[]; clauses=[]
                if role == "student":
                    sid=int(user.get("student_id") or 0)
                    if not sid: return self.send_json([])
                    clauses.append("hp.student_id=?"); args.append(sid)
                elif role == "parent":
                    if not sids: return self.send_json([])
                    ph=",".join("?"*len(sids)); clauses.append(f"hp.student_id IN ({ph})"); args += list(sids)
                elif role == "teacher":
                    # Teachers see students currently enrolled in one of their sections, plus passes they approved.
                    if not cids: return self.send_json([])
                    ph=",".join("?"*len(cids))
                    clauses.append(f"(hp.student_id IN (SELECT student_id FROM enrollments WHERE class_id IN ({ph}) AND COALESCE(status,'Active')='Active') OR hp.approved_by=?)")
                    args += list(cids)+[user.get("id")]
                elif role not in {"admin","counselor"}:
                    return self.send_json({"error":"Permission denied"},403)
                if clauses: sql += " WHERE "+" AND ".join(clauses)
                sql += " ORDER BY CASE hp.status WHEN 'Active' THEN 0 WHEN 'Requested' THEN 1 WHEN 'Approved' THEN 2 ELSE 3 END, hp.id DESC LIMIT 500"
                return self.send_json(rows(sql,args))

            if path == "/api/behavior-referrals":
                if role not in {"admin","teacher","counselor"}:
                    return self.send_json({"error":"Permission denied"},403)
                sql="""
                    SELECT br.*, s.first_name||' '||s.last_name student_name,s.student_number,
                           COALESCE(c.name||' '||c.section,'') class_name,
                           COALESCE(st.name,'') referred_by_name,
                           COALESCE(ad.name,'') assigned_admin_name
                    FROM behavior_referrals br
                    JOIN students s ON s.id=br.student_id
                    LEFT JOIN classes c ON c.id=br.class_id
                    LEFT JOIN staff st ON st.id=br.referred_by
                    LEFT JOIN staff ad ON ad.id=br.assigned_admin
                """
                args=[]; clauses=[]
                if role=="teacher":
                    if user.get("staff_id"):
                        clauses.append("br.referred_by=?");args.append(user.get("staff_id"))
                    else: return self.send_json([])
                if clauses:sql += " WHERE "+" AND ".join(clauses)
                sql += " ORDER BY CASE br.status WHEN 'Submitted' THEN 0 WHEN 'Under Review' THEN 1 WHEN 'Action Assigned' THEN 2 ELSE 3 END, br.id DESC LIMIT 500"
                return self.send_json(rows(sql,args))
            if path == "/api/records":
                module = query.get("module", [""])[0]
                permitted = {"teacherTools", "learning", "behavior", "reporting", "counseling", "special", "scheduling", "health", "finance", "food", "transportation", "registration", "workflow", "communication", "security", "district"}
                if role != "admin" and module not in permitted:
                    return self.send_json({"error": "Permission denied"}, 403)
                sql = """
                    SELECT r.*,COALESCE(s.first_name||' '||s.last_name,'') student_name,COALESCE(st.name,'') staff_name
                    FROM module_records r LEFT JOIN students s ON s.id=r.student_id LEFT JOIN staff st ON st.id=r.staff_id
                    WHERE r.module=?
                """
                args = [module]
                if sids is not None:
                    if not sids:
                        return self.send_json([])
                    ph = ",".join("?" * len(sids))
                    sql += f" AND (r.student_id IS NULL OR r.student_id IN ({ph}))"
                    args += sids
                return self.send_json(rows(sql + " ORDER BY r.id DESC", args))

            if path == "/api/portal-home":
                today = time.strftime("%Y-%m-%d")
                target_sids = sids if sids is not None else []
                if role == "student" and user.get("student_id"):
                    target_sids = [user["student_id"]]
                if target_sids:
                    ph = ",".join("?" * len(target_sids))
                    upcoming = rows(f"""
                        SELECT a.id,a.title,a.description,a.due_date,a.points,a.category,
                               c.name class_name,c.section,co.code course_code,
                               e.student_id,COALESCE(g.status,'') grade_status,g.score,
                               COALESCE(sub.status,'') submission_status
                        FROM enrollments e JOIN classes c ON c.id=e.class_id
                        JOIN assignments a ON a.class_id=c.id AND COALESCE(a.visible,1)=1
                        LEFT JOIN courses co ON co.id=c.course_id
                        LEFT JOIN grades g ON g.assignment_id=a.id AND g.student_id=e.student_id
                        LEFT JOIN assignment_submissions sub ON sub.assignment_id=a.id AND sub.student_id=e.student_id
                        WHERE e.student_id IN ({ph}) AND COALESCE(e.status,'Active')='Active'
                          AND COALESCE(a.due_date,'')>=?
                        ORDER BY a.due_date,a.title LIMIT 60
                    """, tuple(target_sids)+ (today,))
                    att = rows(f"""
                        SELECT at.student_id,at.date,at.status,at.minutes_late,at.note,c.name class_name,c.section
                        FROM attendance at JOIN classes c ON c.id=at.class_id
                        WHERE at.student_id IN ({ph}) ORDER BY at.date DESC LIMIT 30
                    """, tuple(target_sids))
                    fees = rows(f"""
                        SELECT r.*,s.first_name||' '||s.last_name student_name
                        FROM module_records r LEFT JOIN students s ON s.id=r.student_id
                        WHERE r.module='finance' AND r.student_id IN ({ph}) ORDER BY r.id DESC LIMIT 20
                    """, tuple(target_sids))
                    food = rows(f"""
                        SELECT r.*,s.first_name||' '||s.last_name student_name
                        FROM module_records r LEFT JOIN students s ON s.id=r.student_id
                        WHERE r.module='food' AND r.student_id IN ({ph}) ORDER BY r.id DESC LIMIT 20
                    """, tuple(target_sids))
                else:
                    upcoming,att,fees,food=[],[],[],[]
                msgs = rows("SELECT * FROM messages WHERE COALESCE(send_at,'')='' OR send_at<=datetime('now') ORDER BY id DESC LIMIT 25")
                return self.send_json({"upcoming":upcoming,"attendance":att,"fees":fees,"food":food,"messages":msgs,"today":today})

            if path == "/api/calendar-events":
                events=[]
                if cids is None:
                    aa=rows("SELECT a.id,a.title,a.due_date,c.name class_name,c.section FROM assignments a JOIN classes c ON c.id=a.class_id WHERE COALESCE(a.visible,1)=1 AND COALESCE(a.due_date,'')<>'' ORDER BY a.due_date LIMIT 250")
                elif cids:
                    ph=",".join("?"*len(cids)); aa=rows(f"SELECT a.id,a.title,a.due_date,c.name class_name,c.section FROM assignments a JOIN classes c ON c.id=a.class_id WHERE a.class_id IN ({ph}) AND COALESCE(a.visible,1)=1 AND COALESCE(a.due_date,'')<>'' ORDER BY a.due_date LIMIT 250",tuple(cids))
                else: aa=[]
                for a in aa: events.append({"type":"Assignment","date":a["due_date"],"title":a["title"],"detail":f'{a["class_name"]} {a["section"]}'})
                for m in rows("SELECT title,body,send_at FROM messages WHERE COALESCE(send_at,'')<>'' ORDER BY send_at LIMIT 100"):
                    events.append({"type":"Announcement","date":m["send_at"],"title":m["title"],"detail":m["body"]})
                if sids:
                    ph=",".join("?"*len(sids))
                    for r in rows(f"SELECT title,record_date,status,module FROM module_records WHERE student_id IN ({ph}) AND COALESCE(record_date,'')<>'' ORDER BY record_date LIMIT 150",tuple(sids)):
                        events.append({"type":r["module"].title(),"date":r["record_date"],"title":r["title"],"detail":r["status"]})
                events.sort(key=lambda x:str(x.get("date") or ""))
                return self.send_json(events[:400])

            if path == "/api/universal-search":
                q=(query.get("q",[""])[0] or "").strip()
                if len(q)<2: return self.send_json([])
                like=f"%{q}%"; out=[]
                if role in {"admin","teacher","counselor","nurse","finance","transportation","food"}:
                    sql="SELECT id,first_name||' '||last_name title,student_number subtitle FROM students WHERE first_name LIKE ? OR last_name LIKE ? OR student_number LIKE ? OR email LIKE ?"
                    args=[like,like,like,like]
                    if sids is not None:
                        if not sids: data=[]
                        else:
                            ph=",".join("?"*len(sids)); data=rows(sql+f" AND id IN ({ph}) LIMIT 12",tuple(args)+tuple(sids))
                    else: data=rows(sql+" LIMIT 12",args)
                    out += [{"type":"Student","id":x["id"],"title":x["title"],"subtitle":x["subtitle"],"page":"students"} for x in data]
                for x in rows("SELECT id,code||' · '||name title,department subtitle FROM courses WHERE code LIKE ? OR name LIKE ? OR department LIKE ? LIMIT 12",(like,like,like)):
                    out.append({"type":"Course","id":x["id"],"title":x["title"],"subtitle":x["subtitle"],"page":"courses"})
                if role in {"admin","teacher","counselor"}:
                    for x in rows("SELECT id,name title,COALESCE(role,'Staff') subtitle FROM staff WHERE name LIKE ? OR email LIKE ? LIMIT 10",(like,like)):
                        out.append({"type":"Staff","id":x["id"],"title":x["title"],"subtitle":x["subtitle"],"page":"staff"})
                for x in rows("SELECT id,title,body subtitle FROM messages WHERE title LIKE ? OR body LIKE ? ORDER BY id DESC LIMIT 10",(like,like)):
                    out.append({"type":"Message","id":x["id"],"title":x["title"],"subtitle":x["subtitle"],"page":"communication"})
                return self.send_json(out[:35])

            if path == "/api/pending-counts":
                if role != "admin": return self.send_json({})
                return self.send_json({x["module"]:x["n"] for x in rows("SELECT module,COUNT(*) n FROM module_records WHERE lower(COALESCE(status,'')) IN ('pending','open','submitted','under review') GROUP BY module")})

            if path == "/api/course-request-center":
                if role not in {"admin", "teacher", "counselor", "student", "parent"}:
                    return self.send_json({"error": "Permission denied"}, 403)
                window = one("SELECT * FROM course_request_window WHERE id=1") or {"is_open": 0}
                course_rows = rows("""
                    SELECT c.*,COALESCE(st.name,'') creator_name
                    FROM courses c LEFT JOIN staff st ON st.id=c.created_by_staff_id
                    WHERE COALESCE(c.requestable,0)=1
                    ORDER BY c.department,c.code,c.name
                """)
                if role in {"student", "parent"} and not int(window.get("is_open") or 0):
                    course_rows = []
                try:
                    shown_departments=json.loads(window.get("departments") or "[]")
                except Exception:
                    shown_departments=[]
                target_sid=(user.get("student_id") if role=="student" else (sids[0] if role=="parent" and sids and len(sids)==1 else None))
                if role in {"student","parent"}:
                    effective_departments=shown_departments
                    if target_sid:
                        st_opts=one("SELECT registration_departments,registration_blocked_courses FROM students WHERE id=?",(target_sid,)) or {}
                        try: personal_departments=json.loads(st_opts.get("registration_departments") or "[]")
                        except Exception: personal_departments=[]
                        if personal_departments:
                            effective_departments=personal_departments
                        try: blocked={int(x) for x in json.loads(st_opts.get("registration_blocked_courses") or "[]")}
                        except Exception: blocked=set()
                        course_rows=[c for c in course_rows if int(c.get("id") or 0) not in blocked]
                    if effective_departments:
                        course_rows=[c for c in course_rows if (c.get("department") or "Other") in effective_departments]
                base = """SELECT cr.*,s.first_name||' '||s.last_name student_name,s.grade,c.code course_code,c.name course_name,c.department FROM course_requests cr JOIN students s ON s.id=cr.student_id JOIN courses c ON c.id=cr.course_id"""
                if sids is not None:
                    if not sids:
                        reqs=[]; frees=[]
                    else:
                        ph=",".join("?"*len(sids))
                        reqs=rows(base+f" WHERE cr.student_id IN ({ph}) ORDER BY s.last_name,s.first_name,cr.priority",sids)
                        frees=rows(f"SELECT f.*,s.first_name||' '||s.last_name student_name FROM student_free_period_requests f JOIN students s ON s.id=f.student_id WHERE f.student_id IN ({ph}) ORDER BY s.last_name,s.first_name",sids)
                else:
                    reqs=rows(base+" ORDER BY s.last_name,s.first_name,cr.priority")
                    frees=rows("SELECT f.*,s.first_name||' '||s.last_name student_name FROM student_free_period_requests f JOIN students s ON s.id=f.student_id ORDER BY s.last_name,s.first_name")
                student_options=[]
                if role in {"admin","teacher","counselor"}:
                    student_options=rows("SELECT id,student_number,first_name,last_name,grade,registration_departments FROM students WHERE COALESCE(status,'Active')='Active' ORDER BY last_name,first_name")
                return self.send_json({"courses":course_rows,"requests":reqs,"free_periods":frees,"window":window,"students":student_options})

            if path == "/api/scheduler/live-section-data":
                if role not in {"admin", "counselor"}:
                    return self.send_json({"error":"Permission denied"},403)
                return self.send_json({
                    "classes": rows("""
                        SELECT c.*,COALESCE(st.name,'Unassigned') teacher,COALESCE(co.code,'') course_code,COALESCE(co.name,c.name) course_name,
                               (SELECT COUNT(*) FROM enrollments e WHERE e.class_id=c.id AND COALESCE(e.status,'Active')='Active') enrolled
                        FROM classes c LEFT JOIN staff st ON st.id=c.teacher_id LEFT JOIN courses co ON co.id=c.course_id
                        ORDER BY COALESCE(c.term,''),COALESCE(c.cycle_day,1),COALESCE(c.period,''),c.name,c.section
                    """),
                    "students": rows("SELECT id,student_number,first_name,last_name,grade FROM students WHERE COALESCE(status,'Active')='Active' ORDER BY last_name,first_name"),
                    "periods": rows("SELECT * FROM schedule_periods WHERE active=1 ORDER BY cycle_day,sort_order,id"),
                    "rooms": rows("SELECT * FROM schedule_rooms WHERE active=1 ORDER BY name")
                })

            if path == "/api/scheduler/setup":
                if role not in {"admin", "counselor"}:
                    return self.send_json({"error": "Permission denied"}, 403)
                return self.send_json(
                    {
                        "periods": rows("SELECT * FROM schedule_periods WHERE active=1 ORDER BY sort_order,id"),
                        "rooms": rows("SELECT * FROM schedule_rooms WHERE active=1 ORDER BY name"),
                        "requests": rows(
                            """
                            SELECT cr.*,s.first_name||' '||s.last_name student_name,s.grade,c.code course_code,c.name course_name
                            FROM course_requests cr JOIN students s ON s.id=cr.student_id JOIN courses c ON c.id=cr.course_id
                            ORDER BY CASE cr.status WHEN 'Conflict' THEN 0 WHEN 'Requested' THEN 1 ELSE 2 END,s.last_name,s.first_name,cr.priority
                            """
                        ),
                        "runs": rows("SELECT * FROM schedule_runs ORDER BY id DESC LIMIT 20"),
                        "locks": rows("SELECT * FROM schedule_locks ORDER BY id DESC"),
                        "versions": rows("SELECT id,term,name,sections,placements,conflicts,created_at FROM schedule_versions ORDER BY id DESC LIMIT 20"),
                        "rotation": one("SELECT * FROM schedule_rotation_settings WHERE id=1") or {},
                    }
                )

            if path == "/api/scheduler/intelligence":
                if role not in {"admin", "counselor"}:
                    return self.send_json({"error":"Permission denied"},403)
                demand=rows("""
                    SELECT c.id,c.code,c.name,c.department,COUNT(cr.id) requests,
                           COALESCE(SUM(CASE WHEN COALESCE(cr.approval_status,cr.status)='Approved' OR cr.status IN ('Scheduled','Conflict') THEN 1 ELSE 0 END),0) approved,
                           COALESCE((SELECT SUM(capacity) FROM classes cl WHERE cl.course_id=c.id AND cl.generated=1),0) capacity,
                           COALESCE((SELECT COUNT(*) FROM classes cl WHERE cl.course_id=c.id AND cl.generated=1),0) sections
                    FROM courses c LEFT JOIN course_requests cr ON cr.course_id=c.id
                    GROUP BY c.id HAVING COUNT(cr.id)>0 ORDER BY approved DESC,c.name
                """)
                workload=rows("""
                    SELECT st.id,st.name,st.school,COUNT(DISTINCT cl.id) teaching_sections,
                           COUNT(DISTINCT CASE WHEN cl.generated=1 THEN cl.period||'|'||COALESCE(cl.cycle_day,1) END) teaching_slots,
                           COUNT(DISTINCT e.student_id) students,
                           ROUND(CASE WHEN COUNT(DISTINCT cl.id)=0 THEN 0 ELSE COUNT(e.student_id)*1.0/COUNT(DISTINCT cl.id) END,1) average_class_size
                    FROM staff st LEFT JOIN classes cl ON cl.teacher_id=st.id LEFT JOIN enrollments e ON e.class_id=cl.id AND COALESCE(e.status,'Active')='Active'
                    WHERE st.status='Active' AND lower(COALESCE(st.role,'')) LIKE '%teacher%'
                    GROUP BY st.id ORDER BY teaching_slots DESC,st.name
                """)
                heat=rows("""
                    SELECT COALESCE(c.cycle_day,1) cycle_day,c.period,COUNT(DISTINCT c.id) sections,COUNT(DISTINCT c.teacher_id) teachers,COUNT(DISTINCT c.room) rooms,COUNT(e.student_id) placements
                    FROM classes c LEFT JOIN enrollments e ON e.class_id=c.id AND COALESCE(e.status,'Active')='Active'
                    WHERE c.generated=1 GROUP BY COALESCE(c.cycle_day,1),c.period ORDER BY cycle_day,period
                """)
                grouped=rows("""
                    SELECT s.id student_id,s.first_name||' '||s.last_name student_name,COUNT(*) conflicts,
                           GROUP_CONCAT(co.code||' '||co.name, ', ') courses
                    FROM course_requests cr JOIN students s ON s.id=cr.student_id JOIN courses co ON co.id=cr.course_id
                    WHERE COALESCE(cr.scheduling_status,cr.status)='Conflict' GROUP BY s.id ORDER BY conflicts DESC,s.last_name
                """)
                return self.send_json({"demand":demand,"workload":workload,"heat":heat,"student_conflicts":grouped})

            if path == "/api/scheduler/conflicts":
                if role not in {"admin", "counselor"}:
                    return self.send_json({"error": "Permission denied"}, 403)
                return self.send_json(
                    rows(
                        """
                        SELECT s.first_name||' '||s.last_name student_name,c1.period,c1.term,c1.name class_one,c2.name class_two
                        FROM enrollments e1
                        JOIN enrollments e2 ON e1.student_id=e2.student_id AND e1.class_id<e2.class_id
                        JOIN classes c1 ON c1.id=e1.class_id
                        JOIN classes c2 ON c2.id=e2.class_id AND c1.period=c2.period AND c1.term=c2.term
                        JOIN students s ON s.id=e1.student_id
                        ORDER BY student_name,c1.term,c1.period
                        """
                    )
                )

            if path in {"/api/enterprise/backup-create","/api/enterprise/backup-restore","/api/enterprise/settings","/api/enterprise/automation","/api/enterprise/automation-delete","/api/enterprise/report-run","/api/enterprise/security-event"}:
                return self.send_json({"error": "Method not allowed"}, 405)

            if path == "/api/messages":
                return self.send_json(rows("SELECT * FROM messages ORDER BY id DESC"))

            if path == "/api/enterprise":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                sources=report_sources()
                db_size=os.path.getsize(DB) if os.path.exists(DB) else 0
                last_backup=list_database_backups()[0] if list_database_backups() else None
                return self.send_json({
                    "health":{"database":"Online","database_size":db_size,"last_backup":last_backup,"backups":len(list_database_backups()),"users":one("SELECT COUNT(*) n FROM users")['n'],"active_sessions":one("SELECT COUNT(*) n FROM sessions WHERE expires_at>?",(int(time.time()),))['n'],"audit_events":one("SELECT COUNT(*) n FROM audit_log")['n'],"version":"Phase 5 Enterprise"},
                    "backups":list_database_backups(),"quality":data_quality_snapshot(),
                    "automation_rules":rows("SELECT * FROM automation_rules ORDER BY active DESC,id DESC"),
                    "imports":rows("SELECT * FROM import_history ORDER BY id DESC LIMIT 100"),
                    "settings":{x['setting_key']:x['setting_value'] for x in rows("SELECT * FROM district_settings")},
                    "report_sources":{k:{"label":v['label'],"columns":v['columns']} for k,v in sources.items()},
                    "saved_reports":rows("SELECT * FROM report_definitions ORDER BY id DESC"),
                    "security_events":rows("SELECT * FROM security_events ORDER BY id DESC LIMIT 100")
                })

            if path == "/api/enterprise/backup-download":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                name=(query.get('name') or [''])[0]
                safe=os.path.basename(name); target=os.path.join(backup_dir(),safe)
                if not safe or not os.path.isfile(target): return self.send_json({"error":"Backup not found"},404)
                with open(target,'rb') as fh: payload=base64.b64encode(fh.read()).decode()
                return self.send_json({"name":safe,"base64":payload})

            if path == "/api/assignment-submissions":
                if role not in {"admin", "teacher"}:
                    return self.send_json({"error":"Permission denied"},403)
                assignment_id=int(query.get("assignment_id",["0"])[0])
                a=one("SELECT id,class_id,title,points,due_date FROM assignments WHERE id=?",(assignment_id,))
                if not a or not allowed(a["class_id"],cids):
                    return self.send_json({"error":"Permission denied"},403)
                result=rows("""
                    SELECT s.id student_id,s.student_number,s.first_name||' '||s.last_name student_name,
                           sub.file_name,sub.file_type,sub.submitted_at,COALESCE(sub.status,'Not Submitted') submission_status,
                           COALESCE(sub.teacher_note,'') teacher_note,sub.reviewed_at,
                           g.score,COALESCE(g.status,'') grade_status,COALESCE(g.comment,'') feedback
                    FROM enrollments e JOIN students s ON s.id=e.student_id
                    LEFT JOIN assignment_submissions sub ON sub.assignment_id=? AND sub.student_id=s.id
                    LEFT JOIN grades g ON g.assignment_id=? AND g.student_id=s.id
                    WHERE e.class_id=? AND COALESCE(e.status,'Active')='Active'
                    ORDER BY s.last_name,s.first_name
                """,(assignment_id,assignment_id,a["class_id"]))
                return self.send_json({"assignment":a,"students":result})

            if path == "/api/assignment-submission-file":
                assignment_id=int(query.get("assignment_id",["0"])[0]); student_id=int(query.get("student_id",["0"])[0])
                a=one("SELECT class_id FROM assignments WHERE id=?",(assignment_id,))
                if not a: return self.send_json({"error":"Submission not found"},404)
                if role in {"admin","teacher"}:
                    if not allowed(a["class_id"],cids): return self.send_json({"error":"Permission denied"},403)
                elif role=="student":
                    if int(user.get("student_id") or 0)!=student_id: return self.send_json({"error":"Permission denied"},403)
                else: return self.send_json({"error":"Permission denied"},403)
                sub=one("SELECT file_name,file_type,file_data,submitted_at,status FROM assignment_submissions WHERE assignment_id=? AND student_id=?",(assignment_id,student_id))
                if not sub: return self.send_json({"error":"No submitted file"},404)
                return self.send_json(sub)

            if path == "/api/audit":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                return self.send_json(rows("SELECT * FROM audit_log ORDER BY id DESC LIMIT 500"))

            if path == "/api/users":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                user_rows = rows(
                    """
                    SELECT u.id,u.username,u.role,u.display_name,u.active,u.student_id,u.staff_id,
                           u.must_change_password,u.last_login,u.locked_until,
                           COALESCE(s.first_name||' '||s.last_name,'') student_name,
                           COALESCE(st.name,'') staff_name
                    FROM users u LEFT JOIN students s ON s.id=u.student_id LEFT JOIN staff st ON st.id=u.staff_id
                    ORDER BY u.role,u.username
                    """
                )
                for item in user_rows:
                    item["parent_student_ids"] = [x["student_id"] for x in rows("SELECT student_id FROM parent_students WHERE user_id=?", (item["id"],))]
                return self.send_json(user_rows)


            if path == "/api/time-context":
                tzrec=one("SELECT setting_value FROM district_settings WHERE setting_key='school_timezone'")
                tzname=(tzrec or {}).get('setting_value') or 'America/Chicago'
                now,tzname=school_now(tzname)
                return self.send_json({"now":now.isoformat(),"date":now.strftime("%Y-%m-%d"),"time":now.strftime("%H:%M:%S"),"weekday":now.strftime("%A"),"timezone":tzname})

            if path == "/api/teacher-day":
                if role not in {"teacher","admin"}: return self.send_json({"error":"Permission denied"},403)
                staff_id=int(query.get("staff_id",[str(user.get("staff_id") or 0)])[0] or 0)
                if role=="teacher": staff_id=int(user.get("staff_id") or 0)
                if not staff_id: return self.send_json({"date":"","rotation_day":None,"rotation_label":None,"classes":[]})
                tzrec=one("SELECT setting_value FROM district_settings WHERE setting_key='school_timezone'")
                tzname=(tzrec or {}).get('setting_value') or 'America/Chicago'
                now,_resolved_tzname=school_now(tzname); ds=query.get("date",[now.strftime("%Y-%m-%d")])[0]
                try: target_date=datetime.strptime(ds,'%Y-%m-%d').date()
                except Exception: target_date=now.date(); ds=target_date.isoformat()
                special=one("SELECT * FROM school_calendar_days WHERE date=?",(ds,))
                rot=one("SELECT * FROM schedule_rotation_settings WHERE id=1") or {"day_a_date":"","rotation_count":2,"day_labels":"[\"Day A\",\"Day B\"]"}
                try: labels=json.loads(rot.get('day_labels') or '[]')
                except Exception: labels=[]
                count=max(1,int(rot.get('rotation_count') or len(labels) or 2))
                while len(labels)<count: labels.append(f"Day {len(labels)+1}")
                cycle=None
                if not (special and str(special.get('day_type') or '').lower() in {'no school','holiday','closed','school closure'}) and not (target_date.weekday()>=5 and not special):
                    if special and special.get('rotation_day'): cycle=int(special['rotation_day'])
                    else:
                        anchor=rot.get('day_a_date') or rot.get('day_b_date') or ''
                        if not anchor: cycle=1
                        else:
                            try:
                                start_d=datetime.strptime(anchor,'%Y-%m-%d').date(); idx=0; cur=start_d
                                if target_date<start_d: cycle=1
                                else:
                                    while cur<target_date:
                                        cur=cur.fromordinal(cur.toordinal()+1)
                                        if cur.weekday()>=5: continue
                                        rec=one("SELECT day_type FROM school_calendar_days WHERE date=?",(cur.isoformat(),))
                                        if rec and str(rec.get('day_type') or '').lower() in {'no school','holiday','closed','school closure'}: continue
                                        idx+=1
                                    cycle=(idx%count)+1
                            except Exception: cycle=1
                classes=[]
                if cycle:
                    classes=rows("""SELECT c.id,c.name,c.section,c.period,c.room,c.cycle_day,COALESCE(co.code,'') course_code,
                        COALESCE(sp.start_time,'') start_time,COALESCE(sp.end_time,'') end_time,
                        (SELECT COUNT(*) FROM enrollments e WHERE e.class_id=c.id AND COALESCE(e.status,'Active')='Active') enrolled,
                        (SELECT COUNT(*) FROM attendance at WHERE at.class_id=c.id AND at.date=?) marked
                        FROM classes c LEFT JOIN courses co ON co.id=c.course_id
                        LEFT JOIN schedule_periods sp ON sp.cycle_day=c.cycle_day AND sp.name=c.period
                        WHERE c.teacher_id=? AND COALESCE(c.published,0)=1 AND COALESCE(c.cycle_day,1)=?
                        ORDER BY COALESCE(sp.sort_order,999),sp.start_time,c.period""",(ds,staff_id,cycle))
                return self.send_json({"date":ds,"now":now.isoformat(),"rotation_day":cycle,"rotation_label":labels[cycle-1] if cycle and cycle<=len(labels) else None,"special_day":special,"classes":classes})

            if path == "/api/school-calendar":
                start=query.get("start",[""])[0]; end=query.get("end",[""])[0]
                sql="SELECT * FROM school_calendar_days WHERE 1=1"; args=[]
                if start: sql+=" AND date>=?"; args.append(start)
                if end: sql+=" AND date<=?"; args.append(end)
                return self.send_json(rows(sql+" ORDER BY date",tuple(args)))

            if path in {"/api/schedule/day","/api/schedule/month","/api/schedule/year"}:
                student_id=int(query.get("student_id",[str(user.get("student_id") or 0)])[0] or 0)
                if not student_id or not allowed(student_id,sids): return self.send_json({"error":"Permission denied"},403)
                target=query.get("date",[school_now(((one("SELECT setting_value FROM district_settings WHERE setting_key='school_timezone'") or {}).get('setting_value') or 'America/Chicago'))[0].strftime("%Y-%m-%d")])[0]
                rot=one("SELECT * FROM schedule_rotation_settings WHERE id=1") or {"day_a_date":"","rotation_count":2,"day_labels":"[\"Day A\",\"Day B\"]"}
                try: labels=json.loads(rot.get("day_labels") or "[]")
                except Exception: labels=[]
                count=max(1,int(rot.get("rotation_count") or len(labels) or 2))
                while len(labels)<count: labels.append(f"Day {len(labels)+1}")
                def rotation_for_date(ds):
                    special=one("SELECT * FROM school_calendar_days WHERE date=?",(ds,))
                    try:
                        pd=datetime.strptime(ds,"%Y-%m-%d").date(); a,b=_ss_school_window(pd)
                        if not (a<=pd<=b): return None,special
                    except Exception: pass
                    try:
                        pd=datetime.strptime(ds,'%Y-%m-%d').date(); a,b=_ss_school_window(pd)
                        if not (a<=pd<=b): return None,special
                    except Exception: pass
                    try: parsed_day=datetime.strptime(ds,'%Y-%m-%d').date()
                    except Exception: parsed_day=None
                    if special and str(special.get("day_type") or '').lower() in {'no school','holiday','closed','school closure'}:
                        return None,special
                    if parsed_day and parsed_day.weekday()>=5 and not special:
                        return None,None
                    if special and special.get('rotation_day'):
                        return int(special['rotation_day']),special
                    anchor=rot.get('day_a_date') or rot.get('day_b_date') or ''
                    if not anchor: return 1,special
                    try:
                        start_d=datetime.strptime(anchor,'%Y-%m-%d').date(); end_d=datetime.strptime(ds,'%Y-%m-%d').date()
                    except Exception: return 1,special
                    if end_d<start_d: return 1,special
                    idx=0; cur=start_d
                    while cur<end_d:
                        cur=cur.fromordinal(cur.toordinal()+1)
                        if cur.weekday()>=5: continue
                        rec=one("SELECT day_type FROM school_calendar_days WHERE date=?",(cur.isoformat(),))
                        if rec and str(rec.get('day_type') or '').lower() in {'no school','holiday','closed','school closure'}: continue
                        idx+=1
                    return (idx%count)+1,special
                def day_payload(ds):
                    cycle,special=rotation_for_date(ds)
                    classes=[]
                    custom_periods = rows("SELECT * FROM special_schedule_periods WHERE calendar_day_id=? ORDER BY sort_order,start_time",(special['id'],)) if special and str(special.get('day_type') or '').lower()=='special schedule' else []
                    if custom_periods:
                        for cp in custom_periods:
                            classes += rows("""SELECT c.id,c.name,c.section,c.period,c.room,c.cycle_day,COALESCE(st.name,'') teacher,COALESCE(co.code,'') course_code,
                              ? start_time,? end_time,0 is_lunch,COALESCE(att.status,'') attendance_status,COALESCE(att.minutes_late,0) attendance_minutes,COALESCE(att.note,'') attendance_note,
                              ? special_schedule_label,? special_schedule_order
                              FROM enrollments e JOIN classes c ON c.id=e.class_id LEFT JOIN staff st ON st.id=c.teacher_id LEFT JOIN courses co ON co.id=c.course_id
                              LEFT JOIN attendance att ON att.class_id=c.id AND att.student_id=e.student_id AND att.date=?
                              WHERE e.student_id=? AND COALESCE(e.status,'Active')='Active' AND COALESCE(c.published,0)=1 AND COALESCE(c.cycle_day,1)=? AND c.period=?""",
                              (cp['start_time'],cp['end_time'],cp.get('custom_label') or cp['period_name'],cp['sort_order'],ds,student_id,cp['source_cycle_day'],cp['period_name']))
                    elif cycle:
                        classes=rows("""SELECT c.id,c.name,c.section,c.period,c.room,c.cycle_day,COALESCE(st.name,'') teacher,COALESCE(co.code,'') course_code,
                          COALESCE(sp.start_time,'') start_time,COALESCE(sp.end_time,'') end_time,COALESCE(sp.is_lunch,0) is_lunch,
                          COALESCE(att.status,'') attendance_status,COALESCE(att.minutes_late,0) attendance_minutes,COALESCE(att.note,'') attendance_note
                          FROM enrollments e JOIN classes c ON c.id=e.class_id LEFT JOIN staff st ON st.id=c.teacher_id LEFT JOIN courses co ON co.id=c.course_id
                          LEFT JOIN schedule_periods sp ON sp.cycle_day=c.cycle_day AND sp.name=c.period
                          LEFT JOIN attendance att ON att.class_id=c.id AND att.student_id=e.student_id AND att.date=?
                          WHERE e.student_id=? AND COALESCE(e.status,'Active')='Active' AND COALESCE(c.published,0)=1 AND COALESCE(c.cycle_day,1)=?
                          ORDER BY COALESCE(sp.sort_order,999),sp.start_time,c.period""",(ds,student_id,cycle))
                    reg=rows("SELECT sport_id,team_name FROM sports_registrations WHERE student_id=? AND status IN ('Registered','Accepted','Team') AND COALESCE(team_name,'')<>''",(student_id,))
                    events=[]
                    for rr in reg:
                        events += rows("SELECT se.*,sp.name sport_name FROM sports_events se JOIN sports_programs sp ON sp.id=se.sport_id WHERE se.sport_id=? AND se.event_date=? AND (COALESCE(se.team_name,'')='' OR se.team_name=?) ORDER BY se.start_time",(rr['sport_id'],ds,rr['team_name']))
                    return {"date":ds,"weekday":datetime.strptime(ds,"%Y-%m-%d").strftime("%A"),"is_weekend":datetime.strptime(ds,"%Y-%m-%d").weekday()>=5,"rotation_day":cycle,"rotation_label":labels[cycle-1] if cycle and cycle<=len(labels) else None,"special_day":special,"classes":classes,"sports":events,"summer":_ss_summer_for_student(student_id,ds) if "_ss_summer_for_student" in globals() else []}
                if path=="/api/schedule/day": return self.send_json(day_payload(target))
                if path=="/api/schedule/month":
                    try:
                        first=datetime.strptime(target[:7]+"-01","%Y-%m-%d").date()
                    except Exception:
                        today=datetime.now().date(); first=today.replace(day=1)
                    out=[]; cur=first
                    while cur.month==first.month:
                        out.append(day_payload(cur.isoformat()))
                        cur=cur.fromordinal(cur.toordinal()+1)
                    return self.send_json(out)
                year=int(query.get('year',[target[:4] if len(target)>=4 else str(datetime.now().year)])[0])
                start=datetime(year,1,1).date(); out=[]
                for i in range(366):
                    d=start.fromordinal(start.toordinal()+i)
                    if d.year!=year: break
                    if d.weekday()<5 or one("SELECT id FROM school_calendar_days WHERE date=?",(d.isoformat(),)):
                        out.append(day_payload(d.isoformat()))
                return self.send_json(out)

            if path == "/api/sports":
                if role=='coach':
                    data=rows("""SELECT DISTINCT sp.* FROM sports_programs sp JOIN sports_coaches sc ON sc.sport_id=sp.id WHERE sp.active=1 AND sc.user_id=? ORDER BY sp.start_date,sp.name""",(user.get('id'),))
                else:
                    data=rows("SELECT * FROM sports_programs WHERE active=1 ORDER BY start_date,name")
                student_id=int(query.get('student_id',[str(user.get('student_id') or 0)])[0] or 0)
                for x in data:
                    try:x['form']=json.loads(x.get('form_json') or '[]')
                    except Exception:x['form']=[]
                    try:x['teams']=json.loads(x.get('teams_json') or '[]')
                    except Exception:x['teams']=[]
                    x['registration']=one("SELECT * FROM sports_registrations WHERE sport_id=? AND student_id=?",(x['id'],student_id)) if student_id else None
                    x['events']=[]
                    if x['registration'] and x['registration'].get('team_name'):
                        x['events']=rows("SELECT * FROM sports_events WHERE sport_id=? AND (COALESCE(team_name,'')='' OR team_name=?) ORDER BY event_date,start_time",(x['id'],x['registration']['team_name']))
                    x['registrations']=rows("SELECT sr.*,s.first_name||' '||s.last_name student_name,s.student_number FROM sports_registrations sr JOIN students s ON s.id=sr.student_id WHERE sr.sport_id=? ORDER BY s.last_name,s.first_name",(x['id'],)) if role in {'admin','coach'} else []
                    x['coaches']=rows("SELECT sc.*,u.display_name,u.username FROM sports_coaches sc JOIN users u ON u.id=sc.user_id WHERE sc.sport_id=? ORDER BY sc.team_name,u.display_name",(x['id'],)) if role in {'admin','coach'} else []
                return self.send_json(data)

            if path == "/api/sports/events":
                sport_id=int(query.get('sport_id',['0'])[0] or 0)
                return self.send_json(rows("SELECT * FROM sports_events WHERE sport_id=? ORDER BY event_date,start_time",(sport_id,)))

            if path == "/api/class-page":
                class_id=int(query.get('class_id',['0'])[0] or 0)
                if not allowed(class_id,cids): return self.send_json({"error":"Permission denied"},403)
                page=one("SELECT * FROM class_pages WHERE class_id=?",(class_id,)) or {"class_id":class_id,"page_title":"","welcome_text":"","bulletin":"","topics_json":"[]","links_json":"[]","theme":"Clean"}
                try: page['topics']=json.loads(page.get('topics_json') or '[]')
                except Exception: page['topics']=[]
                try: page['links']=json.loads(page.get('links_json') or '[]')
                except Exception: page['links']=[]
                try: page['settings']=json.loads(page.get('settings_json') or '{}')
                except Exception: page['settings']={}
                page['assignments']=rows("SELECT id,title,due_date,points,category,description FROM assignments WHERE class_id=? AND COALESCE(visible,1)=1 ORDER BY due_date,id",(class_id,))
                return self.send_json(page)

            return self.send_json({"error": "Not found"}, 404)
        except Exception as exc:
            return self.send_json({"error": str(exc)}, 500)

    def do_POST(self):
        path = urlparse(self.path).path
        data = self.read_body()

        if path == "/api/auth/bootstrap":
            if PORTAL_LOCK not in {"", "admin"}:
                return self.send_json({"error": "Initial setup must be completed from Launch Administration.bat"}, 403)
            if one("SELECT COUNT(*) n FROM users")["n"]:
                return self.send_json({"error": "Administrator already created"}, 409)
            username = (data.get("username") or "").strip()
            password = data.get("password") or ""
            if not username:
                return self.send_json({"error": "Enter a username"}, 400)
            if len(password) < 8:
                return self.send_json({"error": "Password must be at least 8 characters"}, 400)
            digest, salt = hash_pw(password)
            user_id = run(
                "INSERT INTO users(username,password_hash,salt,role,display_name) VALUES(?,?,?,?,?)",
                (username, digest, salt, "admin", data.get("display_name") or "District Administrator"),
            )
            audit(None, "Created", "Security", user_id, "Initial administrator")
            return self.login_success(user_id)

        if path == "/api/auth/login":
            username = (data.get("username") or "").strip()
            user = one("SELECT * FROM users WHERE lower(username)=lower(?)", (username,))
            now = int(time.time())
            if not user or not user["active"] or int(user.get("locked_until") or 0) > now or not verify(data.get("password") or "", user):
                if user:
                    failed = int(user.get("failed_attempts") or 0) + 1
                    locked_until = now + 900 if failed >= 5 else 0
                    run("UPDATE users SET failed_attempts=?,locked_until=? WHERE id=?", (failed, locked_until, user["id"]))
                return self.send_json({"error": "Incorrect username or password"}, 401)
            expected = PORTAL_LOCK or (data.get("expected_role") or "").strip().lower()
            if expected and expected in ROLES and user["role"] != expected:
                return self.send_json(
                    {"error": f"This launcher only accepts {expected.title()} accounts. That account belongs to the {user['role'].title()} portal."},
                    403,
                )
            run("UPDATE users SET failed_attempts=0,locked_until=0,last_login=CURRENT_TIMESTAMP WHERE id=?", (user["id"],))
            audit(user, "Signed in", "Security", user["id"], f"Portal: {PORTAL_LOCK or 'general'}")
            return self.login_success(user["id"])

        user = self.require_user()
        if not user:
            return
        role = user["role"]
        cids = class_scope(user)
        sids = student_scope(user)

        try:
            if path == "/api/auth/logout":
                token = self.session_token()
                if token:
                    run("DELETE FROM sessions WHERE token=?", (token,))
                cookie = f"{COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0" + ("; Secure" if PRODUCTION or self.headers.get("X-Forwarded-Proto", "").lower()=="https" else "")
                return self.send_json({"ok": 1}, headers={"Set-Cookie": cookie})

            if path == "/api/auth/change-password":
                if not verify(data.get("current_password") or "", user):
                    return self.send_json({"error": "Current password is incorrect"}, 400)
                new_password = data.get("new_password") or ""
                if len(new_password) < 8:
                    return self.send_json({"error": "Password must be at least 8 characters"}, 400)
                digest, salt = hash_pw(new_password)
                run("UPDATE users SET password_hash=?,salt=?,must_change_password=0 WHERE id=?", (digest, salt, user["id"]))
                audit(user, "Changed password", "Security", user["id"])
                return self.send_json({"ok": 1})

            if path == "/api/users":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                new_role = (data.get("role") or "").strip().lower()
                username = (data.get("username") or "").strip()
                password = data.get("password") or ""
                if new_role not in ROLES:
                    return self.send_json({"error": "Invalid role"}, 400)
                if not username:
                    return self.send_json({"error": "Enter a username"}, 400)
                if one("SELECT id FROM users WHERE lower(username)=lower(?)", (username,)):
                    return self.send_json({"error": "That username is already in use"}, 409)
                if len(password) < 8:
                    return self.send_json({"error": "Temporary password must be at least 8 characters"}, 400)
                student_id = int(data.get("student_id") or 0) or None
                staff_id = int(data.get("staff_id") or 0) or None
                if new_role not in {"student", "parent"}:
                    student_id = None
                if new_role not in {"teacher", "substitute"}:
                    staff_id = None
                if new_role == "student" and not student_id:
                    return self.send_json({"error": "A student account must be linked to a student"}, 400)
                if new_role in {"teacher", "substitute"} and not staff_id:
                    return self.send_json({"error": "A teacher or substitute account must be linked to a staff member"}, 400)
                digest, salt = hash_pw(password)
                new_id = run(
                    """
                    INSERT INTO users(username,password_hash,salt,role,display_name,student_id,staff_id,must_change_password)
                    VALUES(?,?,?,?,?,?,?,?)
                    """,
                    (
                        username,
                        digest,
                        salt,
                        new_role,
                        data.get("display_name") or username,
                        student_id,
                        staff_id,
                        1 if data.get("must_change_password", True) else 0,
                    ),
                )
                parent_ids = [int(x) for x in data.get("parent_student_ids", []) if str(x).strip()]
                if new_role == "parent" and student_id and student_id not in parent_ids:
                    parent_ids.append(student_id)
                for student_link in parent_ids:
                    run("INSERT OR IGNORE INTO parent_students(user_id,student_id) VALUES(?,?)", (new_id, student_link))
                audit(user, "Created account", "Security", new_id, new_role)
                return self.send_json({"id": new_id, "username": username, "role": new_role})

            if path == "/api/users/bulk-students":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                grade = str(data.get("grade") or "").strip()
                username_format = str(data.get("username_format") or "email").strip()
                password_format = str(data.get("password_format") or "random").strip()
                domain_suffix = str(data.get("domain_suffix") or "").strip()
                must_change = 1 if data.get("must_change_password", True) else 0
                if domain_suffix and not domain_suffix.startswith("@"):
                    domain_suffix = "@" + domain_suffix
                sql = "SELECT * FROM students WHERE COALESCE(status,'Active')='Active'"
                args = []
                if grade:
                    sql += " AND CAST(grade AS TEXT)=?"
                    args.append(grade)
                students = rows(sql + " ORDER BY last_name,first_name,student_number", args)
                existing_links = {int(x["student_id"]) for x in rows("SELECT student_id FROM users WHERE role='student' AND student_id IS NOT NULL")}
                used_names = {str(x["username"]).lower() for x in rows("SELECT username FROM users")}
                credentials = []
                skipped = 0
                def clean_part(value):
                    return ''.join(ch.lower() for ch in str(value or '') if ch.isalnum() or ch in '._-').strip('._-')
                for st in students:
                    if int(st["id"]) in existing_links:
                        skipped += 1
                        continue
                    first = clean_part(st.get("first_name"))
                    last = clean_part(st.get("last_name"))
                    number = clean_part(st.get("student_number")) or str(st["id"])
                    email = str(st.get("email") or "").strip()
                    if username_format == "student_number":
                        base = number
                    elif username_format == "first.last":
                        base = f"{first}.{last}".strip('.')
                    elif username_format == "firstinitial.last":
                        base = f"{first[:1]}{last}"
                    else:
                        base = clean_part(email.split('@')[0]) if '@' in email else f"{first}.{last}".strip('.')
                    if not base:
                        base = f"student{number}"
                    username = base + domain_suffix
                    if username.lower() in used_names:
                        username = f"{base}{number[-4:]}{domain_suffix}"
                    counter = 2
                    while username.lower() in used_names:
                        username = f"{base}{number[-4:]}{counter}{domain_suffix}"
                        counter += 1
                    used_names.add(username.lower())
                    if password_format == "student_number":
                        password = f"SS{number}{first[:1].upper()}{last[:1].upper()}!"
                        if len(password) < 8:
                            password += "2026"
                    else:
                        alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$"
                        password = ''.join(secrets.choice(alphabet) for _ in range(12))
                    digest, salt = hash_pw(password)
                    display_name = f"{st.get('first_name','')} {st.get('last_name','')}".strip()
                    new_id = run(
                        """INSERT INTO users(username,password_hash,salt,role,display_name,active,student_id,must_change_password)
                           VALUES(?,?,?,?,?,?,?,?)""",
                        (username, digest, salt, "student", display_name or username, 1, st["id"], must_change),
                    )
                    credentials.append({
                        "user_id": new_id,
                        "student_id": st["id"],
                        "student_number": st.get("student_number") or "",
                        "first_name": st.get("first_name") or "",
                        "last_name": st.get("last_name") or "",
                        "display_name": display_name,
                        "grade": st.get("grade") or "",
                        "email": email,
                        "username": username,
                        "password": password,
                    })
                audit(user, "Bulk created student accounts", "Security", "bulk", f"Created {len(credentials)}; skipped {skipped}")
                return self.send_json({"created": len(credentials), "skipped": skipped, "credentials": credentials})

            if path == "/api/users/update":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                target_id = int(data.get("id") or 0)
                target = one("SELECT * FROM users WHERE id=?", (target_id,))
                if not target:
                    return self.send_json({"error": "Account not found"}, 404)
                new_role = (data.get("role") or target["role"]).strip().lower()
                if new_role not in ROLES:
                    return self.send_json({"error": "Invalid role"}, 400)
                student_id = int(data.get("student_id") or 0) or None
                staff_id = int(data.get("staff_id") or 0) or None
                if new_role not in {"student", "parent"}:
                    student_id = None
                if new_role not in {"teacher", "substitute"}:
                    staff_id = None
                if new_role == "student" and not student_id:
                    return self.send_json({"error": "A student account must be linked to a student"}, 400)
                if new_role in {"teacher", "substitute"} and not staff_id:
                    return self.send_json({"error": "A teacher or substitute account must be linked to a staff member"}, 400)
                active = 1 if data.get("active", True) else 0
                if target_id == user["id"] and not active:
                    return self.send_json({"error": "You cannot disable your own account"}, 400)
                run(
                    "UPDATE users SET display_name=?,role=?,student_id=?,staff_id=?,active=? WHERE id=?",
                    (data.get("display_name") or target["display_name"], new_role, student_id, staff_id, active, target_id),
                )
                run("DELETE FROM parent_students WHERE user_id=?", (target_id,))
                parent_ids = [int(x) for x in data.get("parent_student_ids", []) if str(x).strip()]
                if new_role == "parent" and student_id and student_id not in parent_ids:
                    parent_ids.append(student_id)
                for student_link in parent_ids:
                    run("INSERT OR IGNORE INTO parent_students(user_id,student_id) VALUES(?,?)", (target_id, student_link))
                if target["role"] != new_role or not active:
                    run("DELETE FROM sessions WHERE user_id=?", (target_id,))
                audit(user, "Updated account", "Security", target_id, new_role)
                return self.send_json({"ok": 1})

            if path == "/api/users/reset-password":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                password = data.get("password") or ""
                if len(password) < 8:
                    return self.send_json({"error": "Temporary password must be at least 8 characters"}, 400)
                digest, salt = hash_pw(password)
                run(
                    "UPDATE users SET password_hash=?,salt=?,must_change_password=1,failed_attempts=0,locked_until=0 WHERE id=?",
                    (digest, salt, int(data["id"])),
                )
                run("DELETE FROM sessions WHERE user_id=?", (int(data["id"]),))
                audit(user, "Reset password", "Security", data["id"])
                return self.send_json({"ok": 1})

            if path == "/api/users/toggle":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                target_id = int(data["id"])
                if target_id == user["id"]:
                    return self.send_json({"error": "You cannot disable your own account"}, 400)
                active = 1 if data.get("active") else 0
                run("UPDATE users SET active=? WHERE id=?", (active, target_id))
                if not active:
                    run("DELETE FROM sessions WHERE user_id=?", (target_id,))
                return self.send_json({"ok": 1})


            if path == "/api/students/import-preview":
                if role != "admin":
                    return self.send_json({"error":"Permission denied"},403)
                try:
                    blob=base64.b64decode(data.get("content_base64") or "", validate=True)
                    parsed=parse_student_import(data.get("filename", "students.csv"), blob)
                    return self.send_json({"rows":parsed,"count":len(parsed)})
                except Exception as exc:
                    return self.send_json({"error":"Could not read that student file: "+str(exc)},400)

            if path == "/api/students/bulk":
                if role != "admin":
                    return self.send_json({"error":"Permission denied"},403)
                items=data.get("students") or []
                if not isinstance(items,list) or not items:
                    return self.send_json({"error":"Add at least one student."},400)
                if len(items)>5000:
                    return self.send_json({"error":"A maximum of 5,000 students may be imported at once."},400)
                created=updated=skipped=0; errors=[]
                conn=db_connect()
                try:
                    for idx, raw in enumerate(items, start=1):
                        st=normalize_student_import_row(raw)
                        if not st["student_number"]:
                            errors.append({"row":idx,"error":"Student ID is required"}); skipped+=1; continue
                        if not st["first_name"]:
                            errors.append({"row":idx,"error":"First name is required"}); skipped+=1; continue
                        if not st["last_name"]:
                            errors.append({"row":idx,"error":"Last name is required"}); skipped+=1; continue
                        existing=conn.execute("SELECT id FROM students WHERE LOWER(student_number)=LOWER(?)",(st["student_number"],)).fetchone()
                        values=(st["student_number"],st["first_name"],st["last_name"],st["grade"],st["birth_date"],st["gender"],st["email"],st["phone"],st["address"],st["homeroom"],st["status"],json.dumps([]))
                        if existing:
                            conn.execute("""UPDATE students SET student_number=?,first_name=?,last_name=?,grade=?,birth_date=?,gender=?,email=?,phone=?,address=?,homeroom=?,status=? WHERE id=?""",values[:-1]+(existing["id"],)); updated+=1
                        else:
                            conn.execute("""INSERT INTO students(student_number,first_name,last_name,grade,birth_date,gender,email,phone,address,homeroom,status,registration_blocked_courses) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",values); created+=1
                    conn.commit()
                finally:
                    conn.close()
                audit(user,"Bulk imported","Students",created+updated,f"{created} created, {updated} updated, {skipped} skipped")
                return self.send_json({"ok":1,"created":created,"updated":updated,"skipped":skipped,"errors":errors})

            if path == "/api/students/update":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                target_id=int(data.get("id") or 0)
                run("""UPDATE students SET student_number=?,first_name=?,last_name=?,grade=?,birth_date=?,gender=?,email=?,phone=?,address=?,homeroom=?,status=?,registration_blocked_courses=? WHERE id=?""",(data.get("student_number",""),data.get("first_name",""),data.get("last_name",""),data.get("grade",""),data.get("birth_date",""),data.get("gender",""),data.get("email",""),data.get("phone",""),data.get("address",""),data.get("homeroom",""),data.get("status","Active"),json.dumps(data.get("registration_blocked_courses") or []),target_id))
                audit(user,"Updated","Students",target_id)
                return self.send_json({"ok":1})

            if path == "/api/staff/update":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                target_id=int(data.get("id") or 0)
                run("UPDATE staff SET employee_number=?,name=?,role=?,email=?,phone=?,school=?,status=?,eligible_course_ids=? WHERE id=?",(data.get("employee_number",""),data.get("name",""),data.get("role","Teacher"),data.get("email",""),data.get("phone",""),data.get("school",""),data.get("status","Active"),json.dumps(data.get("eligible_course_ids") or []),target_id))
                audit(user,"Updated","Staff",target_id)
                return self.send_json({"ok":1})

            if path == "/api/gpa-settings/update":
                if role != "admin":
                    return self.send_json({"error":"Only administrators can change GPA settings."},403)
                vals=(float(data.get("regular_multiplier") or 1.0),float(data.get("honors_multiplier") or 1.05),float(data.get("ap_multiplier") or 1.08),float(data.get("dual_credit_multiplier") or 1.0),float(data.get("gpa_divisor") or 25.0))
                run("""INSERT INTO gpa_settings(id,regular_multiplier,honors_multiplier,ap_multiplier,dual_credit_multiplier,gpa_divisor,updated_at) VALUES(1,?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET regular_multiplier=excluded.regular_multiplier,honors_multiplier=excluded.honors_multiplier,ap_multiplier=excluded.ap_multiplier,dual_credit_multiplier=excluded.dual_credit_multiplier,gpa_divisor=excluded.gpa_divisor,updated_at=CURRENT_TIMESTAMP""",vals)
                audit(user,"Updated","GPA Settings",1)
                return self.send_json({"ok":1})

            if path == "/api/courses/import-preview":
                if role not in {"admin","teacher"}:
                    return self.send_json({"error":"Permission denied"},403)
                try:
                    blob=base64.b64decode(data.get("content_base64") or "", validate=True)
                    parsed=parse_course_import(data.get("filename", "courses.csv"), blob)
                    return self.send_json({"rows":parsed,"count":len(parsed)})
                except Exception as exc:
                    return self.send_json({"error":"Could not read that file: "+str(exc)},400)

            if path == "/api/courses/bulk":
                if role not in {"admin","teacher"}:
                    return self.send_json({"error":"Permission denied"},403)
                items=data.get("courses") or []
                if not isinstance(items,list) or not items:
                    return self.send_json({"error":"Add at least one course."},400)
                if len(items)>1000:
                    return self.send_json({"error":"A maximum of 1,000 courses may be added at once."},400)
                creator=int(user.get("staff_id") or 0) or None
                created=updated=skipped=0; errors=[]
                conn=db_connect()
                try:
                    for idx, raw in enumerate(items, start=1):
                        c=normalize_course_import_row(raw)
                        if not c["name"]:
                            errors.append({"row":idx,"error":"Course name is required"}); skipped+=1; continue
                        existing=None
                        if c["code"]: existing=conn.execute("SELECT id,created_by_staff_id FROM courses WHERE LOWER(code)=LOWER(?)",(c["code"],)).fetchone()
                        if existing and role=="teacher" and existing["created_by_staff_id"] not in {None,creator}:
                            errors.append({"row":idx,"error":"A course with this code belongs to another staff member"}); skipped+=1; continue
                        values=(c["code"],c["name"],c["department"],c["credits"],c["grade_levels"],creator,c["requestable"],c["course_level"],c["gpa_multiplier"])
                        if existing:
                            conn.execute("UPDATE courses SET code=?,name=?,department=?,credits=?,grade_levels=?,created_by_staff_id=COALESCE(created_by_staff_id,?),requestable=?,course_level=?,gpa_multiplier=? WHERE id=?",values+(existing["id"],)); updated+=1
                        else:
                            conn.execute("INSERT INTO courses(code,name,department,credits,grade_levels,created_by_staff_id,requestable,course_level,gpa_multiplier) VALUES(?,?,?,?,?,?,?,?,?)",values); created+=1
                    conn.commit()
                finally:
                    conn.close()
                audit(user,"Bulk imported","Courses",created+updated)
                return self.send_json({"ok":1,"created":created,"updated":updated,"skipped":skipped,"errors":errors})

            if path == "/api/courses/update":
                if role not in {"admin","teacher"}:
                    return self.send_json({"error": "Permission denied"}, 403)
                target_id=int(data.get("id") or 0)
                course=one("SELECT * FROM courses WHERE id=?",(target_id,))
                if not course: return self.send_json({"error":"Course not found"},404)
                if role=="teacher" and user.get("staff_id") and course.get("created_by_staff_id") not in {None,user.get("staff_id")}:
                    return self.send_json({"error":"Teachers may edit only courses they created."},403)
                creator=course.get("created_by_staff_id") or int(user.get("staff_id") or 0) or None
                level=data.get("course_level","Regular")
                multiplier=float(data.get("gpa_multiplier") or {"Regular":1.00,"Honors":1.05,"AP":1.08,"Dual Credit":1.00}.get(level,1.00))
                run("UPDATE courses SET code=?,name=?,department=?,credits=?,grade_levels=?,created_by_staff_id=?,requestable=?,course_level=?,gpa_multiplier=? WHERE id=?",(data.get("code",""),data.get("name",""),data.get("department",""),float(data.get("credits") or 1),data.get("grade_levels",""),creator,1 if str(data.get("requestable","1")) not in {"0","false","False"} else 0,level,multiplier,target_id))
                audit(user,"Updated","Courses",target_id)
                return self.send_json({"ok":1})

            if path == "/api/classes/update":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                target_id=int(data.get("id") or 0)
                _course_id=int(data.get("course_id") or 0) or None;_teacher_id=int(data.get("teacher_id") or 0) or None
                if _teacher_id and _course_id and not teacher_eligible_for_course(_teacher_id,_course_id):
                    return self.send_json({"error":"That teacher is not marked eligible to teach this course. Update the teacher's Teaching Eligibility first."},409)
                run("""UPDATE classes SET course_id=?,name=?,section=?,period=?,room=?,teacher_id=?,term=?,capacity=?,school=? WHERE id=?""",(_course_id,data.get("name",""),data.get("section",""),data.get("period",""),data.get("room",""),_teacher_id,data.get("term",""),max(1,int(data.get("capacity") or 30)),data.get("school",""),target_id))
                audit(user,"Updated","Classes",target_id)
                return self.send_json({"ok":1})

            if path == "/api/students":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                new_id = run(
                    """
                    INSERT INTO students(student_number,first_name,last_name,grade,birth_date,gender,email,phone,address,homeroom,status,registration_blocked_courses)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (
                        data.get("student_number"),
                        data["first_name"],
                        data["last_name"],
                        data.get("grade", ""),
                        data.get("birth_date", ""),
                        data.get("gender", ""),
                        data.get("email", ""),
                        data.get("phone", ""),
                        data.get("address", ""),
                        data.get("homeroom", ""),
                        data.get("status", "Active"),
                        json.dumps(data.get("registration_blocked_courses") or []),
                    ),
                )
                audit(user, "Created", "Students", new_id)
                return self.send_json({"id": new_id})

            if path == "/api/staff":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                new_id = run(
                    "INSERT INTO staff(employee_number,name,role,email,phone,school,status,eligible_course_ids) VALUES(?,?,?,?,?,?,?,?)",
                    (
                        data.get("employee_number", ""),
                        data["name"],
                        data.get("role", "Teacher"),
                        data.get("email", ""),
                        data.get("phone", ""),
                        data.get("school", ""),
                        data.get("status", "Active"),
                        json.dumps(data.get("eligible_course_ids") or []),
                    ),
                )
                audit(user, "Created", "Staff", new_id)
                return self.send_json({"id": new_id})

            if path == "/api/courses":
                if role not in {"admin","teacher"}:
                    return self.send_json({"error": "Permission denied"}, 403)
                creator=int(user.get("staff_id") or 0) or None
                level=data.get("course_level","Regular")
                multiplier=float(data.get("gpa_multiplier") or {"Regular":1.00,"Honors":1.05,"AP":1.08,"Dual Credit":1.00}.get(level,1.00))
                new_id=run("INSERT INTO courses(code,name,department,credits,grade_levels,created_by_staff_id,requestable,course_level,gpa_multiplier) VALUES(?,?,?,?,?,?,?,?,?)",(data.get("code", ""),data["name"],data.get("department", ""),float(data.get("credits") or 1),data.get("grade_levels", ""),creator,1 if str(data.get("requestable","1")) not in {"0","false","False"} else 0,level,multiplier))
                return self.send_json({"id":new_id})

            if path == "/api/scheduler/live-section":
                if role != "admin":
                    return self.send_json({"error":"Permission denied"},403)
                action=str(data.get("action") or "create").lower()
                if action not in {"create","activate","unpublish"}:
                    return self.send_json({"error":"Unknown live-section action"},400)
                if action == "unpublish":
                    class_id=int(data.get("class_id") or 0)
                    if not class_id or not one("SELECT id FROM classes WHERE id=?",(class_id,)):
                        return self.send_json({"error":"Class section not found"},404)
                    run("UPDATE classes SET published=0 WHERE id=?",(class_id,))
                    audit(user,"Removed from live schedule","Classes",class_id)
                    return self.send_json({"ok":1,"class_id":class_id})

                class_id=int(data.get("class_id") or 0) if action=="activate" else 0
                existing=one("SELECT * FROM classes WHERE id=?",(class_id,)) if class_id else None
                if action=="activate" and not existing:
                    return self.send_json({"error":"Class section not found"},404)
                course_id=int(data.get("course_id") or (existing or {}).get("course_id") or 0) or None
                teacher_id=int(data.get("teacher_id") or (existing or {}).get("teacher_id") or 0) or None
                name=str(data.get("name") or (existing or {}).get("name") or "").strip()
                section=str(data.get("section") if data.get("section") is not None else (existing or {}).get("section") or "").strip()
                period=str(data.get("period") or (existing or {}).get("period") or "").strip()
                room=str(data.get("room") if data.get("room") is not None else (existing or {}).get("room") or "").strip()
                term=str(data.get("term") or (existing or {}).get("term") or "").strip()
                school=str(data.get("school") if data.get("school") is not None else (existing or {}).get("school") or "").strip()
                cycle_day=max(1,int(data.get("cycle_day") or (existing or {}).get("cycle_day") or 1))
                capacity=max(1,int(data.get("capacity") or (existing or {}).get("capacity") or 30))
                if not course_id or not name or not period or not term:
                    return self.send_json({"error":"Course, section name, period, and term are required"},400)
                if teacher_id and not teacher_eligible_for_course(teacher_id,course_id):
                    return self.send_json({"error":"That teacher is not marked eligible to teach this course."},409)
                exclude=(class_id,) if class_id else ()
                extra=" AND id<>?" if class_id else ""
                if teacher_id:
                    hit=one("SELECT id,name,section FROM classes WHERE teacher_id=? AND term=? AND COALESCE(cycle_day,1)=? AND period=? AND COALESCE(published,0)=1"+extra,(teacher_id,term,cycle_day,period)+exclude)
                    if hit:
                        return self.send_json({"error":f"Teacher conflict: this teacher already has {hit['name']} {hit.get('section') or ''} in {period}."},409)
                if room:
                    hit=one("SELECT id,name,section FROM classes WHERE room=? AND term=? AND COALESCE(cycle_day,1)=? AND period=? AND COALESCE(published,0)=1"+extra,(room,term,cycle_day,period)+exclude)
                    if hit:
                        return self.send_json({"error":f"Room conflict: {room} is already used by {hit['name']} {hit.get('section') or ''} in {period}."},409)
                if action=="create":
                    class_id=run("""INSERT INTO classes(course_id,name,section,period,room,teacher_id,term,capacity,school,generated,published,cycle_day) VALUES(?,?,?,?,?,?,?,?,?,0,1,?)""",(course_id,name,section,period,room,teacher_id,term,capacity,school,cycle_day))
                    audit(user,"Created live schedule section","Classes",class_id)
                else:
                    run("UPDATE classes SET course_id=?,name=?,section=?,period=?,room=?,teacher_id=?,term=?,capacity=?,school=?,published=1,cycle_day=? WHERE id=?",(course_id,name,section,period,room,teacher_id,term,capacity,school,cycle_day,class_id))
                    audit(user,"Activated live schedule section","Classes",class_id)

                requested=data.get("student_ids") or []
                if not isinstance(requested,list): requested=[]
                enrolled=[]; conflicts=[]
                current_count=int((one("SELECT COUNT(*) n FROM enrollments WHERE class_id=? AND COALESCE(status,'Active')='Active'",(class_id,)) or {}).get("n") or 0)
                for raw_sid in requested:
                    try: sid=int(raw_sid)
                    except Exception: continue
                    st=one("SELECT id,first_name,last_name FROM students WHERE id=? AND COALESCE(status,'Active')='Active'",(sid,))
                    if not st: continue
                    already=one("SELECT 1 ok FROM enrollments WHERE class_id=? AND student_id=? AND COALESCE(status,'Active')='Active'",(class_id,sid))
                    if already:
                        enrolled.append(sid); continue
                    if current_count>=capacity:
                        conflicts.append({"student_id":sid,"student_name":f"{st['first_name']} {st['last_name']}","reason":"Section is full"}); continue
                    hit=one("""SELECT c.id,c.name,c.section FROM enrollments e JOIN classes c ON c.id=e.class_id WHERE e.student_id=? AND COALESCE(e.status,'Active')='Active' AND COALESCE(c.published,0)=1 AND c.term=? AND COALESCE(c.cycle_day,1)=? AND c.period=? AND c.id<>? LIMIT 1""",(sid,term,cycle_day,period,class_id))
                    if hit:
                        conflicts.append({"student_id":sid,"student_name":f"{st['first_name']} {st['last_name']}","reason":f"Conflicts with {hit['name']} {hit.get('section') or ''}"}); continue
                    run("INSERT OR REPLACE INTO enrollments(class_id,student_id,status,start_date,end_date) VALUES(?,?, 'Active', date('now'),'')",(class_id,sid))
                    enrolled.append(sid);current_count+=1
                return self.send_json({"ok":1,"class_id":class_id,"enrolled":enrolled,"conflicts":conflicts,"published":1})

            if path == "/api/classes":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                _course_id=int(data.get("course_id") or 0) or None;_teacher_id=int(data.get("teacher_id") or 0) or None
                if _teacher_id and _course_id and not teacher_eligible_for_course(_teacher_id,_course_id):
                    return self.send_json({"error":"That teacher is not marked eligible to teach this course. Update the teacher's Teaching Eligibility first."},409)
                data["_validated_course_id"]=_course_id;data["_validated_teacher_id"]=_teacher_id
                new_id = run(
                    """
                    INSERT INTO classes(course_id,name,section,period,room,teacher_id,term,capacity,school,generated)
                    VALUES(?,?,?,?,?,?,?,?,?,0)
                    """,
                    (
                        data.get("_validated_course_id"),
                        data["name"],
                        data.get("section", ""),
                        data.get("period", ""),
                        data.get("room", ""),
                        data.get("_validated_teacher_id"),
                        data.get("term", ""),
                        max(1, int(data.get("capacity") or 30)),
                        data.get("school", ""),
                    ),
                )
                return self.send_json({"id": new_id})

            if path == "/api/enroll":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                run(
                    "INSERT OR REPLACE INTO enrollments(class_id,student_id,status,start_date,end_date) VALUES(?,?,?,?,?)",
                    (
                        int(data["class_id"]),
                        int(data["student_id"]),
                        data.get("status", "Active"),
                        data.get("start_date", ""),
                        data.get("end_date", ""),
                    ),
                )
                return self.send_json({"ok": 1})

            if path == "/api/gradebook-settings":
                class_id=int(data.get("class_id") or 0)
                if role not in {"admin","teacher"} or not allowed(class_id,cids): return self.send_json({"error":"Permission denied"},403)
                weights=data.get("category_weights") or {}
                if not isinstance(weights,dict): return self.send_json({"error":"Category weights must be an object"},400)
                clean={str(k).strip():max(0,float(v or 0)) for k,v in weights.items() if str(k).strip()}
                run("INSERT INTO gradebook_settings(class_id,category_weights,drop_lowest,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(class_id) DO UPDATE SET category_weights=excluded.category_weights,drop_lowest=excluded.drop_lowest,updated_at=CURRENT_TIMESTAMP",(class_id,json.dumps(clean),max(0,int(data.get("drop_lowest") or 0))))
                audit(user,"Updated gradebook settings","Gradebook",class_id,json.dumps(clean))
                return self.send_json({"ok":1})

            if path == "/api/graduation-requirements":
                if role!="admin": return self.send_json({"error":"Permission denied"},403)
                items=data.get("items") or []
                c=db_connect()
                try:
                    c.execute("BEGIN IMMEDIATE")
                    c.execute("DELETE FROM graduation_requirements")
                    for i,x in enumerate(items):
                        c.execute("INSERT INTO graduation_requirements(name,subject_area,credits_required,sort_order,active) VALUES(?,?,?,?,1)",((x.get('name') or '').strip(),(x.get('subject_area') or '').strip(),float(x.get('credits_required') or 0),i+1))
                    c.commit()
                except Exception: c.rollback(); raise
                finally: c.close()
                audit(user,"Updated graduation requirements","Academic Planning",None,f"{len(items)} requirements")
                return self.send_json({"ok":1})

            if path == "/api/academic-plan":
                if role not in {"admin","counselor","student"}: return self.send_json({"error":"Permission denied"},403)
                sid=int(data.get('student_id') or user.get('student_id') or 0)
                if role=='student' and sid!=int(user.get('student_id') or 0): return self.send_json({"error":"Permission denied"},403)
                cid=int(data.get('course_id') or 0) or None
                course=one("SELECT * FROM courses WHERE id=?",(cid,)) if cid else None
                name=(data.get('course_name') or (course.get('name') if course else '') or '').strip()
                if not name:return self.send_json({"error":"Choose or enter a course"},400)
                run("INSERT INTO academic_plan_items(student_id,grade_level,school_year,course_id,course_name,subject_area,credits,status,counselor_note) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(student_id,grade_level,course_name) DO UPDATE SET school_year=excluded.school_year,course_id=excluded.course_id,subject_area=excluded.subject_area,credits=excluded.credits,status=excluded.status,counselor_note=excluded.counselor_note",(sid,int(data.get('grade_level') or 9),data.get('school_year',''),cid,name,data.get('subject_area') or (course.get('department') if course else ''),float(data.get('credits') if data.get('credits') not in {None,''} else (course.get('credits') if course else 0)),data.get('status','Planned'),data.get('counselor_note','')))
                audit(user,"Saved four-year plan item","Academic Planning",sid,name)
                return self.send_json({"ok":1})

            if path == "/api/academic-plan/delete":
                if role not in {"admin","counselor","student"}: return self.send_json({"error":"Permission denied"},403)
                item=one("SELECT * FROM academic_plan_items WHERE id=?",(int(data.get('id') or 0),))
                if not item:return self.send_json({"error":"Plan item not found"},404)
                if role=='student' and item['student_id']!=int(user.get('student_id') or 0):return self.send_json({"error":"Permission denied"},403)
                run("DELETE FROM academic_plan_items WHERE id=?",(item['id'],));return self.send_json({"ok":1})

            if path == "/api/college-readiness":
                if role not in {"admin","counselor","student"}: return self.send_json({"error":"Permission denied"},403)
                sid=int(data.get('student_id') or user.get('student_id') or 0)
                run("INSERT INTO college_readiness_items(student_id,category,item,due_date,status,notes) VALUES(?,?,?,?,?,?)",(sid,data.get('category','College'),data.get('item',''),data.get('due_date',''),data.get('status','Not Started'),data.get('notes','')))
                return self.send_json({"ok":1})

            if path == "/api/grading-config":
                class_id=int(data.get("class_id") or 0)
                if role not in {"admin","teacher"} or not allowed(class_id,cids): return self.send_json({"error":"Permission denied"},403)
                config=data.get("config") or {}
                semesters=config.get("semesters") or []
                if not semesters:return self.send_json({"error":"Add at least one semester or grading period"},400)
                for sem in semesters:
                    comps=sem.get("components") or []
                    if not comps or abs(sum(float(c.get("weight") or 0) for c in comps)-100)>0.01:return self.send_json({"error":f"{sem.get('name','Grading period')} component weights must total 100%"},400)
                if data.get("mode")=='combined_year' and abs(sum(float(x.get("weight") or 0) for x in semesters)-100)>0.01:return self.send_json({"error":"Semester weights must total 100% for a combined year grade"},400)
                run("INSERT INTO class_grading_config(class_id,mode,config_json,updated_by,updated_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(class_id) DO UPDATE SET mode=excluded.mode,config_json=excluded.config_json,updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP",(class_id,data.get("mode","separate_semesters"),json.dumps(config),user.get("id")))
                audit(user,"Updated grading-period setup","Gradebook",class_id,data.get("mode",""));return self.send_json({"ok":1})

            if path == "/api/grading-scale":
                if role!='admin': return self.send_json({"error":"Only an administrator can change the district grading scale"},403)
                scale=data.get("scale") or []
                if not isinstance(scale,list) or not scale: return self.send_json({"error":"Add at least one grade band"},400)
                cleaned=[]
                for item in scale:
                    letter=str(item.get("letter") or '').strip(); minimum=float(item.get("min") or 0); gpa=float(item.get("gpa") or 0)
                    if not letter: return self.send_json({"error":"Every grade band needs a letter or label"},400)
                    cleaned.append({"letter":letter,"min":minimum,"gpa":gpa})
                cleaned.sort(key=lambda x:x["min"],reverse=True)
                if cleaned[-1]["min"]!=0: return self.send_json({"error":"The lowest grade band must start at 0%"},400)
                run("INSERT INTO district_grading_scale(id,name,mode,scale_json,updated_by,updated_at) VALUES(1,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET name=excluded.name,mode=excluded.mode,scale_json=excluded.scale_json,updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP",(str(data.get("name") or 'Custom scale'),str(data.get("mode") or 'custom'),json.dumps(cleaned),user.get("id")))
                audit(user,"Updated district grading scale","Gradebook",1,str(data.get("name") or 'Custom scale')); return self.send_json({"ok":1,"scale":cleaned})

            if path == "/api/seating-chart":
                class_id=int(data.get("class_id") or 0)
                if role not in {"admin","teacher"} or not allowed(class_id,cids): return self.send_json({"error":"Permission denied"},403)
                layout=data.get("layout") or []; rows_count=max(1,min(12,int(data.get("rows_count") or 5))); columns_count=max(1,min(12,int(data.get("columns_count") or 6)))
                run("INSERT INTO seating_charts(class_id,rows_count,columns_count,layout_json,updated_by,updated_at) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(class_id) DO UPDATE SET rows_count=excluded.rows_count,columns_count=excluded.columns_count,layout_json=excluded.layout_json,updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP",(class_id,rows_count,columns_count,json.dumps(layout),user.get("id")))
                audit(user,"Saved seating chart","Attendance",class_id,f"{rows_count}x{columns_count}"); return self.send_json({"ok":1})

            if path == "/api/final-grades/finalize":
                class_id=int(data.get("class_id") or 0)
                if role not in {"admin","teacher"} or not allowed(class_id,cids): return self.send_json({"error":"Permission denied"},403)
                key=str(data.get("grading_key") or '').strip(); name=str(data.get("grading_name") or key).strip()
                if not key:return self.send_json({"error":"Choose a grading period"},400)
                c=db_connect()
                try:
                    c.execute("BEGIN IMMEDIATE")
                    for item in data.get("rows",[]):
                        sid=int(item.get("student_id") or 0); comps=item.get("component_grades") or {}; calc=item.get("calculated_grade"); final=item.get("final_grade")
                        if calc not in {None,''}:calc=float(calc)
                        if final in {None,''}:final=calc
                        else:final=float(final)
                        letter=grading_letter(final)
                        exam=item.get("final_exam_grade"); exam=None if exam in {None,''} else float(exam)
                        c.execute("INSERT INTO finalized_grades(class_id,student_id,grading_key,grading_name,component_grades_json,final_exam_grade,calculated_grade,final_grade,letter_grade,status,finalized_by,finalized_at) VALUES(?,?,?,?,?,?,?,?,?,'Final',?,CURRENT_TIMESTAMP) ON CONFLICT(class_id,student_id,grading_key) DO UPDATE SET grading_name=excluded.grading_name,component_grades_json=excluded.component_grades_json,final_exam_grade=excluded.final_exam_grade,calculated_grade=excluded.calculated_grade,final_grade=excluded.final_grade,letter_grade=excluded.letter_grade,status='Final',finalized_by=excluded.finalized_by,finalized_at=CURRENT_TIMESTAMP",(class_id,sid,key,name,json.dumps(comps),exam,calc,final,letter,user.get("id")))
                    c.commit()
                except Exception:
                    c.rollback();raise
                finally:c.close()
                audit(user,"Finalized grades","Gradebook",class_id,name);return self.send_json({"ok":1,"finalized":len(data.get("rows",[]))})

            if path == "/api/final-grades/reopen":
                if role!='admin':return self.send_json({"error":"Only an administrator can reopen final grades"},403)
                class_id=int(data.get("class_id") or 0); key=str(data.get("grading_key") or ''); reason=str(data.get("reason") or '').strip()
                if not reason:return self.send_json({"error":"Enter a reason for reopening grades"},400)
                run("UPDATE finalized_grades SET status='Reopened',reopened_by=?,reopened_at=CURRENT_TIMESTAMP,reopen_reason=? WHERE class_id=? AND grading_key=?",(user.get("id"),reason,class_id,key));audit(user,"Reopened final grades","Gradebook",class_id,reason);return self.send_json({"ok":1})


            if path == "/api/conferences":
                action=str(data.get("action") or "create").lower()
                if action in {"create","update","delete"}:
                    if role not in {"admin","teacher"}:return self.send_json({"error":"Permission denied"},403)
                    staff_id=int(data.get("staff_id") or user.get("staff_id") or 0)
                    if role=="teacher" and staff_id!=int(user.get("staff_id") or 0):return self.send_json({"error":"Permission denied"},403)
                    if action=="create":
                        start=str(data.get("start_at") or '').strip();end=str(data.get("end_at") or '').strip()
                        if not staff_id or not start or not end:return self.send_json({"error":"Teacher, start, and end times are required"},400)
                        sid=run("INSERT INTO conference_slots(staff_id,start_at,end_at,location,mode,notes,created_by) VALUES(?,?,?,?,?,?,?)",(staff_id,start,end,str(data.get("location") or ''),str(data.get("mode") or 'In Person'),str(data.get("notes") or ''),user.get("id")))
                        return self.send_json({"id":sid,"ok":1})
                    sid=int(data.get("id") or 0);rec=one("SELECT * FROM conference_slots WHERE id=?",(sid,))
                    if not rec:return self.send_json({"error":"Conference slot not found"},404)
                    if role=="teacher" and int(rec.get("staff_id") or 0)!=int(user.get("staff_id") or 0):return self.send_json({"error":"Permission denied"},403)
                    if action=="delete":
                        if one("SELECT id FROM conference_bookings WHERE slot_id=?",(sid,)):return self.send_json({"error":"Cancel the booking before deleting this slot"},409)
                        run("DELETE FROM conference_slots WHERE id=?",(sid,));return self.send_json({"ok":1})
                if action=="book":
                    if role!="parent":return self.send_json({"error":"Only parents can book conference slots"},403)
                    sid=int(data.get("student_id") or 0);slot=int(data.get("slot_id") or 0)
                    if sid not in sids:return self.send_json({"error":"Permission denied"},403)
                    rec=one("SELECT * FROM conference_slots WHERE id=? AND status='Open'",(slot,))
                    if not rec:return self.send_json({"error":"That conference slot is no longer available"},409)
                    try:bid=run("INSERT INTO conference_bookings(slot_id,student_id,parent_user_id,family_note) VALUES(?,?,?,?)",(slot,sid,user.get("id"),str(data.get("family_note") or '')))
                    except Exception:return self.send_json({"error":"That conference slot was just booked"},409)
                    run("UPDATE conference_slots SET status='Booked',updated_at=CURRENT_TIMESTAMP WHERE id=?",(slot,));return self.send_json({"id":bid,"ok":1})
                if action=="cancel-booking":
                    bid=int(data.get("booking_id") or 0);b=one("SELECT cb.*,cs.staff_id FROM conference_bookings cb JOIN conference_slots cs ON cs.id=cb.slot_id WHERE cb.id=?",(bid,))
                    if not b:return self.send_json({"error":"Booking not found"},404)
                    ok=role=='admin' or (role=='teacher' and int(b.get('staff_id') or 0)==int(user.get('staff_id') or 0)) or (role=='parent' and int(b.get('student_id') or 0) in sids)
                    if not ok:return self.send_json({"error":"Permission denied"},403)
                    run("DELETE FROM conference_bookings WHERE id=?",(bid,));run("UPDATE conference_slots SET status='Open',updated_at=CURRENT_TIMESTAMP WHERE id=?",(b['slot_id'],));return self.send_json({"ok":1})
                return self.send_json({"error":"Unknown conference action"},400)

            if path == "/api/substitute/assignments":
                if role!="admin": return self.send_json({"error":"Permission denied"},403)
                action=str(data.get("action") or "create").lower()
                if action=="create":
                    sub=int(data.get("substitute_staff_id") or 0);teacher=int(data.get("teacher_staff_id") or 0);start=str(data.get("start_date") or '').strip();end=str(data.get("end_date") or start).strip()
                    coverage_mode=str(data.get('coverage_mode') or 'all').lower().strip()
                    raw_selected=data.get('selected_class_ids') or []
                    if isinstance(raw_selected,str):
                        try: raw_selected=json.loads(raw_selected)
                        except Exception: raw_selected=[x for x in raw_selected.split(',') if x.strip()]
                    selected_ids=sorted({int(x) for x in raw_selected if str(x).strip()})
                    if coverage_mode not in {'all','selected'}: coverage_mode='all'
                    if not sub or not teacher or not start:return self.send_json({"error":"Substitute, teacher, and dates are required"},400)
                    if coverage_mode=='selected' and end!=start:return self.send_json({"error":"Selected-period coverage is currently limited to one day. Use All classes for a multi-day assignment."},400)
                    if coverage_mode=='selected' and not selected_ids:return self.send_json({"error":"Choose at least one class/period to cover"},400)
                    if end<start:return self.send_json({"error":"End date cannot be before start date"},400)
                    if not one("SELECT id FROM staff WHERE id=? AND COALESCE(status,'Active')='Active'",(sub,)):return self.send_json({"error":"Substitute staff member not found"},404)
                    if not one("SELECT id FROM staff WHERE id=? AND COALESCE(status,'Active')='Active'",(teacher,)):return self.send_json({"error":"Teacher staff member not found"},404)
                    if sub==teacher:return self.send_json({"error":"A teacher cannot cover their own absence"},400)
                    if coverage_mode=='selected':
                        available={int(x.get('id') or 0) for x in teacher_classes_for_date(teacher,start)}
                        invalid=[x for x in selected_ids if x not in available]
                        if invalid:return self.send_json({"error":"One or more selected classes do not meet for this teacher on the coverage date"},400)
                    overlap=one("SELECT id FROM substitute_assignments WHERE substitute_staff_id=? AND status='Active' AND NOT(end_date<? OR start_date>?) LIMIT 1",(sub,start,end))
                    if overlap:return self.send_json({"error":"This substitute already has an overlapping active assignment"},409)
                    sub_staff=one("SELECT id,role,name FROM staff WHERE id=?",(sub,)) or {}
                    if 'teacher' in str(sub_staff.get('role') or '').lower():
                        d0=datetime.strptime(start,'%Y-%m-%d').date(); d1=datetime.strptime(end,'%Y-%m-%d').date()
                        d=d0
                        while d<=d1:
                            ds=d.isoformat()
                            own=teacher_classes_for_date(sub,ds)
                            covered=teacher_classes_for_date(teacher,ds)
                            if coverage_mode=='selected': covered=[x for x in covered if int(x.get('id') or 0) in set(selected_ids)]
                            for oc in own:
                                for cc in covered:
                                    os=str(oc.get('start_time') or ''); oe=str(oc.get('end_time') or '')
                                    cs=str(cc.get('start_time') or ''); ce=str(cc.get('end_time') or '')
                                    clashes = bool(os and oe and cs and ce and os < ce and cs < oe)
                                    if not (os and oe and cs and ce):
                                        clashes = clashes or (str(oc.get('period') or '') and str(oc.get('period') or '')==str(cc.get('period') or ''))
                                    if clashes:
                                        return self.send_json({"error":f"{sub_staff.get('name') or 'This teacher'} is already teaching {oc.get('name') or 'a class'} on {ds} during this coverage time"},409)
                            d += timedelta(days=1)
                    aid=run("INSERT INTO substitute_assignments(substitute_staff_id,teacher_staff_id,start_date,end_date,status,reason,admin_notes,created_by,coverage_mode,selected_class_ids) VALUES(?,?,?,?,?,?,?,?,?,?)",(sub,teacher,start,end,'Active',str(data.get('reason') or ''),str(data.get('admin_notes') or ''),user.get('id'),coverage_mode,json.dumps(selected_ids)))
                    audit(user,"Created substitute assignment","Substitutes",aid,{"substitute_staff_id":sub,"teacher_staff_id":teacher,"start":start,"end":end,"coverage_mode":coverage_mode,"selected_class_ids":selected_ids});return self.send_json({"ok":1,"id":aid})
                aid=int(data.get("id") or 0);a=one("SELECT * FROM substitute_assignments WHERE id=?",(aid,))
                if not a:return self.send_json({"error":"Assignment not found"},404)
                if action=="cancel":
                    run("UPDATE substitute_assignments SET status='Cancelled',updated_at=CURRENT_TIMESTAMP WHERE id=?",(aid,));audit(user,"Cancelled substitute assignment","Substitutes",aid);return self.send_json({"ok":1})
                if action=="reactivate":
                    run("UPDATE substitute_assignments SET status='Active',updated_at=CURRENT_TIMESTAMP WHERE id=?",(aid,));audit(user,"Reactivated substitute assignment","Substitutes",aid);return self.send_json({"ok":1})
                if action=="update":
                    start=str(data.get('start_date') or a['start_date']);end=str(data.get('end_date') or a['end_date'])
                    if end<start:return self.send_json({"error":"End date cannot be before start date"},400)
                    run("UPDATE substitute_assignments SET start_date=?,end_date=?,reason=?,admin_notes=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(start,end,str(data.get('reason') or a.get('reason') or ''),str(data.get('admin_notes') or a.get('admin_notes') or ''),aid));audit(user,"Updated substitute assignment","Substitutes",aid);return self.send_json({"ok":1})
                return self.send_json({"error":"Invalid action"},400)

            if path == "/api/substitute/coverage":
                if role not in {"admin","teacher","substitute"}:return self.send_json({"error":"Permission denied"},403)
                aid=int(data.get('assignment_id') or 0);cid=int(data.get('class_id') or 0);day=str(data.get('date') or '').strip();a=one("SELECT * FROM substitute_assignments WHERE id=?",(aid,))
                if not a or not day or not (a['start_date']<=day<=a['end_date']):return self.send_json({"error":"Invalid substitute assignment/date"},403)
                if not one("SELECT id FROM classes WHERE id=? AND teacher_id=?",(cid,a['teacher_staff_id'])):return self.send_json({"error":"Class is not part of this assignment"},403)
                if not substitute_class_allowed(a,cid):return self.send_json({"error":"Class is not selected for this substitute assignment"},403)
                if role=='teacher' and int(user.get('staff_id') or 0) not in {int(a['teacher_staff_id']),int(a['substitute_staff_id'])}:return self.send_json({"error":"Permission denied"},403)
                if role=='substitute' and int(user.get('staff_id') or 0)!=int(a['substitute_staff_id']):return self.send_json({"error":"Permission denied"},403)
                current=one("SELECT * FROM substitute_coverage WHERE assignment_id=? AND class_id=? AND coverage_date=?",(aid,cid,day)) or {}
                acting_sub = role=='substitute' or (role=='teacher' and int(user.get('staff_id') or 0)==int(a['substitute_staff_id']) and int(a['substitute_staff_id'])!=int(a['teacher_staff_id']))
                if acting_sub:
                    lesson_plan=current.get('lesson_plan','');lesson_links=current.get('lesson_links','');teacher_notes=current.get('teacher_notes','');sub_notes=str(data.get('substitute_notes') or current.get('substitute_notes') or '')
                else:
                    lesson_plan=str(data.get('lesson_plan') if 'lesson_plan' in data else current.get('lesson_plan',''));lesson_links=str(data.get('lesson_links') if 'lesson_links' in data else current.get('lesson_links',''));teacher_notes=str(data.get('teacher_notes') if 'teacher_notes' in data else current.get('teacher_notes',''));sub_notes=current.get('substitute_notes','') if role=='teacher' else str(data.get('substitute_notes') if 'substitute_notes' in data else current.get('substitute_notes',''))
                run("""INSERT INTO substitute_coverage(assignment_id,class_id,coverage_date,lesson_plan,lesson_links,teacher_notes,substitute_notes,attendance_completed,updated_by,updated_at) VALUES(?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
                     ON CONFLICT(assignment_id,class_id,coverage_date) DO UPDATE SET lesson_plan=excluded.lesson_plan,lesson_links=excluded.lesson_links,teacher_notes=excluded.teacher_notes,substitute_notes=excluded.substitute_notes,updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP""",(aid,cid,day,lesson_plan,lesson_links,teacher_notes,sub_notes,int(current.get('attendance_completed') or 0),user.get('id')))
                audit(user,"Updated substitute coverage notes","Substitutes",aid,{"class_id":cid,"date":day});return self.send_json({"ok":1})

            if path == "/api/substitute/attendance":
                if role not in {"admin","teacher","substitute"}:return self.send_json({"error":"Permission denied"},403)
                aid=int(data.get('assignment_id') or 0);cid=int(data.get('class_id') or 0);day=str(data.get('date') or '').strip();a=one("SELECT * FROM substitute_assignments WHERE id=? AND status='Active'",(aid,))
                if not a or not day or not (a['start_date']<=day<=a['end_date']):return self.send_json({"error":"Substitute assignment is not active for this date"},403)
                if role=='substitute' and int(user.get('staff_id') or 0)!=int(a['substitute_staff_id']):return self.send_json({"error":"Permission denied"},403)
                if role=='teacher' and int(user.get('staff_id') or 0)!=int(a['substitute_staff_id']):return self.send_json({"error":"Permission denied"},403)
                if not one("SELECT id FROM classes WHERE id=? AND teacher_id=?",(cid,a['teacher_staff_id'])):return self.send_json({"error":"Class is not covered by this assignment"},403)
                if not substitute_class_allowed(a,cid):return self.send_json({"error":"Class is not selected for this substitute assignment"},403)
                valid={r['student_id'] for r in rows("SELECT student_id FROM enrollments WHERE class_id=? AND COALESCE(status,'Active')='Active'",(cid,))};saved=0
                c=db_connect()
                try:
                    c.execute('BEGIN IMMEDIATE')
                    for item in data.get('records') or []:
                        sid=int(item.get('student_id') or 0)
                        if sid not in valid:continue
                        declared=one("SELECT status,reason,note FROM daily_absences WHERE student_id=? AND absence_date=?",(sid,day))
                        st=normalize_attendance_status(item.get('status'))
                        note=str(item.get('note') or '')
                        if declared:
                            st=normalize_attendance_status(declared.get('status') or 'AU')
                            note=declared.get('note') or declared.get('reason') or 'All-day absence'
                        if not st:
                            c.execute("DELETE FROM attendance WHERE class_id=? AND student_id=? AND date=?",(cid,sid,day));continue
                        mins=max(0,int(float(item.get('minutes_late') or 0))) if st in {'TE','TU'} else 0
                        c.execute("""INSERT INTO attendance(class_id,student_id,date,status,minutes_late,note,updated_at) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(class_id,student_id,date) DO UPDATE SET status=excluded.status,minutes_late=excluded.minutes_late,note=excluded.note,updated_at=CURRENT_TIMESTAMP""",(cid,sid,day,st,mins,note));saved+=1
                    c.execute("""INSERT INTO substitute_coverage(assignment_id,class_id,coverage_date,attendance_completed,updated_by,updated_at) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(assignment_id,class_id,coverage_date) DO UPDATE SET attendance_completed=1,updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP""",(aid,cid,day,1,user.get('id')));c.commit()
                except Exception:
                    c.rollback();raise
                finally:c.close()
                audit(user,"Saved substitute attendance","Attendance",cid,{"assignment_id":aid,"date":day,"saved":saved});return self.send_json({"ok":1,"saved":saved})

            if path == "/api/emergency/incidents":
                if role!="admin":return self.send_json({"error":"Only administrators can manage emergency incidents"},403)
                action=str(data.get("action") or "start").lower()
                if action=="start":
                    itype=str(data.get("incident_type") or "Emergency").strip()
                    title=str(data.get("title") or itype).strip()
                    is_drill=1 if str(data.get("is_drill") or "").lower() in {"1","true","yes","on"} or data.get("is_drill") is True else 0
                    if one("SELECT id FROM emergency_incidents WHERE status='Active' LIMIT 1"):
                        return self.send_json({"error":"An emergency incident or drill is already active"},409)
                    iid=run("INSERT INTO emergency_incidents(incident_type,title,instructions,assembly_location,notes,started_by,is_drill) VALUES(?,?,?,?,?,?,?)",(itype,title,str(data.get("instructions") or ""),str(data.get("assembly_location") or ""),str(data.get("notes") or ""),user.get("id"),is_drill))
                    run("""INSERT OR IGNORE INTO emergency_accountability(incident_id,student_id,status)
                           SELECT ?,id,CASE WHEN status='Active' THEN 'Unaccounted' ELSE 'Absent' END FROM students""",(iid,))
                    tzrec=one("SELECT setting_value FROM district_settings WHERE setting_key='school_timezone'");school_dt,_=school_now((tzrec or {}).get('setting_value') or 'America/Chicago');incident_day=school_dt.strftime('%Y-%m-%d')
                    # A student already recorded absent in any period (or declared absent all day)
                    # is automatically excluded from emergency accountability.
                    run("""UPDATE emergency_accountability SET status='Absent',note='Automatically marked absent from attendance',checked_by=?,updated_at=CURRENT_TIMESTAMP
                           WHERE incident_id=? AND student_id IN (
                             SELECT student_id FROM daily_absences WHERE absence_date=?
                             UNION SELECT DISTINCT student_id FROM attendance WHERE date=? AND status IN ('AE','AU')
                           )""",(user.get('id'),iid,incident_day,incident_day))
                    run("""INSERT OR IGNORE INTO emergency_staff_checkins(incident_id,staff_id,status)
                           SELECT ?,id,'Unaccounted' FROM staff WHERE COALESCE(status,'Active')='Active'""",(iid,))
                    audit(user,"Started emergency drill" if is_drill else "Started emergency incident","Emergency",iid,{"type":itype,"is_drill":bool(is_drill)});return self.send_json({"ok":1,"id":iid,"is_drill":bool(is_drill)})
                iid=int(data.get("id") or 0);inc=one("SELECT * FROM emergency_incidents WHERE id=?",(iid,))
                if not inc:return self.send_json({"error":"Incident not found"},404)
                if action=="update":
                    drill_value=inc.get('is_drill',0)
                    if 'is_drill' in data: drill_value=1 if data.get('is_drill') in (True,1,'1','true','yes','on') else 0
                    run("UPDATE emergency_incidents SET title=?,instructions=?,assembly_location=?,notes=?,is_drill=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(str(data.get("title") or inc.get("title") or ""),str(data.get("instructions") or inc.get("instructions") or ""),str(data.get("assembly_location") or inc.get("assembly_location") or ""),str(data.get("notes") or inc.get("notes") or ""),drill_value,iid))
                elif action=="resolve":
                    run("UPDATE emergency_incidents SET status='Resolved',ended_by=?,ended_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?",(user.get("id"),iid))
                elif action=="reopen":
                    if one("SELECT id FROM emergency_incidents WHERE status='Active' AND id<>? LIMIT 1",(iid,)):return self.send_json({"error":"Another incident is already active"},409)
                    run("UPDATE emergency_incidents SET status='Active',ended_by=NULL,ended_at=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?",(iid,))
                else:return self.send_json({"error":"Unknown incident action"},400)
                audit(user,"Emergency incident "+action,"Emergency",iid);return self.send_json({"ok":1})

            if path == "/api/absence-requests":
                if role!='parent':return self.send_json({"error":"Only parents can submit absence requests"},403)
                sid=int(data.get('student_id') or 0);date=str(data.get('absence_date') or '').strip();reason=str(data.get('reason') or '').strip();details=str(data.get('details') or '').strip()
                if not sid or not allowed(sid,sids):return self.send_json({"error":"Permission denied"},403)
                if not date or not reason:return self.send_json({"error":"Student, date, and reason are required"},400)
                existing=one("SELECT id,status FROM absence_requests WHERE student_id=? AND parent_user_id=? AND absence_date=? AND status='Pending'",(sid,user.get('id'),date))
                if existing:return self.send_json({"error":"There is already a pending request for this student and date"},409)
                rid=run("INSERT INTO absence_requests(student_id,parent_user_id,absence_date,reason,details) VALUES(?,?,?,?,?)",(sid,user.get('id'),date,reason,details))
                fn=str(data.get('attachment_name') or '').strip();ft=str(data.get('attachment_type') or 'application/octet-stream').strip();fb=str(data.get('attachment_base64') or '').strip()
                if fb:
                    if len(fb)>9_000_000:return self.send_json({"error":"Doctor's note attachment is too large (5 MB maximum)"},413)
                    if not fn:fn='medical-note'
                    run("INSERT OR REPLACE INTO absence_request_attachments(request_id,file_name,file_type,file_base64) VALUES(?,?,?,?)",(rid,fn,ft,fb))
                audit(user,'Submitted absence request','Attendance',rid,{'student_id':sid,'date':date,'has_attachment':bool(fb)});return self.send_json({'ok':1,'id':rid})

            if path == "/api/absence-requests/review":
                if role!='admin':return self.send_json({"error":"Permission denied"},403)
                rid=int(data.get('id') or 0);action=str(data.get('action') or '').lower();note=str(data.get('decision_note') or '')
                req=one("SELECT * FROM absence_requests WHERE id=?",(rid,))
                if not req:return self.send_json({"error":"Request not found"},404)
                if req.get('status')!='Pending':return self.send_json({"error":"This request has already been reviewed"},409)
                legacy={'approve':'excused','deny':'unexcused'};action=legacy.get(action,action)
                if action not in {'excused','unexcused'}:return self.send_json({"error":"Choose Excused or Unexcused"},400)
                att='AE' if action=='excused' else 'AU';attendance_decision='Excused' if att=='AE' else 'Unexcused'
                run("UPDATE absence_requests SET status='Reviewed',attendance_decision=?,decision_note=?,reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?",(attendance_decision,note,user.get('id'),rid))
                applied=apply_daily_absence(req['student_id'],req['absence_date'],att,req.get('reason') or '',note or req.get('details') or '',('Parent request - '+attendance_decision),rid,user.get('id'))
                audit(user,'Reviewed parent absence request','Attendance',rid,{'student_id':req['student_id'],'date':req['absence_date'],'attendance_decision':attendance_decision,'status':att,'classes':applied});return self.send_json({'ok':1,'status':att,'attendance_decision':attendance_decision,'classes_marked':applied})

            if path == "/api/daily-absences":
                if role!='admin':return self.send_json({"error":"Permission denied"},403)
                sid=int(data.get('student_id') or 0);date=str(data.get('absence_date') or '').strip();status=str(data.get('status') or 'AU').upper();reason=str(data.get('reason') or '').strip();note=str(data.get('note') or '').strip()
                if not sid or not date:return self.send_json({"error":"Student and date are required"},400)
                if not one("SELECT id FROM students WHERE id=?",(sid,)):return self.send_json({"error":"Student not found"},404)
                if status not in {'AE','AU'}:return self.send_json({"error":"Status must be excused or unexcused"},400)
                applied=apply_daily_absence(sid,date,status,reason,note,'Admin',None,user.get('id'));audit(user,'Set all-day absence','Attendance',sid,{'date':date,'status':status,'classes':applied});return self.send_json({'ok':1,'classes_marked':applied})

            if path == "/api/emergency/accountability/bulk":
                if role not in {'admin','teacher'}:return self.send_json({"error":"Permission denied"},403)
                iid=int(data.get('incident_id') or 0);cid=int(data.get('class_id') or 0);location=str(data.get('location') or '')
                inc=one("SELECT status FROM emergency_incidents WHERE id=?",(iid,))
                if not inc:return self.send_json({"error":"Incident not found"},404)
                if inc.get('status')!='Active':return self.send_json({"error":"This emergency incident is no longer active"},409)
                cls=one("SELECT id,teacher_id FROM classes WHERE id=?",(cid,))
                if not cls:return self.send_json({"error":"Class not found"},404)
                if role=='teacher' and int(cls.get('teacher_id') or 0)!=int(user.get('staff_id') or 0):return self.send_json({"error":"You can only account for your own class"},403)
                student_ids=[r['student_id'] for r in rows("SELECT student_id FROM enrollments WHERE class_id=? AND COALESCE(status,'Active')='Active'",(cid,))]
                updated=0
                for sid in student_ids:
                    current=one("SELECT status FROM emergency_accountability WHERE incident_id=? AND student_id=?",(iid,sid))
                    if not current or current.get('status') in {'Absent','Off Campus'}:continue
                    run("UPDATE emergency_accountability SET status='Accounted',location=?,note='Whole-class accountability',checked_by=?,updated_at=CURRENT_TIMESTAMP WHERE incident_id=? AND student_id=?",(location,user.get('id'),iid,sid));updated+=1
                audit(user,'Accounted for whole class','Emergency',cid,{'incident':iid,'students':updated});return self.send_json({'ok':1,'updated':updated})

            if path == "/api/emergency/accountability":
                if role not in {"admin","teacher","counselor","nurse"}:return self.send_json({"error":"Permission denied"},403)
                iid=int(data.get("incident_id") or 0);sid=int(data.get("student_id") or 0)
                if not iid or not sid:return self.send_json({"error":"incident_id and student_id are required"},400)
                inc=one("SELECT status FROM emergency_incidents WHERE id=?",(iid,))
                if not inc:return self.send_json({"error":"Incident not found"},404)
                if inc.get("status")!="Active":return self.send_json({"error":"This emergency incident is no longer active"},409)
                if role=="teacher" and not allowed(sid,sids):return self.send_json({"error":"You can only account for students you teach"},403)
                status=str(data.get("status") or "Accounted")
                valid={"Unaccounted","Accounted","Missing","Absent","Medical","Off Campus"}
                if status not in valid:return self.send_json({"error":"Invalid accountability status"},400)
                run("""INSERT INTO emergency_accountability(incident_id,student_id,status,location,note,checked_by,updated_at) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
                       ON CONFLICT(incident_id,student_id) DO UPDATE SET status=excluded.status,location=excluded.location,note=excluded.note,checked_by=excluded.checked_by,updated_at=CURRENT_TIMESTAMP""",(iid,sid,status,str(data.get("location") or ""),str(data.get("note") or ""),user.get("id")))
                audit(user,"Updated emergency accountability","Emergency",sid,{"incident":iid,"status":status});return self.send_json({"ok":1})

            if path == "/api/emergency/staff-checkins":
                if role not in {"admin","teacher","counselor","nurse"}:return self.send_json({"error":"Permission denied"},403)
                iid=int(data.get("incident_id") or 0);staff_id=int(data.get("staff_id") or user.get("staff_id") or 0)
                if role=="teacher" and staff_id!=int(user.get("staff_id") or 0):return self.send_json({"error":"Permission denied"},403)
                if not iid or not staff_id:return self.send_json({"error":"incident_id and staff_id are required"},400)
                inc=one("SELECT status FROM emergency_incidents WHERE id=?",(iid,))
                if not inc:return self.send_json({"error":"Incident not found"},404)
                if inc.get("status")!="Active":return self.send_json({"error":"This emergency incident is no longer active"},409)
                status=str(data.get("status") or "Safe")
                if status not in {"Unaccounted","Safe","Needs Assistance","Off Campus"}:return self.send_json({"error":"Invalid staff status"},400)
                run("""INSERT INTO emergency_staff_checkins(incident_id,staff_id,status,location,note,checked_by,updated_at) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
                       ON CONFLICT(incident_id,staff_id) DO UPDATE SET status=excluded.status,location=excluded.location,note=excluded.note,checked_by=excluded.checked_by,updated_at=CURRENT_TIMESTAMP""",(iid,staff_id,status,str(data.get("location") or ""),str(data.get("note") or ""),user.get("id")))
                audit(user,"Emergency staff check-in","Emergency",staff_id,{"incident":iid,"status":status});return self.send_json({"ok":1})

            if path == "/api/reunification":
                if role not in {"admin","counselor","nurse"}:return self.send_json({"error":"Permission denied"},403)
                iid=int(data.get("incident_id") or 0);sid=int(data.get("student_id") or 0)
                if not iid or not sid:return self.send_json({"error":"incident_id and student_id are required"},400)
                inc=one("SELECT status FROM emergency_incidents WHERE id=?",(iid,))
                if not inc:return self.send_json({"error":"Incident not found"},404)
                if inc.get("status")!="Active":return self.send_json({"error":"This emergency incident is no longer active"},409)
                action=str(data.get("action") or "release").lower()
                if action=="release":
                    pickup=str(data.get("pickup_name") or "").strip()
                    if not pickup:return self.send_json({"error":"Pickup name is required"},400)
                    if not bool(data.get("id_verified")):return self.send_json({"error":"Photo ID must be verified before release"},400)
                    if not bool(data.get("authorization_verified")):return self.send_json({"error":"Pickup authorization must be verified before release"},400)
                    if one("SELECT id FROM reunification_releases WHERE incident_id=? AND student_id=?",(iid,sid)):return self.send_json({"error":"Student has already been released for this incident"},409)
                    rid=run("INSERT INTO reunification_releases(incident_id,student_id,pickup_name,relationship,id_verified,authorization_verified,released_by,notes) VALUES(?,?,?,?,1,1,?,?)",(iid,sid,pickup,str(data.get("relationship") or ""),user.get("id"),str(data.get("notes") or "")))
                    run("UPDATE emergency_accountability SET status='Released',location='Reunification',checked_by=?,updated_at=CURRENT_TIMESTAMP WHERE incident_id=? AND student_id=?",(user.get("id"),iid,sid))
                    audit(user,"Released student during reunification","Emergency",sid,{"incident":iid,"pickup":pickup});return self.send_json({"ok":1,"id":rid})
                if action=="undo":
                    if role!="admin":return self.send_json({"error":"Only administrators can undo a release"},403)
                    run("DELETE FROM reunification_releases WHERE incident_id=? AND student_id=?",(iid,sid));run("UPDATE emergency_accountability SET status='Accounted',location='',checked_by=?,updated_at=CURRENT_TIMESTAMP WHERE incident_id=? AND student_id=?",(user.get("id"),iid,sid));audit(user,"Undid reunification release","Emergency",sid,{"incident":iid});return self.send_json({"ok":1})
                return self.send_json({"error":"Unknown reunification action"},400)

            if path == "/api/clubs":
                action=str(data.get("action") or "save").lower()
                if action in {"save","delete"}:
                    if role!="admin":return self.send_json({"error":"Only administrators can manage clubs"},403)
                    cid=int(data.get("id") or 0)
                    if action=="delete":run("UPDATE clubs SET active=0,updated_at=CURRENT_TIMESTAMP WHERE id=?",(cid,));return self.send_json({"ok":1})
                    name=str(data.get("name") or '').strip()
                    if not name:return self.send_json({"error":"Club name is required"},400)
                    form=json.dumps(data.get("form") or [])
                    vals=(name,str(data.get("description") or ''),int(data.get("advisor_staff_id") or 0) or None,1 if data.get("registration_open") else 0,form,str(data.get("meeting_info") or ''),1 if data.get("active",True) else 0)
                    if cid:run("UPDATE clubs SET name=?,description=?,advisor_staff_id=?,registration_open=?,form_json=?,meeting_info=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",vals+(cid,))
                    else:cid=run("INSERT INTO clubs(name,description,advisor_staff_id,registration_open,form_json,meeting_info,active,created_by) VALUES(?,?,?,?,?,?,?,?)",vals+(user.get("id"),))
                    return self.send_json({"id":cid,"ok":1})
                if action=="register":
                    if role!="student":return self.send_json({"error":"Only students can register"},403)
                    cid=int(data.get("club_id") or 0);sid=int(user.get("student_id") or 0);c=one("SELECT * FROM clubs WHERE id=? AND active=1 AND registration_open=1",(cid,))
                    if not c:return self.send_json({"error":"Registration is not open"},409)
                    run("INSERT INTO club_registrations(club_id,student_id,answers_json,status) VALUES(?,?,?,'Registered') ON CONFLICT(club_id,student_id) DO UPDATE SET answers_json=excluded.answers_json,status='Registered',updated_at=CURRENT_TIMESTAMP",(cid,sid,json.dumps(data.get("answers") or {})))
                    return self.send_json({"ok":1})
                if action=="set-status":
                    if role not in {"admin","counselor","teacher"}:return self.send_json({"error":"Permission denied"},403)
                    rid=int(data.get("registration_id") or 0);r=one("SELECT cr.*,c.advisor_staff_id FROM club_registrations cr JOIN clubs c ON c.id=cr.club_id WHERE cr.id=?",(rid,))
                    if not r:return self.send_json({"error":"Registration not found"},404)
                    if role=='teacher' and int(r.get('advisor_staff_id') or 0)!=int(user.get('staff_id') or 0):return self.send_json({"error":"Permission denied"},403)
                    run("UPDATE club_registrations SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(str(data.get("status") or 'Registered'),rid));return self.send_json({"ok":1})
                if action=="add-event":
                    cid=int(data.get("club_id") or 0);c=one("SELECT advisor_staff_id FROM clubs WHERE id=?",(cid,))
                    if role not in {"admin","teacher"} or (role=='teacher' and int(c.get('advisor_staff_id') or 0)!=int(user.get('staff_id') or 0)):return self.send_json({"error":"Permission denied"},403)
                    eid=run("INSERT INTO club_events(club_id,event_date,start_time,end_time,title,location,details) VALUES(?,?,?,?,?,?,?)",(cid,str(data.get("event_date") or ''),str(data.get("start_time") or ''),str(data.get("end_time") or ''),str(data.get("title") or 'Meeting'),str(data.get("location") or ''),str(data.get("details") or '')))
                    return self.send_json({"id":eid,"ok":1})
                return self.send_json({"error":"Unknown club action"},400)


            if path == "/api/forms":
                if role!="admin":return self.send_json({"error":"Only administrators can manage forms"},403)
                action=str(data.get("action") or "create").lower()
                if action in {"create","update"}:
                    title=str(data.get("title") or "").strip()
                    if not title:return self.send_json({"error":"Enter a form title"},400)
                    if action=="create":
                        fid=run("INSERT INTO school_forms(title,description,audience,status,open_date,close_date,require_signature,created_by) VALUES(?,?,?,?,?,?,?,?)",(title,str(data.get("description") or ""),str(data.get("audience") or "Students"),str(data.get("status") or "Draft"),str(data.get("open_date") or ""),str(data.get("close_date") or ""),1 if data.get("require_signature") else 0,user.get("id")))
                    else:
                        fid=int(data.get("id") or 0);run("UPDATE school_forms SET title=?,description=?,audience=?,status=?,open_date=?,close_date=?,require_signature=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(title,str(data.get("description") or ""),str(data.get("audience") or "Students"),str(data.get("status") or "Draft"),str(data.get("open_date") or ""),str(data.get("close_date") or ""),1 if data.get("require_signature") else 0,fid));run("DELETE FROM school_form_questions WHERE form_id=?",(fid,))
                    for i,q in enumerate(data.get("questions") or []):
                        qt=str(q.get("question_text") or "").strip()
                        if not qt:continue
                        run("INSERT INTO school_form_questions(form_id,question_text,question_type,options_json,required,sort_order) VALUES(?,?,?,?,?,?)",(fid,qt,str(q.get("question_type") or "short"),json.dumps(q.get("options") or []),1 if q.get("required") else 0,i))
                    audit(user,"Saved school form","Forms",fid,title);return self.send_json({"id":fid,"ok":1})
                if action=="delete":
                    fid=int(data.get("id") or 0);run("DELETE FROM school_form_responses WHERE form_id=?",(fid,));run("DELETE FROM school_form_questions WHERE form_id=?",(fid,));run("DELETE FROM school_forms WHERE id=?",(fid,));audit(user,"Deleted school form","Forms",fid);return self.send_json({"ok":1})
                return self.send_json({"error":"Unknown form action"},400)

            if path == "/api/forms/respond":
                if role not in {"student","parent"}:return self.send_json({"error":"Permission denied"},403)
                fid=int(data.get("form_id") or 0); f=one("SELECT * FROM school_forms WHERE id=? AND status='Published'",(fid,))
                if not f:return self.send_json({"error":"Form is not open"},404)
                sid=int(data.get("student_id") or user.get("student_id") or 0)
                if role=="student" and sid!=int(user.get("student_id") or 0):return self.send_json({"error":"Permission denied"},403)
                if not sid:return self.send_json({"error":"Student is required"},400)
                answers=data.get("answers") or {}; sig=str(data.get("signature_name") or "").strip()
                if int(f.get("require_signature") or 0) and not sig:return self.send_json({"error":"Signature is required"},400)
                run("INSERT INTO school_form_responses(form_id,student_id,user_id,answers_json,signature_name,status,submitted_at,updated_at) VALUES(?,?,?,?,?,'Submitted',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT(form_id,student_id) DO UPDATE SET user_id=excluded.user_id,answers_json=excluded.answers_json,signature_name=excluded.signature_name,status='Submitted',submitted_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP",(fid,sid,user.get("id"),json.dumps(answers),sig))
                audit(user,"Submitted school form","Forms",fid);return self.send_json({"ok":1})

            if path == "/api/devices":
                if role!="admin":return self.send_json({"error":"Only administrators can manage devices"},403)
                action=str(data.get("action") or "save").lower(); did=int(data.get("id") or 0)
                if action=="save":
                    tag=str(data.get("asset_tag") or "").strip()
                    if not tag:return self.send_json({"error":"Asset tag is required"},400)
                    if did:run("UPDATE devices SET asset_tag=?,serial_number=?,device_type=?,model=?,condition=?,notes=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(tag,str(data.get("serial_number") or ""),str(data.get("device_type") or "Chromebook"),str(data.get("model") or ""),str(data.get("condition") or "Good"),str(data.get("notes") or ""),did))
                    else:did=run("INSERT INTO devices(asset_tag,serial_number,device_type,model,condition,notes) VALUES(?,?,?,?,?,?)",(tag,str(data.get("serial_number") or ""),str(data.get("device_type") or "Chromebook"),str(data.get("model") or ""),str(data.get("condition") or "Good"),str(data.get("notes") or "")))
                    audit(user,"Saved device","Assets",did,tag);return self.send_json({"id":did,"ok":1})
                rec=one("SELECT * FROM devices WHERE id=?",(did,));
                if not rec:return self.send_json({"error":"Device not found"},404)
                if action=="assign":
                    sid=int(data.get("student_id") or 0);run("UPDATE devices SET assigned_student_id=?,status='Assigned',assigned_at=CURRENT_TIMESTAMP,returned_at=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?",(sid,did));run("INSERT INTO device_history(device_id,student_id,action,condition,notes,actor_user_id) VALUES(?,?,'Assigned',?,?,?)",(did,sid,str(rec.get("condition") or ""),str(data.get("notes") or ""),user.get("id")))
                elif action=="return":
                    sid=rec.get("assigned_student_id");cond=str(data.get("condition") or rec.get("condition") or "Good");run("UPDATE devices SET assigned_student_id=NULL,status='Available',condition=?,returned_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?",(cond,did));run("INSERT INTO device_history(device_id,student_id,action,condition,notes,actor_user_id) VALUES(?,?,'Returned',?,?,?)",(did,sid,cond,str(data.get("notes") or ""),user.get("id")))
                elif action=="retire":run("UPDATE devices SET status='Retired',assigned_student_id=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?",(did,))
                else:return self.send_json({"error":"Unknown device action"},400)
                audit(user,"Device "+action,"Assets",did);return self.send_json({"ok":1})

            if path == "/api/lockers":
                if role!="admin":return self.send_json({"error":"Only administrators can manage lockers"},403)
                action=str(data.get("action") or "save").lower(); lid=int(data.get("id") or 0)
                if action=="save":
                    num=str(data.get("locker_number") or "").strip()
                    if not num:return self.send_json({"error":"Locker number is required"},400)
                    if lid:run("UPDATE lockers SET locker_number=?,location=?,combination=?,notes=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(num,str(data.get("location") or ""),str(data.get("combination") or ""),str(data.get("notes") or ""),lid))
                    else:lid=run("INSERT INTO lockers(locker_number,location,combination,notes) VALUES(?,?,?,?)",(num,str(data.get("location") or ""),str(data.get("combination") or ""),str(data.get("notes") or "")))
                    audit(user,"Saved locker","Assets",lid,num);return self.send_json({"id":lid,"ok":1})
                if action=="bulk-create":
                    prefix=str(data.get("prefix") or "");start=int(data.get("start") or 1);count=max(1,min(1000,int(data.get("count") or 1)));loc=str(data.get("location") or "");created=0
                    for n in range(start,start+count):
                        try:run("INSERT INTO lockers(locker_number,location) VALUES(?,?)",(prefix+str(n),loc));created+=1
                        except Exception:pass
                    audit(user,"Bulk-created lockers","Assets",None,str(created));return self.send_json({"ok":1,"created":created})
                rec=one("SELECT * FROM lockers WHERE id=?",(lid,));
                if not rec:return self.send_json({"error":"Locker not found"},404)
                if action=="assign":
                    sid=int(data.get("student_id") or 0);run("UPDATE lockers SET assigned_student_id=?,status='Assigned',assigned_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?",(sid,lid));run("INSERT INTO locker_history(locker_id,student_id,action,notes,actor_user_id) VALUES(?,?,'Assigned',?,?)",(lid,sid,str(data.get("notes") or ""),user.get("id")))
                elif action=="clear":
                    sid=rec.get("assigned_student_id");run("UPDATE lockers SET assigned_student_id=NULL,status='Available',assigned_at=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?",(lid,));run("INSERT INTO locker_history(locker_id,student_id,action,notes,actor_user_id) VALUES(?,?,'Cleared',?,?)",(lid,sid,str(data.get("notes") or ""),user.get("id")))
                else:return self.send_json({"error":"Unknown locker action"},400)
                audit(user,"Locker "+action,"Assets",lid);return self.send_json({"ok":1})

            if path == "/api/hall-passes":
                action=str(data.get("action") or "request").lower()
                if action=="request":
                    if role not in {"student","teacher","admin","counselor"}:
                        return self.send_json({"error":"Permission denied"},403)
                    sid=int(data.get("student_id") or user.get("student_id") or 0)
                    if not sid or not allowed(sid,sids): return self.send_json({"error":"Permission denied"},403)
                    destination=str(data.get("destination") or "").strip()
                    if not destination:return self.send_json({"error":"Choose a destination"},400)
                    existing=one("SELECT id FROM hall_passes WHERE student_id=? AND status IN ('Requested','Approved','Active') ORDER BY id DESC LIMIT 1",(sid,))
                    if existing:return self.send_json({"error":"This student already has an open hall pass"},409)
                    pid=run("INSERT INTO hall_passes(student_id,requested_by_user_id,origin,destination,reason,status) VALUES(?,?,?,?,?,'Requested')",(sid,user.get("id"),str(data.get("origin") or ""),destination,str(data.get("reason") or "")))
                    audit(user,"Requested hall pass","Workflow",pid,destination);return self.send_json({"id":pid,"status":"Requested"})
                pid=int(data.get("id") or 0); rec=one("SELECT * FROM hall_passes WHERE id=?",(pid,))
                if not rec:return self.send_json({"error":"Hall pass not found"},404)
                if role not in {"admin","teacher","counselor"}:return self.send_json({"error":"Permission denied"},403)
                if role=="teacher":
                    # Teacher scopes are class-based, so always verify the student is currently enrolled with this teacher.
                    ok=one("SELECT 1 ok FROM enrollments e JOIN classes c ON c.id=e.class_id WHERE e.student_id=? AND c.teacher_id=? AND COALESCE(e.status,'Active')='Active' LIMIT 1",(rec["student_id"],user.get("staff_id") or 0))
                    if not ok:return self.send_json({"error":"Permission denied"},403)
                now=datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
                if action=="approve":
                    minutes=max(1,min(120,int(data.get("minutes") or 10))); exp=(datetime.utcnow()+timedelta(minutes=minutes)).strftime('%Y-%m-%d %H:%M:%S')
                    run("UPDATE hall_passes SET status='Approved',approved_at=?,approved_by=?,expires_at=?,notes=? WHERE id=?",(now,user.get("id"),exp,str(data.get("notes") or ""),pid))
                elif action=="activate": run("UPDATE hall_passes SET status='Active',activated_at=COALESCE(activated_at,?) WHERE id=?",(now,pid))
                elif action=="return": run("UPDATE hall_passes SET status='Returned',returned_at=? WHERE id=?",(now,pid))
                elif action=="deny": run("UPDATE hall_passes SET status='Denied',approved_by=?,approved_at=?,notes=? WHERE id=?",(user.get("id"),now,str(data.get("notes") or ""),pid))
                elif action=="cancel" and role in {"admin","counselor"}: run("UPDATE hall_passes SET status='Canceled',returned_at=? WHERE id=?",(now,pid))
                else:return self.send_json({"error":"Unknown hall-pass action"},400)
                audit(user,"Hall pass "+action,"Workflow",pid);return self.send_json({"ok":1})

            if path == "/api/behavior-referrals":
                action=str(data.get("action") or "create").lower()
                if role not in {"admin","teacher","counselor"}:return self.send_json({"error":"Permission denied"},403)
                if action=="create":
                    sid=int(data.get("student_id") or 0);cid=int(data.get("class_id") or 0) or None
                    if not sid:return self.send_json({"error":"Choose a student"},400)
                    desc=str(data.get("description") or "").strip()
                    if not desc:return self.send_json({"error":"Describe the concern"},400)
                    if role=="teacher":
                        ok=one("SELECT 1 ok FROM enrollments e JOIN classes c ON c.id=e.class_id WHERE e.student_id=? AND c.teacher_id=? AND COALESCE(e.status,'Active')='Active' LIMIT 1",(sid,user.get("staff_id") or 0))
                        if not ok:return self.send_json({"error":"You can only refer students you teach"},403)
                    rid=run("INSERT INTO behavior_referrals(student_id,class_id,referred_by,incident_at,category,severity,location,description,status) VALUES(?,?,?,?,?,?,?,?,'Submitted')",(sid,cid,user.get("staff_id") or None,str(data.get("incident_at") or ""),str(data.get("category") or "Other"),str(data.get("severity") or "Minor"),str(data.get("location") or ""),desc))
                    audit(user,"Submitted behavior referral","Behavior",rid);return self.send_json({"id":rid})
                rid=int(data.get("id") or 0);rec=one("SELECT * FROM behavior_referrals WHERE id=?",(rid,))
                if not rec:return self.send_json({"error":"Referral not found"},404)
                if role=="teacher" and int(rec.get("referred_by") or 0)!=int(user.get("staff_id") or 0):return self.send_json({"error":"Permission denied"},403)
                if action=="update":
                    if role not in {"admin","counselor"}:return self.send_json({"error":"Only administration/counseling may disposition referrals"},403)
                    run("UPDATE behavior_referrals SET status=?,assigned_admin=?,consequence=?,parent_contacted=?,resolution=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(str(data.get("status") or rec.get("status") or "Submitted"),int(data.get("assigned_admin") or 0) or None,str(data.get("consequence") or ""),1 if data.get("parent_contacted") else 0,str(data.get("resolution") or ""),rid))
                    audit(user,"Updated behavior referral","Behavior",rid);return self.send_json({"ok":1})
                return self.send_json({"error":"Unknown referral action"},400)
            if path == "/api/assignments":
                class_id = int(data.get("class_id") or 0)
                if role not in {"admin", "teacher"} or not allowed(class_id, cids):
                    return self.send_json({"error": "Permission denied"}, 403)
                title = (data.get("title") or "").strip()
                if not title:
                    return self.send_json({"error": "Enter an assignment title"}, 400)
                points = float(data.get("points") or 0)
                if points < 0:
                    return self.send_json({"error": "Points cannot be negative"}, 400)
                new_id = run(
                    """
                    INSERT INTO assignments(class_id,title,category,points,weight,due_date,visible,description,instructions,links_json,rubric_text,extra_credit,allow_late,attachment_name,attachment_type,attachment_data,accept_submissions,allow_any_file,lock_after_due,grading_period_key,is_final_exam,include_in_gradebook,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
                    """,
                    (
                        class_id,
                        title,
                        data.get("category") or "Assignments",
                        points,
                        float(data.get("weight") or 1),
                        data.get("due_date", ""),
                        1 if data.get("visible", True) else 0,
                        data.get("description", ""),data.get("instructions", ""),json.dumps(data.get("links") or []),data.get("rubric_text", ""),1 if data.get("extra_credit") else 0,1 if data.get("allow_late",True) else 0,data.get("attachment_name",""),data.get("attachment_type",""),data.get("attachment_base64",""),1 if data.get("accept_submissions") else 0,1 if data.get("allow_any_file",True) else 0,1 if data.get("lock_after_due") else 0,data.get("grading_period_key", ""),1 if data.get("is_final_exam") else 0,1 if parse_boolish(data.get("include_in_gradebook"), True) else 0,
                    ),
                )
                audit(user, "Created assignment", "Gradebook", new_id, title)
                if bool(data.get("visible", True)):
                    cl=one("SELECT name,term FROM classes WHERE id=?",(class_id,)) or {}
                    due=str(data.get("due_date") or "").strip()
                    detail=f"{title} was posted in {cl.get('name') or 'your class'}."+(f" Due: {due}." if due else "")
                    for er in rows("SELECT student_id FROM enrollments WHERE class_id=? AND COALESCE(status,'Active')='Active'",(class_id,)):
                        _ss277_emit_student_event(int(er['student_id']),'assignment',f"assignment:{new_id}:posted",f"New assignment: {title}",detail)
                return self.send_json({"id": new_id})

            if path == "/api/assignments/update":
                assignment_id = int(data.get("id") or 0)
                assignment = one("SELECT * FROM assignments WHERE id=?", (assignment_id,))
                if not assignment or role not in {"admin", "teacher"} or not allowed(assignment["class_id"], cids):
                    return self.send_json({"error": "Permission denied"}, 403)
                title = (data.get("title") or assignment["title"]).strip()
                points = float(data.get("points") if data.get("points") not in {None, ""} else assignment["points"])
                if points < 0:
                    return self.send_json({"error": "Points cannot be negative"}, 400)
                run(
                    """
                    UPDATE assignments SET title=?,category=?,points=?,weight=?,due_date=?,visible=?,description=?,instructions=?,links_json=?,rubric_text=?,extra_credit=?,allow_late=?,attachment_name=COALESCE(NULLIF(?,''),attachment_name),attachment_type=COALESCE(NULLIF(?,''),attachment_type),attachment_data=COALESCE(NULLIF(?,''),attachment_data),accept_submissions=?,allow_any_file=?,lock_after_due=?,grading_period_key=?,is_final_exam=?,include_in_gradebook=? WHERE id=?
                    """,
                    (
                        title,
                        data.get("category", assignment["category"]),
                        points,
                        float(data.get("weight") if data.get("weight") not in {None, ""} else assignment["weight"]),
                        data.get("due_date", assignment["due_date"]),
                        1 if data.get("visible", assignment["visible"]) else 0,
                        data.get("description", assignment["description"]),data.get("instructions", assignment.get("instructions") or ""),json.dumps(data.get("links") if isinstance(data.get("links"),list) else json.loads(assignment.get("links_json") or "[]")),data.get("rubric_text", assignment.get("rubric_text") or ""),1 if data.get("extra_credit",assignment.get("extra_credit")) else 0,1 if data.get("allow_late",assignment.get("allow_late",1)) else 0,data.get("attachment_name",""),data.get("attachment_type",""),data.get("attachment_base64",""),1 if data.get("accept_submissions",assignment.get("accept_submissions")) else 0,1 if data.get("allow_any_file",assignment.get("allow_any_file",1)) else 0,1 if data.get("lock_after_due",assignment.get("lock_after_due")) else 0,data.get("grading_period_key",assignment.get("grading_period_key") or ""),1 if data.get("is_final_exam",assignment.get("is_final_exam")) else 0,1 if parse_boolish(data.get("include_in_gradebook"), bool(assignment.get("include_in_gradebook",1))) else 0,
                        assignment_id,
                    ),
                )
                audit(user, "Updated assignment", "Gradebook", assignment_id, title)
                return self.send_json({"ok": 1})

            if path == "/api/assignments/delete":
                assignment_id = int(data.get("id") or 0)
                assignment = one("SELECT * FROM assignments WHERE id=?", (assignment_id,))
                if not assignment or role not in {"admin", "teacher"} or not allowed(assignment["class_id"], cids):
                    return self.send_json({"error": "Permission denied"}, 403)
                c = db_connect()
                try:
                    c.execute("BEGIN IMMEDIATE")
                    c.execute("DELETE FROM grades WHERE assignment_id=?", (assignment_id,))
                    c.execute("DELETE FROM assignments WHERE id=?", (assignment_id,))
                    c.commit()
                except Exception:
                    c.rollback()
                    raise
                finally:
                    c.close()
                audit(user, "Deleted assignment", "Gradebook", assignment_id, assignment["title"])
                return self.send_json({"ok": 1})

            if path == "/api/grades":
                class_id = int(data.get("class_id") or 0)
                if role not in {"admin", "teacher"} or not allowed(class_id, cids):
                    return self.send_json({"error": "Permission denied"}, 403)
                valid_assignments = {x["id"] for x in rows("SELECT id FROM assignments WHERE class_id=?", (class_id,))}
                valid_students = {x["student_id"] for x in rows("SELECT student_id FROM enrollments WHERE class_id=?", (class_id,))}
                c = db_connect()
                ss277_grade_changes=[]
                try:
                    c.execute("BEGIN IMMEDIATE")
                    for item in data.get("grades", []):
                        assignment_id = int(item.get("assignment_id") or 0)
                        student_id = int(item.get("student_id") or 0)
                        if assignment_id not in valid_assignments or student_id not in valid_students:
                            continue
                        status = normalize_grade_status(item.get("status"))
                        score = item.get("score")
                        if score in {"", None}:
                            score = None
                        else:
                            score = float(score)
                        if status in {"MISSING", "EXCUSED"}:
                            score = None
                        previous=c.execute("SELECT score,status,comment FROM grades WHERE assignment_id=? AND student_id=?",(assignment_id,student_id)).fetchone()
                        old_score=previous[0] if previous else None; old_status=previous[1] if previous else ''; old_comment=previous[2] if previous else ''
                        new_status=normalize_grade_status(item.get("status")); new_comment=item.get("comment", "")
                        if previous is None or old_score!=score or (old_status or '')!=new_status or (old_comment or '')!=new_comment:
                            c.execute("INSERT INTO grade_history(assignment_id,student_id,old_score,new_score,old_status,new_status,old_comment,new_comment,changed_by) VALUES(?,?,?,?,?,?,?,?,?)",(assignment_id,student_id,old_score,score,old_status,new_status,old_comment,new_comment,user.get("id")))
                            ss277_grade_changes.append((assignment_id,student_id,old_score,score,old_status,new_status))
                        c.execute(
                            """
                            INSERT INTO grades(assignment_id,student_id,score,status,comment,updated_at)
                            VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
                            ON CONFLICT(assignment_id,student_id) DO UPDATE SET
                              score=excluded.score,status=excluded.status,comment=excluded.comment,updated_at=CURRENT_TIMESTAMP
                            """,
                            (assignment_id, student_id, score, status, item.get("comment", "")),
                        )
                    c.commit()
                except Exception:
                    c.rollback()
                    raise
                finally:
                    c.close()
                cl=one("SELECT name FROM classes WHERE id=?",(class_id,)) or {}
                for aid,sid,old_score,new_score,old_status,new_status in ss277_grade_changes:
                    a=one("SELECT title,points FROM assignments WHERE id=?",(aid,)) or {}
                    title=a.get('title') or 'Assignment';points=float(a.get('points') or 0)
                    if str(new_status or '').upper()=='MISSING':
                        _ss277_emit_student_event(sid,'missing',f"grade:{aid}:{sid}:{new_status}:{new_score}",f"Missing work: {title}",f"{title} in {cl.get('name') or 'class'} was marked missing.")
                    elif new_score is not None:
                        shown=(f"{new_score:g}/{points:g}" if points else f"{new_score:g}")
                        _ss277_emit_student_event(sid,'grade',f"grade:{aid}:{sid}:{new_status}:{new_score}",f"Grade posted: {title}",f"A grade of {shown} was posted for {title} in {cl.get('name') or 'class'}.")
                audit(user, "Saved grades", "Gradebook", class_id, f"{len(data.get('grades', []))} cells")
                return self.send_json({"ok": 1})

            if path == "/api/attendance":
                class_id = int(data.get("class_id") or 0)
                date = (data.get("date") or "").strip()
                if role not in {"admin", "teacher"} or not allowed(class_id, cids):
                    return self.send_json({"error": "Permission denied"}, 403)
                if not date:
                    return self.send_json({"error": "Choose an attendance date"}, 400)
                valid_students = {x["student_id"] for x in rows("SELECT student_id FROM enrollments WHERE class_id=?", (class_id,))}
                c = db_connect()
                ss277_attendance_changes=[]
                try:
                    c.execute("BEGIN IMMEDIATE")
                    saved = 0
                    for item in data.get("records", []):
                        student_id = int(item.get("student_id") or 0)
                        if student_id not in valid_students:
                            continue
                        declared = one("SELECT status,reason,note FROM daily_absences WHERE student_id=? AND absence_date=?",(student_id,date))
                        status = normalize_attendance_status(item.get("status"))
                        if declared:
                            status=declared.get('status') or 'AU'
                            item['note']=declared.get('note') or declared.get('reason') or 'All-day absence'
                        if not status:
                            c.execute("DELETE FROM attendance WHERE class_id=? AND student_id=? AND date=?", (class_id, student_id, date))
                            continue
                        minutes = max(0, int(float(item.get("minutes_late") or 0)))
                        if status not in {"LE", "LU", "TE", "TU"}:
                            minutes = 0
                        prev_at=c.execute("SELECT status,minutes_late,note FROM attendance WHERE class_id=? AND student_id=? AND date=?",(class_id,student_id,date)).fetchone()
                        c.execute(
                            """
                            INSERT INTO attendance(class_id,student_id,date,status,minutes_late,note,updated_at)
                            VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
                            ON CONFLICT(class_id,student_id,date) DO UPDATE SET
                              status=excluded.status,minutes_late=excluded.minutes_late,note=excluded.note,updated_at=CURRENT_TIMESTAMP
                            """,
                            (class_id, student_id, date, status, minutes, item.get("note", "")),
                        )
                        if prev_at is None or (prev_at[0] or '')!=status or int(prev_at[1] or 0)!=minutes:
                            ss277_attendance_changes.append((student_id,status,minutes))
                        saved += 1
                    c.commit()
                except Exception:
                    c.rollback()
                    raise
                finally:
                    c.close()
                cl=one("SELECT name FROM classes WHERE id=?",(class_id,)) or {}
                labels={'AE':'Absent — Excused','AU':'Absent — Unexcused','TE':'Tardy — Excused','TU':'Tardy — Unexcused','LE':'Late — Excused','LU':'Late — Unexcused'}
                for sid,status,minutes in ss277_attendance_changes:
                    if status in labels:
                        extra=f" ({minutes} minutes)" if minutes else ''
                        _ss277_emit_student_event(sid,'attendance',f"attendance:{class_id}:{sid}:{date}:{status}:{minutes}",f"Attendance update: {labels[status]}",f"{labels[status]}{extra} was recorded for {cl.get('name') or 'class'} on {date}.")
                audit(user, "Saved attendance", "Attendance", class_id, f"{date}: {saved} marked")
                return self.send_json({"ok": 1, "saved": saved})

            if path == "/api/scheduler/rotation":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                try:
                    rotation_count=max(1,min(6,int(data.get("rotation_count") or 2)))
                except Exception:
                    rotation_count=2
                labels=data.get("day_labels") or []
                if not isinstance(labels,list): labels=[]
                labels=[str(x or "").strip() for x in labels[:rotation_count]]
                while len(labels)<rotation_count: labels.append(f"Day {len(labels)+1}")
                if any(not x for x in labels): return self.send_json({"error":"Give every rotation day a name."},400)
                day_a=(data.get("day_a_date") or "").strip(); day_b=(data.get("day_b_date") or "").strip()
                run("""INSERT INTO schedule_rotation_settings(id,day_a_date,day_b_date,skip_weekends,rotation_count,day_labels,updated_at) VALUES(1,?,?,1,?,?,CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET day_a_date=excluded.day_a_date,day_b_date=excluded.day_b_date,skip_weekends=1,rotation_count=excluded.rotation_count,day_labels=excluded.day_labels,updated_at=CURRENT_TIMESTAMP""",(day_a,day_b,rotation_count,json.dumps(labels)))
                audit(user,"Saved configurable schedule rotation","Scheduling",1,f"{rotation_count} days: {', '.join(labels)}")
                return self.send_json({"ok":1,"rotation_count":rotation_count,"day_labels":labels})

            if path == "/api/course-requests/student-departments":
                if role not in {"admin", "teacher", "counselor"}:
                    return self.send_json({"error":"Permission denied"},403)
                student_id=int(data.get("student_id") or 0)
                if not student_id:
                    return self.send_json({"error":"Choose a student."},400)
                departments=data.get("departments") or []
                if not isinstance(departments,list):
                    return self.send_json({"error":"Departments must be a list."},400)
                run("UPDATE students SET registration_departments=? WHERE id=?",(json.dumps(departments),student_id))
                audit(user,"Updated student registration departments","Course Requests",student_id,f"{len(departments)} departments")
                return self.send_json({"ok":1,"student_id":student_id,"departments":departments})

            if path == "/api/course-requests/window":
                if role not in {"admin", "teacher"}:
                    return self.send_json({"error": "Only administrators and teachers can launch or end course requests."}, 403)
                is_open = 1 if bool(data.get("is_open")) else 0
                departments=json.dumps(data.get("departments") or [])
                if is_open:
                    run("""INSERT INTO course_request_window(id,is_open,opened_by,opened_at,closed_at,updated_at,departments) VALUES(1,1,?,CURRENT_TIMESTAMP,NULL,CURRENT_TIMESTAMP,?) ON CONFLICT(id) DO UPDATE SET is_open=1,opened_by=excluded.opened_by,opened_at=CURRENT_TIMESTAMP,closed_at=NULL,updated_at=CURRENT_TIMESTAMP,departments=excluded.departments""", (user["id"],departments))
                    action = "Launched student course requests"
                else:
                    run("""INSERT INTO course_request_window(id,is_open,opened_by,opened_at,closed_at,updated_at) VALUES(1,0,?,NULL,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET is_open=0,closed_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP""", (user["id"],))
                    action = "Ended student course requests"
                audit(user, action, "Course Requests", 1)
                return self.send_json({"ok":1,"is_open":is_open})

            if path == "/api/course-requests/submit":
                if role not in {"student", "admin", "counselor"}:
                    return self.send_json({"error": "Permission denied"}, 403)
                if role == "student":
                    w = one("SELECT is_open FROM course_request_window WHERE id=1")
                    if not w or not int(w.get("is_open") or 0):
                        return self.send_json({"error":"Course requests are not currently open."},403)
                student_id=int(data.get("student_id") or (user.get("student_id") if role=="student" else 0) or 0)
                if not student_id or not allowed(student_id,sids): return self.send_json({"error":"Permission denied"},403)
                course_id=int(data.get("course_id") or 0)
                course=one("SELECT * FROM courses WHERE id=? AND COALESCE(requestable,0)=1",(course_id,))
                if not course: return self.send_json({"error":"That course is not available for requests."},400)
                department=(course.get("department") or "Other").strip() or "Other"
                existing=one("""SELECT cr.id,cr.status FROM course_requests cr JOIN courses c ON c.id=cr.course_id WHERE cr.student_id=? AND LOWER(COALESCE(c.department,'Other'))=LOWER(?) AND cr.course_id<>?""",(student_id,department,course_id))
                if existing and existing.get("status") == "Approved":
                    return self.send_json({"error":"An approved course in this department cannot be replaced by the student. Ask a counselor to reset it first."},400)
                if existing:
                    run("DELETE FROM course_requests WHERE id=?",(existing["id"],))
                total=one("SELECT COUNT(*) n FROM course_requests WHERE student_id=? AND status<>'Denied'",(student_id,))
                if int(total.get("n") or 0)>=7 and not one("SELECT 1 FROM course_requests WHERE student_id=? AND course_id=?",(student_id,course_id)):
                    return self.send_json({"error":"Students may request no more than seven courses."},400)
                run("""INSERT INTO course_requests(student_id,course_id,priority,status,approval_status,scheduling_status) VALUES(?,?,?,'Pending','Pending','Pending') ON CONFLICT(student_id,course_id) DO UPDATE SET priority=excluded.priority,status='Pending',approval_status='Pending',scheduling_status='Pending',reviewer_note=NULL""",(student_id,course_id,int(data.get("priority") or 1)))
                return self.send_json({"ok":1})

            if path == "/api/course-requests/review":
                if role not in {"admin","counselor","teacher"}: return self.send_json({"error":"Permission denied"},403)
                status=(data.get("status") or "").title()
                if status not in {"Approved","Denied","Pending"}: return self.send_json({"error":"Invalid status"},400)
                run("UPDATE course_requests SET approval_status=?,status=CASE WHEN COALESCE(scheduling_status,'Pending') IN ('Scheduled','Conflict') THEN status ELSE ? END,reviewer_note=?,reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?",(status,status,data.get("reviewer_note", ""),user["id"],int(data.get("id") or 0)))
                return self.send_json({"ok":1})

            if path == "/api/course-requests/deny-replace":
                if role not in {"admin","counselor","teacher"}: return self.send_json({"error":"Permission denied"},403)
                rid=int(data.get("id") or 0); course_id=int(data.get("course_id") or 0)
                rec=one("SELECT * FROM course_requests WHERE id=?",(rid,)); course=one("SELECT * FROM courses WHERE id=? AND COALESCE(requestable,0)=1",(course_id,))
                if not rec or not course: return self.send_json({"error":"Request or replacement course not found"},404)
                run("UPDATE course_requests SET status='Denied',reviewer_note=?,reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?",(data.get("reviewer_note", "Replaced during review"),user["id"],rid))
                run("""INSERT INTO course_requests(student_id,course_id,priority,status,reviewer_note,reviewed_by,reviewed_at) VALUES(?,?,?,'Pending',?,?,CURRENT_TIMESTAMP) ON CONFLICT(student_id,course_id) DO UPDATE SET status='Pending',reviewer_note=excluded.reviewer_note,reviewed_by=excluded.reviewed_by,reviewed_at=CURRENT_TIMESTAMP""",(rec["student_id"],course_id,rec.get("priority") or 1,"Replacement selected by reviewer",user["id"]))
                audit(user,"Denied and replaced","Course Requests",rid,f"Replacement course {course_id}")
                return self.send_json({"ok":1})

            if path == "/api/course-requests/remove":
                if role == "student":
                    w = one("SELECT is_open FROM course_request_window WHERE id=1")
                    if not w or not int(w.get("is_open") or 0): return self.send_json({"error":"Course requests are not currently open."},403)
                rid=int(data.get("id") or 0); rec=one("SELECT * FROM course_requests WHERE id=?",(rid,))
                if not rec or role not in {"student","admin","counselor"} or (role=="student" and rec["student_id"]!=user.get("student_id")): return self.send_json({"error":"Permission denied"},403)
                run("DELETE FROM course_requests WHERE id=?",(rid,)); return self.send_json({"ok":1})

            if path == "/api/free-period-requests/save":
                if role not in {"student","admin","counselor"}: return self.send_json({"error":"Permission denied"},403)
                if role == "student":
                    w = one("SELECT is_open FROM course_request_window WHERE id=1")
                    if not w or not int(w.get("is_open") or 0): return self.send_json({"error":"Course requests are not currently open."},403)
                student_id=int(data.get("student_id") or (user.get("student_id") if role=="student" else 0) or 0)
                if not student_id or not allowed(student_id,sids): return self.send_json({"error":"Permission denied"},403)
                count=max(1,int(data.get("requested_count") or 1))
                run("""INSERT INTO student_free_period_requests(student_id,requested_count,status) VALUES(?,?,'Pending') ON CONFLICT(student_id) DO UPDATE SET requested_count=excluded.requested_count,status='Pending',updated_at=CURRENT_TIMESTAMP""",(student_id,count))
                return self.send_json({"ok":1})

            if path == "/api/free-period-requests/review":
                if role not in {"admin","counselor"}: return self.send_json({"error":"Permission denied"},403)
                status=(data.get("status") or "").title(); approved=max(0,int(data.get("approved_count") or 0))
                if status not in {"Approved","Denied","Pending"}: return self.send_json({"error":"Invalid status"},400)
                run("UPDATE student_free_period_requests SET status=?,approved_count=?,reviewer_note=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(status,approved,data.get("reviewer_note", ""),int(data.get("id") or 0)))
                return self.send_json({"ok":1})

            if path == "/api/scheduler/periods":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                name = (data.get("name") or "").strip()
                if not name:
                    return self.send_json({"error": "Enter a period name"}, 400)
                item_id=int(data.get("id") or 0)
                vals=(name,data.get("start_time", ""),data.get("end_time", ""),int(data.get("sort_order") or 0),int(data.get("cycle_day") or 1),data.get("day_label") or ("Day A" if int(data.get("cycle_day") or 1)==1 else "Day B"),1 if str(data.get("is_lunch") or "0").lower() in {"1","true","yes","on"} else 0)
                if item_id:
                    run("UPDATE schedule_periods SET name=?,start_time=?,end_time=?,sort_order=?,cycle_day=?,day_label=?,is_lunch=? WHERE id=?",vals+(item_id,));new_id=item_id
                else:
                    new_id=run("INSERT INTO schedule_periods(name,start_time,end_time,sort_order,cycle_day,day_label,is_lunch) VALUES(?,?,?,?,?,?,?)",vals)
                audit(user, "Saved", "Scheduling Period", new_id)
                return self.send_json({"id": new_id})

            if path == "/api/scheduler/periods/delete":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                run("DELETE FROM schedule_periods WHERE id=?", (int(data["id"]),))
                return self.send_json({"ok": 1})

            if path == "/api/scheduler/rooms":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                name = (data.get("name") or "").strip()
                if not name:
                    return self.send_json({"error": "Enter a room name"}, 400)
                item_id=int(data.get("id") or 0)
                vals=(name,max(1,int(data.get("capacity") or 30)),data.get("school", ""))
                if item_id:
                    run("UPDATE schedule_rooms SET name=?,capacity=?,school=? WHERE id=?",vals+(item_id,));new_id=item_id
                else:
                    new_id=run("INSERT INTO schedule_rooms(name,capacity,school) VALUES(?,?,?)",vals)
                audit(user, "Saved", "Scheduling Room", new_id)
                return self.send_json({"id": new_id})

            if path == "/api/scheduler/rooms/delete":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                run("DELETE FROM schedule_rooms WHERE id=?", (int(data["id"]),))
                return self.send_json({"ok": 1})

            if path == "/api/scheduler/requests":
                if role not in {"admin", "counselor"}:
                    return self.send_json({"error": "Permission denied"}, 403)
                run(
                    """
                    INSERT INTO course_requests(student_id,course_id,priority,status)
                    VALUES(?,?,?,'Requested')
                    ON CONFLICT(student_id,course_id) DO UPDATE SET priority=excluded.priority,status='Requested'
                    """,
                    (int(data["student_id"]), int(data["course_id"]), int(data.get("priority") or 1)),
                )
                return self.send_json({"ok": 1})

            if path == "/api/scheduler/requests/delete":
                if role not in {"admin", "counselor"}:
                    return self.send_json({"error": "Permission denied"}, 403)
                run("DELETE FROM course_requests WHERE id=?", (int(data["id"]),))
                return self.send_json({"ok": 1})

            if path == "/api/scheduler/clear-generated":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                term = (data.get("term") or "").strip()
                if not term:
                    return self.send_json({"error": "Choose a term"}, 400)
                c = db_connect()
                try:
                    c.execute("BEGIN IMMEDIATE")
                    generated_ids = [
                        x[0]
                        for x in c.execute(
                            "SELECT id FROM classes WHERE term=? AND (generated=1 OR section LIKE 'G%') AND id NOT IN (SELECT class_id FROM schedule_locks)", (term,)
                        ).fetchall()
                    ]
                    if generated_ids:
                        ph = ",".join("?" * len(generated_ids))
                        c.execute(f"DELETE FROM enrollments WHERE class_id IN ({ph})", generated_ids)
                        c.execute(f"DELETE FROM classes WHERE id IN ({ph})", generated_ids)
                    c.execute("UPDATE course_requests SET scheduling_status='Pending',status=CASE WHEN COALESCE(approval_status,'Pending')='Approved' THEN 'Approved' ELSE COALESCE(approval_status,'Pending') END WHERE COALESCE(scheduling_status,'') IN ('Scheduled','Conflict') OR status IN ('Scheduled','Conflict')")
                    c.commit()
                except Exception:
                    c.rollback()
                    raise
                finally:
                    c.close()
                audit(user, "Cleared generated schedule", "Scheduling", term, f"{len(generated_ids)} sections")
                return self.send_json({"deleted_sections": len(generated_ids)})

            if path == "/api/scheduler/lock":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                cid=int(data.get("class_id") or 0)
                if not cid: return self.send_json({"error":"Choose a section"},400)
                run("INSERT INTO schedule_locks(class_id,lock_period,lock_room,lock_teacher) VALUES(?,?,?,?) ON CONFLICT(class_id) DO UPDATE SET lock_period=excluded.lock_period,lock_room=excluded.lock_room,lock_teacher=excluded.lock_teacher",(cid,int(bool(data.get('lock_period',1))),int(bool(data.get('lock_room',1))),int(bool(data.get('lock_teacher',1)))))
                return self.send_json({"ok":1})

            if path == "/api/scheduler/unlock":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                run("DELETE FROM schedule_locks WHERE class_id=?",(int(data.get('class_id') or 0),))
                return self.send_json({"ok":1})

            if path == "/api/scheduler/version/save":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                term=(data.get('term') or '').strip()
                if not term: return self.send_json({"error":"Choose a term"},400)
                snapshot=rows("""SELECT c.*,co.code course_code,co.name course_name,st.name teacher_name,(SELECT COUNT(*) FROM enrollments e WHERE e.class_id=c.id AND COALESCE(e.status,'Active')='Active') enrolled FROM classes c LEFT JOIN courses co ON co.id=c.course_id LEFT JOIN staff st ON st.id=c.teacher_id WHERE c.term=? AND c.generated=1 ORDER BY c.cycle_day,c.period,c.id""",(term,))
                placements=sum(int(x.get('enrolled') or 0) for x in snapshot)
                conflicts=one("SELECT COUNT(*) n FROM course_requests WHERE COALESCE(scheduling_status,status)='Conflict'")["n"]
                cur=run("INSERT INTO schedule_versions(term,name,snapshot,sections,placements,conflicts) VALUES(?,?,?,?,?,?)",(term,(data.get('name') or f'Version {term}').strip(),json.dumps(snapshot),len(snapshot),placements,conflicts))
                return self.send_json({"id":cur.lastrowid,"sections":len(snapshot),"placements":placements,"conflicts":conflicts})

            if path == "/api/scheduler/version/restore":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                v=one("SELECT * FROM schedule_versions WHERE id=?",(int(data.get('id') or 0),))
                if not v: return self.send_json({"error":"Version not found"},404)
                snap=json.loads(v['snapshot'] or '[]')
                c=db_connect()
                try:
                    c.execute('BEGIN IMMEDIATE')
                    ids=[r[0] for r in c.execute("SELECT id FROM classes WHERE term=? AND generated=1",(v['term'],)).fetchall()]
                    if ids:
                        ph=','.join('?'*len(ids)); c.execute(f"DELETE FROM enrollments WHERE class_id IN ({ph})",ids); c.execute(f"DELETE FROM classes WHERE id IN ({ph})",ids)
                    for x in snap:
                        c.execute("INSERT INTO classes(course_id,name,section,period,room,teacher_id,term,capacity,school,cycle_day,generated,published) VALUES(?,?,?,?,?,?,?,?,?,?,1,?)",(x.get('course_id'),x.get('name') or x.get('course_name'),x.get('section'),x.get('period'),x.get('room'),x.get('teacher_id'),x.get('term'),x.get('capacity') or 30,x.get('school') or '',x.get('cycle_day') or 1,x.get('published') or 0))
                    c.commit()
                except Exception:
                    c.rollback(); raise
                finally: c.close()
                return self.send_json({"restored":len(snap),"term":v['term']})

            if path == "/api/scheduler/generate":
                if role != "admin":
                    return self.send_json({"error": "Permission denied"}, 403)
                term = (data.get("term") or "").strip()
                if not term:
                    return self.send_json({"error": "Choose a term"}, 400)
                section_capacity = max(1, int(data.get("section_capacity") or 30))
                replace_existing = bool(data.get("replace_existing"))
                c = db_connect()
                created_ids = []
                scheduled = 0
                conflicts = []
                try:
                    c.execute("BEGIN IMMEDIATE")
                    periods = [dict(x) for x in c.execute("SELECT * FROM schedule_periods WHERE active=1 AND COALESCE(is_lunch,0)=0 ORDER BY sort_order,id").fetchall()]
                    rooms_data = [dict(x) for x in c.execute("SELECT * FROM schedule_rooms WHERE active=1 ORDER BY name").fetchall()]
                    teachers = [
                        dict(x)
                        for x in c.execute(
                            "SELECT * FROM staff WHERE status='Active' AND lower(COALESCE(role,'')) LIKE '%teacher%' ORDER BY id"
                        ).fetchall()
                    ]
                    existing_generated = [
                        x[0]
                        for x in c.execute(
                            "SELECT id FROM classes WHERE term=? AND (generated=1 OR section LIKE 'G%') AND id NOT IN (SELECT class_id FROM schedule_locks)", (term,)
                        ).fetchall()
                    ]
                    if existing_generated and not replace_existing:
                        raise ValueError("A generated schedule already exists for this term. Enable Replace existing generated schedule and try again.")
                    if replace_existing and existing_generated:
                        ph = ",".join("?" * len(existing_generated))
                        c.execute(f"DELETE FROM enrollments WHERE class_id IN ({ph})", existing_generated)
                        c.execute(f"DELETE FROM classes WHERE id IN ({ph})", existing_generated)
                        c.execute("UPDATE course_requests SET scheduling_status='Pending',status=CASE WHEN COALESCE(approval_status,'Pending')='Approved' THEN 'Approved' ELSE COALESCE(approval_status,'Pending') END WHERE COALESCE(scheduling_status,'') IN ('Scheduled','Conflict') OR status IN ('Scheduled','Conflict')")
                    # Only students with a fully approved registration are eligible for
                    # student placement. Everyone else is intentionally ignored so the
                    # district can build/test a master schedule without registering every
                    # active student in the database.
                    eligible_student_ids = {
                        int(x["student_id"])
                        for x in c.execute(
                            """
                            SELECT DISTINCT cr.student_id
                            FROM course_requests cr
                            WHERE COALESCE(cr.approval_status,CASE WHEN cr.status IN ('Approved','Scheduled','Conflict') THEN 'Approved' ELSE cr.status END)='Approved'
                              AND EXISTS (
                                  SELECT 1
                                  FROM student_free_period_requests f
                                  WHERE f.student_id=cr.student_id
                                    AND f.status='Approved'
                                    AND COALESCE(f.approved_count,0)>0
                              )
                            """
                        ).fetchall()
                    }
                    requests_data = [
                        dict(x)
                        for x in c.execute(
                            """
                            SELECT cr.*,co.name course_name,co.code course_code,co.credits
                            FROM course_requests cr JOIN courses co ON co.id=cr.course_id
                            WHERE COALESCE(cr.approval_status,CASE WHEN cr.status IN ('Approved','Scheduled','Conflict') THEN 'Approved' ELSE cr.status END)='Approved'
                              AND EXISTS (
                                  SELECT 1
                                  FROM student_free_period_requests f
                                  WHERE f.student_id=cr.student_id
                                    AND f.status='Approved'
                                    AND COALESCE(f.approved_count,0)>0
                              )
                            ORDER BY cr.course_id,cr.priority,cr.id
                            """
                        ).fetchall()
                    ]
                    missing = []
                    if not periods:
                        missing.append("bell periods")
                    if not rooms_data:
                        missing.append("rooms")
                    if not teachers:
                        missing.append("active teacher staff")
                    if not requests_data:
                        missing.append("approved student course requests")
                    if missing:
                        raise ValueError("Before generating, add: " + ", ".join(missing) + ".")
                    total_slots=len(periods)
                    overloaded=[x['name'] for x in c.execute("""
                        SELECT s.first_name||' '||s.last_name name,
                               (SELECT COUNT(*) FROM course_requests cr WHERE cr.student_id=s.id AND COALESCE(cr.approval_status,CASE WHEN cr.status IN ('Approved','Scheduled','Conflict') THEN 'Approved' ELSE cr.status END)='Approved') course_count,
                               COALESCE((SELECT MAX(approved_count) FROM student_free_period_requests f WHERE f.student_id=s.id AND f.status='Approved'),0) free_count
                        FROM students s
                        WHERE s.id IN (
                            SELECT DISTINCT cr.student_id
                            FROM course_requests cr
                            WHERE COALESCE(cr.approval_status,CASE WHEN cr.status IN ('Approved','Scheduled','Conflict') THEN 'Approved' ELSE cr.status END)='Approved'
                              AND EXISTS (
                                  SELECT 1 FROM student_free_period_requests f
                                  WHERE f.student_id=cr.student_id
                                    AND f.status='Approved'
                                    AND COALESCE(f.approved_count,0)>0
                              )
                        )
                    """).fetchall() if int(x['course_count'])+int(x['free_count'])>total_slots]
                    if overloaded:
                        raise ValueError("Not enough schedule slots to preserve free periods for: "+", ".join(overloaded[:8]))

                    # A schedule slot is rotation day + period. Day A Period 1 and
                    # Day B Period 1 are different slots, while many different classes may
                    # run simultaneously in the same slot using different rooms/teachers.
                    occupied_rooms = set()
                    occupied_teachers = set()
                    for existing in c.execute("SELECT period,cycle_day,room,teacher_id FROM classes WHERE term=?", (term,)).fetchall():
                        slot_key = (int(existing["cycle_day"] or 1), existing["period"])
                        if existing["room"]:
                            occupied_rooms.add((slot_key, existing["room"]))
                        if existing["teacher_id"]:
                            occupied_teachers.add((slot_key, existing["teacher_id"]))

                    by_course = {}
                    student_courses = {}
                    for request in requests_data:
                        by_course.setdefault(request["course_id"], []).append(request)
                        student_courses.setdefault(int(request["student_id"]), set()).add(int(request["course_id"]))

                    # Build the student co-request graph. Courses commonly requested by the
                    # same students receive different A/B period slots whenever possible.
                    course_neighbors = {cid: set() for cid in by_course}
                    for course_set in student_courses.values():
                        course_list = list(course_set)
                        for i, cid in enumerate(course_list):
                            for other in course_list[i + 1:]:
                                course_neighbors.setdefault(cid, set()).add(other)
                                course_neighbors.setdefault(other, set()).add(cid)

                    slot_records = []
                    seen_slots = set()
                    for period in periods:
                        key = (int(period.get("cycle_day") or 1), period["name"])
                        if key not in seen_slots:
                            seen_slots.add(key)
                            slot_records.append({"key": key, "period": period})
                    if not slot_records:
                        raise ValueError("No instructional Day A/Day B periods are configured.")

                    # DSATUR-style greedy coloring minimizes student overlaps before any
                    # student is enrolled. More demanded/highly connected courses go first.
                    course_slot = {}
                    unscheduled_courses = set(by_course)
                    while unscheduled_courses:
                        def course_rank(cid):
                            used_neighbor_slots = {course_slot[n] for n in course_neighbors.get(cid, set()) if n in course_slot}
                            return (len(used_neighbor_slots), len(course_neighbors.get(cid, set())), len(by_course[cid]))
                        cid = max(unscheduled_courses, key=course_rank)
                        best = None
                        for slot in slot_records:
                            skey = slot["key"]
                            overlap = sum(
                                1 for req in by_course[cid]
                                if any(course_slot.get(other) == skey for other in student_courses.get(int(req["student_id"]), set()) if other != cid)
                            )
                            # Prefer less-used slots when overlap is tied.
                            load = sum(1 for value in course_slot.values() if value == skey)
                            score = (overlap, load, skey[0], slot["period"].get("sort_order") or 0)
                            if best is None or score < best[0]:
                                best = (score, skey)
                        course_slot[cid] = best[1]
                        unscheduled_courses.remove(cid)

                    sections_by_course = {}
                    section_conflicts = []
                    requested_sections = 0

                    def find_resource_pair(slot_key, course_id):
                        for room in rooms_data:
                            if (slot_key, room["name"]) in occupied_rooms:
                                continue
                            for teacher in teachers:
                                if (slot_key, teacher["id"]) in occupied_teachers:
                                    continue
                                try:
                                    eligible_ids={int(x) for x in json.loads(teacher.get("eligible_course_ids") or "[]")}
                                except Exception:
                                    eligible_ids=set()
                                if int(course_id) not in eligible_ids:
                                    continue
                                return room, teacher
                        return None

                    # Create sections in their demand-optimized A/B slots. Multiple courses
                    # can run in the same slot, as long as room and teacher are different.
                    for course_id, request_items in sorted(by_course.items(), key=lambda item: -len(item[1])):
                        course = c.execute("SELECT * FROM courses WHERE id=?", (course_id,)).fetchone()
                        needed = (len(request_items) + section_capacity - 1) // section_capacity
                        requested_sections += needed
                        sections = []
                        preferred_key = course_slot[course_id]
                        ordered_slots = sorted(slot_records, key=lambda x: (x["key"] != preferred_key, x["key"][0], x["period"].get("sort_order") or 0))
                        for index in range(needed):
                            chosen = None
                            for slot in ordered_slots:
                                pair = find_resource_pair(slot["key"], course_id)
                                if pair:
                                    chosen = (slot, pair[0], pair[1])
                                    break
                            if not chosen:
                                section_conflicts.append({"course_id": course_id, "course": course["name"], "course_code": course["code"], "section_number": index + 1, "reason": "No unused room/teacher pair remains in any Day A or Day B period"})
                                continue
                            slot, room, teacher = chosen
                            period = slot["period"]
                            slot_key = slot["key"]
                            capacity = min(section_capacity, max(1, int(room.get("capacity") or section_capacity)))
                            section_code = f"G{index + 1:02d}"
                            cur = c.execute(
                                """
                                INSERT INTO classes(course_id,name,section,period,room,teacher_id,term,capacity,school,cycle_day,generated)
                                VALUES(?,?,?,?,?,?,?,?,?,?,1)
                                """,
                                (course_id, course["name"], section_code, period["name"], room["name"], teacher["id"], term, capacity, room.get("school") or teacher.get("school") or "", slot_key[0]),
                            )
                            class_id = cur.lastrowid
                            created_ids.append(class_id)
                            occupied_rooms.add((slot_key, room["name"]))
                            occupied_teachers.add((slot_key, teacher["id"]))
                            sections.append({"id": class_id, "slot": slot_key, "period": period["name"], "cycle_day": slot_key[0], "capacity": capacity, "count": 0})
                        sections_by_course[course_id] = sections

                    student_slots = {}
                    for existing in c.execute(
                        """
                        SELECT e.student_id,c.period,c.cycle_day FROM enrollments e JOIN classes c ON c.id=e.class_id
                        WHERE c.term=? AND COALESCE(e.status,'Active')='Active'
                        """, (term,)
                    ).fetchall():
                        student_slots.setdefault(int(existing["student_id"]), set()).add((int(existing["cycle_day"] or 1), existing["period"]))

                    # Hard rule: one class per student per rotation-day/period slot.
                    # Day A and Day B are independent, and lunch is not included.
                    for request in sorted(requests_data, key=lambda r: (int(r["student_id"]), int(r.get("priority") or 1))):
                        candidates = sorted(sections_by_course.get(request["course_id"], []), key=lambda x: (x["count"], x["cycle_day"], x["period"]))
                        placed = False
                        for section in candidates:
                            slots_used = student_slots.setdefault(int(request["student_id"]), set())
                            if section["count"] >= section["capacity"] or section["slot"] in slots_used:
                                continue
                            c.execute("INSERT OR IGNORE INTO enrollments(class_id,student_id,status,start_date) VALUES(?,?,'Active',date('now'))", (section["id"], request["student_id"]))
                            c.execute("UPDATE course_requests SET scheduling_status='Scheduled',status='Scheduled' WHERE id=?", (request["id"],))
                            section["count"] += 1
                            slots_used.add(section["slot"])
                            scheduled += 1
                            placed = True
                            break
                        if not placed:
                            c.execute("UPDATE course_requests SET scheduling_status='Conflict',status='Conflict' WHERE id=?", (request["id"],))
                            conflicts.append({"student_id": request["student_id"], "course": request["course_name"], "reason": "No section fits an unused Day A/Day B period for this student"})

                    details = json.dumps({"created_class_ids": created_ids, "conflicts": conflicts, "section_conflicts": section_conflicts})
                    cur = c.execute(
                        """
                        INSERT INTO schedule_runs(term,status,sections_created,students_scheduled,conflicts,details)
                        VALUES(?,?,?,?,?,?)
                        """,
                        (term, "Completed With Conflicts" if section_conflicts or conflicts else "Completed", len(created_ids), scheduled, len(conflicts) + len(section_conflicts), details),
                    )
                    run_id = cur.lastrowid
                    auto_snapshot=[dict(x) for x in c.execute("SELECT * FROM classes WHERE term=? AND generated=1 ORDER BY cycle_day,period,id",(term,)).fetchall()]
                    c.execute("INSERT INTO schedule_versions(term,name,snapshot,sections,placements,conflicts) VALUES(?,?,?,?,?,?)",(term,f"Automatic run #{run_id}",json.dumps(auto_snapshot),len(auto_snapshot),scheduled,len(conflicts)+len(section_conflicts)))
                    c.commit()
                except ValueError as exc:
                    c.rollback()
                    return self.send_json({"error": str(exc)}, 400)
                except Exception:
                    c.rollback()
                    raise
                finally:
                    c.close()
                audit(user, "Generated master schedule", "Scheduling", run_id, f"{len(created_ids)} sections, {scheduled} placements, {len(conflicts)} conflicts, {len(eligible_student_ids)} eligible students")
                return self.send_json(
                    {
                        "run_id": run_id,
                        "sections_created": len(created_ids),
                        "students_scheduled": scheduled,
                        "eligible_students": len(eligible_student_ids),
                        "conflicts": conflicts,
                        "section_conflicts": section_conflicts,
                        "requested_sections": requested_sections,
                        "readiness": {
                            "periods": len(periods),
                            "rooms": len(rooms_data),
                            "teachers": len(teachers),
                            "eligible_students": len(eligible_student_ids),
                            "approved_requests": len(requests_data),
                            "maximum_room_slots": len(periods) * len(rooms_data),
                            "maximum_teacher_slots": len(periods) * len(teachers),
                        },
                    }
                )

            if path == "/api/course-requests/approve-all":
                if role not in {"admin","teacher","counselor"}: return self.send_json({"error":"Permission denied"},403)
                sid=int(data.get("student_id") or 0)
                c=db_connect()
                try:
                    c.execute("BEGIN IMMEDIATE")
                    cur=c.execute("UPDATE course_requests SET approval_status='Approved',status=CASE WHEN COALESCE(scheduling_status,'Pending') IN ('Scheduled','Conflict') THEN status ELSE 'Approved' END,reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP WHERE student_id=? AND COALESCE(approval_status,'Pending')!='Denied'",(user["id"],sid))
                    c.execute("UPDATE student_free_period_requests SET status='Approved',approved_count=COALESCE(NULLIF(approved_count,0),requested_count),updated_at=CURRENT_TIMESTAMP WHERE student_id=?",(sid,))
                    c.commit(); count=cur.rowcount
                except Exception:
                    c.rollback(); raise
                finally: c.close()
                audit(user,"Approved all course requests","Scheduling",sid,f"{count} courses")
                return self.send_json({"ok":1,"approved":count})

            if path == "/api/course-requests/approve-everything":
                if role not in {"admin","counselor"}: return self.send_json({"error":"Permission denied"},403)
                c=db_connect()
                try:
                    c.execute("BEGIN IMMEDIATE")
                    cur=c.execute("UPDATE course_requests SET approval_status='Approved',status=CASE WHEN COALESCE(scheduling_status,'Pending') IN ('Scheduled','Conflict') THEN status ELSE 'Approved' END,reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP WHERE COALESCE(approval_status,'Pending')!='Denied' OR COALESCE(scheduling_status,'Pending') IN ('Scheduled','Conflict')",(user["id"],))
                    free_cur=c.execute("UPDATE student_free_period_requests SET status='Approved',approved_count=COALESCE(NULLIF(approved_count,0),requested_count),updated_at=CURRENT_TIMESTAMP")
                    c.commit(); count=cur.rowcount; free_count=free_cur.rowcount
                except Exception:
                    c.rollback(); raise
                finally: c.close()
                audit(user,"Approved every student's courses","Scheduling",None,f"{count} courses, {free_count} free-period requests")
                return self.send_json({"ok":1,"approved":count,"free_periods":free_count})

            if path == "/api/scheduler/publish":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                count=one("SELECT COUNT(*) n FROM classes WHERE generated=1 AND COALESCE(published,0)=0")["n"]
                run("UPDATE classes SET published=1 WHERE generated=1")
                audit(user,"Released master schedule","Scheduling",None,f"{count} sections")
                return self.send_json({"published":count})

            if path == "/api/assignment-submissions/review":
                if role not in {"admin","teacher"}: return self.send_json({"error":"Permission denied"},403)
                aid=int(data.get("assignment_id") or 0); sid=int(data.get("student_id") or 0)
                a=one("SELECT id,class_id,points FROM assignments WHERE id=?",(aid,))
                if not a or not allowed(a["class_id"],cids): return self.send_json({"error":"Permission denied"},403)
                enrolled=one("SELECT 1 ok FROM enrollments WHERE class_id=? AND student_id=? AND COALESCE(status,'Active')='Active'",(a["class_id"],sid))
                if not enrolled: return self.send_json({"error":"Student is not enrolled in this class"},400)
                score=data.get("score")
                if score in {None,""}: score=None
                else:
                    score=float(score)
                    if score<0: return self.send_json({"error":"Score cannot be negative"},400)
                grade_status=normalize_grade_status(data.get("grade_status"))
                feedback=(data.get("feedback") or "").strip(); teacher_note=(data.get("teacher_note") or "").strip()
                submission_status=(data.get("submission_status") or ("Graded" if score is not None else "Returned")).strip()
                c=db_connect()
                try:
                    c.execute("BEGIN IMMEDIATE")
                    previous=c.execute("SELECT score,status,comment FROM grades WHERE assignment_id=? AND student_id=?",(aid,sid)).fetchone()
                    old_score=previous[0] if previous else None; old_status=previous[1] if previous else ''; old_comment=previous[2] if previous else ''
                    if previous is None or old_score!=score or (old_status or '')!=grade_status or (old_comment or '')!=feedback:
                        c.execute("INSERT INTO grade_history(assignment_id,student_id,old_score,new_score,old_status,new_status,old_comment,new_comment,changed_by) VALUES(?,?,?,?,?,?,?,?,?)",(aid,sid,old_score,score,old_status,grade_status,old_comment,feedback,user.get("id")))
                    c.execute("""INSERT INTO grades(assignment_id,student_id,score,status,comment,updated_at) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
                               ON CONFLICT(assignment_id,student_id) DO UPDATE SET score=excluded.score,status=excluded.status,comment=excluded.comment,updated_at=CURRENT_TIMESTAMP""",(aid,sid,score,grade_status,feedback))
                    c.execute("UPDATE assignment_submissions SET status=?,teacher_note=?,reviewed_at=CURRENT_TIMESTAMP,reviewed_by=? WHERE assignment_id=? AND student_id=?",(submission_status,teacher_note,user.get("id"),aid,sid))
                    c.commit()
                except Exception:
                    c.rollback(); raise
                finally: c.close()
                aa=one("SELECT a.title,a.points,c.name class_name FROM assignments a JOIN classes c ON c.id=a.class_id WHERE a.id=?",(aid,)) or {}
                if str(grade_status or '').upper()=='MISSING':
                    _ss277_emit_student_event(sid,'missing',f"review:{aid}:{sid}:{grade_status}:{score}",f"Missing work: {aa.get('title') or 'Assignment'}",f"{aa.get('title') or 'Assignment'} in {aa.get('class_name') or 'class'} was marked missing.")
                elif score is not None:
                    pts=float(aa.get('points') or 0);shown=(f"{score:g}/{pts:g}" if pts else f"{score:g}")
                    _ss277_emit_student_event(sid,'grade',f"review:{aid}:{sid}:{grade_status}:{score}",f"Grade posted: {aa.get('title') or 'Assignment'}",f"A grade of {shown} was posted for {aa.get('title') or 'Assignment'} in {aa.get('class_name') or 'class'}.")
                audit(user,"Reviewed assignment submission","Gradebook",aid,f"Student {sid}: {submission_status}")
                return self.send_json({"ok":1,"score":score,"status":submission_status})

            if path == "/api/assignment-submissions":
                if role != "student": return self.send_json({"error":"Permission denied"},403)
                aid=int(data.get("assignment_id") or 0); a=one("SELECT * FROM assignments WHERE id=?",(aid,))
                sid=int(user.get("student_id") or 0)
                if not a or not int(a.get("accept_submissions") or 0): return self.send_json({"error":"This assignment is not accepting submissions"},400)
                if not sid or not one("SELECT 1 ok FROM enrollments WHERE class_id=? AND student_id=? AND COALESCE(status,'Active')='Active'",(a.get("class_id"),sid)):
                    return self.send_json({"error":"Permission denied"},403)
                if (int(a.get("lock_after_due") or 0) or not int(a.get("allow_late",1) or 0)) and a.get("due_date") and str(a["due_date"]) < time.strftime('%Y-%m-%dT%H:%M'): return self.send_json({"error":"The due date has passed"},400)
                file_data=data.get("file_base64","") or ""
                if len(file_data) > 20_000_000:
                    return self.send_json({"error":"Submission file is too large"},413)
                run("INSERT OR REPLACE INTO assignment_submissions(assignment_id,student_id,file_name,file_type,file_data,submitted_at,status) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP,'Submitted')",(aid,sid,data.get("file_name",""),data.get("file_type",""),file_data))
                st=one("SELECT first_name||' '||last_name name FROM students WHERE id=?",(sid,)) or {}
                _ss277_emit_teacher_event(int(a.get('class_id') or 0),f"submission:{aid}:{sid}:{int(time.time())}",f"Assignment submitted: {a.get('title') or 'Assignment'}",f"{st.get('name') or 'A student'} submitted {a.get('title') or 'an assignment'}.")
                return self.send_json({"ok":1})

            if path == "/api/student-notes":
                if role not in {"admin", "teacher", "counselor", "nurse"}:
                    return self.send_json({"error": "Permission denied"}, 403)
                student_id = int(data.get("student_id") or 0)
                if not student_id or not allowed(student_id, sids):
                    return self.send_json({"error": "Permission denied"}, 403)
                note = (data.get("note") or "").strip()
                if not note:
                    return self.send_json({"error": "Enter a note"}, 400)
                new_id = run(
                    "INSERT INTO module_records(module,title,student_id,staff_id,status,record_date,data) VALUES(?,?,?,?,?,?,?)",
                    (
                        "studentNotes",
                        data.get("title", "Student note"),
                        student_id,
                        user.get("staff_id") or None,
                        data.get("status", "Active"),
                        data.get("record_date", ""),
                        json.dumps({"tool": "Student Notes", "fields": {"note": note}}),
                    ),
                )
                audit(user, "Added note", "Students", student_id)
                return self.send_json({"id": new_id})

            if path == "/api/records":
                student_id = int(data.get("student_id") or 0) or None
                if student_id and not allowed(student_id, sids):
                    return self.send_json({"error": "Permission denied"}, 403)
                new_id = run(
                    "INSERT INTO module_records(module,title,student_id,staff_id,status,record_date,data) VALUES(?,?,?,?,?,?,?)",
                    (
                        data["module"],
                        data["title"],
                        student_id,
                        int(data.get("staff_id") or 0) or None,
                        data.get("status", "Active"),
                        data.get("record_date", ""),
                        json.dumps(data.get("data", {})),
                    ),
                )
                return self.send_json({"id": new_id})

            if path == "/api/enterprise/backup-create":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                item=create_database_backup(data.get('label') or 'Manual',user.get('username') or user.get('display_name') or 'Admin')
                return self.send_json(item)

            if path == "/api/enterprise/backup-restore":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                safe=os.path.basename(data.get('name') or ''); source=os.path.join(backup_dir(),safe)
                if not safe or not os.path.isfile(source): return self.send_json({"error":"Backup not found"},404)
                safety=create_database_backup('Before_Restore',user.get('username') or 'Admin')
                src=sqlite3.connect(source); dst=sqlite3.connect(DB)
                try: src.backup(dst)
                finally: dst.close(); src.close()
                return self.send_json({"ok":1,"restored":safe,"safety_backup":safety['name']})

            if path == "/api/enterprise/settings":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                for k,v in (data.get('settings') or {}).items():
                    run("INSERT INTO district_settings(setting_key,setting_value,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value,updated_at=CURRENT_TIMESTAMP",(str(k),str(v)))
                audit(user,'Updated district settings','Enterprise','',data.get('settings') or {})
                return self.send_json({"ok":1})

            if path == "/api/enterprise/automation":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                rid=int(data.get('id') or 0)
                vals=(data.get('name','').strip(),data.get('trigger_type','Manual'),json.dumps(data.get('condition') or {}),data.get('action_type','Notification'),json.dumps(data.get('action') or {}),1 if data.get('active',True) else 0)
                if not vals[0]: return self.send_json({"error":"Enter a rule name"},400)
                if rid: run("UPDATE automation_rules SET name=?,trigger_type=?,condition_json=?,action_type=?,action_json=?,active=? WHERE id=?",vals+(rid,))
                else: rid=run("INSERT INTO automation_rules(name,trigger_type,condition_json,action_type,action_json,active) VALUES(?,?,?,?,?,?)",vals)
                return self.send_json({"id":rid})

            if path == "/api/enterprise/automation-delete":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                run("DELETE FROM automation_rules WHERE id=?",(int(data.get('id') or 0),)); return self.send_json({"ok":1})

            if path == "/api/enterprise/report-run":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                source=data.get('source'); spec=report_sources().get(source)
                if not spec: return self.send_json({"error":"Invalid report source"},400)
                requested=[x for x in (data.get('columns') or []) if x in spec['columns']] or spec['columns']
                all_rows=rows(spec['sql'])
                q=str(data.get('search') or '').strip().lower()
                if q: all_rows=[r for r in all_rows if any(q in str(v or '').lower() for v in r.values())]
                result=[{k:r.get(k) for k in requested} for r in all_rows[:5000]]
                if data.get('save_name'):
                    run("INSERT INTO report_definitions(name,data_source,columns_json,filters_json,created_by) VALUES(?,?,?,?,?)",(data['save_name'],source,json.dumps(requested),json.dumps({'search':q}),user.get('username','')))
                audit(user,'Ran custom report','Reports',source,{'rows':len(result),'columns':requested})
                return self.send_json({"columns":requested,"rows":result,"count":len(result)})

            if path == "/api/enterprise/security-event":
                if role != "admin": return self.send_json({"error":"Permission denied"},403)
                run("INSERT INTO security_events(username,event_type,ip_address,details) VALUES(?,?,?,?)",(data.get('username',''),data.get('event_type','Administrative review'),self.client_address[0],data.get('details','')))
                return self.send_json({"ok":1})

            if path == "/api/messages":
                if role not in {"admin", "teacher", "counselor"}:
                    return self.send_json({"error": "Permission denied"}, 403)
                new_id = run(
                    "INSERT INTO messages(audience,title,body,channel,send_at) VALUES(?,?,?,?,?)",
                    (
                        data.get("audience", "All"),
                        data["title"],
                        data.get("body", ""),
                        data.get("channel", "Portal"),
                        data.get("send_at", ""),
                    ),
                )
                return self.send_json({"id": new_id})


            if path == "/api/time-settings":
                if role!='admin': return self.send_json({"error":"Permission denied"},403)
                tzname=(data.get('timezone') or 'America/Chicago').strip()
                # Store the requested school timezone. The runtime has built-in US fallbacks and safe local fallback.
                run("INSERT INTO district_settings(setting_key,setting_value,updated_at) VALUES('school_timezone',?,CURRENT_TIMESTAMP) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value,updated_at=CURRENT_TIMESTAMP",(tzname,))
                return self.send_json({"ok":1,"timezone":tzname})

            if path == "/api/school-calendar":
                if role!='admin': return self.send_json({"error":"Permission denied"},403)
                item_id=int(data.get('id') or 0); date=(data.get('date') or '').strip(); title=(data.get('title') or '').strip()
                if not date or not title: return self.send_json({"error":"Date and title are required"},400)
                vals=(date,title,data.get('day_type') or 'School Day',int(data.get('rotation_day') or 0) or None,data.get('details') or '',data.get('start_time') or '',data.get('end_time') or '',user.get('id'))
                if item_id: run("UPDATE school_calendar_days SET date=?,title=?,day_type=?,rotation_day=?,details=?,start_time=?,end_time=?,created_by=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",vals+(item_id,))
                else: item_id=run("INSERT INTO school_calendar_days(date,title,day_type,rotation_day,details,start_time,end_time,created_by) VALUES(?,?,?,?,?,?,?,?)",vals)
                return self.send_json({"id":item_id})

            if path == "/api/school-calendar/delete":
                if role!='admin': return self.send_json({"error":"Permission denied"},403)
                run("DELETE FROM school_calendar_days WHERE id=?",(int(data.get('id') or 0),)); return self.send_json({"ok":1})

            if path == "/api/sports":
                if role!='admin': return self.send_json({"error":"Permission denied"},403)
                item_id=int(data.get('id') or 0); name=(data.get('name') or '').strip()
                if not name:return self.send_json({"error":"Sport/activity name is required"},400)
                vals=(name,data.get('season') or '',data.get('description') or '',1 if data.get('registration_open',True) else 0,json.dumps(data.get('form') or []),json.dumps(data.get('teams') or []),data.get('start_date') or '',data.get('end_date') or '',1,user.get('id'))
                if item_id: run("UPDATE sports_programs SET name=?,season=?,description=?,registration_open=?,form_json=?,teams_json=?,start_date=?,end_date=?,active=?,created_by=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",vals+(item_id,))
                else:item_id=run("INSERT INTO sports_programs(name,season,description,registration_open,form_json,teams_json,start_date,end_date,active,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)",vals)
                return self.send_json({"id":item_id})

            if path == "/api/sports/delete":
                if role!='admin': return self.send_json({"error":"Permission denied"},403)
                run("UPDATE sports_programs SET active=0 WHERE id=?",(int(data.get('id') or 0),)); return self.send_json({"ok":1})

            if path == "/api/sports/register":
                student_id=int(data.get('student_id') or user.get('student_id') or 0); sport_id=int(data.get('sport_id') or 0)
                if not student_id or not allowed(student_id,sids): return self.send_json({"error":"Permission denied"},403)
                response=data.get('response') or 'Yes'
                if response=='No':
                    run("""INSERT INTO sports_registrations(sport_id,student_id,response,answers_json,status,submitted_at,updated_at) VALUES(?,?,?,'{}','Declined',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)
                        ON CONFLICT(sport_id,student_id) DO UPDATE SET response='No',status='Declined',answers_json='{}',updated_at=CURRENT_TIMESTAMP""",(sport_id,student_id,'No'))
                    return self.send_json({"ok":1,"declined":1})
                run("""INSERT INTO sports_registrations(sport_id,student_id,response,answers_json,status,submitted_at,updated_at) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)
                    ON CONFLICT(sport_id,student_id) DO UPDATE SET response=excluded.response,answers_json=excluded.answers_json,status=excluded.status,updated_at=CURRENT_TIMESTAMP""",(sport_id,student_id,response,json.dumps(data.get('answers') or {}),'Registered'))
                return self.send_json({"ok":1})

            if path == "/api/sports/cut":
                if role not in {'admin','coach'}: return self.send_json({"error":"Permission denied"},403)
                sport_id=int(data.get('sport_id') or 0); student_id=int(data.get('student_id') or 0)
                if role=='coach' and not one("SELECT id FROM sports_coaches WHERE sport_id=? AND user_id=?",(sport_id,user.get('id'))): return self.send_json({"error":"Permission denied"},403)
                reg=one("SELECT id FROM sports_registrations WHERE sport_id=? AND student_id=?",(sport_id,student_id))
                if not reg: return self.send_json({"error":"Registration not found"},404)
                run("UPDATE sports_registrations SET team_name='',status='Cut',updated_at=CURRENT_TIMESTAMP WHERE sport_id=? AND student_id=?",(sport_id,student_id))
                audit(user,"Cut athlete from team","Sports",sport_id,f"student_id={student_id}")
                return self.send_json({"ok":1,"status":"Cut"})

            if path == "/api/sports/team":
                if role not in {'admin','coach'}: return self.send_json({"error":"Permission denied"},403)
                if role=='coach' and not one("SELECT id FROM sports_coaches WHERE sport_id=? AND user_id=?",(int(data.get('sport_id') or 0),user.get('id'))): return self.send_json({"error":"Permission denied"},403)
                run("UPDATE sports_registrations SET team_name=?,status='Team',updated_at=CURRENT_TIMESTAMP WHERE sport_id=? AND student_id=?",(data.get('team_name') or '',int(data.get('sport_id') or 0),int(data.get('student_id') or 0)))
                return self.send_json({"ok":1})

            if path == "/api/sports/event":
                if role not in {'admin','coach'}: return self.send_json({"error":"Permission denied"},403)
                sport_id=int(data.get('sport_id') or 0)
                if role=='coach' and not one("SELECT id FROM sports_coaches WHERE sport_id=? AND user_id=?",(sport_id,user.get('id'))): return self.send_json({"error":"Permission denied"},403)
                item_id=int(data.get('id') or 0); vals=(sport_id,data.get('team_name') or '',data.get('event_date') or '',data.get('start_time') or '',data.get('end_time') or '',data.get('title') or '',data.get('opponent') or '',data.get('location') or '',data.get('details') or '')
                if item_id:run("UPDATE sports_events SET sport_id=?,team_name=?,event_date=?,start_time=?,end_time=?,title=?,opponent=?,location=?,details=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",vals+(item_id,))
                else:item_id=run("INSERT INTO sports_events(sport_id,team_name,event_date,start_time,end_time,title,opponent,location,details) VALUES(?,?,?,?,?,?,?,?,?)",vals)
                return self.send_json({"id":item_id})

            if path == "/api/sports/event-delete":
                if role not in {'admin','coach'}: return self.send_json({"error":"Permission denied"},403)
                event_id=int(data.get('id') or 0)
                if role=='coach':
                    ev=one("SELECT sport_id FROM sports_events WHERE id=?",(event_id,))
                    if not ev or not one("SELECT id FROM sports_coaches WHERE sport_id=? AND user_id=?",(ev['sport_id'],user.get('id'))): return self.send_json({"error":"Permission denied"},403)
                run("DELETE FROM sports_events WHERE id=?",(event_id,));return self.send_json({"ok":1})

            if path == "/api/sports/coach/create":
                if role!='admin': return self.send_json({"error":"Permission denied"},403)
                sport_id=int(data.get('sport_id') or 0); team=(data.get('team_name') or '').strip(); username=(data.get('username') or '').strip(); password=data.get('password') or ''; name=(data.get('display_name') or username).strip()
                if not sport_id or not username or len(password)<8: return self.send_json({"error":"Sport, username, and an 8+ character temporary password are required"},400)
                if one("SELECT id FROM users WHERE lower(username)=lower(?)",(username,)): return self.send_json({"error":"That username is already in use"},409)
                digest,salt=hash_pw(password)
                uid=run("INSERT INTO users(username,password_hash,salt,role,display_name,must_change_password) VALUES(?,?,?,?,?,1)",(username,digest,salt,'coach',name))
                run("INSERT OR IGNORE INTO sports_coaches(sport_id,team_name,user_id) VALUES(?,?,?)",(sport_id,team,uid))
                audit(user,'Created coach account','Activities',uid,{'sport_id':sport_id,'team':team})
                return self.send_json({'id':uid,'username':username,'role':'coach'})

            if path == "/api/sports/coach/assign":
                if role!='admin': return self.send_json({"error":"Permission denied"},403)
                run("INSERT OR IGNORE INTO sports_coaches(sport_id,team_name,user_id) VALUES(?,?,?)",(int(data.get('sport_id') or 0),data.get('team_name') or '',int(data.get('user_id') or 0)))
                return self.send_json({'ok':1})

            if path == "/api/class-page":
                class_id=int(data.get('class_id') or 0)
                if role not in {'admin','teacher'} or not allowed(class_id,cids):return self.send_json({"error":"Permission denied"},403)
                run("""INSERT INTO class_pages(class_id,page_title,welcome_text,bulletin,topics_json,links_json,theme,updated_by,updated_at) VALUES(?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
                    ON CONFLICT(class_id) DO UPDATE SET page_title=excluded.page_title,welcome_text=excluded.welcome_text,bulletin=excluded.bulletin,topics_json=excluded.topics_json,links_json=excluded.links_json,theme=excluded.theme,updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP""",(class_id,data.get('page_title') or '',data.get('welcome_text') or '',data.get('bulletin') or '',json.dumps(data.get('topics') or []),json.dumps(data.get('links') or []),data.get('theme') or 'Clean',user.get('id')))
                run("UPDATE class_pages SET settings_json=? WHERE class_id=?",(json.dumps(data.get('settings') or {}),class_id))
                return self.send_json({"ok":1})

            return self.send_json({"error": "Not found"}, 404)
        except KeyError as exc:
            return self.send_json({"error": f"Missing required field: {exc.args[0]}"}, 400)
        except sqlite3.IntegrityError as exc:
            message = str(exc)
            if "users.username" in message:
                message = "That username is already in use"
            elif "schedule_rooms.name" in message:
                message = "That room already exists"
            elif "students.student_number" in message:
                message = "That student number is already in use"
            return self.send_json({"error": message}, 409)
        except Exception as exc:
            return self.send_json({"error": str(exc)}, 500)


def is_server_running(port):
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.5):
            return True
    except OSError:
        return False


def parse_args():
    parser = argparse.ArgumentParser(description="ScholarSync District SIS")
    parser.add_argument("--portal", choices=sorted(ROLES), default="")
    parser.add_argument("--port", type=int, default=None)
    parser.add_argument("--db", default=None)
    parser.add_argument("--no-browser", action="store_true")
    return parser.parse_args()


# --- ScholarSync Campus Operations Expansion ---
_SS_ORIG_INIT_DB = init_db

def init_db():
    _SS_ORIG_INIT_DB()
    ddl = [
    """CREATE TABLE IF NOT EXISTS student_id_cards(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER NOT NULL UNIQUE,card_number TEXT NOT NULL UNIQUE,barcode_value TEXT DEFAULT '',status TEXT DEFAULT 'Active',issued_at TEXT DEFAULT CURRENT_TIMESTAMP,expires_on TEXT DEFAULT '',replaced_count INTEGER DEFAULT 0,updated_by INTEGER,updated_at TEXT DEFAULT CURRENT_TIMESTAMP)""",
    """CREATE TABLE IF NOT EXISTS parking_permits(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER NOT NULL,permit_number TEXT UNIQUE,plate TEXT DEFAULT '',vehicle_make TEXT DEFAULT '',vehicle_model TEXT DEFAULT '',vehicle_color TEXT DEFAULT '',lot TEXT DEFAULT '',space TEXT DEFAULT '',status TEXT DEFAULT 'Pending',expires_on TEXT DEFAULT '',fee_status TEXT DEFAULT 'Unpaid',violations INTEGER DEFAULT 0,notes TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP)""",
    """CREATE TABLE IF NOT EXISTS announcements(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,body TEXT NOT NULL,audience TEXT DEFAULT 'All',priority TEXT DEFAULT 'Normal',publish_at TEXT DEFAULT CURRENT_TIMESTAMP,expires_at TEXT DEFAULT '',active INTEGER DEFAULT 1,created_by INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP)""",
    """CREATE TABLE IF NOT EXISTS announcement_reads(announcement_id INTEGER NOT NULL,user_id INTEGER NOT NULL,read_at TEXT DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(announcement_id,user_id))""",
    """CREATE TABLE IF NOT EXISTS library_items(id INTEGER PRIMARY KEY AUTOINCREMENT,barcode TEXT UNIQUE,title TEXT NOT NULL,author TEXT DEFAULT '',item_type TEXT DEFAULT 'Book',location TEXT DEFAULT '',status TEXT DEFAULT 'Available',replacement_cost REAL DEFAULT 0)""",
    """CREATE TABLE IF NOT EXISTS library_loans(id INTEGER PRIMARY KEY AUTOINCREMENT,item_id INTEGER NOT NULL,student_id INTEGER NOT NULL,checkout_at TEXT DEFAULT CURRENT_TIMESTAMP,due_on TEXT DEFAULT '',returned_at TEXT,status TEXT DEFAULT 'Checked Out',fine REAL DEFAULT 0)""",
    """CREATE TABLE IF NOT EXISTS inventory_items(id INTEGER PRIMARY KEY AUTOINCREMENT,asset_tag TEXT UNIQUE,name TEXT NOT NULL,category TEXT DEFAULT '',quantity INTEGER DEFAULT 1,location TEXT DEFAULT '',condition TEXT DEFAULT 'Good',assigned_to TEXT DEFAULT '',notes TEXT DEFAULT '',updated_at TEXT DEFAULT CURRENT_TIMESTAMP)""",
    """CREATE TABLE IF NOT EXISTS student_fees(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER NOT NULL,description TEXT NOT NULL,amount REAL NOT NULL DEFAULT 0,due_on TEXT DEFAULT '',status TEXT DEFAULT 'Open',category TEXT DEFAULT 'General',created_at TEXT DEFAULT CURRENT_TIMESTAMP)""",
    """CREATE TABLE IF NOT EXISTS fee_payments(id INTEGER PRIMARY KEY AUTOINCREMENT,fee_id INTEGER NOT NULL,amount REAL NOT NULL DEFAULT 0,method TEXT DEFAULT 'Recorded',reference TEXT DEFAULT '',paid_at TEXT DEFAULT CURRENT_TIMESTAMP,recorded_by INTEGER)""",
    """CREATE TABLE IF NOT EXISTS bus_routes(id INTEGER PRIMARY KEY AUTOINCREMENT,route_code TEXT NOT NULL UNIQUE,name TEXT DEFAULT '',driver_name TEXT DEFAULT '',bus_number TEXT DEFAULT '',morning_time TEXT DEFAULT '',afternoon_time TEXT DEFAULT '',active INTEGER DEFAULT 1,notes TEXT DEFAULT '')""",
    """CREATE TABLE IF NOT EXISTS bus_assignments(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER NOT NULL UNIQUE,route_id INTEGER NOT NULL,stop_name TEXT DEFAULT '',stop_time TEXT DEFAULT '',pickup_address TEXT DEFAULT '',notes TEXT DEFAULT '',updated_at TEXT DEFAULT CURRENT_TIMESTAMP)""",
    """CREATE TABLE IF NOT EXISTS meal_accounts(student_id INTEGER PRIMARY KEY,balance REAL DEFAULT 0,status TEXT DEFAULT 'Active',low_balance_threshold REAL DEFAULT 10,updated_at TEXT DEFAULT CURRENT_TIMESTAMP)""",
    """CREATE TABLE IF NOT EXISTS meal_transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER NOT NULL,amount REAL NOT NULL,transaction_type TEXT DEFAULT 'Purchase',description TEXT DEFAULT '',occurred_at TEXT DEFAULT CURRENT_TIMESTAMP,recorded_by INTEGER)"""
    ]
    for sql in ddl: run(sql)
    for sql in ["CREATE INDEX IF NOT EXISTS idx_parking_student ON parking_permits(student_id,status)","CREATE INDEX IF NOT EXISTS idx_library_student ON library_loans(student_id,status)","CREATE INDEX IF NOT EXISTS idx_fees_student ON student_fees(student_id,status)","CREATE INDEX IF NOT EXISTS idx_meals_student ON meal_transactions(student_id,occurred_at)"]:
        run(sql)

_SS_OLD_GET = Handler.do_GET
_SS_OLD_POST = Handler.do_POST

def _ss_target_student(user, query):
    role=user['role']; sids=student_scope(user)
    target=int(query.get('student_id',[str(user.get('student_id') or 0)])[0] or 0)
    if role=='student': target=int(user.get('student_id') or 0)
    if role=='parent' and target not in (sids or []): return None
    return target

def _ss_campus_get(self):
    parsed=urlparse(self.path); path=parsed.path
    if not path.startswith('/api/campus/'): return _SS_OLD_GET(self)
    user=self.require_user()
    if not user:return
    role=user['role']; q=parse_qs(parsed.query); sids=student_scope(user)
    try:
        if path=='/api/campus/id-parking':
            if role not in {'admin','student','parent','counselor'}: return self.send_json({'error':'Permission denied'},403)
            t=_ss_target_student(user,q)
            if role=='parent' and t is None:return self.send_json({'error':'Permission denied'},403)
            if t:return self.send_json({'student':one("SELECT id,student_number,first_name,last_name,grade FROM students WHERE id=?",(t,)),'card':one("SELECT * FROM student_id_cards WHERE student_id=?",(t,)),'parking':rows("SELECT * FROM parking_permits WHERE student_id=? ORDER BY id DESC",(t,))})
            return self.send_json({'cards':rows("SELECT c.*,s.first_name||' '||s.last_name student_name,s.student_number,s.grade FROM student_id_cards c JOIN students s ON s.id=c.student_id ORDER BY s.last_name"),'parking':rows("SELECT p.*,s.first_name||' '||s.last_name student_name,s.student_number FROM parking_permits p JOIN students s ON s.id=p.student_id ORDER BY p.id DESC")})
        if path=='/api/campus/announcements':
            now=datetime.now().strftime('%Y-%m-%d %H:%M:%S'); data=rows("SELECT a.*,CASE WHEN ar.user_id IS NULL THEN 0 ELSE 1 END is_read FROM announcements a LEFT JOIN announcement_reads ar ON ar.announcement_id=a.id AND ar.user_id=? WHERE a.active=1 AND (COALESCE(a.expires_at,'')='' OR a.expires_at>=?) ORDER BY CASE a.priority WHEN 'Emergency' THEN 0 WHEN 'High' THEN 1 ELSE 2 END,a.id DESC",(user['id'],now)); out=[]
            for x in data:
                aud=(x.get('audience') or 'All').lower()
                if role=='admin' or aud in {'all',role,role+'s'}:out.append(x)
            return self.send_json(out)
        if path=='/api/campus/library':
            if role not in {'admin','student','parent','counselor'}:return self.send_json({'error':'Permission denied'},403)
            t=_ss_target_student(user,q)
            if role=='parent' and t is None:return self.send_json({'error':'Permission denied'},403)
            out={'items':rows("SELECT * FROM library_items ORDER BY title") if role=='admin' else []}
            out['loans']=rows("SELECT l.*,i.title,i.barcode FROM library_loans l JOIN library_items i ON i.id=l.item_id WHERE l.student_id=? ORDER BY l.id DESC",(t,)) if t else (rows("SELECT l.*,i.title,s.first_name||' '||s.last_name student_name FROM library_loans l JOIN library_items i ON i.id=l.item_id JOIN students s ON s.id=l.student_id ORDER BY l.id DESC LIMIT 500") if role=='admin' else [])
            return self.send_json(out)
        if path=='/api/campus/inventory':
            if role!='admin':return self.send_json({'error':'Permission denied'},403)
            return self.send_json(rows("SELECT * FROM inventory_items ORDER BY category,name"))
        if path=='/api/campus/finance':
            if role not in {'admin','finance','student','parent'}:return self.send_json({'error':'Permission denied'},403)
            t=_ss_target_student(user,q)
            if role=='parent' and t is None:return self.send_json({'error':'Permission denied'},403)
            if t: fs=rows("SELECT f.*,COALESCE((SELECT SUM(amount) FROM fee_payments p WHERE p.fee_id=f.id),0) paid FROM student_fees f WHERE f.student_id=? ORDER BY f.id DESC",(t,))
            else: fs=rows("SELECT f.*,s.first_name||' '||s.last_name student_name,COALESCE((SELECT SUM(amount) FROM fee_payments p WHERE p.fee_id=f.id),0) paid FROM student_fees f JOIN students s ON s.id=f.student_id ORDER BY f.id DESC")
            return self.send_json({'fees':fs,'balance':round(sum(max(0,float(x['amount'] or 0)-float(x['paid'] or 0)) for x in fs),2)})
        if path=='/api/campus/transportation':
            if role not in {'admin','transportation','student','parent'}:return self.send_json({'error':'Permission denied'},403)
            t=_ss_target_student(user,q)
            if role=='parent' and t is None:return self.send_json({'error':'Permission denied'},403)
            if t:return self.send_json({'assignment':one("SELECT a.*,r.route_code,r.name route_name,r.driver_name,r.bus_number,r.morning_time,r.afternoon_time FROM bus_assignments a JOIN bus_routes r ON r.id=a.route_id WHERE a.student_id=?",(t,)),'routes':rows("SELECT * FROM bus_routes WHERE active=1 ORDER BY route_code") if role in {'admin','transportation'} else []})
            return self.send_json({'routes':rows("SELECT * FROM bus_routes ORDER BY route_code"),'assignments':rows("SELECT a.*,r.route_code,s.first_name||' '||s.last_name student_name,s.student_number FROM bus_assignments a JOIN bus_routes r ON r.id=a.route_id JOIN students s ON s.id=a.student_id ORDER BY r.route_code,s.last_name")})
        if path=='/api/campus/meals':
            if role not in {'admin','food','student','parent'}:return self.send_json({'error':'Permission denied'},403)
            t=_ss_target_student(user,q)
            if role=='parent' and t is None:return self.send_json({'error':'Permission denied'},403)
            if t:
                acct=one("SELECT * FROM meal_accounts WHERE student_id=?",(t,)) or {'student_id':t,'balance':0,'status':'Active','low_balance_threshold':10}
                return self.send_json({'account':acct,'transactions':rows("SELECT * FROM meal_transactions WHERE student_id=? ORDER BY id DESC LIMIT 100",(t,))})
            return self.send_json({'accounts':rows("SELECT m.*,s.first_name||' '||s.last_name student_name,s.student_number FROM meal_accounts m JOIN students s ON s.id=m.student_id ORDER BY s.last_name"),'transactions':rows("SELECT t.*,s.first_name||' '||s.last_name student_name FROM meal_transactions t JOIN students s ON s.id=t.student_id ORDER BY t.id DESC LIMIT 300")})
        if path=='/api/campus/analytics':
            if role not in {'admin','counselor','finance'}:return self.send_json({'error':'Permission denied'},403)
            ar=one("SELECT 100.0*SUM(CASE WHEN status IN ('P','TE','TU') THEN 1 ELSE 0 END)/NULLIF(COUNT(*),0) v FROM attendance")['v'] or 0
            return self.send_json({'students':one("SELECT COUNT(*) n FROM students WHERE status='Active'")['n'],'attendance_rate':round(float(ar),1),'open_fees':round(float(one("SELECT COALESCE(SUM(f.amount-COALESCE((SELECT SUM(p.amount) FROM fee_payments p WHERE p.fee_id=f.id),0)),0) v FROM student_fees f")['v'] or 0),2),'library_out':one("SELECT COUNT(*) n FROM library_loans WHERE returned_at IS NULL AND status='Checked Out'")['n'],'parking_pending':one("SELECT COUNT(*) n FROM parking_permits WHERE status='Pending'")['n'],'low_meal_accounts':one("SELECT COUNT(*) n FROM meal_accounts WHERE balance<low_balance_threshold")['n'],'bus_assigned':one("SELECT COUNT(*) n FROM bus_assignments")['n'],'announcements':one("SELECT COUNT(*) n FROM announcements WHERE active=1")['n']})
        return self.send_json({'error':'Not found'},404)
    except Exception as exc:return self.send_json({'error':str(exc)},500)

def _ss_campus_post(self):
    path=urlparse(self.path).path
    if not path.startswith('/api/campus/'):return _SS_OLD_POST(self)
    data=self.read_body(); user=self.require_user()
    if not user:return
    role=user['role']
    try:
        if path=='/api/campus/id-card':
            if role!='admin':return self.send_json({'error':'Permission denied'},403)
            sid=int(data.get('student_id') or 0); card=(data.get('card_number') or f'SS{sid:07d}').strip(); run("INSERT INTO student_id_cards(student_id,card_number,barcode_value,status,expires_on,updated_by) VALUES(?,?,?,?,?,?) ON CONFLICT(student_id) DO UPDATE SET card_number=excluded.card_number,barcode_value=excluded.barcode_value,status=excluded.status,expires_on=excluded.expires_on,updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP",(sid,card,data.get('barcode_value') or card,data.get('status') or 'Active',data.get('expires_on') or '',user['id'])); return self.send_json({'ok':1})
        if path=='/api/campus/parking':
            if role not in {'admin','student'}:return self.send_json({'error':'Permission denied'},403)
            sid=int(user.get('student_id') or 0) if role=='student' else int(data.get('student_id') or 0)
            if not sid:return self.send_json({'error':'Student required'},400)
            pid=int(data.get('id') or 0)
            if pid and role=='admin':run("UPDATE parking_permits SET permit_number=?,plate=?,vehicle_make=?,vehicle_model=?,vehicle_color=?,lot=?,space=?,status=?,expires_on=?,fee_status=?,violations=?,notes=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(data.get('permit_number') or None,data.get('plate') or '',data.get('vehicle_make') or '',data.get('vehicle_model') or '',data.get('vehicle_color') or '',data.get('lot') or '',data.get('space') or '',data.get('status') or 'Pending',data.get('expires_on') or '',data.get('fee_status') or 'Unpaid',int(data.get('violations') or 0),data.get('notes') or '',pid))
            else:run("INSERT INTO parking_permits(student_id,plate,vehicle_make,vehicle_model,vehicle_color,status) VALUES(?,?,?,?,?,?)",(sid,data.get('plate') or '',data.get('vehicle_make') or '',data.get('vehicle_model') or '',data.get('vehicle_color') or '','Pending'))
            return self.send_json({'ok':1})
        if path=='/api/campus/announcement':
            if role not in {'admin','teacher','counselor'}:return self.send_json({'error':'Permission denied'},403)
            if not data.get('title') or not data.get('body'):return self.send_json({'error':'Title and message required'},400)
            run("INSERT INTO announcements(title,body,audience,priority,publish_at,expires_at,active,created_by) VALUES(?,?,?,?,?,?,1,?)",(data['title'],data['body'],data.get('audience') or 'All',data.get('priority') or 'Normal',data.get('publish_at') or datetime.now().strftime('%Y-%m-%d %H:%M:%S'),data.get('expires_at') or '',user['id']));return self.send_json({'ok':1})
        if path=='/api/campus/announcement/read':run("INSERT OR REPLACE INTO announcement_reads(announcement_id,user_id,read_at) VALUES(?,?,CURRENT_TIMESTAMP)",(int(data.get('announcement_id') or 0),user['id']));return self.send_json({'ok':1})
        if path=='/api/campus/library/item':
            if role!='admin':return self.send_json({'error':'Permission denied'},403)
            run("INSERT INTO library_items(barcode,title,author,item_type,location,replacement_cost) VALUES(?,?,?,?,?,?)",(data.get('barcode') or None,data.get('title') or 'Untitled',data.get('author') or '',data.get('item_type') or 'Book',data.get('location') or '',float(data.get('replacement_cost') or 0)));return self.send_json({'ok':1})
        if path=='/api/campus/library/checkout':
            if role!='admin':return self.send_json({'error':'Permission denied'},403)
            iid=int(data.get('item_id') or 0)
            if one("SELECT id FROM library_loans WHERE item_id=? AND returned_at IS NULL",(iid,)):return self.send_json({'error':'Item already checked out'},409)
            run("INSERT INTO library_loans(item_id,student_id,due_on) VALUES(?,?,?)",(iid,int(data.get('student_id') or 0),data.get('due_on') or ''));run("UPDATE library_items SET status='Checked Out' WHERE id=?",(iid,));return self.send_json({'ok':1})
        if path=='/api/campus/library/return':
            if role!='admin':return self.send_json({'error':'Permission denied'},403)
            lid=int(data.get('loan_id') or 0); rec=one("SELECT item_id FROM library_loans WHERE id=?",(lid,));
            if not rec:return self.send_json({'error':'Loan not found'},404)
            run("UPDATE library_loans SET returned_at=CURRENT_TIMESTAMP,status='Returned',fine=? WHERE id=?",(float(data.get('fine') or 0),lid));run("UPDATE library_items SET status='Available' WHERE id=?",(rec['item_id'],));return self.send_json({'ok':1})
        if path=='/api/campus/inventory':
            if role!='admin':return self.send_json({'error':'Permission denied'},403)
            run("INSERT INTO inventory_items(asset_tag,name,category,quantity,location,condition,assigned_to,notes) VALUES(?,?,?,?,?,?,?,?)",(data.get('asset_tag') or None,data.get('name') or 'Item',data.get('category') or '',int(data.get('quantity') or 1),data.get('location') or '',data.get('condition') or 'Good',data.get('assigned_to') or '',data.get('notes') or ''));return self.send_json({'ok':1})
        if path=='/api/campus/fee':
            if role not in {'admin','finance'}:return self.send_json({'error':'Permission denied'},403)
            run("INSERT INTO student_fees(student_id,description,amount,due_on,category) VALUES(?,?,?,?,?)",(int(data.get('student_id') or 0),data.get('description') or 'Fee',float(data.get('amount') or 0),data.get('due_on') or '',data.get('category') or 'General'));return self.send_json({'ok':1})
        if path=='/api/campus/payment':
            if role not in {'admin','finance'}:return self.send_json({'error':'Permission denied'},403)
            run("INSERT INTO fee_payments(fee_id,amount,method,reference,recorded_by) VALUES(?,?,?,?,?)",(int(data.get('fee_id') or 0),float(data.get('amount') or 0),data.get('method') or 'Recorded',data.get('reference') or '',user['id']));return self.send_json({'ok':1})
        if path=='/api/campus/bus-route':
            if role not in {'admin','transportation'}:return self.send_json({'error':'Permission denied'},403)
            run("INSERT INTO bus_routes(route_code,name,driver_name,bus_number,morning_time,afternoon_time,notes) VALUES(?,?,?,?,?,?,?) ON CONFLICT(route_code) DO UPDATE SET name=excluded.name,driver_name=excluded.driver_name,bus_number=excluded.bus_number,morning_time=excluded.morning_time,afternoon_time=excluded.afternoon_time,notes=excluded.notes",(data.get('route_code') or '',data.get('name') or '',data.get('driver_name') or '',data.get('bus_number') or '',data.get('morning_time') or '',data.get('afternoon_time') or '',data.get('notes') or ''));return self.send_json({'ok':1})
        if path=='/api/campus/bus-assign':
            if role not in {'admin','transportation'}:return self.send_json({'error':'Permission denied'},403)
            run("INSERT INTO bus_assignments(student_id,route_id,stop_name,stop_time,pickup_address,notes) VALUES(?,?,?,?,?,?) ON CONFLICT(student_id) DO UPDATE SET route_id=excluded.route_id,stop_name=excluded.stop_name,stop_time=excluded.stop_time,pickup_address=excluded.pickup_address,notes=excluded.notes,updated_at=CURRENT_TIMESTAMP",(int(data.get('student_id') or 0),int(data.get('route_id') or 0),data.get('stop_name') or '',data.get('stop_time') or '',data.get('pickup_address') or '',data.get('notes') or ''));return self.send_json({'ok':1})
        if path=='/api/campus/meal-transaction':
            if role not in {'admin','food','finance'}:return self.send_json({'error':'Permission denied'},403)
            sid=int(data.get('student_id') or 0);amt=float(data.get('amount') or 0);run("INSERT INTO meal_accounts(student_id,balance) VALUES(?,0) ON CONFLICT(student_id) DO NOTHING",(sid,));run("INSERT INTO meal_transactions(student_id,amount,transaction_type,description,recorded_by) VALUES(?,?,?,?,?)",(sid,amt,data.get('transaction_type') or ('Deposit' if amt>=0 else 'Purchase'),data.get('description') or '',user['id']));run("UPDATE meal_accounts SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE student_id=?",(amt,sid));return self.send_json({'ok':1})
        return self.send_json({'error':'Not found'},404)
    except sqlite3.IntegrityError as exc:return self.send_json({'error':str(exc)},409)
    except Exception as exc:return self.send_json({'error':str(exc)},500)

Handler.do_GET=_ss_campus_get
Handler.do_POST=_ss_campus_post
# --- End Campus Operations Expansion ---


# --- ScholarSync School Closure + Smart Assignment Due Dates ---
_SS_PRE_CLOSURE_INIT_DB = init_db

def init_db():
    _SS_PRE_CLOSURE_INIT_DB()
    # Backward-compatible metadata for prominent closure alerts.
    cols={r['name'] for r in rows("PRAGMA table_info(school_calendar_days)")}
    for name, ddl in [
        ('closure_reason', "TEXT DEFAULT ''"),
        ('closure_message', "TEXT DEFAULT ''"),
        ('cancel_activities', "INTEGER DEFAULT 0"),
        ('alert_enabled', "INTEGER DEFAULT 1"),
    ]:
        if name not in cols:
            run(f"ALTER TABLE school_calendar_days ADD COLUMN {name} {ddl}")

_SS_PRE_CLOSURE_GET = Handler.do_GET
_SS_PRE_CLOSURE_POST = Handler.do_POST

def _ss_class_meeting_options(class_id, user):
    c=one("SELECT id,teacher_id,cycle_day,period,name,section FROM classes WHERE id=?",(class_id,))
    if not c: return None
    if user['role']=='teacher' and int(c.get('teacher_id') or 0)!=int(user.get('staff_id') or 0): return 'forbidden'
    if user['role'] not in {'admin','teacher'}: return 'forbidden'
    tzrec=one("SELECT setting_value FROM district_settings WHERE setting_key='school_timezone'")
    now,_=school_now((tzrec or {}).get('setting_value') or 'America/Chicago')
    today=now.date()
    period=one("SELECT start_time,end_time FROM schedule_periods WHERE cycle_day=? AND name=?",(int(c.get('cycle_day') or 1),c.get('period') or '')) or {}
    start_time=(period.get('start_time') or '08:00')[:5]
    end_time=(period.get('end_time') or start_time)[:5]
    meetings=[]
    cur=today
    for _ in range(75):
        ds=cur.isoformat()
        special=one("SELECT * FROM school_calendar_days WHERE date=?",(ds,))
        custom=one("SELECT * FROM special_schedule_periods WHERE calendar_day_id=? AND source_cycle_day=? AND period_name=?",(special['id'],int(c.get('cycle_day') or 1),c.get('period') or '')) if special and str(special.get('day_type') or '').lower()=='special schedule' else None
        meets = bool(custom) or school_rotation_for_date(ds)==int(c.get('cycle_day') or 1)
        if meets and not (special and str(special.get('day_type') or '').lower() in {'no school','holiday','closed','school closure'}):
            st=(custom.get('start_time') if custom else start_time) or start_time
            et=(custom.get('end_time') if custom else end_time) or end_time
            meetings.append({'date':ds,'start':f'{ds}T{st[:5]}','end':f'{ds}T{et[:5]}','label':cur.strftime('%A, %B %-d') if os.name!='nt' else cur.strftime('%A, %B %d').replace(' 0',' ')})
            if len(meetings)>=5: break
        cur=cur.fromordinal(cur.toordinal()+1)
    opts=[]
    todays=[m for m in meetings if m['date']==today.isoformat()]
    if todays:
        opts += [
            {'key':'today_start','label':'Start of Class Today','value':todays[0]['start']},
            {'key':'today_end','label':'End of Class Today','value':todays[0]['end']},
        ]
    future=[m for m in meetings if m['date']>today.isoformat()]
    for idx,m in enumerate(future[:3],1):
        prefix='Next Class Meeting' if idx==1 else f'{idx}{"nd" if idx==2 else "rd"} Class Meeting'
        opts.append({'key':f'next_{idx}_start','label':f'Start of {prefix}','value':m['start']})
        opts.append({'key':f'next_{idx}_end','label':f'End of {prefix}','value':m['end']})
    # End of this school week is a convenience option independent of meeting pattern.
    friday=today.fromordinal(today.toordinal()+(4-today.weekday())%7)
    opts.append({'key':'week_end','label':'End of This Week','value':f'{friday.isoformat()}T23:59'})
    return {'class':c,'meetings':meetings,'options':opts,'now':now.isoformat()}

def _ss_closure_get(self):
    parsed=urlparse(self.path); path=parsed.path; q=parse_qs(parsed.query)
    if path not in {'/api/closure-status','/api/class-due-options'}:
        return _SS_PRE_CLOSURE_GET(self)
    user=self.require_user()
    if not user:return
    try:
        if path=='/api/closure-status':
            tzrec=one("SELECT setting_value FROM district_settings WHERE setting_key='school_timezone'")
            now,_=school_now((tzrec or {}).get('setting_value') or 'America/Chicago')
            ds=q.get('date',[now.strftime('%Y-%m-%d')])[0]
            rec=one("SELECT * FROM school_calendar_days WHERE date=?",(ds,))
            if not rec or str(rec.get('day_type') or '').lower() not in {'school closure','closed','no school'} or not int(rec.get('alert_enabled') if rec.get('alert_enabled') is not None else 1):
                return self.send_json({'active':False,'date':ds})
            return self.send_json({'active':True,'date':ds,'closure':rec})
        cid=int(q.get('class_id',['0'])[0] or 0)
        result=_ss_class_meeting_options(cid,user)
        if result=='forbidden': return self.send_json({'error':'Permission denied'},403)
        if result is None:return self.send_json({'error':'Class not found'},404)
        return self.send_json(result)
    except Exception as exc:return self.send_json({'error':str(exc)},500)

def _ss_closure_post(self):
    parsed=urlparse(self.path); path=parsed.path
    if path!='/api/school-calendar': return _SS_PRE_CLOSURE_POST(self)
    user=self.require_user()
    if not user:return
    if user['role']!='admin':return self.send_json({'error':'Permission denied'},403)
    try:data=self.read_body()
    except Exception:return self.send_json({'error':'Invalid request body'},400)
    try:
        item_id=int(data.get('id') or 0); date=(data.get('date') or '').strip(); title=(data.get('title') or '').strip()
        if not date or not title:return self.send_json({'error':'Date and title are required'},400)
        day_type=data.get('day_type') or 'School Day'
        vals=(date,title,day_type,int(data.get('rotation_day') or 0) or None,data.get('details') or '',data.get('start_time') or '',data.get('end_time') or '',user.get('id'),data.get('closure_reason') or '',data.get('closure_message') or '',1 if data.get('cancel_activities') else 0,0 if str(data.get('alert_enabled','1')).lower() in {'0','false','no'} else 1)
        if item_id:
            run("UPDATE school_calendar_days SET date=?,title=?,day_type=?,rotation_day=?,details=?,start_time=?,end_time=?,created_by=?,closure_reason=?,closure_message=?,cancel_activities=?,alert_enabled=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",vals+(item_id,))
        else:
            item_id=run("INSERT INTO school_calendar_days(date,title,day_type,rotation_day,details,start_time,end_time,created_by,closure_reason,closure_message,cancel_activities,alert_enabled) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",vals)
        if str(day_type).lower() in {'school closure','closed','no school'}:
            msg=(data.get('closure_message') or data.get('details') or title).strip()
            existing=one("SELECT id FROM announcements WHERE title=? AND substr(publish_at,1,10)=?",(f'SCHOOL CLOSED — {title}',date))
            if not existing:
                run("INSERT INTO announcements(title,body,audience,priority,publish_at,active,created_by) VALUES(?,?,?,?,?,1,?)",(f'SCHOOL CLOSED — {title}',msg,'All','Emergency',f'{date} 00:00:00',user.get('id')))
        return self.send_json({'id':item_id})
    except sqlite3.IntegrityError as exc:return self.send_json({'error':str(exc)},409)
    except Exception as exc:return self.send_json({'error':str(exc)},500)

Handler.do_GET=_ss_closure_get
Handler.do_POST=_ss_closure_post
# --- End School Closure + Smart Assignment Due Dates ---


# --- ScholarSync School-Year + Teacher Schedule + Summer School ---
_SS_PRE_TERM_INIT_DB = init_db
def init_db():
    _SS_PRE_TERM_INIT_DB()
    run("CREATE TABLE IF NOT EXISTS summer_classes(id INTEGER PRIMARY KEY AUTOINCREMENT,course_id INTEGER,name TEXT NOT NULL,section TEXT DEFAULT '',teacher_id INTEGER,room TEXT DEFAULT '',start_date TEXT NOT NULL,end_date TEXT NOT NULL,meeting_days TEXT DEFAULT '1,2,3,4,5',start_time TEXT DEFAULT '08:00',end_time TEXT DEFAULT '09:00',capacity INTEGER DEFAULT 30,active INTEGER DEFAULT 1)")
    run("CREATE TABLE IF NOT EXISTS summer_enrollments(class_id INTEGER NOT NULL,student_id INTEGER NOT NULL,status TEXT DEFAULT 'Active',PRIMARY KEY(class_id,student_id))")
    defaults={'school_year_start_month_day':'08-15','school_year_end_month_day':'06-15'}
    for k,v in defaults.items():
        if not one("SELECT setting_key FROM district_settings WHERE setting_key=?",(k,)):
            run("INSERT INTO district_settings(setting_key,setting_value) VALUES(?,?)",(k,v))

def _ss_school_window(for_date):
    d=datetime.strptime(for_date,'%Y-%m-%d').date() if isinstance(for_date,str) else for_date
    smd=(one("SELECT setting_value FROM district_settings WHERE setting_key='school_year_start_month_day'") or {}).get('setting_value') or '08-15'
    emd=(one("SELECT setting_value FROM district_settings WHERE setting_key='school_year_end_month_day'") or {}).get('setting_value') or '06-15'
    sm,sd=map(int,smd.split('-')); em,ed=map(int,emd.split('-'))
    sy=d.year if d.month>=sm else d.year-1
    return date(sy,sm,sd),date(sy+1,em,ed)

def _ss_summer_for_student(student_id,ds):
    wd=datetime.strptime(ds,'%Y-%m-%d').date().isoweekday()
    data=rows("""SELECT sc.*,COALESCE(co.code,'') course_code,COALESCE(st.name,'') teacher
      FROM summer_enrollments se JOIN summer_classes sc ON sc.id=se.class_id LEFT JOIN courses co ON co.id=sc.course_id LEFT JOIN staff st ON st.id=sc.teacher_id
      WHERE se.student_id=? AND COALESCE(se.status,'Active')='Active' AND sc.active=1 AND ? BETWEEN sc.start_date AND sc.end_date ORDER BY sc.start_time""",(student_id,ds))
    return [x for x in data if str(wd) in [z.strip() for z in str(x.get('meeting_days') or '').split(',')]]

def _ss_summer_for_teacher(staff_id,ds):
    wd=datetime.strptime(ds,'%Y-%m-%d').date().isoweekday()
    data=rows("""SELECT sc.*,COALESCE(co.code,'') course_code,(SELECT COUNT(*) FROM summer_enrollments se WHERE se.class_id=sc.id AND COALESCE(se.status,'Active')='Active') enrolled
      FROM summer_classes sc LEFT JOIN courses co ON co.id=sc.course_id WHERE sc.teacher_id=? AND sc.active=1 AND ? BETWEEN sc.start_date AND sc.end_date ORDER BY sc.start_time""",(staff_id,ds))
    return [x for x in data if str(wd) in [z.strip() for z in str(x.get('meeting_days') or '').split(',')]]

_SS_PRE_TERM_GET=Handler.do_GET
_SS_PRE_TERM_POST=Handler.do_POST

def _ss_term_get(self):
    parsed=urlparse(self.path); path=parsed.path
    if path not in {'/api/school-year-window','/api/teacher-schedule','/api/summer-school'}: return _SS_PRE_TERM_GET(self)
    user=self.require_user()
    if not user:return
    q=parse_qs(parsed.query); role=user['role']
    try:
        if path=='/api/school-year-window':
            ds=q.get('date',[school_now(((one("SELECT setting_value FROM district_settings WHERE setting_key='school_timezone'") or {}).get('setting_value') or 'America/Chicago'))[0].strftime('%Y-%m-%d')])[0]; a,b=_ss_school_window(ds)
            return self.send_json({'start':a.isoformat(),'end':b.isoformat()})
        if path=='/api/teacher-schedule':
            if role not in {'teacher','admin'}:return self.send_json({'error':'Permission denied'},403)
            staff_id=int(q.get('staff_id',[str(user.get('staff_id') or 0)])[0] or 0)
            if role=='teacher':staff_id=int(user.get('staff_id') or 0)
            ds=q.get('date',[school_now(((one("SELECT setting_value FROM district_settings WHERE setting_key='school_timezone'") or {}).get('setting_value') or 'America/Chicago'))[0].strftime('%Y-%m-%d')])[0]
            d=datetime.strptime(ds,'%Y-%m-%d').date(); a,b=_ss_school_window(d)
            regular=[]
            special=one("SELECT * FROM school_calendar_days WHERE date=?",(ds,))
            if a<=d<=b:
                custom_periods=rows("SELECT * FROM special_schedule_periods WHERE calendar_day_id=? ORDER BY sort_order,start_time",(special['id'],)) if special and str(special.get('day_type') or '').lower()=='special schedule' else []
                if custom_periods:
                    for cp in custom_periods:
                        regular += rows("""SELECT c.id,c.name,c.section,c.period,c.room,c.cycle_day,COALESCE(co.code,'') course_code,? start_time,? end_time,
                        (SELECT COUNT(*) FROM enrollments e WHERE e.class_id=c.id AND COALESCE(e.status,'Active')='Active') enrolled,? special_schedule_label,? special_schedule_order
                        FROM classes c LEFT JOIN courses co ON co.id=c.course_id WHERE c.teacher_id=? AND COALESCE(c.published,0)=1 AND COALESCE(c.cycle_day,1)=? AND c.period=?""",
                        (cp['start_time'],cp['end_time'],cp.get('custom_label') or cp['period_name'],cp['sort_order'],staff_id,cp['source_cycle_day'],cp['period_name']))
                else:
                    cycle=school_rotation_for_date(ds)
                    if cycle:
                        regular=rows("""SELECT c.id,c.name,c.section,c.period,c.room,c.cycle_day,COALESCE(co.code,'') course_code,COALESCE(sp.start_time,'') start_time,COALESCE(sp.end_time,'') end_time,
                        (SELECT COUNT(*) FROM enrollments e WHERE e.class_id=c.id AND COALESCE(e.status,'Active')='Active') enrolled FROM classes c LEFT JOIN courses co ON co.id=c.course_id LEFT JOIN schedule_periods sp ON sp.cycle_day=c.cycle_day AND sp.name=c.period WHERE c.teacher_id=? AND COALESCE(c.published,0)=1 AND COALESCE(c.cycle_day,1)=? ORDER BY COALESCE(sp.sort_order,999),sp.start_time""",(staff_id,cycle))
            # Annotate the teacher's own classes when another staff member is covering,
            # and add classes this teacher is covering as a substitute on this date.
            own_assignments=rows("""SELECT sa.*,sub.name substitute_name FROM substitute_assignments sa
                JOIN staff sub ON sub.id=sa.substitute_staff_id
                WHERE sa.teacher_staff_id=? AND sa.status='Active' AND ? BETWEEN sa.start_date AND sa.end_date""",(staff_id,ds))
            for c in regular:
                for sa in own_assignments:
                    if substitute_class_allowed(sa,int(c.get('id') or 0)):
                        c['teacher_out']=1;c['has_substitute']=1;c['substitute_name']=sa.get('substitute_name') or 'Substitute'
                        break
            cover_assignments=rows("""SELECT sa.*,t.name teacher_name FROM substitute_assignments sa
                JOIN staff t ON t.id=sa.teacher_staff_id
                WHERE sa.substitute_staff_id=? AND sa.status='Active' AND ? BETWEEN sa.start_date AND sa.end_date""",(staff_id,ds))
            existing_ids={int(x.get('id') or 0) for x in regular}
            for sa in cover_assignments:
                for c in teacher_classes_for_date(int(sa['teacher_staff_id']),ds):
                    cid=int(c.get('id') or 0)
                    if not substitute_class_allowed(sa,cid):continue
                    cc=dict(c);cc['is_substitute_coverage']=1;cc['covering_for_name']=sa.get('teacher_name') or 'Teacher';cc['substitute_assignment_id']=sa['id']
                    if cid not in existing_ids:
                        regular.append(cc);existing_ids.add(cid)
            regular.sort(key=lambda x:(str(x.get('start_time') or '99:99'),str(x.get('period') or ''),str(x.get('name') or '')))
            return self.send_json({'date':ds,'school_year_start':a.isoformat(),'school_year_end':b.isoformat(),'in_regular_year':a<=d<=b,'special_day':special,'classes':regular,'summer':_ss_summer_for_teacher(staff_id,ds)})
        if path=='/api/summer-school':
            if role=='admin':
                return self.send_json({'classes':rows("""SELECT sc.*,COALESCE(co.code,'') course_code,COALESCE(st.name,'') teacher_name,(SELECT COUNT(*) FROM summer_enrollments se WHERE se.class_id=sc.id AND COALESCE(se.status,'Active')='Active') enrolled FROM summer_classes sc LEFT JOIN courses co ON co.id=sc.course_id LEFT JOIN staff st ON st.id=sc.teacher_id ORDER BY sc.start_date,sc.start_time"""),'enrollments':rows("""SELECT se.*,s.first_name||' '||s.last_name student_name,s.student_number,sc.name class_name FROM summer_enrollments se JOIN students s ON s.id=se.student_id JOIN summer_classes sc ON sc.id=se.class_id ORDER BY sc.name,s.last_name""")})
            sid=int(user.get('student_id') or 0); return self.send_json({'classes':rows("SELECT sc.* FROM summer_enrollments se JOIN summer_classes sc ON sc.id=se.class_id WHERE se.student_id=? AND COALESCE(se.status,'Active')='Active'",(sid,))})
    except Exception as exc:return self.send_json({'error':str(exc)},500)

def _ss_term_post(self):
    parsed=urlparse(self.path); path=parsed.path
    if path not in {'/api/summer-school/class','/api/summer-school/enroll','/api/summer-school/unenroll','/api/school-year-window'}:return _SS_PRE_TERM_POST(self)
    user=self.require_user()
    if not user:return
    if user['role']!='admin':return self.send_json({'error':'Permission denied'},403)
    data=self.read_body() or {}
    try:
        if path=='/api/school-year-window':
            for k in ['school_year_start_month_day','school_year_end_month_day']:
                if data.get(k):run("INSERT INTO district_settings(setting_key,setting_value) VALUES(?,?) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value",(k,data[k]))
            return self.send_json({'ok':1})
        if path=='/api/summer-school/class':
            vals=(int(data.get('course_id') or 0) or None,data.get('name') or 'Summer Course',data.get('section') or '',int(data.get('teacher_id') or 0) or None,data.get('room') or '',data.get('start_date'),data.get('end_date'),data.get('meeting_days') or '1,2,3,4,5',data.get('start_time') or '08:00',data.get('end_time') or '09:00',int(data.get('capacity') or 30))
            iid=int(data.get('id') or 0)
            if iid:run("UPDATE summer_classes SET course_id=?,name=?,section=?,teacher_id=?,room=?,start_date=?,end_date=?,meeting_days=?,start_time=?,end_time=?,capacity=? WHERE id=?",vals+(iid,))
            else:iid=run("INSERT INTO summer_classes(course_id,name,section,teacher_id,room,start_date,end_date,meeting_days,start_time,end_time,capacity) VALUES(?,?,?,?,?,?,?,?,?,?,?)",vals)
            return self.send_json({'id':iid})
        cid=int(data.get('class_id') or 0);sid=int(data.get('student_id') or 0)
        if path=='/api/summer-school/enroll':run("INSERT INTO summer_enrollments(class_id,student_id,status) VALUES(?,?,'Active') ON CONFLICT(class_id,student_id) DO UPDATE SET status='Active'",(cid,sid));return self.send_json({'ok':1})
        run("UPDATE summer_enrollments SET status='Dropped' WHERE class_id=? AND student_id=?",(cid,sid));return self.send_json({'ok':1})
    except Exception as exc:return self.send_json({'error':str(exc)},500)
Handler.do_GET=_ss_term_get
Handler.do_POST=_ss_term_post
# --- End School-Year + Teacher Schedule + Summer School ---


# --- ScholarSync Student Class Gradebooks + Admin-Defined Academic Year ---
_SS_PRE_ACADEMIC_YEAR_INIT_DB = init_db
def init_db():
    _SS_PRE_ACADEMIC_YEAR_INIT_DB()
    # Data-safe migration for installations created before district_settings
    # had updated_at. CREATE TABLE IF NOT EXISTS does not add columns.
    try:
        _ds_cols={r.get('name') for r in rows("PRAGMA table_info(district_settings)")}
        if 'updated_at' not in _ds_cols:
            run("ALTER TABLE district_settings ADD COLUMN updated_at TEXT")
            run("UPDATE district_settings SET updated_at=CURRENT_TIMESTAMP WHERE updated_at IS NULL")
    except Exception:
        pass
    run("""CREATE TABLE IF NOT EXISTS special_schedule_periods(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        calendar_day_id INTEGER NOT NULL,
        source_cycle_day INTEGER NOT NULL,
        period_name TEXT NOT NULL,
        custom_label TEXT DEFAULT '',
        start_time TEXT NOT NULL,
        end_time TEXT NOT NULL,
        sort_order INTEGER DEFAULT 0,
        UNIQUE(calendar_day_id,source_cycle_day,period_name)
    )""")
    # Exact dates supersede the legacy month/day defaults. Existing databases are
    # migrated once so this update remains data-safe, then admins own these values.
    existing_start = (one("SELECT setting_value FROM district_settings WHERE setting_key='school_year_start_date'") or {}).get('setting_value') or ''
    existing_end = (one("SELECT setting_value FROM district_settings WHERE setting_key='school_year_end_date'") or {}).get('setting_value') or ''
    if not existing_start or not existing_end:
        now = datetime.now().date()
        legacy_s = (one("SELECT setting_value FROM district_settings WHERE setting_key='school_year_start_month_day'") or {}).get('setting_value') or '08-15'
        legacy_e = (one("SELECT setting_value FROM district_settings WHERE setting_key='school_year_end_month_day'") or {}).get('setting_value') or '06-15'
        try:
            sm,sd=map(int,legacy_s.split('-')); em,ed=map(int,legacy_e.split('-'))
            sy=now.year if now.month>=sm else now.year-1
            start=date(sy,sm,sd).isoformat(); end=date(sy+1,em,ed).isoformat()
        except Exception:
            start=date(now.year,1,1).isoformat(); end=date(now.year,12,31).isoformat()
        if not existing_start:
            run("INSERT INTO district_settings(setting_key,setting_value) VALUES('school_year_start_date',?) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value",(start,))
        if not existing_end:
            run("INSERT INTO district_settings(setting_key,setting_value) VALUES('school_year_end_date',?) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value",(end,))
    if not one("SELECT setting_key FROM district_settings WHERE setting_key='school_year_name'"):
        a=(one("SELECT setting_value FROM district_settings WHERE setting_key='school_year_start_date'") or {}).get('setting_value') or ''
        b=(one("SELECT setting_value FROM district_settings WHERE setting_key='school_year_end_date'") or {}).get('setting_value') or ''
        try:name=f"{a[:4]}–{b[:4]} School Year"
        except Exception:name='Current School Year'
        run("INSERT INTO district_settings(setting_key,setting_value) VALUES('school_year_name',?)",(name,))

def _ss_school_window(for_date=None):
    start=(one("SELECT setting_value FROM district_settings WHERE setting_key='school_year_start_date'") or {}).get('setting_value') or ''
    end=(one("SELECT setting_value FROM district_settings WHERE setting_key='school_year_end_date'") or {}).get('setting_value') or ''
    try:
        return datetime.strptime(start,'%Y-%m-%d').date(),datetime.strptime(end,'%Y-%m-%d').date()
    except Exception:
        d=datetime.now().date() if for_date is None else (datetime.strptime(for_date,'%Y-%m-%d').date() if isinstance(for_date,str) else for_date)
        return date(d.year,1,1),date(d.year,12,31)

_SS_PRE_ACADEMIC_YEAR_GET=Handler.do_GET
_SS_PRE_ACADEMIC_YEAR_POST=Handler.do_POST

def _ss_academic_year_get(self):
    parsed=urlparse(self.path); path=parsed.path
    if path!='/api/academic-year-settings': return _SS_PRE_ACADEMIC_YEAR_GET(self)
    user=self.require_user()
    if not user:return
    if user['role'] not in {'admin','teacher','student','parent','counselor','substitute'}:
        return self.send_json({'error':'Permission denied'},403)
    start=(one("SELECT setting_value FROM district_settings WHERE setting_key='school_year_start_date'") or {}).get('setting_value') or ''
    end=(one("SELECT setting_value FROM district_settings WHERE setting_key='school_year_end_date'") or {}).get('setting_value') or ''
    name=(one("SELECT setting_value FROM district_settings WHERE setting_key='school_year_name'") or {}).get('setting_value') or 'Current School Year'
    return self.send_json({'name':name,'start_date':start,'end_date':end})

def _ss_academic_year_post(self):
    parsed=urlparse(self.path); path=parsed.path
    if path!='/api/academic-year-settings':return _SS_PRE_ACADEMIC_YEAR_POST(self)
    user=self.require_user()
    if not user:return
    if user['role']!='admin':return self.send_json({'error':'Permission denied'},403)
    data=self.read_body() or {}; name=str(data.get('name') or '').strip(); start=str(data.get('start_date') or '').strip(); end=str(data.get('end_date') or '').strip()
    try:
        a=datetime.strptime(start,'%Y-%m-%d').date(); b=datetime.strptime(end,'%Y-%m-%d').date()
    except Exception:return self.send_json({'error':'Valid start and end dates are required'},400)
    if b<=a:return self.send_json({'error':'The school year end date must be after the start date'},400)
    if (b-a).days>550:return self.send_json({'error':'School year range is too long'},400)
    if not name:name=f'{a.year}–{b.year} School Year'
    try:
        for k,v in [('school_year_name',name),('school_year_start_date',start),('school_year_end_date',end)]:
            try:
                run("INSERT INTO district_settings(setting_key,setting_value,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value,updated_at=CURRENT_TIMESTAMP",(k,v))
            except Exception as exc:
                # Backward-compatible fallback for older databases whose
                # district_settings table does not yet have updated_at.
                if 'updated_at' not in str(exc).lower():
                    raise
                run("INSERT INTO district_settings(setting_key,setting_value) VALUES(?,?) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value",(k,v))
        audit(user,'Updated academic year boundaries','Academic Year','',f'{name}: {start} through {end}')
        return self.send_json({'ok':1,'name':name,'start_date':start,'end_date':end})
    except Exception as exc:
        return self.send_json({'error':f'Could not save academic year: {exc}'},500)

Handler.do_GET=_ss_academic_year_get
Handler.do_POST=_ss_academic_year_post
# --- End Student Class Gradebooks + Admin-Defined Academic Year ---


# --- ScholarSync Custom Special-Day Period Builder ---
_SS_PRE_SPECIAL_SCHEDULE_GET=Handler.do_GET
_SS_PRE_SPECIAL_SCHEDULE_POST=Handler.do_POST

def _ss_rotation_labels_and_periods():
    rot=one("SELECT * FROM schedule_rotation_settings WHERE id=1") or {'rotation_count':2,'day_labels':'["Day A","Day B"]'}
    try: labels=json.loads(rot.get('day_labels') or '[]')
    except Exception: labels=[]
    count=max(1,int(rot.get('rotation_count') or len(labels) or 2))
    while len(labels)<count: labels.append(f'Day {len(labels)+1}')
    periods=rows("SELECT id,name,start_time,end_time,sort_order,cycle_day,day_label,COALESCE(is_lunch,0) is_lunch FROM schedule_periods WHERE COALESCE(active,1)=1 ORDER BY cycle_day,sort_order,start_time,name")
    grouped=[]
    for i in range(1,count+1):
        grouped.append({'cycle_day':i,'label':labels[i-1],'periods':[p for p in periods if int(p.get('cycle_day') or 1)==i]})
    return grouped

def _ss_special_periods_for_date(ds):
    day=one("SELECT * FROM school_calendar_days WHERE date=?",(ds,))
    if not day:return day,[]
    return day,rows("SELECT * FROM special_schedule_periods WHERE calendar_day_id=? ORDER BY sort_order,start_time,id",(day['id'],))

def _ss_teacher_special_classes(staff_id,ds):
    day,custom=_ss_special_periods_for_date(ds)
    out=[]
    for cp in custom:
        out += rows("""SELECT c.id,c.name,c.section,c.period,c.room,c.cycle_day,COALESCE(co.code,'') course_code,
          ? start_time,? end_time,(SELECT COUNT(*) FROM enrollments e WHERE e.class_id=c.id AND COALESCE(e.status,'Active')='Active') enrolled,
          (SELECT COUNT(*) FROM attendance at WHERE at.class_id=c.id AND at.date=?) marked,? special_schedule_label,? special_schedule_order
          FROM classes c LEFT JOIN courses co ON co.id=c.course_id WHERE c.teacher_id=? AND COALESCE(c.published,0)=1 AND COALESCE(c.cycle_day,1)=? AND c.period=?""",
          (cp['start_time'],cp['end_time'],ds,cp.get('custom_label') or cp['period_name'],cp['sort_order'],staff_id,cp['source_cycle_day'],cp['period_name']))
    return day,out

def _ss_special_schedule_get(self):
    parsed=urlparse(self.path); path=parsed.path; q=parse_qs(parsed.query)
    if path not in {'/api/special-schedule/setup','/api/special-schedule','/api/teacher-day'}:
        return _SS_PRE_SPECIAL_SCHEDULE_GET(self)
    user=self.require_user()
    if not user:return
    try:
        if path=='/api/special-schedule/setup':
            if user['role']!='admin':return self.send_json({'error':'Permission denied'},403)
            ds=q.get('date',[''])[0]; day,selected=_ss_special_periods_for_date(ds) if ds else (None,[])
            return self.send_json({'rotation_days':_ss_rotation_labels_and_periods(),'day':day,'selected':selected})
        if path=='/api/special-schedule':
            ds=q.get('date',[''])[0]
            day,selected=_ss_special_periods_for_date(ds)
            return self.send_json({'day':day,'periods':selected})
        # Override the teacher live-day endpoint only for a custom special schedule.
        if user['role'] not in {'teacher','admin'}: return self.send_json({'error':'Permission denied'},403)
        tzrec=one("SELECT setting_value FROM district_settings WHERE setting_key='school_timezone'")
        now,_=school_now((tzrec or {}).get('setting_value') or 'America/Chicago')
        ds=q.get('date',[now.strftime('%Y-%m-%d')])[0]
        day,_custom=_ss_special_periods_for_date(ds)
        if not day or str(day.get('day_type') or '').lower()!='special schedule' or not _custom:
            return _SS_PRE_SPECIAL_SCHEDULE_GET(self)
        staff_id=int(q.get('staff_id',[str(user.get('staff_id') or 0)])[0] or 0)
        if user['role']=='teacher':staff_id=int(user.get('staff_id') or 0)
        day,classes=_ss_teacher_special_classes(staff_id,ds)
        return self.send_json({'date':ds,'now':now.isoformat(),'rotation_day':None,'rotation_label':'Special Schedule','special_day':day,'classes':classes,'custom_schedule':True})
    except Exception as exc:return self.send_json({'error':str(exc)},500)

def _ss_special_schedule_post(self):
    parsed=urlparse(self.path); path=parsed.path
    if path!='/api/school-calendar':
        return _SS_PRE_SPECIAL_SCHEDULE_POST(self)
    user=self.require_user()
    if not user:return
    if user['role']!='admin':return self.send_json({'error':'Permission denied'},403)
    try:data=self.read_body() or {}
    except Exception:return self.send_json({'error':'Invalid request body'},400)
    try:
        item_id=int(data.get('id') or 0); ds=str(data.get('date') or '').strip(); title=str(data.get('title') or '').strip(); day_type=str(data.get('day_type') or 'School Day')
        if not ds or not title:return self.send_json({'error':'Date and title are required'},400)
        try:datetime.strptime(ds,'%Y-%m-%d')
        except Exception:return self.send_json({'error':'Valid date is required'},400)
        periods=data.get('special_periods') or []
        if str(day_type).lower()=='special schedule':
            if not isinstance(periods,list) or not periods:return self.send_json({'error':'Choose at least one period for the special schedule'},400)
            cleaned=[]; seen=set()
            for idx,p in enumerate(periods):
                cyc=int(p.get('source_cycle_day') or 0); name=str(p.get('period_name') or '').strip(); st=str(p.get('start_time') or '').strip(); et=str(p.get('end_time') or '').strip(); label=str(p.get('custom_label') or '').strip()
                if not cyc or not name or not st or not et:return self.send_json({'error':'Every selected period needs a start and end time'},400)
                if et<=st:return self.send_json({'error':f'{name}: end time must be after start time'},400)
                key=(cyc,name)
                if key in seen:return self.send_json({'error':f'{name} was selected more than once'},400)
                seen.add(key);cleaned.append((cyc,name,label,st,et,idx+1))
            # Prevent accidental overlapping blocks.
            ordered=sorted(cleaned,key=lambda x:x[3])
            for a,b in zip(ordered,ordered[1:]):
                if a[4]>b[3]:return self.send_json({'error':f'Schedule times overlap between {a[1]} and {b[1]}'},400)
        else: cleaned=[]
        vals=(ds,title,day_type,None,data.get('details') or '',data.get('start_time') or '',data.get('end_time') or '',user.get('id'),data.get('closure_reason') or '',data.get('closure_message') or '',1 if data.get('cancel_activities') else 0,0 if str(data.get('alert_enabled','1')).lower() in {'0','false','no'} else 1)
        if item_id:
            run("UPDATE school_calendar_days SET date=?,title=?,day_type=?,rotation_day=?,details=?,start_time=?,end_time=?,created_by=?,closure_reason=?,closure_message=?,cancel_activities=?,alert_enabled=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",vals+(item_id,))
        else:
            item_id=run("INSERT INTO school_calendar_days(date,title,day_type,rotation_day,details,start_time,end_time,created_by,closure_reason,closure_message,cancel_activities,alert_enabled) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",vals)
        run("DELETE FROM special_schedule_periods WHERE calendar_day_id=?",(item_id,))
        for cp in cleaned:
            run("INSERT INTO special_schedule_periods(calendar_day_id,source_cycle_day,period_name,custom_label,start_time,end_time,sort_order) VALUES(?,?,?,?,?,?,?)",(item_id,)+cp)
        if str(day_type).lower() in {'school closure','closed','no school'}:
            msg=(data.get('closure_message') or data.get('details') or title).strip()
            existing=one("SELECT id FROM announcements WHERE title=? AND substr(publish_at,1,10)=?",(f'SCHOOL CLOSED — {title}',ds))
            if not existing:run("INSERT INTO announcements(title,body,audience,priority,publish_at,active,created_by) VALUES(?,?,?,?,?,1,?)",(f'SCHOOL CLOSED — {title}',msg,'All','Emergency',f'{ds} 00:00:00',user.get('id')))
        audit(user,'Updated school calendar day','Calendar Day',str(item_id),f'{day_type}: {title} on {ds}')
        return self.send_json({'id':item_id,'special_periods':len(cleaned)})
    except sqlite3.IntegrityError as exc:return self.send_json({'error':str(exc)},409)
    except Exception as exc:return self.send_json({'error':str(exc)},500)

Handler.do_GET=_ss_special_schedule_get
Handler.do_POST=_ss_special_schedule_post
# --- End Custom Special-Day Period Builder ---



# --- ScholarSync Next-Wave School Operations Suite (Build 244) ---
_SS_PRE_NEXTWAVE_INIT = init_db

def init_db():
    _SS_PRE_NEXTWAVE_INIT()
    run("""CREATE TABLE IF NOT EXISTS nextwave_records(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        feature TEXT NOT NULL,
        title TEXT NOT NULL,
        subject_id INTEGER,
        subject_type TEXT DEFAULT '',
        event_date TEXT DEFAULT '',
        status TEXT DEFAULT 'Open',
        details TEXT DEFAULT '',
        data_json TEXT DEFAULT '{}',
        created_by INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run("CREATE INDEX IF NOT EXISTS idx_nextwave_feature ON nextwave_records(feature,event_date,status)")

_SS_PRE_NEXTWAVE_GET = Handler.do_GET
_SS_PRE_NEXTWAVE_POST = Handler.do_POST

_NEXTWAVE_ROLE_FEATURES = {
    'admin': {'bell-schedules', 'progress-reports', 'teacher-comments', 'support-flags', 'office-checkin', 'consequences', 'nurse-visits', 'notification-preferences', 'notification-center-plus', 'assignment-extensions', 'late-work-rules', 'extra-credit', 'rubrics', 'grade-rules', 'transcripts', 'graduation-requirements', 'course-prerequisites', 'waitlists', 'schedule-change-requests', 'room-conflicts', 'teacher-coverage', 'attendance-patterns', 'grade-risk-alerts', 'eligibility', 'repair-requests', 'lost-found', 'field-trips', 'permission-slips', 'visitor-management', 'school-store', 'family-household', 'impersonation', 'audit-viewer-plus', 'data-import', 'data-export', 'school-setup-wizard', 'term-boundaries', 'exam-schedules', 'inclement-weather-modes', 'closure-acknowledgment', 'reunification-queue', 'drill-analytics', 'mobile-attendance'},
    'counselor': {'progress-reports', 'support-flags', 'office-checkin', 'consequences', 'transcripts', 'graduation-requirements', 'course-prerequisites', 'waitlists', 'schedule-change-requests', 'room-conflicts', 'attendance-patterns', 'grade-risk-alerts', 'eligibility'},
    'finance': {'school-store', 'data-export'},
    'nurse': {'support-flags', 'nurse-visits'},
    'parent': {'notification-preferences', 'schedule-change-requests', 'repair-requests', 'lost-found', 'field-trips', 'permission-slips'},
    'student': {'notification-preferences', 'schedule-change-requests', 'repair-requests', 'lost-found', 'field-trips', 'permission-slips'},
    'teacher': {'progress-reports', 'teacher-comments', 'support-flags', 'office-checkin', 'consequences', 'notification-preferences', 'assignment-extensions', 'late-work-rules', 'extra-credit', 'rubrics', 'grade-rules', 'teacher-coverage', 'attendance-patterns', 'grade-risk-alerts', 'eligibility', 'repair-requests', 'field-trips', 'permission-slips', 'exam-schedules', 'drill-analytics', 'mobile-attendance'},
}

def _nextwave_allowed(user, feature, write=False):
    role = str(user.get('role') or '')
    if role == 'admin': return feature in _NEXTWAVE_ROLE_FEATURES.get('admin', set())
    return feature in _NEXTWAVE_ROLE_FEATURES.get(role, set())

def _ss_nextwave_get(self):
    parsed=urlparse(self.path); path=parsed.path; q=parse_qs(parsed.query)
    if path!='/api/nextwave/records': return _SS_PRE_NEXTWAVE_GET(self)
    user=self.require_user()
    if not user:return
    feature=str(q.get('feature',[''])[0] or '').strip()
    if not feature:return self.send_json({'error':'Feature is required'},400)
    if not _nextwave_allowed(user,feature):return self.send_json({'error':'Permission denied'},403)
    sql="SELECT * FROM nextwave_records WHERE feature=?";args=[feature]
    if user.get('role') in {'student','parent'}:
        sql+=' AND created_by=?';args.append(user.get('id'))
    sql+=' ORDER BY CASE WHEN event_date="" THEN 1 ELSE 0 END,event_date DESC,id DESC LIMIT 500'
    out=rows(sql,args)
    for r in out:
        try:r['data']=json.loads(r.get('data_json') or '{}')
        except Exception:r['data']={}
    return self.send_json(out)

def _ss_nextwave_post(self):
    parsed=urlparse(self.path); path=parsed.path
    if path!='/api/nextwave/records':return _SS_PRE_NEXTWAVE_POST(self)
    user=self.require_user()
    if not user:return
    try:data=self.read_body() or {}
    except Exception:return self.send_json({'error':'Invalid request body'},400)
    feature=str(data.get('feature') or '').strip();action=str(data.get('action') or 'create').lower()
    if not feature:return self.send_json({'error':'Feature is required'},400)
    if not _nextwave_allowed(user,feature,True):return self.send_json({'error':'Permission denied'},403)
    try:
        if action=='delete':
            rid=int(data.get('id') or 0);rec=one('SELECT * FROM nextwave_records WHERE id=? AND feature=?',(rid,feature))
            if not rec:return self.send_json({'error':'Record not found'},404)
            if user.get('role')!='admin' and int(rec.get('created_by') or 0)!=int(user.get('id') or 0):return self.send_json({'error':'Permission denied'},403)
            run('DELETE FROM nextwave_records WHERE id=?',(rid,));audit(user,'Deleted next-wave record',feature,rid);return self.send_json({'ok':1})
        title=str(data.get('title') or '').strip();status=str(data.get('status') or 'Open').strip();event_date=str(data.get('event_date') or '').strip();details=str(data.get('details') or '').strip()
        if not title:return self.send_json({'error':'Title is required'},400)
        payload=data.get('data') or {}
        if not isinstance(payload,dict):payload={}
        subject_id=int(data.get('subject_id') or 0) or None;subject_type=str(data.get('subject_type') or '')
        rid=int(data.get('id') or 0)
        if rid:
            rec=one('SELECT * FROM nextwave_records WHERE id=? AND feature=?',(rid,feature))
            if not rec:return self.send_json({'error':'Record not found'},404)
            run('UPDATE nextwave_records SET title=?,subject_id=?,subject_type=?,event_date=?,status=?,details=?,data_json=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(title,subject_id,subject_type,event_date,status,details,json.dumps(payload),rid))
            audit(user,'Updated next-wave record',feature,rid)
        else:
            rid=run('INSERT INTO nextwave_records(feature,title,subject_id,subject_type,event_date,status,details,data_json,created_by) VALUES(?,?,?,?,?,?,?,?,?)',(feature,title,subject_id,subject_type,event_date,status,details,json.dumps(payload),user.get('id')))
            audit(user,'Created next-wave record',feature,rid)
        return self.send_json({'ok':1,'id':rid})
    except Exception as exc:return self.send_json({'error':str(exc)},500)

Handler.do_GET=_ss_nextwave_get
Handler.do_POST=_ss_nextwave_post
# --- End Next-Wave School Operations Suite ---


# --- ScholarSync Build 246: contextual integrations ---
_SS_PRE_INTEGRATED_GET = Handler.do_GET

def _ss_integrated_get(self):
    parsed=urlparse(self.path); path=parsed.path
    if path!='/api/integrated/assignment-extensions':
        return _SS_PRE_INTEGRATED_GET(self)
    user=self.require_user()
    if not user:return
    scope=student_scope(user)
    if user.get('role')=='student': sid=int(user.get('student_id') or 0)
    else:
        q=parse_qs(parsed.query); sid=int((q.get('student_id') or [0])[0] or 0)
    if not sid:return self.send_json([])
    if scope is not None and sid not in [int(x) for x in scope if x]:return self.send_json({'error':'Permission denied'},403)
    out=rows("SELECT * FROM nextwave_records WHERE feature='assignment-extensions' AND subject_id=? ORDER BY id DESC",(sid,))
    for r in out:
        try:r['data']=json.loads(r.get('data_json') or '{}')
        except Exception:r['data']={}
    return self.send_json(out)

Handler.do_GET=_ss_integrated_get
# --- End Build 246 contextual integrations ---

# --- Build 255: Teacher Substitute Coverage Requests ---
def _ensure_substitute_request_schema():
    try:
        with db_connect() as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS substitute_requests(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    teacher_staff_id INTEGER NOT NULL,
                    request_date TEXT NOT NULL,
                    reason TEXT DEFAULT '',
                    notes TEXT DEFAULT '',
                    scope TEXT NOT NULL DEFAULT 'all',
                    selected_class_ids TEXT DEFAULT '[]',
                    status TEXT NOT NULL DEFAULT 'Pending',
                    admin_note TEXT DEFAULT '',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    reviewed_at TEXT DEFAULT '',
                    reviewed_by TEXT DEFAULT ''
                )
            """)
            con.commit()
    except Exception as ex:
        print("substitute request schema migration:", ex)

_old_init_db_build255 = init_db
def init_db():
    _old_init_db_build255()
    _ensure_substitute_request_schema()



# --- Build 255 substitute request GET routes ---
_old_do_GET_build255 = Handler.do_GET
def _do_GET_build255(self):
    path = urlparse(self.path).path
    q = parse_qs(urlparse(self.path).query)
    if path == "/api/substitute/requests":
        user = self.current_user()
        if not user:
            return self.send_json({"error":"Unauthorized"},401)
        role = str(user.get("role") or "").lower()
        with db_connect() as con:
            con.row_factory = sqlite3.Row
            if role == "admin":
                rr = con.execute("""
                    SELECT sr.*, s.name AS teacher_name
                    FROM substitute_requests sr
                    LEFT JOIN staff s ON s.id=sr.teacher_staff_id
                    ORDER BY sr.request_date DESC, sr.id DESC
                """).fetchall()
            elif role == "teacher":
                sid = int(user.get("staff_id") or 0)
                rr = con.execute("""
                    SELECT sr.*, s.name AS teacher_name
                    FROM substitute_requests sr
                    LEFT JOIN staff s ON s.id=sr.teacher_staff_id
                    WHERE sr.teacher_staff_id=?
                    ORDER BY sr.request_date DESC, sr.id DESC
                """,(sid,)).fetchall()
            else:
                return self.send_json({"error":"Permission denied"},403)
        return self.send_json([dict(x) for x in rr])
    if path == "/api/substitute/request/classes":
        user = self.current_user()
        if not user:
            return self.send_json({"error":"Unauthorized"},401)
        role = str(user.get("role") or "").lower()
        date = (q.get("date") or [""])[0]
        teacher_id = int((q.get("teacher_id") or [0])[0] or 0)
        if role == "teacher":
            teacher_id = int(user.get("staff_id") or 0)
        elif role != "admin":
            return self.send_json({"error":"Permission denied"},403)
        if not date or not teacher_id:
            return self.send_json([])
        try:
            classes = teacher_classes_for_date(teacher_id,date)
        except Exception:
            classes = []
        return self.send_json(classes)
    return _old_do_GET_build255(self)
Handler.do_GET = _do_GET_build255



# --- Build 255 substitute request POST routes ---
_old_do_POST_build255 = Handler.do_POST
def _do_POST_build255(self):
    path = urlparse(self.path).path
    if path in {"/api/substitute/request","/api/substitute/request/review"}:
        user = self.current_user()
        if not user:
            return self.send_json({"error":"Unauthorized"},401)
        role = str(user.get("role") or "").lower()
        data = self.read_body()
        if path == "/api/substitute/request":
            if role != "teacher":
                return self.send_json({"error":"Permission denied"},403)
            teacher_id = int(user.get("staff_id") or 0)
            req_date = str(data.get("date") or "").strip()
            scope = str(data.get("scope") or "all").strip().lower()
            selected = data.get("selected_class_ids") or []
            reason = str(data.get("reason") or "").strip()
            notes = str(data.get("notes") or "").strip()
            if not req_date:
                return self.send_json({"error":"Date is required"},400)
            try:
                valid_classes = teacher_classes_for_date(teacher_id,req_date)
            except Exception:
                valid_classes = []
            valid_ids = {int(c.get("id")) for c in valid_classes if c.get("id") is not None}
            if scope == "selected":
                try:
                    chosen = [int(x) for x in selected]
                except Exception:
                    chosen = []
                chosen = [x for x in chosen if x in valid_ids]
                if not chosen:
                    return self.send_json({"error":"Choose at least one class/period"},400)
            else:
                scope = "all"
                chosen = sorted(valid_ids)
            with db_connect() as con:
                cur = con.execute("""
                    INSERT INTO substitute_requests
                    (teacher_staff_id,request_date,reason,notes,scope,selected_class_ids,status)
                    VALUES(?,?,?,?,?,?, 'Pending')
                """,(teacher_id,req_date,reason,notes,scope,json.dumps(chosen)))
                con.commit()
                rid = cur.lastrowid
            return self.send_json({"ok":True,"id":rid})
        else:
            if role != "admin":
                return self.send_json({"error":"Permission denied"},403)
            rid = int(data.get("id") or 0)
            status = str(data.get("status") or "").strip()
            note = str(data.get("admin_note") or "").strip()
            if status not in {"Pending","Approved","Declined","Assigned","Cancelled"}:
                return self.send_json({"error":"Invalid status"},400)
            with db_connect() as con:
                con.execute("""
                    UPDATE substitute_requests
                    SET status=?, admin_note=?, reviewed_at=CURRENT_TIMESTAMP, reviewed_by=?
                    WHERE id=?
                """,(status,note,str(user.get("name") or user.get("email") or "Admin"),rid))
                con.commit()
            return self.send_json({"ok":True})
    return _old_do_POST_build255(self)
Handler.do_POST = _do_POST_build255


# --- Build 260: Complete Admin Substitute Request Workflow ---
_OLD_DO_POST_BUILD260 = Handler.do_POST
def _do_POST_build260(self):
    path = urlparse(self.path).path
    if path not in {"/api/substitute/request/assign", "/api/substitute/request/deny"}:
        return _OLD_DO_POST_BUILD260(self)

    user = self.current_user()
    if not user:
        return self.send_json({"error":"Unauthorized"},401)
    if str(user.get("role") or "").lower() != "admin":
        return self.send_json({"error":"Permission denied"},403)

    data = self.read_body()
    rid = int(data.get("request_id") or data.get("id") or 0)
    if not rid:
        return self.send_json({"error":"Request is required"},400)

    req = one("SELECT * FROM substitute_requests WHERE id=?",(rid,))
    if not req:
        return self.send_json({"error":"Substitute request not found"},404)

    if path == "/api/substitute/request/deny":
        note = str(data.get("admin_note") or "").strip()
        run("""UPDATE substitute_requests
               SET status='Declined',admin_note=?,reviewed_at=CURRENT_TIMESTAMP,reviewed_by=?
               WHERE id=?""",(note,str(user.get("name") or user.get("email") or "Admin"),rid))
        audit(user,"Declined substitute request","Substitutes",rid,{"teacher_staff_id":req.get("teacher_staff_id"),"date":req.get("request_date")})
        return self.send_json({"ok":1,"status":"Declined"})

    # Approve + assign coverage atomically.
    sub = int(data.get("substitute_staff_id") or 0)
    if not sub:
        return self.send_json({"error":"Choose a substitute or covering teacher"},400)

    teacher = int(req.get("teacher_staff_id") or 0)
    day = str(req.get("request_date") or "").strip()
    if not teacher or not day:
        return self.send_json({"error":"Request is missing teacher/date information"},400)
    if sub == teacher:
        return self.send_json({"error":"A teacher cannot cover their own class"},400)

    sub_staff = one("SELECT id,name,role,status FROM staff WHERE id=?",(sub,))
    if not sub_staff or str(sub_staff.get("status") or "Active") != "Active":
        return self.send_json({"error":"Selected covering staff member is not active"},404)

    scope = str(req.get("scope") or "all").lower()
    try:
        selected_ids = [int(x) for x in json.loads(req.get("selected_class_ids") or "[]")]
    except Exception:
        selected_ids = []

    teacher_classes = teacher_classes_for_date(teacher,day)
    valid_ids = {int(c.get("id") or 0) for c in teacher_classes}
    if scope == "selected":
        selected_ids = [x for x in selected_ids if x in valid_ids]
        if not selected_ids:
            return self.send_json({"error":"This request has no valid selected periods/classes"},400)
        covered = [c for c in teacher_classes if int(c.get("id") or 0) in set(selected_ids)]
        coverage_mode = "selected"
    else:
        selected_ids = []
        covered = teacher_classes
        coverage_mode = "all"

    if not covered:
        return self.send_json({"error":"The teacher has no classes to cover on this date"},400)

    # Do not double-book the covering staff member on another active substitute assignment.
    existing = one("""SELECT id FROM substitute_assignments
                      WHERE substitute_staff_id=? AND status='Active'
                      AND NOT(end_date<? OR start_date>?) LIMIT 1""",(sub,day,day))
    if existing:
        return self.send_json({"error":"This staff member already has substitute coverage assigned on that date"},409)

    # Regular teachers must be free during every requested class.
    if "teacher" in str(sub_staff.get("role") or "").lower():
        own = teacher_classes_for_date(sub,day)
        for oc in own:
            for cc in covered:
                os = str(oc.get("start_time") or "")
                oe = str(oc.get("end_time") or "")
                cs = str(cc.get("start_time") or "")
                ce = str(cc.get("end_time") or "")
                if os and oe and cs and ce:
                    clash = os < ce and cs < oe
                else:
                    clash = bool(str(oc.get("period") or "") and str(oc.get("period") or "") == str(cc.get("period") or ""))
                if clash:
                    return self.send_json({
                        "error":f"{sub_staff.get('name') or 'That teacher'} is unavailable: they teach {oc.get('name') or 'another class'} during the requested coverage time."
                    },409)

    admin_note = str(data.get("admin_note") or "").strip()
    aid = run("""INSERT INTO substitute_assignments
                 (substitute_staff_id,teacher_staff_id,start_date,end_date,status,reason,admin_notes,created_by,coverage_mode,selected_class_ids)
                 VALUES(?,?,?,?,?,?,?,?,?,?)""",
              (sub,teacher,day,day,'Active',str(req.get("reason") or ""),admin_note,user.get("id"),coverage_mode,json.dumps(selected_ids)))

    run("""UPDATE substitute_requests
           SET status='Assigned',admin_note=?,reviewed_at=CURRENT_TIMESTAMP,reviewed_by=?
           WHERE id=?""",(admin_note,str(user.get("name") or user.get("email") or "Admin"),rid))

    audit(user,"Approved and assigned substitute request","Substitutes",aid,{
        "request_id":rid,"substitute_staff_id":sub,"teacher_staff_id":teacher,"date":day,
        "coverage_mode":coverage_mode,"selected_class_ids":selected_ids
    })
    return self.send_json({"ok":1,"status":"Assigned","assignment_id":aid})

Handler.do_POST = _do_POST_build260
# --- End Build 260 ---


# --- Build 265: Summer School Academic-Term Integration ---
_SS265_PRE_INIT_DB = init_db
def init_db():
    _SS265_PRE_INIT_DB()
    ensure_column("summer_classes","linked_class_id INTEGER")
    ensure_column("summer_classes","status TEXT DEFAULT 'Open'")
    ensure_column("summer_classes","notes TEXT DEFAULT ''")
    ensure_column("summer_enrollments","created_at TEXT")
    ensure_column("summer_enrollments","updated_at TEXT")
    # Link existing summer classes into the normal academic class infrastructure.
    for _sc in rows("SELECT * FROM summer_classes"):
        try:
            _ss265_sync_linked_class(int(_sc["id"]))
        except Exception as _exc:
            print("summer class sync:",_exc)

def _ss265_meeting_days(value):
    out=set()
    for x in str(value or "").split(","):
        try: out.add(int(x.strip()))
        except Exception: pass
    return out or {1,2,3,4,5}

def _ss265_ranges_overlap(a_start,a_end,b_start,b_end):
    return str(a_start)<=str(b_end) and str(b_start)<=str(a_end)

def _ss265_times_overlap(a_start,a_end,b_start,b_end):
    return bool(a_start and a_end and b_start and b_end and str(a_start)<str(b_end) and str(b_start)<str(a_end))

def _ss265_classes_conflict(a,b):
    if not _ss265_ranges_overlap(a.get("start_date"),a.get("end_date"),b.get("start_date"),b.get("end_date")):
        return False
    if not (_ss265_meeting_days(a.get("meeting_days")) & _ss265_meeting_days(b.get("meeting_days"))):
        return False
    return _ss265_times_overlap(a.get("start_time"),a.get("end_time"),b.get("start_time"),b.get("end_time"))

def _ss265_status(sc,today=None):
    if not sc: return "Unknown"
    if not int(sc.get("active") if sc.get("active") is not None else 1) or str(sc.get("status") or "").lower()=="cancelled":
        return "Cancelled"
    today=today or school_now(((one("SELECT setting_value FROM district_settings WHERE setting_key='school_timezone'") or {}).get("setting_value") or "America/Chicago"))[0].strftime("%Y-%m-%d")
    if today < str(sc.get("start_date") or ""): return "Upcoming"
    if today > str(sc.get("end_date") or ""): return "Completed"
    enrolled=int((one("SELECT COUNT(*) n FROM summer_enrollments WHERE class_id=? AND status='Active'",(sc["id"],)) or {}).get("n") or 0)
    if enrolled>=int(sc.get("capacity") or 30): return "Full"
    return "Active"

def _ss265_sync_linked_class(summer_id):
    sc=one("SELECT * FROM summer_classes WHERE id=?",(summer_id,))
    if not sc:return None
    linked=int(sc.get("linked_class_id") or 0)
    term=f"Summer {str(sc.get('start_date') or '')[:4]}"
    if linked and one("SELECT id FROM classes WHERE id=?",(linked,)):
        run("""UPDATE classes SET course_id=?,name=?,section=?,period='Summer',room=?,teacher_id=?,term=?,capacity=?,generated=0,published=1,cycle_day=99 WHERE id=?""",
            (sc.get("course_id"),sc.get("name"),sc.get("section") or "",sc.get("room") or "",sc.get("teacher_id"),term,int(sc.get("capacity") or 30),linked))
    else:
        linked=run("""INSERT INTO classes(course_id,name,section,period,room,teacher_id,term,capacity,school,generated,published,cycle_day)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                   (sc.get("course_id"),sc.get("name"),sc.get("section") or "Summer","Summer",sc.get("room") or "",sc.get("teacher_id"),term,int(sc.get("capacity") or 30),"",0,1,99))
        run("UPDATE summer_classes SET linked_class_id=? WHERE id=?",(linked,summer_id))
    # Keep linked academic enrollments synchronized with active summer enrollments.
    active=rows("SELECT student_id FROM summer_enrollments WHERE class_id=? AND status='Active'",(summer_id,))
    active_ids={int(x["student_id"]) for x in active}
    for sid in active_ids:
        run("""INSERT INTO enrollments(class_id,student_id,status,start_date,end_date) VALUES(?,?,'Active',?,?)
               ON CONFLICT(class_id,student_id) DO UPDATE SET status='Active',start_date=excluded.start_date,end_date=excluded.end_date""",
            (linked,sid,sc.get("start_date"),sc.get("end_date")))
    for rec in rows("SELECT student_id FROM enrollments WHERE class_id=? AND status='Active'",(linked,)):
        if int(rec["student_id"]) not in active_ids:
            run("UPDATE enrollments SET status='Dropped',end_date=? WHERE class_id=? AND student_id=?",(sc.get("end_date"),linked,rec["student_id"]))
    return linked

def _ss265_student_conflict(student_id,target_class,exclude_class_id=0):
    for other in rows("""SELECT sc.* FROM summer_enrollments se JOIN summer_classes sc ON sc.id=se.class_id
                         WHERE se.student_id=? AND se.status='Active' AND sc.active=1 AND sc.id<>?""",(student_id,exclude_class_id or target_class.get("id") or 0)):
        if _ss265_classes_conflict(target_class,other):
            return other
    return None

def _ss265_teacher_conflict(teacher_id,target_class,exclude_class_id=0):
    if not teacher_id:return None
    for other in rows("SELECT * FROM summer_classes WHERE teacher_id=? AND active=1 AND id<>?",(teacher_id,exclude_class_id or target_class.get("id") or 0)):
        if _ss265_classes_conflict(target_class,other):
            return other
    return None

def _ss265_promote_waitlist(class_id):
    sc=one("SELECT * FROM summer_classes WHERE id=?",(class_id,))
    if not sc:return
    active=int((one("SELECT COUNT(*) n FROM summer_enrollments WHERE class_id=? AND status='Active'",(class_id,)) or {}).get("n") or 0)
    while active<int(sc.get("capacity") or 30):
        nxt=one("SELECT student_id FROM summer_enrollments WHERE class_id=? AND status='Waitlisted' ORDER BY COALESCE(created_at,''),student_id LIMIT 1",(class_id,))
        if not nxt:break
        sid=int(nxt["student_id"])
        conflict=_ss265_student_conflict(sid,sc,class_id)
        if conflict:
            # Leave them waitlisted; try the next person only if ordering can advance.
            break
        run("UPDATE summer_enrollments SET status='Active',updated_at=CURRENT_TIMESTAMP WHERE class_id=? AND student_id=?",(class_id,sid))
        active+=1
    _ss265_sync_linked_class(class_id)

_SS265_PRE_GET=Handler.do_GET
def _ss265_get(self):
    parsed=urlparse(self.path);path=parsed.path;q=parse_qs(parsed.query)
    if path not in {"/api/summer-school","/api/summer-school/detail","/api/summer-school/students"}:
        return _SS265_PRE_GET(self)
    user=self.require_user()
    if not user:return
    role=user.get("role")
    try:
        if path=="/api/summer-school":
            if role=="admin":
                classes=rows("""SELECT sc.*,COALESCE(co.code,'') course_code,COALESCE(co.name,sc.name) course_name,COALESCE(st.name,'') teacher_name,
                  (SELECT COUNT(*) FROM summer_enrollments se WHERE se.class_id=sc.id AND se.status='Active') enrolled,
                  (SELECT COUNT(*) FROM summer_enrollments se WHERE se.class_id=sc.id AND se.status='Waitlisted') waitlisted
                  FROM summer_classes sc LEFT JOIN courses co ON co.id=sc.course_id LEFT JOIN staff st ON st.id=sc.teacher_id
                  ORDER BY sc.start_date,sc.start_time,sc.name""")
                for c in classes:
                    c["effective_status"]=_ss265_status(c)
                    c["seats_remaining"]=max(0,int(c.get("capacity") or 30)-int(c.get("enrolled") or 0))
                return self.send_json({"classes":classes})
            if role=="teacher":
                sid=int(user.get("staff_id") or 0)
                data=rows("""SELECT sc.*,COALESCE(co.code,'') course_code,(SELECT COUNT(*) FROM summer_enrollments se WHERE se.class_id=sc.id AND se.status='Active') enrolled
                             FROM summer_classes sc LEFT JOIN courses co ON co.id=sc.course_id WHERE sc.teacher_id=? ORDER BY sc.start_date,sc.start_time""",(sid,))
                return self.send_json({"classes":data})
            student_ids=list(student_scope(user) or [])
            if not student_ids:return self.send_json({"classes":[]})
            marks=",".join("?"*len(student_ids))
            data=rows(f"""SELECT DISTINCT sc.*,COALESCE(co.code,'') course_code,COALESCE(st.name,'') teacher
                          FROM summer_enrollments se JOIN summer_classes sc ON sc.id=se.class_id
                          LEFT JOIN courses co ON co.id=sc.course_id LEFT JOIN staff st ON st.id=sc.teacher_id
                          WHERE se.student_id IN ({marks}) AND se.status='Active' ORDER BY sc.start_date,sc.start_time""",tuple(student_ids))
            return self.send_json({"classes":data})

        if path=="/api/summer-school/detail":
            cid=int(q.get("id",["0"])[0] or 0)
            sc=one("""SELECT sc.*,COALESCE(co.code,'') course_code,COALESCE(co.name,sc.name) course_name,COALESCE(st.name,'') teacher_name
                      FROM summer_classes sc LEFT JOIN courses co ON co.id=sc.course_id LEFT JOIN staff st ON st.id=sc.teacher_id WHERE sc.id=?""",(cid,))
            if not sc:return self.send_json({"error":"Summer class not found"},404)
            if role=="teacher" and int(sc.get("teacher_id") or 0)!=int(user.get("staff_id") or 0):return self.send_json({"error":"Permission denied"},403)
            if role not in {"admin","teacher"}:return self.send_json({"error":"Permission denied"},403)
            roster=rows("""SELECT se.*,s.first_name||' '||s.last_name student_name,s.student_number,s.grade AS grade_level
                           FROM summer_enrollments se JOIN students s ON s.id=se.student_id WHERE se.class_id=?
                           ORDER BY CASE se.status WHEN 'Active' THEN 0 WHEN 'Waitlisted' THEN 1 ELSE 2 END,s.last_name,s.first_name""",(cid,))
            sc["effective_status"]=_ss265_status(sc)
            sc["enrolled"]=sum(1 for x in roster if x.get("status")=="Active")
            sc["waitlisted"]=sum(1 for x in roster if x.get("status")=="Waitlisted")
            sc["seats_remaining"]=max(0,int(sc.get("capacity") or 30)-sc["enrolled"])
            return self.send_json({"class":sc,"roster":roster})

        # Admin searchable enrollment candidates.
        if role!="admin":return self.send_json({"error":"Permission denied"},403)
        cid=int(q.get("class_id",["0"])[0] or 0);term=str(q.get("q",[""])[0] or "").strip().lower()
        sc=one("SELECT * FROM summer_classes WHERE id=?",(cid,))
        if not sc:return self.send_json({"error":"Summer class not found"},404)
        data=rows("""SELECT s.id,s.student_number,s.first_name,s.last_name,s.grade AS grade_level,
                     COALESCE((SELECT status FROM summer_enrollments se WHERE se.class_id=? AND se.student_id=s.id),'') summer_status
                     FROM students s WHERE COALESCE(s.status,'Active')='Active' ORDER BY s.last_name,s.first_name""",(cid,))
        out=[]
        for st in data:
            label=f"{st.get('first_name','')} {st.get('last_name','')} {st.get('student_number','')} {st.get('grade_level','')}".lower()
            if term and term not in label:continue
            conflict=_ss265_student_conflict(int(st["id"]),sc,cid)
            st["conflict"]=bool(conflict)
            st["conflict_name"]=conflict.get("name") if conflict else ""
            out.append(st)
        return self.send_json(out[:200])
    except Exception as exc:
        return self.send_json({"error":str(exc)},500)
Handler.do_GET=_ss265_get

_SS265_PRE_POST=Handler.do_POST
def _ss265_post(self):
    path=urlparse(self.path).path
    if path not in {"/api/summer-school/class","/api/summer-school/enroll","/api/summer-school/unenroll","/api/summer-school/cancel"}:
        return _SS265_PRE_POST(self)
    user=self.require_user()
    if not user:return
    if user.get("role")!="admin":return self.send_json({"error":"Permission denied"},403)
    data=self.read_body() or {}
    try:
        if path=="/api/summer-school/class":
            iid=int(data.get("id") or 0)
            course_id=int(data.get("course_id") or 0) or None
            teacher_id=int(data.get("teacher_id") or 0) or None
            start_date=str(data.get("start_date") or "")
            end_date=str(data.get("end_date") or "")
            start_time=str(data.get("start_time") or "08:00")
            end_time=str(data.get("end_time") or "09:00")
            if not start_date or not end_date or end_date<start_date:return self.send_json({"error":"Enter a valid summer-school date range"},400)
            if end_time<=start_time:return self.send_json({"error":"End time must be after start time"},400)
            if teacher_id and course_id and "teacher_eligible_for_course" in globals() and not teacher_eligible_for_course(teacher_id,course_id):
                return self.send_json({"error":"That teacher is not marked eligible to teach this course."},409)
            target={"id":iid,"start_date":start_date,"end_date":end_date,"meeting_days":data.get("meeting_days") or "1,2,3,4,5","start_time":start_time,"end_time":end_time}
            conflict=_ss265_teacher_conflict(teacher_id,target,iid)
            if conflict:return self.send_json({"error":f"Teacher conflict with {conflict.get('name')} ({conflict.get('start_time')}–{conflict.get('end_time')})."},409)
            vals=(course_id,data.get("name") or "Summer Course",data.get("section") or "",teacher_id,data.get("room") or "",start_date,end_date,data.get("meeting_days") or "1,2,3,4,5",start_time,end_time,int(data.get("capacity") or 30),data.get("notes") or "")
            if iid:
                run("""UPDATE summer_classes SET course_id=?,name=?,section=?,teacher_id=?,room=?,start_date=?,end_date=?,meeting_days=?,start_time=?,end_time=?,capacity=?,notes=?,active=1 WHERE id=?""",vals+(iid,))
            else:
                iid=run("""INSERT INTO summer_classes(course_id,name,section,teacher_id,room,start_date,end_date,meeting_days,start_time,end_time,capacity,notes,active,status)
                           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1,'Open')""",vals)
            linked=_ss265_sync_linked_class(iid)
            return self.send_json({"id":iid,"linked_class_id":linked})

        cid=int(data.get("class_id") or 0)
        sc=one("SELECT * FROM summer_classes WHERE id=?",(cid,))
        if not sc:return self.send_json({"error":"Summer class not found"},404)
        if path=="/api/summer-school/cancel":
            run("UPDATE summer_classes SET active=0,status='Cancelled' WHERE id=?",(cid,))
            if sc.get("linked_class_id"):run("UPDATE classes SET published=0 WHERE id=?",(sc["linked_class_id"],))
            return self.send_json({"ok":1})

        sid=int(data.get("student_id") or 0)
        if not sid:return self.send_json({"error":"Choose a student"},400)
        if path=="/api/summer-school/unenroll":
            run("UPDATE summer_enrollments SET status='Dropped',updated_at=CURRENT_TIMESTAMP WHERE class_id=? AND student_id=?",(cid,sid))
            _ss265_sync_linked_class(cid);_ss265_promote_waitlist(cid)
            return self.send_json({"ok":1})

        conflict=_ss265_student_conflict(sid,sc,cid)
        if conflict:return self.send_json({"error":f"Student schedule conflict with {conflict.get('name')} ({conflict.get('start_time')}–{conflict.get('end_time')})."},409)
        active=int((one("SELECT COUNT(*) n FROM summer_enrollments WHERE class_id=? AND status='Active'",(cid,)) or {}).get("n") or 0)
        status="Active" if active<int(sc.get("capacity") or 30) else "Waitlisted"
        run("""INSERT INTO summer_enrollments(class_id,student_id,status,created_at,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)
               ON CONFLICT(class_id,student_id) DO UPDATE SET status=excluded.status,updated_at=CURRENT_TIMESTAMP""",(cid,sid,status))
        _ss265_sync_linked_class(cid)
        return self.send_json({"ok":1,"status":status})
    except Exception as exc:
        return self.send_json({"error":str(exc)},500)
Handler.do_POST=_ss265_post
# --- End Build 265 ---


# --- Build 266: Unified Term Compatibility + Course Transfer + Summer Command Center ---
_SS266_PRE_INIT_DB=init_db
def init_db():
    _SS266_PRE_INIT_DB()
    run("""CREATE TABLE IF NOT EXISTS course_transfers(
      id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER NOT NULL,from_class_id INTEGER NOT NULL,to_class_id INTEGER NOT NULL,
      effective_date TEXT NOT NULL,grade_policy TEXT DEFAULT 'historical',reason TEXT DEFAULT '',notes TEXT DEFAULT '',
      requested_by INTEGER,status TEXT DEFAULT 'Completed',created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    run("""CREATE TABLE IF NOT EXISTS term_service_options(
      id INTEGER PRIMARY KEY AUTOINCREMENT,service TEXT NOT NULL,term_scope TEXT DEFAULT 'Regular',summer_class_id INTEGER,
      enabled INTEGER DEFAULT 1,config_json TEXT DEFAULT '{}',updated_by INTEGER,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(service,term_scope,summer_class_id))""")
    run("""CREATE TABLE IF NOT EXISTS summer_closeouts(
      class_id INTEGER PRIMARY KEY,status TEXT DEFAULT 'Open',closed_by INTEGER,closed_at TEXT,notes TEXT DEFAULT '')""")
    run("""CREATE TABLE IF NOT EXISTS summer_intervention_rules(
      id INTEGER PRIMARY KEY CHECK(id=1),absence_warning INTEGER DEFAULT 2,absence_critical INTEGER DEFAULT 3,
      grade_warning REAL DEFAULT 75,grade_critical REAL DEFAULT 65,missing_warning INTEGER DEFAULT 2,updated_by INTEGER,updated_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    run("INSERT OR IGNORE INTO summer_intervention_rules(id) VALUES(1)")
    # Existing systems become term-aware instead of getting duplicate summer pages.
    for table,col,ddl in [
      ('announcements','term_scope',"TEXT DEFAULT 'All'"),('announcements','summer_class_id','INTEGER'),
      ('bus_assignments','term_scope',"TEXT DEFAULT 'Regular'"),('bus_assignments','start_date','TEXT'),('bus_assignments','end_date','TEXT'),
      ('meal_transactions','term_scope',"TEXT DEFAULT 'Regular'"),('school_calendar_days','term_scope',"TEXT DEFAULT 'Regular'")]:
        try:
            cols={r.get('name') for r in rows(f'PRAGMA table_info({table})')}
            if col not in cols: run(f'ALTER TABLE {table} ADD COLUMN {col} {ddl}')
        except Exception: pass

def _ss266_class_time(c):
    p=one("SELECT start_time,end_time FROM schedule_periods WHERE cycle_day=? AND name=?",(int(c.get('cycle_day') or 1),c.get('period') or '')) or {}
    return str(p.get('start_time') or ''),str(p.get('end_time') or '')

def _ss266_regular_conflict(student_id,to_class_id,effective_date):
    target=one("SELECT * FROM classes WHERE id=?",(to_class_id,))
    if not target:return None
    ts,te=_ss266_class_time(target)
    for c in rows("""SELECT c.* FROM enrollments e JOIN classes c ON c.id=e.class_id WHERE e.student_id=? AND e.class_id<>?
                      AND COALESCE(e.status,'Active')='Active' AND (COALESCE(e.end_date,'')='' OR e.end_date>=?)""",(student_id,to_class_id,effective_date)):
        if str(c.get('term') or '')!=str(target.get('term') or ''):continue
        if int(c.get('cycle_day') or 1)!=int(target.get('cycle_day') or 1):continue
        cs,ce=_ss266_class_time(c)
        if (target.get('period') and c.get('period')==target.get('period')) or (ts and te and cs and ce and ts<ce and cs<te): return c
    return None

def _ss266_transfer_preview(student_id,from_id,to_id,effective_date):
    st=one("SELECT id,student_number,first_name,last_name,grade FROM students WHERE id=?",(student_id,))
    old=one("SELECT c.*,COALESCE(co.code,'') course_code,COALESCE(t.name,'') teacher FROM classes c LEFT JOIN courses co ON co.id=c.course_id LEFT JOIN staff t ON t.id=c.teacher_id WHERE c.id=?",(from_id,))
    new=one("SELECT c.*,COALESCE(co.code,'') course_code,COALESCE(t.name,'') teacher,(SELECT COUNT(*) FROM enrollments e WHERE e.class_id=c.id AND COALESCE(e.status,'Active')='Active') enrolled FROM classes c LEFT JOIN courses co ON co.id=c.course_id LEFT JOIN staff t ON t.id=c.teacher_id WHERE c.id=?",(to_id,))
    if not st or not old or not new:return {'error':'Student or class not found'}
    enrolled=one("SELECT * FROM enrollments WHERE student_id=? AND class_id=? AND COALESCE(status,'Active')='Active'",(student_id,from_id))
    if not enrolled:return {'error':'Student is not actively enrolled in the current class'}
    if int(new.get('enrolled') or 0)>=int(new.get('capacity') or 30):return {'error':'The destination class is full','student':st,'from_class':old,'to_class':new}
    conflict=_ss266_regular_conflict(student_id,to_id,effective_date)
    return {'student':st,'from_class':old,'to_class':new,'conflict':conflict,'ok':not conflict}

def _ss266_do_transfer(user,data):
    sid=int(data.get('student_id') or 0);old_id=int(data.get('from_class_id') or 0);new_id=int(data.get('to_class_id') or 0)
    eff=str(data.get('effective_date') or school_now()[0].strftime('%Y-%m-%d'));policy=str(data.get('grade_policy') or 'historical')
    preview=_ss266_transfer_preview(sid,old_id,new_id,eff)
    if preview.get('error'):return preview,409
    if preview.get('conflict'):return {'error':f"Schedule conflict with {preview['conflict'].get('name')}",'preview':preview},409
    if old_id==new_id:return {'error':'Choose a different destination class'},400
    # End old enrollment the day before the effective transfer; preserve all old grades/attendance/submissions.
    try: end=(datetime.strptime(eff,'%Y-%m-%d').date()-timedelta(days=1)).isoformat()
    except Exception:end=eff
    run("UPDATE enrollments SET status='Transferred',end_date=? WHERE class_id=? AND student_id=?",(end,old_id,sid))
    run("""INSERT INTO enrollments(class_id,student_id,status,start_date,end_date) VALUES(?,?,'Active',?,'')
           ON CONFLICT(class_id,student_id) DO UPDATE SET status='Active',start_date=excluded.start_date,end_date=''""",(new_id,sid,eff))
    # If either class is a linked Summer School class, keep the Summer School roster in sync too.
    old_summer=one("SELECT id FROM summer_classes WHERE linked_class_id=?",(old_id,));new_summer=one("SELECT id FROM summer_classes WHERE linked_class_id=?",(new_id,))
    if old_summer: run("UPDATE summer_enrollments SET status='Dropped',updated_at=CURRENT_TIMESTAMP WHERE class_id=? AND student_id=?",(old_summer['id'],sid))
    if new_summer: run("INSERT INTO summer_enrollments(class_id,student_id,status,created_at,updated_at) VALUES(?,?,'Active',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT(class_id,student_id) DO UPDATE SET status='Active',updated_at=CURRENT_TIMESTAMP",(new_summer['id'],sid))
    if old_summer: _ss265_promote_waitlist(int(old_summer['id']))
    if new_summer: _ss265_sync_linked_class(int(new_summer['id']))
    # Optional grade migration is explicit. Historical is safest and default.
    if policy in {'carry_current','copy_matching'}:
        old_assign=rows("SELECT a.*,g.score,g.status grade_status,g.comment FROM assignments a LEFT JOIN grades g ON g.assignment_id=a.id AND g.student_id=? WHERE a.class_id=?",(sid,old_id))
        if policy=='carry_current':
            possible=sum(float(a.get('points') or 0) for a in old_assign if a.get('score') is not None and str(a.get('grade_status') or '').upper()!='EXCUSED')
            earned=sum(float(a.get('score') or 0) for a in old_assign if a.get('score') is not None and str(a.get('grade_status') or '').upper()!='EXCUSED')
            if possible>0:
                pct=round(earned/possible*100,2)
                aid=run("INSERT INTO assignments(class_id,title,category,points,weight,due_date,visible,description) VALUES(?,?,'Transfer Grade',100,1,?,0,?)",(new_id,'Transfer-in Grade',eff,f'Carried from class #{old_id} on {eff}'))
                run("INSERT OR REPLACE INTO grades(assignment_id,student_id,score,status,comment) VALUES(?,?,?,'Graded',?)",(aid,sid,pct,'Transferred cumulative grade'))
        else:
            dest=rows("SELECT id,title,category,points FROM assignments WHERE class_id=?",(new_id,));by={(str(a.get('title') or '').strip().lower(),str(a.get('category') or '').strip().lower()):a for a in dest}
            for a in old_assign:
                if a.get('score') is None:continue
                d=by.get((str(a.get('title') or '').strip().lower(),str(a.get('category') or '').strip().lower()))
                if d: run("INSERT OR REPLACE INTO grades(assignment_id,student_id,score,status,comment) VALUES(?,?,?,?,?)",(d['id'],sid,a.get('score'),a.get('grade_status') or 'Graded',f"Transferred from {preview['from_class'].get('name')}: {a.get('comment') or ''}"))
    tid=run("INSERT INTO course_transfers(student_id,from_class_id,to_class_id,effective_date,grade_policy,reason,notes,requested_by,status) VALUES(?,?,?,?,?,?,?,?, 'Completed')",(sid,old_id,new_id,eff,policy,data.get('reason') or '',data.get('notes') or '',user.get('id')))
    audit(user,'Course transfer','Student',sid,f"Class {old_id} -> {new_id}, effective {eff}, grade policy {policy}")
    return {'ok':1,'transfer_id':tid,'preview':preview},200

def _ss266_summer_command():
    today=school_now()[0].strftime('%Y-%m-%d'); rules=one("SELECT * FROM summer_intervention_rules WHERE id=1") or {}
    courses=rows("""SELECT sc.*,COALESCE(co.code,'') course_code,COALESCE(st.name,'Unassigned') teacher_name,
      (SELECT COUNT(*) FROM summer_enrollments se WHERE se.class_id=sc.id AND se.status='Active') enrolled,
      (SELECT COUNT(*) FROM summer_enrollments se WHERE se.class_id=sc.id AND se.status='Waitlisted') waitlisted
      FROM summer_classes sc LEFT JOIN courses co ON co.id=sc.course_id LEFT JOIN staff st ON st.id=sc.teacher_id WHERE sc.active=1 ORDER BY sc.start_date,sc.start_time""")
    active_students=rows("""SELECT se.student_id,sc.id summer_class_id,sc.linked_class_id,sc.name class_name,s.first_name||' '||s.last_name student_name,s.student_number
      FROM summer_enrollments se JOIN summer_classes sc ON sc.id=se.class_id JOIN students s ON s.id=se.student_id WHERE se.status='Active' AND sc.active=1""")
    risks=[]
    for x in active_students:
        lid=int(x.get('linked_class_id') or 0);sid=int(x['student_id'])
        if not lid:continue
        grades=rows("SELECT g.score,a.points,g.status FROM assignments a LEFT JOIN grades g ON g.assignment_id=a.id AND g.student_id=? WHERE a.class_id=? AND COALESCE(a.include_in_gradebook,1)=1",(sid,lid))
        poss=sum(float(g.get('points') or 0) for g in grades if g.get('score') is not None and str(g.get('status') or '').upper()!='EXCUSED');earned=sum(float(g.get('score') or 0) for g in grades if g.get('score') is not None and str(g.get('status') or '').upper()!='EXCUSED');pct=round(earned/poss*100,1) if poss else None
        missing=sum(1 for g in grades if g.get('score') is None and str(g.get('status') or '').upper() not in {'EXCUSED','DROPPED'})
        absn=int((one("SELECT COUNT(*) n FROM attendance WHERE class_id=? AND student_id=? AND status IN ('AE','AU')",(lid,sid)) or {}).get('n') or 0)
        level='On Track';reasons=[]
        if (pct is not None and pct<float(rules.get('grade_critical') or 65)) or absn>=int(rules.get('absence_critical') or 3):level='Critical'
        elif (pct is not None and pct<float(rules.get('grade_warning') or 75)) or absn>=int(rules.get('absence_warning') or 2) or missing>=int(rules.get('missing_warning') or 2):level='At Risk'
        if pct is not None and pct<float(rules.get('grade_warning') or 75):reasons.append(f'Grade {pct}%')
        if absn>=int(rules.get('absence_warning') or 2):reasons.append(f'{absn} absences')
        if missing>=int(rules.get('missing_warning') or 2):reasons.append(f'{missing} missing')
        if level!='On Track':risks.append({**x,'level':level,'grade':pct,'absences':absn,'missing':missing,'reasons':reasons})
    today_courses=[c for c in courses if str(c.get('start_date'))<=today<=str(c.get('end_date')) and str(datetime.strptime(today,'%Y-%m-%d').date().isoweekday()) in str(c.get('meeting_days') or '').split(',')]
    return {'today':today,'courses':courses,'today_courses':today_courses,'risks':risks,'rules':rules,
      'metrics':{'active_courses':len([c for c in courses if str(c.get('start_date'))<=today<=str(c.get('end_date'))]),'students':len({x['student_id'] for x in active_students}),'at_risk':len(risks),'waitlisted':sum(int(c.get('waitlisted') or 0) for c in courses)}}

_SS266_PRE_GET=Handler.do_GET
def _ss266_get(self):
    parsed=urlparse(self.path);path=parsed.path;q=parse_qs(parsed.query)
    if path not in {'/api/course-transfer/preview','/api/course-transfer/history','/api/summer-school/command','/api/term-services'}:return _SS266_PRE_GET(self)
    user=self.require_user()
    if not user:return
    if path.startswith('/api/course-transfer') and user.get('role') not in {'admin','counselor'}:return self.send_json({'error':'Permission denied'},403)
    if path=='/api/course-transfer/preview':return self.send_json(_ss266_transfer_preview(int(q.get('student_id',['0'])[0]),int(q.get('from_class_id',['0'])[0]),int(q.get('to_class_id',['0'])[0]),q.get('effective_date',[school_now()[0].strftime('%Y-%m-%d')])[0]))
    if path=='/api/course-transfer/history':
        sid=int(q.get('student_id',['0'])[0]);return self.send_json(rows("""SELECT ct.*,a.name from_name,b.name to_name,u.display_name changed_by FROM course_transfers ct JOIN classes a ON a.id=ct.from_class_id JOIN classes b ON b.id=ct.to_class_id LEFT JOIN users u ON u.id=ct.requested_by WHERE ct.student_id=? ORDER BY ct.id DESC""",(sid,)))
    if path=='/api/summer-school/command':
        if user.get('role') not in {'admin','counselor'}:return self.send_json({'error':'Permission denied'},403)
        return self.send_json(_ss266_summer_command())
    if path=='/api/term-services':
        if user.get('role') not in {'admin','transportation','food','counselor'}:return self.send_json({'error':'Permission denied'},403)
        return self.send_json({'options':rows("SELECT * FROM term_service_options ORDER BY service,term_scope"),'summer_classes':rows("SELECT id,name,start_date,end_date FROM summer_classes WHERE active=1 ORDER BY start_date,name")})
Handler.do_GET=_ss266_get

_SS266_PRE_POST=Handler.do_POST
def _ss266_post(self):
    path=urlparse(self.path).path
    if path not in {'/api/course-transfer','/api/summer-school/closeout','/api/summer-school/rules','/api/term-services'}:return _SS266_PRE_POST(self)
    user=self.require_user()
    if not user:return
    data=self.read_body() or {}
    if path=='/api/course-transfer':
        if user.get('role') not in {'admin','counselor'}:return self.send_json({'error':'Permission denied'},403)
        out,code=_ss266_do_transfer(user,data);return self.send_json(out,code)
    if path=='/api/summer-school/closeout':
        if user.get('role')!='admin':return self.send_json({'error':'Permission denied'},403)
        cid=int(data.get('class_id') or 0);sc=one("SELECT * FROM summer_classes WHERE id=?",(cid,))
        if not sc:return self.send_json({'error':'Summer class not found'},404)
        action=str(data.get('status') or 'Closed');run("INSERT INTO summer_closeouts(class_id,status,closed_by,closed_at,notes) VALUES(?,?,?,CURRENT_TIMESTAMP,?) ON CONFLICT(class_id) DO UPDATE SET status=excluded.status,closed_by=excluded.closed_by,closed_at=CURRENT_TIMESTAMP,notes=excluded.notes",(cid,action,user.get('id'),data.get('notes') or ''))
        if action=='Closed':run("UPDATE summer_classes SET status='Completed' WHERE id=?",(cid,))
        return self.send_json({'ok':1})
    if path=='/api/summer-school/rules':
        if user.get('role')!='admin':return self.send_json({'error':'Permission denied'},403)
        run("UPDATE summer_intervention_rules SET absence_warning=?,absence_critical=?,grade_warning=?,grade_critical=?,missing_warning=?,updated_by=?,updated_at=CURRENT_TIMESTAMP WHERE id=1",(int(data.get('absence_warning') or 2),int(data.get('absence_critical') or 3),float(data.get('grade_warning') or 75),float(data.get('grade_critical') or 65),int(data.get('missing_warning') or 2),user.get('id')));return self.send_json({'ok':1})
    if user.get('role') not in {'admin','transportation','food'}:return self.send_json({'error':'Permission denied'},403)
    service=str(data.get('service') or '');scope=str(data.get('term_scope') or 'Regular');cid=int(data.get('summer_class_id') or 0) or None
    run("INSERT INTO term_service_options(service,term_scope,summer_class_id,enabled,config_json,updated_by) VALUES(?,?,?,?,?,?) ON CONFLICT(service,term_scope,summer_class_id) DO UPDATE SET enabled=excluded.enabled,config_json=excluded.config_json,updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP",(service,scope,cid,1 if data.get('enabled',True) else 0,json.dumps(data.get('config') or {}),user.get('id')));return self.send_json({'ok':1})
Handler.do_POST=_ss266_post
# --- End Build 266 ---


# --- Build 269: Integrated Student Success + Scheduling Intelligence ---
_SS269_PRE_INIT_DB=init_db
def init_db():
    _SS269_PRE_INIT_DB()
    run("""CREATE TABLE IF NOT EXISTS course_prerequisite_rules(
      id INTEGER PRIMARY KEY AUTOINCREMENT,course_id INTEGER NOT NULL,prerequisite_course_id INTEGER NOT NULL,
      min_grade_pct REAL DEFAULT 60,allow_concurrent INTEGER DEFAULT 0,active INTEGER DEFAULT 1,
      created_by INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(course_id,prerequisite_course_id))""")
    # Build 274: rules sharing a requirement_group are alternatives (OR). Different groups are cumulative (AND).
    try: ensure_column("course_prerequisite_rules","requirement_group INTEGER")
    except Exception: pass
    run("""CREATE TABLE IF NOT EXISTS schedule_change_requests(
      id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER NOT NULL,request_type TEXT DEFAULT 'Transfer',
      from_class_id INTEGER,to_class_id INTEGER,reason TEXT DEFAULT '',status TEXT DEFAULT 'Pending',
      requested_by INTEGER,reviewed_by INTEGER,review_note TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      reviewed_at TEXT,completed_at TEXT)""")
    run("""CREATE TABLE IF NOT EXISTS course_recommendations(
      id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER NOT NULL,course_id INTEGER NOT NULL,staff_id INTEGER,
      recommendation TEXT DEFAULT 'Recommended',note TEXT DEFAULT '',school_year TEXT DEFAULT '',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(student_id,course_id,staff_id,school_year))""")
    run("""CREATE TABLE IF NOT EXISTS student_interventions(
      id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER NOT NULL,category TEXT DEFAULT 'Academic',
      status TEXT DEFAULT 'Open',summary TEXT NOT NULL,details TEXT DEFAULT '',assigned_to INTEGER,
      created_by INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP,resolved_at TEXT)""")
    run("""CREATE TABLE IF NOT EXISTS academic_eligibility_settings(
      id INTEGER PRIMARY KEY CHECK(id=1),min_average REAL DEFAULT 70,max_failing_classes INTEGER DEFAULT 1,
      max_absences INTEGER DEFAULT 5,updated_by INTEGER,updated_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    run("INSERT OR IGNORE INTO academic_eligibility_settings(id) VALUES(1)")
    run("""CREATE TABLE IF NOT EXISTS class_handoffs(
      id INTEGER PRIMARY KEY AUTOINCREMENT,class_id INTEGER NOT NULL,old_teacher_id INTEGER,new_teacher_id INTEGER NOT NULL,
      effective_date TEXT NOT NULL,note TEXT DEFAULT '',changed_by INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    run("""CREATE TABLE IF NOT EXISTS student_status_history(
      id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER NOT NULL,old_status TEXT,new_status TEXT NOT NULL,
      effective_date TEXT NOT NULL,reason TEXT DEFAULT '',changed_by INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    run("""CREATE TABLE IF NOT EXISTS term_closeout_status(
      term TEXT PRIMARY KEY,status TEXT DEFAULT 'Open',notes TEXT DEFAULT '',closed_by INTEGER,closed_at TEXT,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    # Room metadata extends the existing Scheduling room records.
    try: ensure_column("schedule_rooms","room_type TEXT DEFAULT 'Standard Classroom'")
    except Exception: pass

def _ss269_class_percent(student_id,class_id):
    gs=rows("""SELECT g.score,g.status,a.points,COALESCE(a.extra_credit,0) extra_credit,COALESCE(a.include_in_gradebook,1) include_in_gradebook
               FROM assignments a LEFT JOIN grades g ON g.assignment_id=a.id AND g.student_id=?
               WHERE a.class_id=? AND COALESCE(a.visible,1)=1""",(student_id,class_id))
    earned=possible=0.0
    for g in gs:
        if not int(g.get('include_in_gradebook') if g.get('include_in_gradebook') is not None else 1): continue
        st=str(g.get('status') or '').upper()
        if st in {'EXCUSED','DROPPED'}: continue
        if g.get('score') is not None: earned+=float(g.get('score') or 0)
        if not int(g.get('extra_credit') or 0): possible+=float(g.get('points') or 0)
    return round(earned/possible*100,2) if possible>0 else None

def _ss269_prereq_check(student_id,course_id):
    rules=rows("""SELECT r.*,c.code prereq_code,c.name prereq_name FROM course_prerequisite_rules r
                  JOIN courses c ON c.id=r.prerequisite_course_id
                  WHERE r.course_id=? AND COALESCE(r.active,1)=1
                  ORDER BY COALESCE(r.requirement_group,r.id),c.code,c.name""",(course_id,))
    evaluated=[]
    # Backward compatibility: legacy rows with no group remain separate AND requirements.
    for r in rules:
        group_id=int(r.get('requirement_group') or r.get('id') or 0)
        classes=rows("""SELECT cl.id,e.status,e.start_date,e.end_date FROM enrollments e JOIN classes cl ON cl.id=e.class_id
                        WHERE e.student_id=? AND cl.course_id=? ORDER BY cl.id DESC""",(student_id,r['prerequisite_course_id']))
        best=None;concurrent=False
        for cl in classes:
            if str(cl.get('status') or '').lower()=='active':
                concurrent=True
            pct=_ss269_class_percent(student_id,int(cl['id']))
            if pct is not None and (best is None or pct>best):best=pct
        passed=(best is not None and best>=float(r.get('min_grade_pct') or 60)) or (int(r.get('allow_concurrent') or 0) and concurrent)
        evaluated.append({**r,'requirement_group':group_id,'best_grade':best,'concurrent':concurrent,'met':passed})

    groups={}
    for r in evaluated:
        groups.setdefault(r['requirement_group'],[]).append(r)
    group_results=[]
    for gid,opts in groups.items():
        met=any(bool(x.get('met')) for x in opts)
        labels=[str(x.get('prereq_code') or x.get('prereq_name') or 'Course') for x in opts]
        group_results.append({'group':gid,'met':met,'label':' or '.join(labels),'options':opts})
        for x in opts:x['group_met']=met
    missing=[g['label'] for g in group_results if not g['met']]
    return {'ok':not missing,'requirements':evaluated,'groups':group_results,'missing_labels':missing}

# Enforce prerequisite rules in the existing transfer engine.
_SS269_PRE_TRANSFER_PREVIEW=_ss266_transfer_preview
def _ss266_transfer_preview(student_id,from_id,to_id,effective_date):
    base=_SS269_PRE_TRANSFER_PREVIEW(student_id,from_id,to_id,effective_date)
    if base.get('error') or base.get('conflict'): return base
    course_id=int((base.get('to_class') or {}).get('course_id') or 0)
    if course_id:
        pc=_ss269_prereq_check(student_id,course_id)
        base['prerequisites']=pc
        if not pc['ok']:
            names=', '.join(pc.get('missing_labels') or [])
            base['error']=f"Prerequisite not met: {names}"
            base['ok']=False
    return base

def _ss269_attendance_patterns(student_id):
    recs=rows("""SELECT a.date,a.status,a.class_id,c.name class_name,c.period
                 FROM attendance a LEFT JOIN classes c ON c.id=a.class_id
                 WHERE a.student_id=? AND UPPER(COALESCE(a.status,'')) IN ('AE','AU','TE','TU')
                 ORDER BY a.date DESC""",(student_id,))
    wd={};byclass={}
    for r in recs:
        try: day=datetime.strptime(str(r.get('date')),'%Y-%m-%d').strftime('%A')
        except Exception: day='Unknown'
        wd[day]=wd.get(day,0)+1
        key=r.get('class_name') or f"Class {r.get('class_id')}"
        byclass[key]=byclass.get(key,0)+1
    patterns=[]
    if wd:
        d,n=max(wd.items(),key=lambda x:x[1])
        if n>=2:patterns.append(f"{n} attendance exceptions on {d}s")
    if byclass:
        c,n=max(byclass.items(),key=lambda x:x[1])
        if n>=2:patterns.append(f"{n} attendance exceptions in {c}")
    return {'records':recs[:40],'patterns':patterns,'total':len(recs)}

def _ss269_grade_risk(student_id):
    active=rows("""SELECT cl.id,cl.name,cl.section,co.code course_code
                   FROM enrollments e JOIN classes cl ON cl.id=e.class_id LEFT JOIN courses co ON co.id=cl.course_id
                   WHERE e.student_id=? AND COALESCE(e.status,'Active')='Active'""",(student_id,))
    items=[]
    for c in active:
        pct=_ss269_class_percent(student_id,int(c['id']))
        miss=int((one("""SELECT COUNT(*) n FROM assignments a LEFT JOIN grades g ON g.assignment_id=a.id AND g.student_id=?
                         WHERE a.class_id=? AND COALESCE(a.visible,1)=1 AND COALESCE(a.include_in_gradebook,1)=1
                         AND g.score IS NULL AND UPPER(COALESCE(g.status,'')) NOT IN ('EXCUSED','DROPPED')""",(student_id,c['id'])) or {}).get('n') or 0)
        if (pct is not None and pct<75) or miss>=2:
            items.append({**c,'percent':pct,'missing':miss,'level':'Critical' if (pct is not None and pct<65) or miss>=5 else 'Watch'})
    return items

def _ss269_eligibility(student_id):
    cfg=one("SELECT * FROM academic_eligibility_settings WHERE id=1") or {}
    active=rows("""SELECT cl.id,cl.name,co.code course_code FROM enrollments e JOIN classes cl ON cl.id=e.class_id
                   LEFT JOIN courses co ON co.id=cl.course_id WHERE e.student_id=? AND COALESCE(e.status,'Active')='Active'""",(student_id,))
    grades=[]
    for c in active:
        pct=_ss269_class_percent(student_id,int(c['id']))
        if pct is not None:grades.append({**c,'percent':pct})
    avg=round(sum(x['percent'] for x in grades)/len(grades),1) if grades else None
    failing=sum(1 for x in grades if x['percent']<60)
    absences=int((one("SELECT COUNT(*) n FROM attendance WHERE student_id=? AND UPPER(COALESCE(status,'')) IN ('AE','AU')",(student_id,)) or {}).get('n') or 0)
    eligible=(avg is None or avg>=float(cfg.get('min_average') or 70)) and failing<=int(cfg.get('max_failing_classes') or 1) and absences<=int(cfg.get('max_absences') or 5)
    reasons=[]
    if avg is not None and avg<float(cfg.get('min_average') or 70):reasons.append(f"Average {avg}% below {cfg.get('min_average') or 70}%")
    if failing>int(cfg.get('max_failing_classes') or 1):reasons.append(f"{failing} failing classes")
    if absences>int(cfg.get('max_absences') or 5):reasons.append(f"{absences} absences")
    return {'eligible':eligible,'average':avg,'failing_classes':failing,'absences':absences,'reasons':reasons,'settings':cfg,'classes':grades}

def _ss269_success_snapshot(student_id):
    snap=academic_snapshot(student_id)
    if not snap:return None
    return {**snap,'attendance_patterns':_ss269_attendance_patterns(student_id),
            'grade_risks':_ss269_grade_risk(student_id),'eligibility':_ss269_eligibility(student_id),
            'recommendations':rows("""SELECT r.*,c.code course_code,c.name course_name,s.name staff_name
                FROM course_recommendations r JOIN courses c ON c.id=r.course_id LEFT JOIN staff s ON s.id=r.staff_id
                WHERE r.student_id=? ORDER BY r.id DESC""",(student_id,)),
            'interventions':rows("SELECT * FROM student_interventions WHERE student_id=? ORDER BY id DESC LIMIT 30",(student_id,)),
            'schedule_changes':rows("""SELECT scr.*,a.name from_name,b.name to_name FROM schedule_change_requests scr
                LEFT JOIN classes a ON a.id=scr.from_class_id LEFT JOIN classes b ON b.id=scr.to_class_id
                WHERE scr.student_id=? ORDER BY scr.id DESC LIMIT 30""",(student_id,))}

def _ss269_repair_options(student_id,class_id):
    current=one("SELECT * FROM classes WHERE id=?",(class_id,))
    if not current:return []
    options=rows("""SELECT c.*,COALESCE(st.name,'') teacher_name,
                    (SELECT COUNT(*) FROM enrollments e WHERE e.class_id=c.id AND COALESCE(e.status,'Active')='Active') enrolled
                    FROM classes c LEFT JOIN staff st ON st.id=c.teacher_id
                    WHERE c.course_id=? AND c.id<>? AND COALESCE(c.published,1)=1 ORDER BY c.period,c.section""",(current.get('course_id'),class_id))
    out=[]
    for c in options:
        if int(c.get('enrolled') or 0)>=int(c.get('capacity') or 30):continue
        conflict=_ss266_regular_conflict(student_id,int(c['id']),school_now()[0].strftime('%Y-%m-%d'))
        if not conflict:out.append(c)
    return out

def _ss269_teacher_coverage(class_id,date):
    cl=one("SELECT * FROM classes WHERE id=?",(class_id,))
    if not cl:return []
    out=[]
    for st in rows("SELECT * FROM staff WHERE LOWER(COALESCE(role,'')) LIKE '%teacher%' AND COALESCE(status,'Active')='Active' ORDER BY name"):
        sid=int(st['id'])
        if sid==int(cl.get('teacher_id') or 0):continue
        try:
            if cl.get('course_id') and not teacher_eligible_for_course(sid,int(cl['course_id'])):continue
        except Exception: pass
        own=rows("""SELECT c.* FROM classes c WHERE c.teacher_id=? AND c.term=?""",(sid,cl.get('term')))
        conflict=False
        ts,te=_ss266_class_time(cl)
        for oc in own:
            os_,oe=_ss266_class_time(oc)
            if oc.get('period')==cl.get('period') or (ts and te and os_ and oe and ts<oe and os_<te):
                conflict=True;break
        if not conflict:out.append({'id':sid,'name':st.get('name'),'role':st.get('role')})
    return out[:25]

_SS269_PRE_GET=Handler.do_GET
def _ss269_get(self):
    p=urlparse(self.path);path=p.path;q=parse_qs(p.query)
    handled={'/api/success-center','/api/prerequisites','/api/schedule-change','/api/course-change-options','/api/schedule-repair',
             '/api/teacher-coverage-suggestions','/api/student-compare','/api/athletic-eligibility',
             '/api/what-if-planner','/api/course-recommendations','/api/term-closeout','/api/gradebook-alerts'}
    if path not in handled:return _SS269_PRE_GET(self)
    user=self.require_user()
    if not user:return
    role=user.get('role')
    try:
        if path=='/api/prerequisites':
            cid=int(q.get('course_id',['0'])[0] or 0)
            data=rows("""SELECT r.*,a.code prerequisite_code,a.name prerequisite_name FROM course_prerequisite_rules r
                         JOIN courses a ON a.id=r.prerequisite_course_id WHERE r.course_id=? ORDER BY a.code,a.name""",(cid,))
            return self.send_json(data)
        if path=='/api/success-center':
            sid=int(q.get('student_id',[str(user.get('student_id') or 0)])[0] or 0)
            if role not in {'admin','counselor','teacher'} and sid not in set(student_scope(user) or []):return self.send_json({'error':'Permission denied'},403)
            d=_ss269_success_snapshot(sid)
            return self.send_json(d or {'error':'Student not found'},200 if d else 404)
        if path=='/api/course-change-options':
            sid=int(q.get('student_id',[str(user.get('student_id') or 0)])[0] or 0)
            if not sid:return self.send_json({'error':'Student required'},400)
            if role not in {'admin','counselor'} and sid not in set(student_scope(user) or []):return self.send_json({'error':'Permission denied'},403)

            request_type=(q.get('request_type',[''])[0] or '').strip()
            from_class_id=int(q.get('from_class_id',['0'])[0] or 0)

            # Build 272 smart destination intelligence. The server uses the school's
            # own course metadata (department + course level) and a normalized course
            # family name, so this works with imported/custom catalogs instead of a
            # hard-coded list of Algebra/English/etc. examples.
            def course_family(name):
                x=str(name or '').lower().replace('&',' and ')
                # Remove level descriptors while preserving the actual course identity.
                phrases=['advanced placement','college preparatory','college prep','accelerated college preparatory',
                         'accelerated','honors','honour','regular','standard','general','ap','dual credit','dual-credit']
                for ph in sorted(phrases,key=len,reverse=True):
                    x=re.sub(r'\b'+re.escape(ph)+r'\b',' ',x)
                x=re.sub(r'\blevel\s*[0-9]+\b',' ',x)
                x=re.sub(r'[^a-z0-9]+',' ',x)
                return ' '.join(x.split())

            source=None
            if from_class_id:
                source=one("""SELECT c.id,c.term,c.course_id,c.name class_name,co.code course_code,co.name course_name,
                                    COALESCE(co.department,'Other') department,COALESCE(co.course_level,'Regular') course_level
                             FROM classes c LEFT JOIN courses co ON co.id=c.course_id WHERE c.id=?""",(from_class_id,))
                # Students/parents may only use one of their own active classes as source.
                if source and role not in {'admin','counselor'} and not one("SELECT 1 FROM enrollments WHERE student_id=? AND class_id=? AND COALESCE(status,'Active')='Active'",(sid,from_class_id)):
                    return self.send_json({'error':'Current class is not on this student schedule'},403)

            data=rows("""
                SELECT c.*,COALESCE(st.name,'Unassigned') teacher,COALESCE(co.code,'') course_code,
                       COALESCE(co.name,c.name) course_name,COALESCE(co.department,'Other') department,
                       COALESCE(co.course_level,'Regular') course_level,
                       (SELECT COUNT(*) FROM enrollments e2 WHERE e2.class_id=c.id AND COALESCE(e2.status,'Active')='Active') enrolled
                FROM classes c
                LEFT JOIN staff st ON st.id=c.teacher_id
                LEFT JOIN courses co ON co.id=c.course_id
                WHERE COALESCE(c.published,0)<>0
                  AND c.id NOT IN (
                    SELECT e.class_id FROM enrollments e
                    WHERE e.student_id=? AND COALESCE(e.status,'Active')='Active'
                  )
                ORDER BY c.term,c.period,co.code,c.name,c.section
            """,(sid,))

            rt=request_type.lower()
            if rt=='drop course':
                data=[]
            elif rt=='level change':
                if not source:
                    data=[]
                else:
                    src_family=course_family(source.get('course_name') or source.get('class_name'))
                    src_dept=str(source.get('department') or 'Other').strip().lower()
                    src_level=str(source.get('course_level') or 'Regular').strip().lower()
                    src_term=str(source.get('term') or '').strip().lower()
                    smart=[]
                    for c in data:
                        same_term=(not src_term) or str(c.get('term') or '').strip().lower()==src_term
                        same_dept=str(c.get('department') or 'Other').strip().lower()==src_dept
                        same_family=course_family(c.get('course_name') or c.get('name'))==src_family
                        different_level=str(c.get('course_level') or 'Regular').strip().lower()!=src_level
                        if same_term and same_dept and same_family and different_level:
                            smart.append(c)
                    data=smart
            elif rt=='transfer':
                # A transfer stays within the same subject/category and academic term,
                # but can move to another course or another section in that category.
                if not source:
                    data=[]
                else:
                    src_dept=str(source.get('department') or 'Other').strip().lower()
                    src_term=str(source.get('term') or '').strip().lower()
                    data=[c for c in data if str(c.get('department') or 'Other').strip().lower()==src_dept
                          and ((not src_term) or str(c.get('term') or '').strip().lower()==src_term)]
            # Add Course / Other intentionally keep the full published, non-enrolled catalog.

            return self.send_json(data)
        if path=='/api/schedule-change':
            if role in {'admin','counselor'}:
                sid=int(q.get('student_id',['0'])[0] or 0)
                sql="""SELECT r.*,s.first_name||' '||s.last_name student_name,a.name from_name,b.name to_name
                       FROM schedule_change_requests r JOIN students s ON s.id=r.student_id
                       LEFT JOIN classes a ON a.id=r.from_class_id LEFT JOIN classes b ON b.id=r.to_class_id"""
                args=()
                if sid:sql+=" WHERE r.student_id=?";args=(sid,)
                return self.send_json(rows(sql+" ORDER BY r.id DESC",args))
            ids=list(student_scope(user) or [])
            if not ids:return self.send_json([])
            ph=','.join('?'*len(ids))
            return self.send_json(rows(f"""SELECT r.*,a.name from_name,b.name to_name FROM schedule_change_requests r
               LEFT JOIN classes a ON a.id=r.from_class_id LEFT JOIN classes b ON b.id=r.to_class_id
               WHERE r.student_id IN ({ph}) ORDER BY r.id DESC""",tuple(ids)))
        if path=='/api/schedule-repair':
            if role not in {'admin','counselor'}:return self.send_json({'error':'Permission denied'},403)
            return self.send_json(_ss269_repair_options(int(q.get('student_id',['0'])[0]),int(q.get('class_id',['0'])[0])))
        if path=='/api/teacher-coverage-suggestions':
            if role not in {'admin','teacher'}:return self.send_json({'error':'Permission denied'},403)
            return self.send_json(_ss269_teacher_coverage(int(q.get('class_id',['0'])[0]),q.get('date',[school_now()[0].strftime('%Y-%m-%d')])[0]))
        if path=='/api/student-compare':
            if role not in {'admin','counselor'}:return self.send_json({'error':'Permission denied'},403)
            a=int(q.get('a',['0'])[0]);b=int(q.get('b',['0'])[0])
            def sched(sid):
                return rows("""SELECT c.id,c.name,c.period,c.term,c.room,co.code course_code FROM enrollments e JOIN classes c ON c.id=e.class_id
                    LEFT JOIN courses co ON co.id=c.course_id WHERE e.student_id=? AND COALESCE(e.status,'Active')='Active' ORDER BY c.term,c.cycle_day,c.period""",(sid,))
            sa,sb=sched(a),sched(b);pairs=[]
            for x in sa:
                for y in sb:
                    if x.get('term')==y.get('term') and x.get('period')==y.get('period'):pairs.append({'a':x,'b':y,'shared':int(x['id'])==int(y['id'])})
            return self.send_json({'a':one("SELECT id,first_name,last_name,student_number FROM students WHERE id=?",(a,)),'b':one("SELECT id,first_name,last_name,student_number FROM students WHERE id=?",(b,)),'schedule_a':sa,'schedule_b':sb,'period_pairs':pairs})
        if path=='/api/athletic-eligibility':
            sid=int(q.get('student_id',[str(user.get('student_id') or 0)])[0] or 0)
            if role not in {'admin','counselor','teacher','coach'} and sid not in set(student_scope(user) or []):return self.send_json({'error':'Permission denied'},403)
            return self.send_json(_ss269_eligibility(sid))
        if path=='/api/what-if-planner':
            sid=int(q.get('student_id',['0'])[0])
            if role not in {'admin','counselor'} and sid not in set(student_scope(user) or []):return self.send_json({'error':'Permission denied'},403)
            ids=[int(x) for x in str(q.get('course_ids',[''])[0]).split(',') if x.strip().isdigit()]
            snap=academic_snapshot(sid)
            if not snap:return self.send_json({'error':'Student not found'},404)
            hypothetical=rows("SELECT id,code,name,department,credits FROM courses WHERE id IN (%s)"%(','.join('?'*len(ids))),tuple(ids)) if ids else []
            earned_by={r['subject_area']:float(r.get('credits_earned') or 0) for r in snap['requirements']}
            req=[]
            for r in snap['requirements']:
                extra=sum(float(c.get('credits') or 0) for c in hypothetical if (c.get('department') or 'Other')==r['subject_area'])
                have=float(r.get('credits_earned') or 0)+extra
                req.append({**r,'projected_credits':round(have,2),'projected_remaining':round(max(0,float(r.get('credits_required') or 0)-have),2)})
            return self.send_json({'student':snap['student'],'selected_courses':hypothetical,'requirements':req})
        if path=='/api/course-recommendations':
            sid=int(q.get('student_id',['0'])[0])
            if role not in {'admin','counselor','teacher'} and sid not in set(student_scope(user) or []):return self.send_json({'error':'Permission denied'},403)
            return self.send_json(rows("""SELECT r.*,c.code course_code,c.name course_name,s.name staff_name FROM course_recommendations r
                JOIN courses c ON c.id=r.course_id LEFT JOIN staff s ON s.id=r.staff_id WHERE r.student_id=? ORDER BY r.id DESC""",(sid,)))
        if path=='/api/term-closeout':
            term=q.get('term',[''])[0]
            if term:return self.send_json(one("SELECT * FROM term_closeout_status WHERE term=?",(term,)) or {'term':term,'status':'Open'})
            return self.send_json(rows("SELECT * FROM term_closeout_status ORDER BY term DESC"))
        if path=='/api/gradebook-alerts':
            sid=int(q.get('student_id',['0'])[0] or 0)
            if sid:
                if role not in {'admin','counselor','teacher'} and sid not in set(student_scope(user) or []):return self.send_json({'error':'Permission denied'},403)
                return self.send_json(_ss269_grade_risk(sid))
            if role=='teacher':
                staff_id=int(user.get('staff_id') or 0)
                cls=rows("SELECT id,name FROM classes WHERE teacher_id=?",(staff_id,));alerts=[]
                for c in cls:
                    ungraded=int((one("""SELECT COUNT(*) n FROM assignments a JOIN enrollments e ON e.class_id=a.class_id
                        LEFT JOIN grades g ON g.assignment_id=a.id AND g.student_id=e.student_id
                        WHERE a.class_id=? AND COALESCE(e.status,'Active')='Active' AND COALESCE(a.include_in_gradebook,1)=1 AND g.score IS NULL""",(c['id'],)) or {}).get('n') or 0)
                    if ungraded:alerts.append({'class_id':c['id'],'class_name':c['name'],'ungraded':ungraded})
                return self.send_json(alerts)
            return self.send_json([])
    except Exception as exc:return self.send_json({'error':str(exc)},500)
Handler.do_GET=_ss269_get

_SS269_PRE_POST=Handler.do_POST
def _ss269_post(self):
    path=urlparse(self.path).path
    handled={'/api/prerequisites','/api/schedule-change','/api/course-recommendations','/api/interventions',
             '/api/eligibility-settings','/api/mass-enrollment','/api/class-handoff','/api/student-status',
             '/api/term-closeout','/api/course-requests/submit','/api/scheduler/rooms'}
    if path not in handled:return _SS269_PRE_POST(self)
    user=self.require_user()
    if not user:return
    role=user.get('role');data=self.read_body() or {}
    try:
        if path=='/api/scheduler/rooms':
            if role!='admin':return self.send_json({'error':'Permission denied'},403)
            rid=int(data.get('id') or 0);vals=(data.get('name') or '',int(data.get('capacity') or 30),data.get('school') or '',data.get('room_type') or 'Standard Classroom')
            if rid:
                run("UPDATE schedule_rooms SET name=?,capacity=?,school=?,room_type=? WHERE id=?",vals+(rid,))
                return self.send_json({'ok':1,'id':rid})
            new_id=run("INSERT INTO schedule_rooms(name,capacity,school,room_type) VALUES(?,?,?,?)",vals)
            return self.send_json({'ok':1,'id':new_id})
        if path=='/api/course-requests/submit':
            if role not in {'student','admin','counselor'}:return self.send_json({'error':'Permission denied'},403)
            if role=='student':
                w=one("SELECT is_open FROM course_request_window WHERE id=1")
                if not w or not int(w.get('is_open') or 0):return self.send_json({'error':'Course requests are not currently open.'},403)
            sid=int(data.get('student_id') or (user.get('student_id') if role=='student' else 0) or 0)
            if not sid:return self.send_json({'error':'Student required'},400)
            if role not in {'admin','counselor'} and sid not in set(student_scope(user) or []):return self.send_json({'error':'Permission denied'},403)
            cid=int(data.get('course_id') or 0);course=one("SELECT * FROM courses WHERE id=? AND COALESCE(requestable,0)=1",(cid,))
            if not course:return self.send_json({'error':'That course is not available for requests.'},400)
            pc=_ss269_prereq_check(sid,cid)
            if not pc['ok']:
                missing=', '.join(pc.get('missing_labels') or [])
                return self.send_json({'error':f'Prerequisite not met: {missing}','prerequisites':pc},409)
            dep=(course.get('department') or 'Other').strip() or 'Other'
            existing=one("""SELECT cr.id,cr.status FROM course_requests cr JOIN courses c ON c.id=cr.course_id
                WHERE cr.student_id=? AND LOWER(COALESCE(c.department,'Other'))=LOWER(?) AND cr.course_id<>?""",(sid,dep,cid))
            if existing and existing.get('status')=='Approved':return self.send_json({'error':'An approved course in this department cannot be replaced by the student. Ask a counselor to reset it first.'},400)
            if existing:run("DELETE FROM course_requests WHERE id=?",(existing['id'],))
            total=one("SELECT COUNT(*) n FROM course_requests WHERE student_id=? AND status<>'Denied'",(sid,))
            if int(total.get('n') or 0)>=7 and not one("SELECT 1 FROM course_requests WHERE student_id=? AND course_id=?",(sid,cid)):return self.send_json({'error':'Students may request no more than seven courses.'},400)
            run("""INSERT INTO course_requests(student_id,course_id,priority,status,approval_status,scheduling_status)
                   VALUES(?,?,?,'Pending','Pending','Pending')
                   ON CONFLICT(student_id,course_id) DO UPDATE SET priority=excluded.priority,status='Pending',approval_status='Pending',scheduling_status='Pending',reviewer_note=NULL""",(sid,cid,int(data.get('priority') or 1)))
            return self.send_json({'ok':1,'prerequisites':pc})
        if path=='/api/prerequisites':
            if role not in {'admin','counselor'}:return self.send_json({'error':'Permission denied'},403)
            cid=int(data.get('course_id') or 0)
            run("DELETE FROM course_prerequisite_rules WHERE course_id=?",(cid,))
            for r in data.get('rules') or []:
                pid=int(r.get('prerequisite_course_id') or 0)
                if pid and pid!=cid:
                    grp=int(r.get('requirement_group') or 0) or None
                    run("""INSERT INTO course_prerequisite_rules(course_id,prerequisite_course_id,min_grade_pct,allow_concurrent,active,created_by,requirement_group)
                    VALUES(?,?,?,?,1,?,?)""",(cid,pid,float(r.get('min_grade_pct') or 60),1 if r.get('allow_concurrent') else 0,user.get('id'),grp))
            audit(user,'Updated prerequisites','Course',cid)
            return self.send_json({'ok':1})
        if path=='/api/schedule-change':
            action=str(data.get('action') or 'request').lower()
            if action=='request':
                sid=int(data.get('student_id') or user.get('student_id') or 0)
                if not sid:return self.send_json({'error':'Student required'},400)
                if role not in {'admin','counselor'} and sid not in set(student_scope(user) or []):return self.send_json({'error':'Permission denied'},403)
                rid=run("""INSERT INTO schedule_change_requests(student_id,request_type,from_class_id,to_class_id,reason,status,requested_by)
                    VALUES(?,?,?,?,?,'Pending',?)""",(sid,data.get('request_type') or 'Transfer',int(data.get('from_class_id') or 0) or None,int(data.get('to_class_id') or 0) or None,data.get('reason') or '',user.get('id')))
                return self.send_json({'ok':1,'id':rid})
            if role not in {'admin','counselor'}:return self.send_json({'error':'Permission denied'},403)
            rid=int(data.get('id') or 0);req=one("SELECT * FROM schedule_change_requests WHERE id=?",(rid,))
            if not req:return self.send_json({'error':'Request not found'},404)
            if action=='deny':
                run("UPDATE schedule_change_requests SET status='Denied',reviewed_by=?,review_note=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?",(user.get('id'),data.get('review_note') or '',rid))
                return self.send_json({'ok':1})
            if action=='approve':
                if req.get('from_class_id') and req.get('to_class_id'):
                    out,code=_ss266_do_transfer(user,{'student_id':req['student_id'],'from_class_id':req['from_class_id'],'to_class_id':req['to_class_id'],'effective_date':data.get('effective_date') or school_now()[0].strftime('%Y-%m-%d'),'grade_policy':data.get('grade_policy') or 'historical','reason':req.get('reason') or 'Approved schedule-change request'})
                    if code!=200:return self.send_json(out,code)
                run("UPDATE schedule_change_requests SET status='Completed',reviewed_by=?,review_note=?,reviewed_at=CURRENT_TIMESTAMP,completed_at=CURRENT_TIMESTAMP WHERE id=?",(user.get('id'),data.get('review_note') or '',rid))
                return self.send_json({'ok':1})
        if path=='/api/course-recommendations':
            if role not in {'admin','teacher','counselor'}:return self.send_json({'error':'Permission denied'},403)
            sid=int(data.get('student_id') or 0);cid=int(data.get('course_id') or 0)
            staff_id=int(user.get('staff_id') or 0) or None
            run("""INSERT INTO course_recommendations(student_id,course_id,staff_id,recommendation,note,school_year)
                VALUES(?,?,?,?,?,?) ON CONFLICT(student_id,course_id,staff_id,school_year) DO UPDATE SET recommendation=excluded.recommendation,note=excluded.note,created_at=CURRENT_TIMESTAMP""",
                (sid,cid,staff_id,data.get('recommendation') or 'Recommended',data.get('note') or '',data.get('school_year') or ''))
            return self.send_json({'ok':1})
        if path=='/api/interventions':
            if role not in {'admin','teacher','counselor','nurse'}:return self.send_json({'error':'Permission denied'},403)
            rid=run("""INSERT INTO student_interventions(student_id,category,status,summary,details,assigned_to,created_by)
                VALUES(?,?,?,?,?,?,?)""",(int(data.get('student_id') or 0),data.get('category') or 'Academic',data.get('status') or 'Open',data.get('summary') or 'Intervention',data.get('details') or '',int(data.get('assigned_to') or 0) or None,user.get('id')))
            return self.send_json({'ok':1,'id':rid})
        if path=='/api/eligibility-settings':
            if role!='admin':return self.send_json({'error':'Permission denied'},403)
            run("""UPDATE academic_eligibility_settings SET min_average=?,max_failing_classes=?,max_absences=?,updated_by=?,updated_at=CURRENT_TIMESTAMP WHERE id=1""",
                (float(data.get('min_average') or 70),int(data.get('max_failing_classes') or 1),int(data.get('max_absences') or 5),user.get('id')))
            return self.send_json({'ok':1})
        if path=='/api/mass-enrollment':
            if role not in {'admin','counselor'}:return self.send_json({'error':'Permission denied'},403)
            cid=int(data.get('class_id') or 0);cl=one("SELECT * FROM classes WHERE id=?",(cid,))
            if not cl:return self.send_json({'error':'Class not found'},404)
            done=[];errors=[]
            for sid0 in data.get('student_ids') or []:
                sid=int(sid0)
                if _ss266_regular_conflict(sid,cid,school_now()[0].strftime('%Y-%m-%d')):errors.append({'student_id':sid,'error':'Schedule conflict'});continue
                n=int((one("SELECT COUNT(*) n FROM enrollments WHERE class_id=? AND COALESCE(status,'Active')='Active'",(cid,)) or {}).get('n') or 0)
                if n>=int(cl.get('capacity') or 30):errors.append({'student_id':sid,'error':'Class full'});continue
                pc=_ss269_prereq_check(sid,int(cl.get('course_id') or 0))
                if not pc['ok']:errors.append({'student_id':sid,'error':'Prerequisite not met'});continue
                run("""INSERT INTO enrollments(class_id,student_id,status,start_date,end_date) VALUES(?,?,'Active',?,'')
                    ON CONFLICT(class_id,student_id) DO UPDATE SET status='Active',start_date=excluded.start_date,end_date=''""",(cid,sid,school_now()[0].strftime('%Y-%m-%d')))
                done.append(sid)
            return self.send_json({'ok':1,'enrolled':done,'errors':errors})
        if path=='/api/class-handoff':
            if role!='admin':return self.send_json({'error':'Permission denied'},403)
            cid=int(data.get('class_id') or 0);newid=int(data.get('new_teacher_id') or 0);cl=one("SELECT * FROM classes WHERE id=?",(cid,))
            if not cl:return self.send_json({'error':'Class not found'},404)
            if cl.get('course_id') and not teacher_eligible_for_course(newid,int(cl['course_id'])):return self.send_json({'error':'New teacher is not eligible for this course'},409)
            run("INSERT INTO class_handoffs(class_id,old_teacher_id,new_teacher_id,effective_date,note,changed_by) VALUES(?,?,?,?,?,?)",(cid,cl.get('teacher_id'),newid,data.get('effective_date') or school_now()[0].strftime('%Y-%m-%d'),data.get('note') or '',user.get('id')))
            run("UPDATE classes SET teacher_id=? WHERE id=?",(newid,cid))
            audit(user,'Teacher class handoff','Class',cid,f"{cl.get('teacher_id')} -> {newid}")
            return self.send_json({'ok':1})
        if path=='/api/student-status':
            if role not in {'admin','counselor'}:return self.send_json({'error':'Permission denied'},403)
            sid=int(data.get('student_id') or 0);new=str(data.get('status') or 'Active');st=one("SELECT status FROM students WHERE id=?",(sid,))
            if not st:return self.send_json({'error':'Student not found'},404)
            run("INSERT INTO student_status_history(student_id,old_status,new_status,effective_date,reason,changed_by) VALUES(?,?,?,?,?,?)",(sid,st.get('status') or '',new,data.get('effective_date') or school_now()[0].strftime('%Y-%m-%d'),data.get('reason') or '',user.get('id')))
            run("UPDATE students SET status=? WHERE id=?",(new,sid))
            if new.lower() not in {'active','enrolled'}:
                run("UPDATE enrollments SET status='Withdrawn',end_date=? WHERE student_id=? AND COALESCE(status,'Active')='Active'",(data.get('effective_date') or school_now()[0].strftime('%Y-%m-%d'),sid))
            return self.send_json({'ok':1})
        if path=='/api/term-closeout':
            if role!='admin':return self.send_json({'error':'Permission denied'},403)
            term=str(data.get('term') or '')
            run("""INSERT INTO term_closeout_status(term,status,notes,closed_by,closed_at,updated_at)
                VALUES(?,?,?,?,CASE WHEN ?='Closed' THEN CURRENT_TIMESTAMP ELSE NULL END,CURRENT_TIMESTAMP)
                ON CONFLICT(term) DO UPDATE SET status=excluded.status,notes=excluded.notes,closed_by=excluded.closed_by,closed_at=excluded.closed_at,updated_at=CURRENT_TIMESTAMP""",
                (term,data.get('status') or 'Open',data.get('notes') or '',user.get('id'),data.get('status') or 'Open'))
            return self.send_json({'ok':1})
    except Exception as exc:return self.send_json({'error':str(exc)},500)
Handler.do_POST=_ss269_post
# --- End Build 269 ---


# --- Build 273: Smart Course Change Scheduling Engine ---
def _ss273_course_family(name):
    x=str(name or '').lower().replace('&',' and ')
    phrases=['advanced placement','college preparatory','college prep','accelerated college preparatory',
             'accelerated','honors','honour','regular','standard','general','ap','dual credit','dual-credit']
    for ph in sorted(phrases,key=len,reverse=True):
        x=re.sub(r'\b'+re.escape(ph)+r'\b',' ',x)
    x=re.sub(r'\blevel\s*[0-9]+\b',' ',x)
    x=re.sub(r'[^a-z0-9]+',' ',x)
    return ' '.join(x.split())

def _ss273_conflict(student_id,to_class_id,exclude_class_id=0):
    target=one("SELECT * FROM classes WHERE id=?",(to_class_id,))
    if not target:return None
    ts,te=_ss266_class_time(target)
    for c in rows("""SELECT c.* FROM enrollments e JOIN classes c ON c.id=e.class_id
                     WHERE e.student_id=? AND e.class_id<>? AND COALESCE(e.status,'Active')='Active'""",
                  (student_id,to_class_id)):
        if exclude_class_id and int(c.get('id') or 0)==int(exclude_class_id):continue
        if str(c.get('term') or '')!=str(target.get('term') or ''):continue
        if int(c.get('cycle_day') or 1)!=int(target.get('cycle_day') or 1):continue
        cs,ce=_ss266_class_time(c)
        if (target.get('period') and c.get('period')==target.get('period')) or (ts and te and cs and ce and ts<ce and cs<te):
            return c
    return None

def _ss273_course_change_options(student_id,request_type,from_class_id=0):
    request_type=str(request_type or '').strip()
    rt=request_type.lower()
    source=None
    if from_class_id:
        source=one("""SELECT c.id,c.term,c.course_id,c.name class_name,c.period,c.cycle_day,
                            co.code course_code,co.name course_name,COALESCE(co.department,'Other') department,
                            COALESCE(co.course_level,'Regular') course_level
                     FROM classes c LEFT JOIN courses co ON co.id=c.course_id WHERE c.id=?""",(from_class_id,))

    data=rows("""
        SELECT c.*,COALESCE(st.name,'Unassigned') teacher,COALESCE(co.code,'') course_code,
               COALESCE(co.name,c.name) course_name,COALESCE(co.department,'Other') department,
               COALESCE(co.course_level,'Regular') course_level,
               (SELECT COUNT(*) FROM enrollments e2 WHERE e2.class_id=c.id AND COALESCE(e2.status,'Active')='Active') enrolled
        FROM classes c
        LEFT JOIN staff st ON st.id=c.teacher_id
        LEFT JOIN courses co ON co.id=c.course_id
        WHERE COALESCE(c.published,0)<>0
          AND c.id NOT IN (
            SELECT e.class_id FROM enrollments e
            WHERE e.student_id=? AND COALESCE(e.status,'Active')='Active'
          )
        ORDER BY c.term,c.period,co.code,c.name,c.section
    """,(student_id,))

    if rt=='drop course':
        data=[]
    elif rt=='level change':
        if not source:data=[]
        else:
            sf=_ss273_course_family(source.get('course_name') or source.get('class_name'))
            sd=str(source.get('department') or 'Other').strip().lower()
            sl=str(source.get('course_level') or 'Regular').strip().lower()
            st=str(source.get('term') or '').strip().lower()
            data=[c for c in data
                  if ((not st) or str(c.get('term') or '').strip().lower()==st)
                  and str(c.get('department') or 'Other').strip().lower()==sd
                  and _ss273_course_family(c.get('course_name') or c.get('name'))==sf
                  and str(c.get('course_level') or 'Regular').strip().lower()!=sl]
    elif rt=='transfer':
        if not source:data=[]
        else:
            sd=str(source.get('department') or 'Other').strip().lower()
            st=str(source.get('term') or '').strip().lower()
            data=[c for c in data if str(c.get('department') or 'Other').strip().lower()==sd
                  and ((not st) or str(c.get('term') or '').strip().lower()==st)]

    out=[]
    for c in data:
        cid=int(c.get('id') or 0)
        cap=max(1,int(c.get('capacity') or 30));enr=int(c.get('enrolled') or 0);seats=max(0,cap-enr)
        conflict=_ss273_conflict(student_id,cid,from_class_id if rt in {'level change','transfer'} else 0)
        pc=_ss269_prereq_check(student_id,int(c.get('course_id') or 0)) if c.get('course_id') else {'ok':True,'requirements':[]}
        same_period=bool(source and str(c.get('term') or '')==str(source.get('term') or '')
                         and int(c.get('cycle_day') or 1)==int(source.get('cycle_day') or 1)
                         and str(c.get('period') or '')==str(source.get('period') or ''))
        blockers=[]
        if seats<=0:blockers.append('Class full')
        if conflict:blockers.append('Conflicts with '+str(conflict.get('name') or 'another class'))
        if not pc.get('ok'):
            missing=', '.join(pc.get('missing_labels') or [])
            blockers.append('Prerequisite not met'+((': '+missing) if missing else ''))
        score=80
        if same_period:score+=12
        if seats>=10:score+=8
        elif seats>=5:score+=5
        elif seats>=2:score+=2
        elif seats==1:score-=3
        if conflict:score-=45
        if seats<=0:score-=40
        if not pc.get('ok'):score-=45
        score=max(0,min(100,score))
        viable=not blockers
        if not viable:fit='Blocked'
        elif score>=95:fit='Best fit'
        elif score>=88:fit='Strong fit'
        elif score>=80:fit='Good fit'
        else:fit='Available'
        out.append({**c,'seats_remaining':seats,'schedule_conflict':bool(conflict),
                    'conflict_class':(conflict.get('name') if conflict else None),
                    'prerequisites_ok':bool(pc.get('ok')),'prerequisites':pc.get('requirements') or [],
                    'same_period':same_period,'fit_score':score,'fit_label':fit,'viable':viable,'blockers':blockers})
    out.sort(key=lambda c:(0 if c.get('viable') else 1,-int(c.get('fit_score') or 0),-int(c.get('seats_remaining') or 0),str(c.get('period') or ''),str(c.get('section') or '')))
    return out

_SS273_PRE_GET=Handler.do_GET
def _ss273_get(self):
    p=urlparse(self.path);path=p.path;q=parse_qs(p.query)
    if path!='/api/course-change-options':return _SS273_PRE_GET(self)
    user=self.require_user()
    if not user:return
    role=user.get('role')
    sid=int(q.get('student_id',[str(user.get('student_id') or 0)])[0] or 0)
    if not sid:return self.send_json({'error':'Student required'},400)
    if role not in {'admin','counselor'} and sid not in set(student_scope(user) or []):return self.send_json({'error':'Permission denied'},403)
    rt=(q.get('request_type',[''])[0] or '').strip();from_id=int(q.get('from_class_id',['0'])[0] or 0)
    if from_id and role not in {'admin','counselor'} and not one("SELECT 1 FROM enrollments WHERE student_id=? AND class_id=? AND COALESCE(status,'Active')='Active'",(sid,from_id)):
        return self.send_json({'error':'Current class is not on this student schedule'},403)
    return self.send_json(_ss273_course_change_options(sid,rt,from_id))
Handler.do_GET=_ss273_get

_SS273_PRE_POST=Handler.do_POST
def _ss273_post(self):
    path=urlparse(self.path).path
    if path!='/api/schedule-change':return _SS273_PRE_POST(self)
    user=self.require_user()
    if not user:return
    data=self.read_body() or {}
    if str(data.get('action') or 'request').lower()!='request':
        # The previous handler needs the request body; reproduce approval/deny path here
        role=user.get('role')
        if role not in {'admin','counselor'}:return self.send_json({'error':'Permission denied'},403)
        rid=int(data.get('id') or 0);req=one("SELECT * FROM schedule_change_requests WHERE id=?",(rid,))
        if not req:return self.send_json({'error':'Request not found'},404)
        action=str(data.get('action') or '').lower()
        if action=='deny':
            run("UPDATE schedule_change_requests SET status='Denied',reviewed_by=?,review_note=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?",(user.get('id'),data.get('review_note') or '',rid))
            _ss277_emit_student_event(int(req.get('student_id') or 0),'schedule',f"schedule-change:{rid}:denied",'Course change request denied',f"Your {req.get('request_type') or 'course change'} request was denied. {data.get('review_note') or ''}".strip())
            return self.send_json({'ok':1})
        if action=='approve':
            if req.get('from_class_id') and req.get('to_class_id'):
                out,code=_ss266_do_transfer(user,{'student_id':req['student_id'],'from_class_id':req['from_class_id'],'to_class_id':req['to_class_id'],'effective_date':data.get('effective_date') or school_now()[0].strftime('%Y-%m-%d'),'grade_policy':data.get('grade_policy') or 'historical','reason':req.get('reason') or 'Approved schedule-change request'})
                if code!=200:return self.send_json(out,code)
            run("UPDATE schedule_change_requests SET status='Completed',reviewed_by=?,review_note=?,reviewed_at=CURRENT_TIMESTAMP,completed_at=CURRENT_TIMESTAMP WHERE id=?",(user.get('id'),data.get('review_note') or '',rid))
            _ss277_emit_student_event(int(req.get('student_id') or 0),'schedule',f"schedule-change:{rid}:approved",'Course change request approved',f"Your {req.get('request_type') or 'course change'} request was approved and applied.")
            return self.send_json({'ok':1})
        return self.send_json({'error':'Unknown action'},400)

    role=user.get('role');sid=int(data.get('student_id') or user.get('student_id') or 0)
    if not sid:return self.send_json({'error':'Student required'},400)
    if role not in {'admin','counselor'} and sid not in set(student_scope(user) or []):return self.send_json({'error':'Permission denied'},403)
    rt=str(data.get('request_type') or 'Transfer').strip();rtl=rt.lower()
    from_id=int(data.get('from_class_id') or 0);to_id=int(data.get('to_class_id') or 0)
    if rtl in {'level change','transfer','drop course'}:
        if not from_id:return self.send_json({'error':'Choose the current class first.'},400)
        if not one("SELECT 1 FROM enrollments WHERE student_id=? AND class_id=? AND COALESCE(status,'Active')='Active'",(sid,from_id)):
            return self.send_json({'error':'Current class is not on this student schedule.'},403)
    if rtl!='drop course':
        if not to_id:return self.send_json({'error':'Choose a requested class.'},400)
        options=_ss273_course_change_options(sid,rt,from_id)
        chosen=next((x for x in options if int(x.get('id') or 0)==to_id),None)
        if not chosen:return self.send_json({'error':'That requested class is not a valid match for this change.'},409)
        if not chosen.get('viable'):
            return self.send_json({'error':'That class cannot currently be requested: '+'; '.join(chosen.get('blockers') or ['not available'])},409)
    rid=run("""INSERT INTO schedule_change_requests(student_id,request_type,from_class_id,to_class_id,reason,status,requested_by)
               VALUES(?,?,?,?,?,'Pending',?)""",(sid,rt,from_id or None,to_id or None,data.get('reason') or '',user.get('id')))
    return self.send_json({'ok':1,'id':rid})
Handler.do_POST=_ss273_post
# --- End Build 273 ---


# --- Build 277: Automated Email Notification Engine ---
_SS277_PRE_INIT = init_db

def init_db():
    _SS277_PRE_INIT()
    run("""CREATE TABLE IF NOT EXISTS notification_email_preferences(
        user_id INTEGER PRIMARY KEY,
        enabled INTEGER DEFAULT 1,
        email_address TEXT DEFAULT '',
        grade_mode TEXT DEFAULT 'Immediate',
        assignment_mode TEXT DEFAULT 'Immediate',
        missing_mode TEXT DEFAULT 'Immediate',
        attendance_mode TEXT DEFAULT 'Immediate',
        schedule_mode TEXT DEFAULT 'Immediate',
        teacher_mode TEXT DEFAULT 'Immediate',
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    run("""CREATE TABLE IF NOT EXISTS notification_email_queue(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_key TEXT DEFAULT '',
        event_type TEXT NOT NULL,
        recipient_user_id INTEGER,
        recipient_role TEXT DEFAULT '',
        student_id INTEGER,
        email_to TEXT NOT NULL,
        subject TEXT NOT NULL,
        body TEXT NOT NULL,
        status TEXT DEFAULT 'Pending',
        attempts INTEGER DEFAULT 0,
        last_error TEXT DEFAULT '',
        send_after TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        sent_at TEXT
    )""")
    run("CREATE INDEX IF NOT EXISTS idx_notification_email_status ON notification_email_queue(status,created_at)")
    run("CREATE UNIQUE INDEX IF NOT EXISTS idx_notification_email_dedupe ON notification_email_queue(event_key,email_to) WHERE event_key<>''")


def _ss277_setting(key, default=''):
    r=one("SELECT setting_value FROM district_settings WHERE setting_key=?",(key,))
    return (r or {}).get('setting_value',default) if r else default


def _ss277_set_setting(key, value):
    run("""INSERT INTO district_settings(setting_key,setting_value,updated_at) VALUES(?,?,CURRENT_TIMESTAMP)
           ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value,updated_at=CURRENT_TIMESTAMP""",(key,str(value if value is not None else '')))


def _ss277_smtp_config():
    def env_or(key, env, default=''):
        return os.environ.get(env) or _ss277_setting(key,default)
    try: port=int(env_or('email_smtp_port','SCHOLARSYNC_SMTP_PORT','587') or 587)
    except Exception: port=587
    return {
        'enabled': str(env_or('email_enabled','SCHOLARSYNC_EMAIL_ENABLED','0')).lower() in {'1','true','yes','on'},
        'host': env_or('email_smtp_host','SCHOLARSYNC_SMTP_HOST',''),
        'port': port,
        'username': env_or('email_smtp_username','SCHOLARSYNC_SMTP_USERNAME',''),
        'password': env_or('email_smtp_password','SCHOLARSYNC_SMTP_PASSWORD',''),
        'from_address': env_or('email_from_address','SCHOLARSYNC_EMAIL_FROM',''),
        'from_name': env_or('email_from_name','SCHOLARSYNC_EMAIL_FROM_NAME','ScholarSync'),
        'security': env_or('email_smtp_security','SCHOLARSYNC_SMTP_SECURITY','STARTTLS'),
        'reply_to': env_or('email_reply_to','SCHOLARSYNC_EMAIL_REPLY_TO',''),
    }


def _ss277_user_pref(user_id):
    if not user_id:return None
    p=one("SELECT * FROM notification_email_preferences WHERE user_id=?",(int(user_id),))
    if p:return p
    return {'user_id':int(user_id),'enabled':1,'email_address':'','grade_mode':'Immediate','assignment_mode':'Immediate','missing_mode':'Immediate','attendance_mode':'Immediate','schedule_mode':'Immediate','teacher_mode':'Immediate'}


def _ss277_inferred_email(user_id):
    if not user_id:return ''
    u=one("SELECT * FROM users WHERE id=?",(int(user_id),)) or {}
    role=str(u.get('role') or '')
    if role=='student' and u.get('student_id'):
        return str((one("SELECT email FROM students WHERE id=?",(u['student_id'],)) or {}).get('email') or '').strip()
    if role in {'teacher','counselor','nurse','finance','transportation','food','coach','substitute','admin'} and u.get('staff_id'):
        return str((one("SELECT email FROM staff WHERE id=?",(u['staff_id'],)) or {}).get('email') or '').strip()
    return ''


def _ss277_pref_mode(pref,event_type):
    col={
        'grade':'grade_mode','missing':'missing_mode','assignment':'assignment_mode','attendance':'attendance_mode',
        'schedule':'schedule_mode','teacher':'teacher_mode'
    }.get(str(event_type or '').lower(),'assignment_mode')
    return str((pref or {}).get(col) or 'Immediate')


def _ss277_recipient_accounts_for_student(student_id):
    out=[]
    seen=set()
    # Student account(s), if present.
    for u in rows("SELECT id,role,student_id,staff_id,display_name FROM users WHERE active=1 AND role='student' AND student_id=?",(int(student_id),)):
        pref=_ss277_user_pref(u['id']); email=str(pref.get('email_address') or _ss277_inferred_email(u['id']) or '').strip()
        if email and email.lower() not in seen:
            seen.add(email.lower());out.append({'user_id':u['id'],'role':'student','email':email,'pref':pref})
    # If a student has an email but no portal user yet, school notifications can still reach them.
    if not any(x['role']=='student' for x in out):
        st=one("SELECT email FROM students WHERE id=?",(int(student_id),)) or {}
        email=str(st.get('email') or '').strip()
        if email and email.lower() not in seen:
            seen.add(email.lower());out.append({'user_id':None,'role':'student','email':email,'pref':{'enabled':1,'grade_mode':'Immediate','missing_mode':'Immediate','assignment_mode':'Immediate','attendance_mode':'Immediate','schedule_mode':'Immediate','teacher_mode':'Immediate'}})
    # Linked parent/guardian portal accounts. Parents can provide their delivery email in Notification Preferences.
    for u in rows("""SELECT u.id,u.role,u.display_name FROM parent_students ps JOIN users u ON u.id=ps.user_id
                     WHERE ps.student_id=? AND u.active=1 AND u.role='parent'""",(int(student_id),)):
        pref=_ss277_user_pref(u['id']);email=str(pref.get('email_address') or '').strip()
        if email and email.lower() not in seen:
            seen.add(email.lower());out.append({'user_id':u['id'],'role':'parent','email':email,'pref':pref})
    return out


def _ss277_teacher_recipient_for_class(class_id):
    c=one("SELECT teacher_id,name FROM classes WHERE id=?",(int(class_id),)) or {}
    tid=int(c.get('teacher_id') or 0)
    if not tid:return []
    st=one("SELECT email,name FROM staff WHERE id=?",(tid,)) or {}
    users=rows("SELECT id,role FROM users WHERE active=1 AND staff_id=? ORDER BY CASE WHEN role='teacher' THEN 0 ELSE 1 END,id",(tid,))
    if users:
        u=users[0];pref=_ss277_user_pref(u['id']);email=str(pref.get('email_address') or st.get('email') or '').strip()
        return [{'user_id':u['id'],'role':u.get('role') or 'teacher','email':email,'pref':pref}] if email else []
    email=str(st.get('email') or '').strip()
    return [{'user_id':None,'role':'teacher','email':email,'pref':{'enabled':1,'teacher_mode':'Immediate'}}] if email else []


def _ss279_render_email_html(subject, body, event_type='', recipient_role='', student_id=None, digest_items=None):
    event = str(event_type or '').lower()
    title = str(subject or 'ScholarSync update')
    safe_body = html.escape(str(body or '')).replace('\n', '<br>')
    detail = '<p style="margin:0;color:#475569;font-size:16px;line-height:1.6">' + safe_body + '</p>'
    if event == 'grade':
        m = re.search(r"A grade of\s+(.+?)\s+was posted for\s+(.+?)\s+in\s+(.+?)\.?$", str(body or ''), re.I | re.S)
        if m:
            score, assignment, course = [x.strip().rstrip('.') for x in m.groups()]
            pct = ''
            sm = re.fullmatch(r"\s*(-?\d+(?:\.\d+)?)\s*/\s*(-?\d+(?:\.\d+)?)\s*", score)
            if sm and float(sm.group(2)):
                v = float(sm.group(1)) / float(sm.group(2)) * 100
                pct = (f"{v:.1f}".rstrip('0').rstrip('.') + '%')
            detail = (
                '<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:16px;padding:20px">'
                '<div style="font-size:13px;color:#64748b;font-weight:700;text-transform:uppercase">' + html.escape(course) + '</div>'
                '<div style="font-size:20px;font-weight:800;margin-top:6px">' + html.escape(assignment) + '</div>'
                '<div style="font-size:36px;font-weight:800;margin-top:16px">' + html.escape(score) + '</div>'
                + (('<div style="font-size:16px;color:#2563eb;font-weight:700;margin-top:4px">' + html.escape(pct) + '</div>') if pct else '')
                + '</div>'
            )
    if digest_items:
        detail = ''.join(
            '<div style="padding:12px 0;border-bottom:1px solid #e2e8f0"><b>' + html.escape(str(x.get('subject') or 'Update')) + '</b><div style="color:#64748b;margin-top:4px">' + html.escape(str(x.get('body') or '')) + '</div></div>'
            for x in digest_items
        )
    return (
        '<!doctype html><html><body style="margin:0;background:#f1f5f9;font-family:Arial,sans-serif">'
        '<table width="100%" cellpadding="0" cellspacing="0" style="padding:24px 12px"><tr><td align="center">'
        '<table width="100%" cellpadding="0" cellspacing="0" style="max-width:620px;background:#fff;border:1px solid #e2e8f0;border-radius:18px;overflow:hidden">'
        '<tr><td style="background:#0f172a;color:#fff;padding:22px 28px"><div style="font-size:22px;font-weight:800">ScholarSync</div><div style="font-size:12px;color:#cbd5e1;margin-top:3px">District SIS</div></td></tr>'
        '<tr><td style="padding:30px 28px"><div style="display:inline-block;background:#eff6ff;color:#1d4ed8;border-radius:999px;padding:6px 10px;font-size:12px;font-weight:800;text-transform:uppercase">' + html.escape(event or 'notification') + '</div>'
        '<div style="font-size:30px;font-weight:800;margin:18px 0 20px">' + html.escape(title) + '</div>' + detail + '</td></tr>'
        '<tr><td style="padding:18px 28px;background:#f8fafc;border-top:1px solid #e2e8f0;color:#64748b;font-size:12px">You are receiving this because ScholarSync email notifications are enabled for your account.</td></tr>'
        '</table></td></tr></table></body></html>'
    )


def _ss277_send_email(to_addr, subject, body, html_body=None):
    cfg = _ss277_smtp_config()
    if not cfg['enabled']:
        raise RuntimeError('Email delivery is disabled in Admin > Notifications > Email delivery')
    if not cfg['host']:
        raise RuntimeError('SMTP host is not configured')
    from_addr = cfg['from_address'] or cfg['username']
    if not from_addr:
        raise RuntimeError('From email address is not configured')
    msg = EmailMessage()
    msg['To'] = to_addr
    msg['From'] = f"{cfg['from_name']} <{from_addr}>" if cfg['from_name'] else from_addr
    msg['Subject'] = subject
    if cfg.get('reply_to'):
        msg['Reply-To'] = cfg['reply_to']
    msg.set_content(body)
    if html_body:
        msg.add_alternative(html_body, subtype='html')
    sec = str(cfg.get('security') or 'STARTTLS').upper()
    smtp = smtplib.SMTP_SSL(cfg['host'], cfg['port'], timeout=15) if sec == 'SSL' else smtplib.SMTP(cfg['host'], cfg['port'], timeout=15)
    try:
        smtp.ehlo()
        if sec == 'STARTTLS':
            smtp.starttls(); smtp.ehlo()
        if cfg['username']:
            smtp.login(cfg['username'], cfg['password'])
        smtp.send_message(msg)
    finally:
        try: smtp.quit()
        except Exception: pass


def _ss277_attempt_queue(qid):
    q=one("SELECT * FROM notification_email_queue WHERE id=?",(int(qid),))
    if not q or q.get('status')=='Sent':return False
    try:
        _ss277_send_email(q['email_to'], q['subject'], q['body'], _ss279_render_email_html(q['subject'], q['body'], q.get('event_type'), q.get('recipient_role'), q.get('student_id')))
        run("UPDATE notification_email_queue SET status='Sent',attempts=attempts+1,last_error='',sent_at=CURRENT_TIMESTAMP WHERE id=?",(qid,))
        return True
    except Exception as exc:
        status='Queued' if 'disabled' in str(exc).lower() or 'not configured' in str(exc).lower() else 'Failed'
        run("UPDATE notification_email_queue SET status=?,attempts=attempts+1,last_error=? WHERE id=?",(status,str(exc)[:500],qid))
        return False


def _ss277_queue_recipient(rec,event_type,event_key,subject,body,student_id=None):
    pref=rec.get('pref') or {}
    if not int(pref.get('enabled') if pref.get('enabled') is not None else 1):return None
    mode=_ss277_pref_mode(pref,event_type)
    if mode.lower()=='off':return None
    email=str(rec.get('email') or '').strip()
    if not email:return None
    status='Digest' if mode.lower().startswith('daily') else 'Pending'
    try:
        qid=run("""INSERT INTO notification_email_queue(event_key,event_type,recipient_user_id,recipient_role,student_id,email_to,subject,body,status)
                   VALUES(?,?,?,?,?,?,?,?,?)""",(event_key,event_type,rec.get('user_id'),rec.get('role') or '',student_id,email,subject,body,status))
    except sqlite3.IntegrityError:
        return None
    if status=='Pending':_ss277_attempt_queue(qid)
    return qid


def _ss277_emit_student_event(student_id,event_type,event_key,subject,body):
    for rec in _ss277_recipient_accounts_for_student(student_id):
        _ss277_queue_recipient(rec,event_type,event_key,subject,body,student_id)


def _ss277_emit_teacher_event(class_id,event_key,subject,body):
    for rec in _ss277_teacher_recipient_for_class(class_id):
        _ss277_queue_recipient(rec,'teacher',event_key,subject,body,None)


def _ss277_process_digest_groups():
    now=school_now()[0]
    # Daily summaries are sent after 5 PM local time; older unsent summaries are sent on the next worker pass.
    cutoff_today=now.hour>=17
    pending=rows("SELECT * FROM notification_email_queue WHERE status='Digest' ORDER BY email_to,recipient_user_id,id LIMIT 500")
    groups={}
    for q in pending:
        try:created=datetime.fromisoformat(str(q.get('created_at') or '').replace('Z','+00:00'))
        except Exception:created=now-timedelta(days=1)
        if created.date()>=now.date() and not cutoff_today:continue
        groups.setdefault((q['email_to'],q.get('recipient_user_id')),[]).append(q)
    for (email,uid),items in groups.items():
        ids=[int(x['id']) for x in items]
        ph=','.join('?'*len(ids))
        # claim before network send so multiple portal processes cannot send the same digest.
        con=db_connect()
        try:
            con.execute('BEGIN IMMEDIATE')
            cur=con.execute(f"UPDATE notification_email_queue SET status='SendingDigest' WHERE id IN ({ph}) AND status='Digest'",ids)
            if cur.rowcount!=len(ids):con.rollback();continue
            con.commit()
        except Exception:
            con.rollback();continue
        finally:con.close()
        subject=f"ScholarSync daily summary — {len(items)} update{'s' if len(items)!=1 else ''}"
        body="Here are today's ScholarSync updates:\n\n"+'\n\n'.join(f"• {x['subject']}\n  {x['body'].replace(chr(10), ' ')}" for x in items)+"\n\nYou can change email preferences in ScholarSync > Notifications."
        try:
            _ss277_send_email(email, subject, body, _ss279_render_email_html(subject, body, 'digest', '', None, items))
            run(f"UPDATE notification_email_queue SET status='Sent',attempts=attempts+1,last_error='',sent_at=CURRENT_TIMESTAMP WHERE id IN ({ph})",ids)
        except Exception as exc:
            status='Digest' if 'disabled' in str(exc).lower() or 'not configured' in str(exc).lower() else 'Failed'
            run(f"UPDATE notification_email_queue SET status=?,attempts=attempts+1,last_error=? WHERE id IN ({ph})",[status,str(exc)[:500],*ids])


def _ss277_worker_loop():
    while True:
        try:
            for q in rows("SELECT id FROM notification_email_queue WHERE status IN ('Pending','Failed','Queued') AND attempts<5 ORDER BY id LIMIT 25"):
                _ss277_attempt_queue(q['id'])
            _ss277_process_digest_groups()
        except Exception:
            pass
        time.sleep(60)


def _ss277_pref_payload(user):
    uid=int(user.get('id') or 0);pref=_ss277_user_pref(uid) or {}
    inferred=_ss277_inferred_email(uid)
    return {**pref,'inferred_email':inferred,'effective_email':pref.get('email_address') or inferred}


_SS277_PRE_GET = Handler.do_GET
def _ss277_get(self):
    parsed=urlparse(self.path);path=parsed.path
    if path not in {'/api/email-notifications/preferences','/api/email-notifications/admin','/api/email-notifications/log'}:
        return _SS277_PRE_GET(self)
    user=self.require_user()
    if not user:return
    if path=='/api/email-notifications/preferences':
        return self.send_json(_ss277_pref_payload(user))
    if path=='/api/email-notifications/log':
        role=user.get('role');uid=int(user.get('id') or 0)
        if role=='admin':out=rows("SELECT * FROM notification_email_queue ORDER BY id DESC LIMIT 200")
        else:out=rows("SELECT * FROM notification_email_queue WHERE recipient_user_id=? ORDER BY id DESC LIMIT 100",(uid,))
        return self.send_json(out)
    if user.get('role')!='admin':return self.send_json({'error':'Permission denied'},403)
    cfg=_ss277_smtp_config()
    safe={k:v for k,v in cfg.items() if k!='password'};safe['password_configured']=bool(cfg.get('password'))
    stats=one("""SELECT COUNT(*) total,
        SUM(CASE WHEN status='Sent' THEN 1 ELSE 0 END) sent,
        SUM(CASE WHEN status IN ('Pending','Queued','Digest') THEN 1 ELSE 0 END) queued,
        SUM(CASE WHEN status='Failed' THEN 1 ELSE 0 END) failed
        FROM notification_email_queue""") or {}
    return self.send_json({'settings':safe,'stats':stats,'recent':rows("SELECT * FROM notification_email_queue ORDER BY id DESC LIMIT 100")})
Handler.do_GET=_ss277_get


_SS277_PRE_POST = Handler.do_POST
def _ss277_post(self):
    path=urlparse(self.path).path
    if path not in {'/api/email-notifications/preferences','/api/email-notifications/admin'}:
        return _SS277_PRE_POST(self)
    user=self.require_user()
    if not user:return
    data=self.read_body() or {}
    if path=='/api/email-notifications/preferences':
        uid=int(user.get('id') or 0)
        modes={'Immediate','Daily summary','Off'}
        vals=[]
        for k in ['grade_mode','assignment_mode','missing_mode','attendance_mode','schedule_mode','teacher_mode']:
            v=str(data.get(k) or 'Immediate');vals.append(v if v in modes else 'Immediate')
        run("""INSERT INTO notification_email_preferences(user_id,enabled,email_address,grade_mode,assignment_mode,missing_mode,attendance_mode,schedule_mode,teacher_mode,updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
               ON CONFLICT(user_id) DO UPDATE SET enabled=excluded.enabled,email_address=excluded.email_address,grade_mode=excluded.grade_mode,
               assignment_mode=excluded.assignment_mode,missing_mode=excluded.missing_mode,attendance_mode=excluded.attendance_mode,
               schedule_mode=excluded.schedule_mode,teacher_mode=excluded.teacher_mode,updated_at=CURRENT_TIMESTAMP""",
            (uid,1 if data.get('enabled',True) else 0,str(data.get('email_address') or '').strip(),*vals))
        audit(user,'Updated email notification preferences','Notifications',uid)
        return self.send_json({'ok':1,**_ss277_pref_payload(user)})
    if user.get('role')!='admin':return self.send_json({'error':'Permission denied'},403)
    action=str(data.get('action') or 'settings').lower()
    if action=='settings':
        fields={'enabled':'email_enabled','host':'email_smtp_host','port':'email_smtp_port','username':'email_smtp_username','from_address':'email_from_address','from_name':'email_from_name','security':'email_smtp_security','reply_to':'email_reply_to'}
        for field,key in fields.items():
            if field in data:_ss277_set_setting(key,1 if field=='enabled' and data.get(field) else (0 if field=='enabled' else data.get(field)))
        if str(data.get('password') or ''):_ss277_set_setting('email_smtp_password',data.get('password'))
        audit(user,'Updated automated email delivery settings','Notifications')
        return self.send_json({'ok':1})
    if action=='test':
        email=str(data.get('email') or '').strip()
        if not email:return self.send_json({'error':'Enter a test email address'},400)
        try:_ss277_send_email(email,'ScholarSync email test','ScholarSync automated email delivery is configured correctly.');return self.send_json({'ok':1})
        except Exception as exc:return self.send_json({'error':str(exc)},400)
    if action=='retry':
        qid=int(data.get('id') or 0)
        if qid:_ss277_attempt_queue(qid)
        else:
            for q in rows("SELECT id FROM notification_email_queue WHERE status IN ('Failed','Queued','Pending') ORDER BY id LIMIT 100"):_ss277_attempt_queue(q['id'])
        return self.send_json({'ok':1})
    if action=='process-digests':
        _ss277_process_digest_groups();return self.send_json({'ok':1})
    return self.send_json({'error':'Unknown action'},400)
Handler.do_POST=_ss277_post
# --- End Build 277 Automated Email Notification Engine ---


# --- ScholarSync Build 282 Cloud Production Readiness ---
_SS282_ORIG_GET = Handler.do_GET
_SS282_ORIG_POST = Handler.do_POST
_SS282_RESTORE_LOCK = threading.Lock()

def _ss282_get(self):
    path = urlparse(self.path).path
    if path == '/api/cloud/status':
        user = self.require_user({'admin'})
        if not user:
            return
        db_dir = os.path.dirname(os.path.abspath(DB))
        return self.send_json({
            'ok': 1,
            'build': 282,
            'production': PRODUCTION,
            'public_url': PUBLIC_URL,
            'persistent_database': bool(os.environ.get('SCHOLARSYNC_DB') or os.environ.get('DATABASE_PATH')),
            'database_directory': os.path.basename(db_dir) or '/',
            'https': PRODUCTION or self.headers.get('X-Forwarded-Proto','').lower() == 'https',
        })
    return _SS282_ORIG_GET(self)

def _ss282_post(self):
    path = urlparse(self.path).path
    if path == '/api/enterprise/backup-upload':
        user = self.require_user({'admin'})
        if not user:
            return
        data = self.read_body()
        raw = str(data.get('data_base64') or '')
        if raw.startswith('data:') and ',' in raw:
            raw = raw.split(',',1)[1]
        if not raw:
            return self.send_json({'error':'Choose a ScholarSync .db backup file first.'},400)
        try:
            blob = base64.b64decode(raw, validate=True)
        except Exception:
            return self.send_json({'error':'The selected file could not be decoded.'},400)
        if len(blob) > 100 * 1024 * 1024:
            return self.send_json({'error':'Database backup is larger than the 100 MB migration limit.'},413)
        if not blob.startswith(b'SQLite format 3\x00'):
            return self.send_json({'error':'That file is not a valid SQLite ScholarSync database backup.'},400)
        requested = os.path.basename(str(data.get('name') or 'uploaded_cloud_migration.db'))
        if not requested.lower().endswith('.db'):
            requested += '.db'
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        safe_name = f"uploaded_{stamp}_{re.sub(r'[^A-Za-z0-9_.-]+','_',requested)}"
        target = os.path.join(backup_dir(), safe_name)
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target,'wb') as fh:
            fh.write(blob)
        if not data.get('restore'):
            audit(user,'Uploaded database backup for cloud migration','Enterprise',safe_name,{'bytes':len(blob)})
            return self.send_json({'ok':1,'name':safe_name,'bytes':len(blob),'restored':False})
        with _SS282_RESTORE_LOCK:
            safety = create_database_backup('Before_Cloud_Migration', user.get('username') or 'Admin')
            src = sqlite3.connect(target)
            dst = sqlite3.connect(DB)
            try:
                src.backup(dst)
            finally:
                src.close(); dst.close()
            init_db()
            audit(user,'Restored uploaded database into cloud instance','Enterprise',safe_name,{'safety_backup':safety['name']})
        return self.send_json({'ok':1,'name':safe_name,'bytes':len(blob),'restored':True,'safety_backup':safety['name']})
    return _SS282_ORIG_POST(self)

Handler.do_GET = _ss282_get
Handler.do_POST = _ss282_post
# --- End Build 282 Cloud Production Readiness ---


if __name__ == "__main__":
    args = parse_args()
    PORTAL_LOCK = args.portal or ""
    PORT = args.port or int(os.environ.get("PORT") or ROLE_PORTS[PORTAL_LOCK])
    if args.db:
        DB = os.path.abspath(args.db)
    COOKIE_NAME = f"scholarsync_session_{PORTAL_LOCK or 'general'}"
    init_db()
    threading.Thread(target=_ss277_worker_loop, daemon=True, name="ScholarSyncEmailWorker").start()
    query = f"?portal={PORTAL_LOCK}" if PORTAL_LOCK else ""
    url = f"http://127.0.0.1:{PORT}/{query}"
    try:
        _lan_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        _lan_sock.connect(("8.8.8.8", 80))
        LAN_IP = _lan_sock.getsockname()[0]
        _lan_sock.close()
    except Exception:
        try:
            LAN_IP = socket.gethostbyname(socket.gethostname())
        except Exception:
            LAN_IP = ""
    LAN_URL = f"http://{LAN_IP}:{PORT}/{query}" if LAN_IP and not LAN_IP.startswith("127.") else ""
    if is_server_running(PORT):
        if not args.no_browser:
            webbrowser.open(url)
        print(f"ScholarSync {PORTAL_LOCK or 'general'} portal is already running at {url}")
        raise SystemExit(0)
    if not args.no_browser:
        threading.Timer(0.9, lambda: webbrowser.open(url)).start()
    print("ScholarSync District SIS")
    print("Portal:", PORTAL_LOCK or "General")
    print("Running on this computer:", url)
    if LAN_URL:
        print("iPhone / same Wi-Fi:", LAN_URL)
        print("On iPhone: open this address in Safari, then Share > Add to Home Screen.")
    else:
        print("LAN address could not be detected automatically.")
    print("Keep this window open. Press Ctrl+C to stop this portal.")
    if PRODUCTION:
        print("Production mode: ON")
        if PUBLIC_URL:
            print("Public URL:", PUBLIC_URL)
        print("Database:", "persistent cloud volume" if os.path.isabs(DB) else "configured path")
    else:
        print("Security: phone access is limited by your Wi-Fi/router/firewall; do not port-forward this server to the public internet.")
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()

