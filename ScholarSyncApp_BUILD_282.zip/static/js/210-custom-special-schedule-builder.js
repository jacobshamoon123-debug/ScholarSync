/* ScholarSync Custom Special-Day Period Builder */
(function(){
  const esc2=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const css=document.createElement('style');css.id='ss-special-builder-css';css.textContent=`
  .ss-special-builder{border:1px solid var(--line);border-radius:14px;background:#f8fafc;padding:14px}.ss-rotation-group{border:1px solid var(--line);border-radius:12px;background:#fff;margin-top:12px;overflow:hidden}.ss-rotation-head{padding:11px 13px;background:#f1f5f8;font-weight:900;display:flex;justify-content:space-between;align-items:center}.ss-period-pick{display:grid;grid-template-columns:32px minmax(160px,1fr) 135px 135px;gap:9px;align-items:center;padding:10px 12px;border-top:1px solid #edf1f4}.ss-period-pick.selected{background:#f3f9ff}.ss-period-pick input[type=time]{width:100%;padding:8px;border:1px solid var(--line);border-radius:8px}.ss-period-name b,.ss-period-name span{display:block}.ss-period-name span{font-size:11px;color:var(--muted);margin-top:2px}.ss-special-summary{margin-top:12px;padding:11px;border-radius:10px;background:#eef7ff;border:1px solid #c8deef;font-size:12px}.ss-special-fields-hidden{display:none!important}@media(max-width:720px){.ss-period-pick{grid-template-columns:32px minmax(0,1fr);}.ss-period-pick .ss-time-field{grid-column:2}}
  `;document.head.appendChild(css);

  window.schoolDayForm=async function(x={}){
    let setup={rotation_days:[],selected:[]};
    try{setup=await api('/api/special-schedule/setup'+(x.date?'?date='+encodeURIComponent(x.date):''))}catch(_){ }
    const isClosure=['School Closure','Closed','No School'].includes(x.day_type);
    const selectedMap=new Map((setup.selected||[]).map(p=>[`${p.source_cycle_day}|${p.period_name}`,p]));
    const groups=(setup.rotation_days||[]).map(g=>`<div class="ss-rotation-group"><div class="ss-rotation-head"><span>${esc2(g.label)}</span><span class="student-sub">Choose any periods from this day</span></div>${(g.periods||[]).map(p=>{
      const key=`${g.cycle_day}|${p.name}`,sel=selectedMap.get(key),checked=!!sel;
      return `<div class="ss-period-pick ${checked?'selected':''}" data-cycle="${g.cycle_day}" data-period="${esc2(p.name)}"><input class="ss-special-check" type="checkbox" ${checked?'checked':''} aria-label="Include ${esc2(p.name)}"><div class="ss-period-name"><b>${esc2(p.name)}</b><span>${esc2(g.label)} · Normal ${fmtTime(p.start_time)}–${fmtTime(p.end_time)}</span></div><label class="ss-time-field"><span class="student-sub">Start</span><input class="ss-special-start" type="time" value="${esc2((sel&&sel.start_time)||p.start_time||'')}"></label><label class="ss-time-field"><span class="student-sub">End</span><input class="ss-special-end" type="time" value="${esc2((sel&&sel.end_time)||p.end_time||'')}"></label></div>`}).join('')||'<div class="empty-modern">No periods are configured for this rotation day yet.</div>'}</div>`).join('');
    openModal(x.id?'Edit Calendar Day':'Add Calendar Day',`<form class="form" id="ssCalendarDayForm" onsubmit="saveSchoolDay(event)"><input type="hidden" name="id" value="${x.id||''}">
      <label><span>Date</span><input name="date" type="date" value="${esc2(x.date||'')}" required></label>
      <label><span>Type</span><select name="day_type" onchange="ssCalendarTypeChanged(this.value)"><option>School Day</option><option>School Closure</option><option>Holiday</option><option>Assembly</option><option>Special Schedule</option></select></label>
      <label class="full"><span>Title</span><input name="title" value="${esc2(x.title||'')}" placeholder="Late Start / Testing Schedule" required></label>
      <div id="ssClosureFields" class="full" style="display:${isClosure?'block':'none'}"><div class="closure-form-note"><b>School Closure Alert</b><br>Classes and normal attendance are suppressed and the closure alert is shown across portals.</div><div class="form" style="margin-top:10px"><label><span>Reason</span><select name="closure_reason"><option>Snow / Ice</option><option>Extreme Cold</option><option>Extreme Heat</option><option>Power Outage</option><option>Building Issue</option><option>Emergency</option><option>Other</option></select></label><label class="checkbox-line"><input name="cancel_activities" type="checkbox" ${Number(x.cancel_activities)?'checked':''}><span>Cancel athletics & extracurriculars</span></label><label class="full"><span>Message shown to school community</span><textarea name="closure_message" rows="4">${esc2(x.closure_message||'')}</textarea></label><label class="checkbox-line full"><input name="alert_enabled" type="checkbox" ${x.alert_enabled===0?'':'checked'}><span>Show prominent closure alert</span></label></div></div>
      <div id="ssSpecialBuilder" class="full ss-special-builder" style="display:${x.day_type==='Special Schedule'?'block':'none'}"><div><b>Build this day's schedule</b><div class="student-sub">Mix periods from any rotation day and give each selected period its own start and end time. Only the periods you select will meet.</div></div>${groups||'<div class="empty-modern">Configure rotation periods first.</div>'}<div class="ss-special-summary" id="ssSpecialSummary">Select the periods that will meet on this special day.</div></div>
      <label class="full"><span>Internal details</span><textarea name="details">${esc2(x.details||'')}</textarea></label>
      <div class="full row-actions"><button class="btn primary">Save Day</button>${x.id?`<button type="button" class="btn danger" onclick="deleteSchoolDay(${x.id})">Delete</button>`:''}</div>
    </form>`);
    setTimeout(()=>{
      const t=document.querySelector('#ssCalendarDayForm [name="day_type"]');if(t)t.value=x.day_type||'School Day';
      const r=document.querySelector('#ssCalendarDayForm [name="closure_reason"]');if(r&&x.closure_reason)r.value=x.closure_reason;
      document.querySelectorAll('.ss-period-pick').forEach(row=>{const cb=row.querySelector('.ss-special-check');cb?.addEventListener('change',()=>{row.classList.toggle('selected',cb.checked);ssUpdateSpecialSummary()});row.querySelectorAll('input[type=time]').forEach(inp=>inp.addEventListener('change',ssUpdateSpecialSummary))});
      ssCalendarTypeChanged(t?.value||'School Day');ssUpdateSpecialSummary();
    },0);
  };
  function fmtTime(v){if(!v)return '—';const [h,m]=String(v).split(':').map(Number);if(Number.isNaN(h))return v;return new Date(2000,0,1,h,m||0).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})}
  window.ssCalendarTypeChanged=function(v){const close=document.getElementById('ssClosureFields'),builder=document.getElementById('ssSpecialBuilder');if(close)close.style.display=v==='School Closure'?'block':'none';if(builder)builder.style.display=v==='Special Schedule'?'block':'none'};
  window.ssUpdateSpecialSummary=function(){const rows=[...document.querySelectorAll('.ss-period-pick')].filter(r=>r.querySelector('.ss-special-check')?.checked),box=document.getElementById('ssSpecialSummary');if(!box)return;if(!rows.length){box.textContent='Select the periods that will meet on this special day.';return}box.innerHTML=`<b>${rows.length} period${rows.length===1?'':'s'} selected</b> · `+rows.map(r=>`${esc2(r.dataset.period)} ${fmtTime(r.querySelector('.ss-special-start').value)}–${fmtTime(r.querySelector('.ss-special-end').value)}`).join(' · ')};
  window.saveSchoolDay=async function(ev){
    ev.preventDefault();const form=ev.target,fd=new FormData(form),d=Object.fromEntries(fd);d.cancel_activities=fd.has('cancel_activities');d.alert_enabled=fd.has('alert_enabled');
    if(d.day_type==='Special Schedule'){
      d.special_periods=[...form.querySelectorAll('.ss-period-pick')].filter(r=>r.querySelector('.ss-special-check')?.checked).map((r,i)=>({source_cycle_day:Number(r.dataset.cycle),period_name:r.dataset.period,start_time:r.querySelector('.ss-special-start').value,end_time:r.querySelector('.ss-special-end').value,sort_order:i+1}));
      if(!d.special_periods.length){toastMsg('Choose at least one period for the special schedule');return}
    }
    try{await api('/api/school-calendar',{method:'POST',body:JSON.stringify(d)});closeModal();toastMsg(d.day_type==='Special Schedule'?'Custom special schedule saved':d.day_type==='School Closure'?'School closure published':'School calendar updated');if(typeof calendarPage==='function')calendarPage();setTimeout(()=>window.refreshSchoolClosureBanner?.(),50)}catch(err){toastMsg(err?.message||'Could not save calendar day')}
  };
})();
