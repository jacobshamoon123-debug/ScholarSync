/* ScholarSync Build 265 — Summer School Management Center */
(function(){
  const H=x=>typeof esc==='function'?esc(x):String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const dayNames={1:'Mon',2:'Tue',3:'Wed',4:'Thu',5:'Fri',6:'Sat',7:'Sun'};
  const dayLabel=v=>String(v||'').split(',').map(x=>dayNames[Number(x)]||'').filter(Boolean).join(' / ');
  const statusClass=s=>({Active:'success',Upcoming:'info',Full:'warn',Completed:'muted',Cancelled:'danger'}[s]||'');
  const fmtDate=d=>{if(!d)return '—';try{return new Date(d+'T12:00:00').toLocaleDateString([],{month:'short',day:'numeric',year:'numeric'})}catch(_){return d}};
  const fmtTime=t=>typeof ssFmtTime==='function'?ssFmtTime(t):t;

  function ssSummerStyles(){
    if(document.getElementById('ssSummer265Styles'))return;
    const st=document.createElement('style');st.id='ssSummer265Styles';st.textContent=`
    .summer-hero{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;padding:22px;border:1px solid var(--border);border-radius:18px;background:linear-gradient(135deg,color-mix(in srgb,#fdb022 13%,var(--panel)),var(--panel));margin-bottom:16px}
    .summer-hero h1{margin:0 0 4px}.summer-hero p{margin:0;color:var(--muted)}
    .summer-metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:16px}.summer-metric{border:1px solid var(--border);border-radius:14px;padding:15px;background:var(--panel)}.summer-metric small{display:block;color:var(--muted);font-weight:750}.summer-metric strong{display:block;font-size:26px;margin-top:5px}
    .summer-toolbar{display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap;padding:13px;border-bottom:1px solid var(--border)}.summer-toolbar .left{display:flex;gap:8px;flex-wrap:wrap;flex:1}.summer-toolbar input,.summer-toolbar select{min-width:180px}
    .summer-course-name{display:flex;align-items:center;gap:9px}.summer-sun{display:grid;place-items:center;width:34px;height:34px;border-radius:10px;background:#fff2c7}.summer-seatbar{height:6px;border-radius:999px;background:color-mix(in srgb,var(--border) 70%,transparent);overflow:hidden;margin-top:5px}.summer-seatbar>span{display:block;height:100%;background:currentColor}
    .summer-manager-head{display:grid;grid-template-columns:1fr auto;gap:16px;align-items:start}.summer-manager-head h2{margin:0}.summer-summary{display:flex;gap:7px;flex-wrap:wrap;margin-top:8px}.summer-tabs{display:flex;gap:5px;border-bottom:1px solid var(--border);margin:16px 0}.summer-tabs button{border:0;background:none;padding:10px 12px;font-weight:800;cursor:pointer;border-bottom:3px solid transparent}.summer-tabs button.active{border-color:#f59e0b}
    .summer-roster-row{display:grid;grid-template-columns:minmax(210px,1.4fr) 130px 120px auto;gap:12px;align-items:center;padding:11px 0;border-bottom:1px solid var(--border)}.summer-roster-row:last-child{border-bottom:0}
    .summer-search-results{max-height:430px;overflow:auto;display:grid;gap:7px}.summer-student-card{display:grid;grid-template-columns:1fr auto;gap:12px;align-items:center;border:1px solid var(--border);border-radius:12px;padding:11px}.summer-student-card.conflict{border-color:#fda29b;background:color-mix(in srgb,#fef3f2 80%,var(--panel))}
    .summer-schedule-preview{display:grid;gap:8px}.summer-meeting{display:flex;justify-content:space-between;gap:14px;padding:12px;border:1px solid var(--border);border-radius:12px}
    .summer-empty{padding:34px;text-align:center;color:var(--muted)}
    .summer-linked-note{padding:12px;border-radius:12px;border:1px solid #b2ddff;background:color-mix(in srgb,#eff8ff 80%,var(--panel));font-size:12px}
    .ss-summer-month-event{background:#fff2c7;color:#805a00;border-radius:5px;padding:2px 4px;font-size:10px;font-weight:800;margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    @media(max-width:900px){.summer-metrics{grid-template-columns:repeat(2,minmax(0,1fr))}.summer-roster-row{grid-template-columns:1fr}.summer-manager-head{grid-template-columns:1fr}}`;
    document.head.appendChild(st);
  }
  ssSummerStyles();

  let summerData={classes:[]},summerManager=null,summerSearchTimer=null;

  window.summerSchoolPage=async function(){
    await preload();summerData=await api('/api/summer-school');
    const list=summerData.classes||[];
    const active=list.filter(x=>x.effective_status==='Active'||x.effective_status==='Full').length;
    const students=list.reduce((n,x)=>n+Number(x.enrolled||0),0);
    const seats=list.reduce((n,x)=>n+Number(x.seats_remaining||0),0);
    const wait=list.reduce((n,x)=>n+Number(x.waitlisted||0),0);
    $('#content').innerHTML=`<div class="summer-hero"><div><div class="ss-summer-chip">SUMMER TERM</div><h1>Summer School</h1><p>Courses, rosters, scheduling, attendance and gradebooks in one place.</p></div><button class="btn primary" onclick="summerClassForm()">+ Create Summer Course</button></div>
    <div class="summer-metrics"><div class="summer-metric"><small>Active courses</small><strong>${active}</strong></div><div class="summer-metric"><small>Students enrolled</small><strong>${students}</strong></div><div class="summer-metric"><small>Seats available</small><strong>${seats}</strong></div><div class="summer-metric"><small>Waitlisted</small><strong>${wait}</strong></div></div>
    <div class="panel"><div class="summer-toolbar"><div class="left"><input id="summerSearch" class="control" placeholder="Search course, teacher or room" oninput="filterSummerCourses()"><select id="summerStatus" class="control" onchange="filterSummerCourses()"><option value="">All statuses</option>${['Upcoming','Active','Full','Completed','Cancelled'].map(x=>`<option>${x}</option>`).join('')}</select></div><span class="student-sub">${list.length} summer course${list.length===1?'':'s'}</span></div>
    <div class="table-wrap"><table><thead><tr><th>Course</th><th>Dates & Meeting Pattern</th><th>Teacher</th><th>Seats</th><th>Status</th><th>Actions</th></tr></thead><tbody id="summerCourseRows">${list.map(ssSummerCourseRow).join('')||'<tr><td colspan="6" class="summer-empty">No summer courses yet. Create one to begin.</td></tr>'}</tbody></table></div></div>`;
  };

  function ssSummerCourseRow(c){
    const cap=Math.max(1,Number(c.capacity||30)),en=Number(c.enrolled||0),pct=Math.min(100,en/cap*100);
    const search=H(`${c.course_code||''} ${c.name||''} ${c.teacher_name||''} ${c.room||''}`.toLowerCase());
    return `<tr class="summer-course-row" data-search="${search}" data-status="${H(c.effective_status||'')}"><td><div class="summer-course-name"><span class="summer-sun">☀️</span><div><b>${H(c.course_code||'')} ${H(c.name)}</b><span class="student-sub">${H(c.section||'Summer')}</span></div></div></td><td><b>${fmtDate(c.start_date)} – ${fmtDate(c.end_date)}</b><span class="student-sub">${H(dayLabel(c.meeting_days))} · ${fmtTime(c.start_time)}–${fmtTime(c.end_time)} · Room ${H(c.room||'—')}</span></td><td>${H(c.teacher_name||'Unassigned')}</td><td><b>${en} / ${cap}</b><span class="student-sub">${Number(c.seats_remaining||0)} available${Number(c.waitlisted||0)?` · ${c.waitlisted} waitlisted`:''}</span><div class="summer-seatbar"><span style="width:${pct}%"></span></div></td><td><span class="badge ${statusClass(c.effective_status)}">${H(c.effective_status)}</span></td><td><div class="row-actions"><button class="btn mini primary" onclick="summerCourseManager(${c.id})">Manage</button><button class="btn mini outline" onclick="summerClassForm(${c.id})">Edit</button></div></td></tr>`;
  }
  window.filterSummerCourses=function(){
    const q=String($('#summerSearch')?.value||'').toLowerCase(),st=$('#summerStatus')?.value||'';
    document.querySelectorAll('.summer-course-row').forEach(r=>r.style.display=(!q||r.dataset.search.includes(q))&&(!st||r.dataset.status===st)?'':'none');
  };

  window.summerClassForm=async function(id=0){
    let src=id?(summerData.classes||[]).find(x=>Number(x.id)===Number(id))||{}:{};
    const courses=cache.courses||[],staff=cache.staff||[];
    const selectedCourse=Number(src.course_id||courses[0]?.id||0);
    const eligible=staff.filter(x=>String(x.role||'').toLowerCase().includes('teacher')).filter(t=>{
      if(!selectedCourse)return true;try{const ids=JSON.parse(t.eligible_course_ids||'[]').map(Number);return ids.includes(selectedCourse)}catch(_){return true}
    });
    openModal(id?'Edit Summer Course':'Create Summer Course',`<form class="form summer-course-form" onsubmit="saveSummerClass(event,${id})">
      <label><span>Course</span><select name="course_id" required onchange="summerRefreshTeacherOptions(this.form)">${courses.map(c=>`<option value="${c.id}" ${Number(c.id)===selectedCourse?'selected':''}>${H(c.code)} ${H(c.name)}</option>`).join('')}</select></label>
      <label><span>Summer class name</span><input name="name" value="${H(src.name||'')}" placeholder="e.g. Honors Geometry" required></label>
      <label><span>Section</span><input name="section" value="${H(src.section||'Summer 1')}" placeholder="Summer 1"></label>
      <label><span>Teacher</span><select name="teacher_id"><option value="">Unassigned</option>${eligible.map(t=>`<option value="${t.id}" ${Number(t.id)===Number(src.teacher_id)?'selected':''}>${H(t.name)}</option>`).join('')}</select><small>Only teachers eligible for the selected course are shown.</small></label>
      <label><span>Start date</span><input name="start_date" type="date" value="${H(src.start_date||'')}" required></label><label><span>End date</span><input name="end_date" type="date" value="${H(src.end_date||'')}" required></label>
      <label><span>Start time</span><input name="start_time" type="time" value="${H(src.start_time||'08:00')}" required></label><label><span>End time</span><input name="end_time" type="time" value="${H(src.end_time||'09:00')}" required></label>
      <label><span>Room</span><input name="room" value="${H(src.room||'')}"></label><label><span>Capacity</span><input name="capacity" type="number" min="1" value="${Number(src.capacity||30)}"></label>
      <label class="full"><span>Meeting days</span><select name="meeting_days"><option value="1,2,3,4,5">Monday–Friday</option><option value="1,2,3,4">Monday–Thursday</option><option value="1,3,5">Monday / Wednesday / Friday</option><option value="2,4">Tuesday / Thursday</option></select></label>
      <label class="full"><span>Internal notes</span><textarea name="notes" rows="3">${H(src.notes||'')}</textarea></label>
      <div class="full summer-linked-note"><b>Integrated academic class:</b> saving creates/updates the linked ScholarSync class used by Gradebook, Attendance, Assignments and Class Pages. Dates/times above control when it appears on summer schedules.</div>
      <div class="full row-actions"><button type="button" class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn primary">${id?'Save Changes':'Create Summer Course'}</button></div>
    </form>`);
    const md=document.querySelector('#modal [name="meeting_days"]');if(md&&src.meeting_days)md.value=String(src.meeting_days);
  };

  window.summerRefreshTeacherOptions=function(form){
    const courseId=Number(form.course_id.value),sel=form.teacher_id,current=Number(sel.value||0);
    const teachers=(cache.staff||[]).filter(x=>String(x.role||'').toLowerCase().includes('teacher')).filter(t=>{try{return JSON.parse(t.eligible_course_ids||'[]').map(Number).includes(courseId)}catch(_){return true}});
    sel.innerHTML='<option value="">Unassigned</option>'+teachers.map(t=>`<option value="${t.id}" ${Number(t.id)===current?'selected':''}>${H(t.name)}</option>`).join('');
  };

  window.saveSummerClass=async function(ev,id=0){
    ev.preventDefault();const d=Object.fromEntries(new FormData(ev.target));if(id)d.id=id;
    try{await api('/api/summer-school/class',{method:'POST',body:JSON.stringify(d)});closeModal();toastMsg(id?'Summer course updated':'Summer course created');summerSchoolPage()}
    catch(err){toastMsg(err?.message||'Could not save summer course')}
  };

  window.summerCourseManager=async function(id,tab='overview'){
    summerManager=await api('/api/summer-school/detail?id='+id);const c=summerManager.class,r=summerManager.roster||[];
    const active=r.filter(x=>x.status==='Active'),wait=r.filter(x=>x.status==='Waitlisted'),dropped=r.filter(x=>x.status==='Dropped');
    openModal(`${H(c.course_code||'')} ${H(c.name)}`,`<div class="summer-manager-head"><div><div class="ss-summer-chip">SUMMER COURSE</div><h2>${H(c.name)}</h2><div class="summer-summary"><span class="badge ${statusClass(c.effective_status)}">${H(c.effective_status)}</span><span class="badge">${active.length}/${Number(c.capacity||30)} enrolled</span>${wait.length?`<span class="badge warn">${wait.length} waitlisted</span>`:''}</div></div><div class="row-actions"><button class="btn outline" onclick="closeModal();summerClassForm(${c.id})">Edit Course</button>${c.effective_status!=='Cancelled'?`<button class="btn danger" onclick="cancelSummerClass(${c.id})">Cancel Course</button>`:''}</div></div>
      <div class="summer-tabs"><button class="${tab==='overview'?'active':''}" onclick="summerCourseManager(${c.id},'overview')">Overview</button><button class="${tab==='roster'?'active':''}" onclick="summerCourseManager(${c.id},'roster')">Roster</button><button class="${tab==='schedule'?'active':''}" onclick="summerCourseManager(${c.id},'schedule')">Schedule</button><button onclick="summerOpenAcademicTool(${c.linked_class_id},'attendance')">Attendance</button><button onclick="summerOpenAcademicTool(${c.linked_class_id},'gradebook')">Gradebook</button></div>
      <div id="summerManagerBody">${summerManagerTab(c,r,tab)}</div>`);
  };

  function summerManagerTab(c,r,tab){
    if(tab==='roster'){
      return `<div class="page-actions" style="justify-content:flex-end;margin-bottom:10px"><button class="btn success" onclick="summerEnroll(${c.id})">+ Enroll Student</button></div><div class="panel"><div class="panel-body">${r.map(x=>`<div class="summer-roster-row"><div><b>${H(x.student_name)}</b><span class="student-sub">${H(x.student_number)} · Grade ${H(x.grade_level||'—')}</span></div><span class="badge ${x.status==='Waitlisted'?'warn':x.status==='Dropped'?'muted':'success'}">${H(x.status)}</span><span class="student-sub">${x.status==='Active'?'On roster':x.status==='Waitlisted'?'Waiting for seat':'Historical'}</span><div class="row-actions">${x.status!=='Dropped'?`<button class="btn mini danger" onclick="summerDropStudent(${c.id},${x.student_id})">${x.status==='Waitlisted'?'Remove':'Withdraw'}</button>`:''}</div></div>`).join('')||'<div class="summer-empty">No students enrolled yet.</div>'}</div></div>`;
    }
    if(tab==='schedule'){
      return `<div class="summer-schedule-preview"><div class="summer-meeting"><div><b>${fmtDate(c.start_date)} – ${fmtDate(c.end_date)}</b><span class="student-sub">${H(dayLabel(c.meeting_days))}</span></div><b>${fmtTime(c.start_time)}–${fmtTime(c.end_time)}</b></div><div class="summer-meeting"><div><b>Room ${H(c.room||'—')}</b><span class="student-sub">Assigned teacher: ${H(c.teacher_name||'Unassigned')}</span></div><span class="ss-summer-chip">Appears automatically on schedules</span></div><div class="summer-linked-note">Students and the assigned teacher see this class on every meeting date. The linked class powers Gradebook, Attendance, Assignments and Class Pages; summer dates and meeting days control schedule visibility.</div></div>`;
    }
    return `<div class="summer-metrics"><div class="summer-metric"><small>Enrolled</small><strong>${Number(c.enrolled||0)}</strong></div><div class="summer-metric"><small>Capacity</small><strong>${Number(c.capacity||30)}</strong></div><div class="summer-metric"><small>Available</small><strong>${Number(c.seats_remaining||0)}</strong></div><div class="summer-metric"><small>Waitlisted</small><strong>${Number(c.waitlisted||0)}</strong></div></div><div class="panel"><div class="panel-body"><div class="detail-line"><span>Teacher</span><b>${H(c.teacher_name||'Unassigned')}</b></div><div class="detail-line"><span>Meeting pattern</span><b>${H(dayLabel(c.meeting_days))} · ${fmtTime(c.start_time)}–${fmtTime(c.end_time)}</b></div><div class="detail-line"><span>Dates</span><b>${fmtDate(c.start_date)} – ${fmtDate(c.end_date)}</b></div><div class="detail-line"><span>Room</span><b>${H(c.room||'—')}</b></div><div class="detail-line"><span>Linked academic class</span><b>#${H(c.linked_class_id||'—')}</b></div></div></div>`;
  }

  window.summerEnroll=async function(cid){
    const c=(await api('/api/summer-school/detail?id='+cid)).class;
    openModal('Enroll Student',`<div class="callout"><b>${H(c.course_code||'')} ${H(c.name)}</b><br>${fmtDate(c.start_date)}–${fmtDate(c.end_date)} · ${H(dayLabel(c.meeting_days))} · ${fmtTime(c.start_time)}–${fmtTime(c.end_time)}<br><b>${Number(c.enrolled||0)} / ${Number(c.capacity||30)}</b> enrolled · ${Number(c.seats_remaining||0)} seats available${Number(c.seats_remaining||0)===0?' · New enrollments will be waitlisted':''}</div><div style="margin:12px 0"><input id="summerStudentSearch" class="control" style="width:100%" placeholder="Search student name, ID or grade" oninput="summerSearchStudents(${cid},this.value)"></div><div id="summerStudentResults" class="summer-search-results"><div class="summer-empty">Start typing to search students.</div></div>`);
    summerSearchStudents(cid,'');
  };
  window.summerSearchStudents=function(cid,q){
    clearTimeout(summerSearchTimer);summerSearchTimer=setTimeout(async()=>{
      const rows=await api(`/api/summer-school/students?class_id=${cid}&q=${encodeURIComponent(q||'')}`),box=$('#summerStudentResults');if(!box)return;
      box.innerHTML=(rows||[]).map(s=>`<div class="summer-student-card ${s.conflict?'conflict':''}"><div><b>${H(s.last_name)}, ${H(s.first_name)}</b><span class="student-sub">${H(s.student_number)} · Grade ${H(s.grade_level||'—')}${s.summer_status?' · '+H(s.summer_status):''}</span>${s.conflict?`<span class="student-sub" style="color:#b42318">Schedule conflict: ${H(s.conflict_name)}</span>`:''}</div><button class="btn mini ${s.conflict?'ghost':'success'}" ${s.conflict||s.summer_status==='Active'||s.summer_status==='Waitlisted'?'disabled':''} onclick="saveSummerEnroll(${cid},${s.id})">${s.summer_status==='Active'?'Enrolled':s.summer_status==='Waitlisted'?'Waitlisted':'Enroll'}</button></div>`).join('')||'<div class="summer-empty">No matching students.</div>';
    },120);
  };
  window.saveSummerEnroll=async function(cid,sid){
    try{const r=await api('/api/summer-school/enroll',{method:'POST',body:JSON.stringify({class_id:cid,student_id:sid})});closeModal();toastMsg(r.status==='Waitlisted'?'Course is full — student added to waitlist':'Student enrolled in Summer School');summerCourseManager(cid,'roster')}
    catch(err){toastMsg(err?.message||'Could not enroll student')}
  };
  window.summerDropStudent=async function(cid,sid){
    if(!confirm('Withdraw/remove this student from the summer course? Their historical records will be preserved.'))return;
    await api('/api/summer-school/unenroll',{method:'POST',body:JSON.stringify({class_id:cid,student_id:sid})});toastMsg('Summer enrollment updated');summerCourseManager(cid,'roster');
  };
  window.cancelSummerClass=async function(cid){
    if(!confirm('Cancel this summer course? It will stop appearing on future schedules, but historical records remain.'))return;
    await api('/api/summer-school/cancel',{method:'POST',body:JSON.stringify({class_id:cid})});closeModal();toastMsg('Summer course cancelled');summerSchoolPage();
  };
  window.summerOpenAcademicTool=function(linked,tool){
    closeModal();if(!linked)return toastMsg('This summer course is not linked yet.');
    showPage(tool);setTimeout(()=>{
      if(tool==='gradebook'&&typeof openGrade==='function')openGrade(Number(linked),document.querySelector(`.class-row[data-id="${linked}"]`));
      if(tool==='attendance'&&typeof openAttendance==='function')openAttendance(Number(linked),document.querySelector(`.class-row[data-id="${linked}"]`));
    },250);
  };

  /* Summer meetings in student Month view, not only Day view. */
  if(typeof window.ssShowScheduleMonth==='function'){
    const _month265=window.ssShowScheduleMonth;
    window.ssShowScheduleMonth=async function(studentId,date){
      await _month265(studentId,date);
      const month=(window.ssScheduleDate||date||ssTodayISO()).slice(0,7);
      const days=await api(`/api/schedule/month?student_id=${studentId}&date=${month}-01`);
      const buttons=[...document.querySelectorAll('#studentScheduleView .ss-month-day')];
      buttons.forEach((btn,i)=>{
        const d=days[i];if(!d||!(d.summer||[]).length)return;
        (d.summer||[]).slice(0,2).forEach(c=>{const x=document.createElement('div');x.className='ss-summer-month-event';x.textContent=`☀️ ${c.course_code||c.name}`;btn.appendChild(x)});
      });
    };
  }

  /* Whole-year schedule keeps admin-defined school-year boundaries, but also exposes
     the summer months when this student is actually enrolled. */
  window.openYearSchedule=async function(studentId){
    const [w,summer]=await Promise.all([api('/api/school-year-window?date='+ssTodayISO()),api('/api/summer-school')]);
    const start=new Date(w.start+'T12:00:00'),end=new Date(w.end+'T12:00:00'),months=[],seen=new Set();let cur=new Date(start.getFullYear(),start.getMonth(),1,12);
    while(cur<=end){const key=`${cur.getFullYear()}-${String(cur.getMonth()+1).padStart(2,'0')}`;months.push({date:key+'-01',label:cur.toLocaleDateString([],{month:'long',year:'numeric'}),summer:false});seen.add(key);cur.setMonth(cur.getMonth()+1)}
    (summer.classes||[]).forEach(c=>{let d=new Date(c.start_date+'T12:00:00'),e2=new Date(c.end_date+'T12:00:00');d=new Date(d.getFullYear(),d.getMonth(),1,12);while(d<=e2){const key=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;if(!seen.has(key)){months.push({date:key+'-01',label:d.toLocaleDateString([],{month:'long',year:'numeric'}),summer:true});seen.add(key)}d.setMonth(d.getMonth()+1)}});
    months.sort((a,b)=>a.date.localeCompare(b.date));
    openModal('School Year & Summer Schedule',`<div class="callout"><b>Regular School Year</b><br>${w.start} through ${w.end}. Summer months appear below only when this student has an active Summer School enrollment.</div><div class="activity-grid" style="margin-top:12px">${months.map(m=>`<button class="activity-card" style="text-align:left;cursor:pointer" onclick="closeModal();window.ssScheduleDate='${m.date}';ssRenderScheduleShell(${studentId},'month')"><h3>${m.summer?'☀️ ':''}${m.label}</h3><p>${m.summer?'Summer School schedule':'Open month schedule'}</p></button>`).join('')}</div>`);
  };


  /* Teacher School-Year view also includes every assigned Summer School course. */
  if(typeof window.teacherScheduleYear==='function'){
    window.teacherScheduleYear=async function(){
      const [w,summer]=await Promise.all([api('/api/school-year-window?date='+ssTodayISO()),api('/api/summer-school')]);
      const classes=summer.classes||[];
      $('#teacherScheduleView').innerHTML=`<div class="panel"><div class="panel-head"><div><h3>Teaching Year</h3><small>Regular school: ${H(w.start)} through ${H(w.end)}</small></div></div><div class="panel-body"><div class="ss-term-note">Use Month view for the full instructional calendar. Assigned Summer School courses are included below and on every date they meet.</div>${classes.length?`<div class="activity-grid" style="margin-top:14px">${classes.map(c=>`<button class="activity-card" style="text-align:left;cursor:pointer" onclick="teacherScheduleMonth('${String(c.start_date).slice(0,7)}-01')"><div class="ss-summer-chip">SUMMER</div><h3>${H(c.course_code||'')} ${H(c.name)}</h3><p>${fmtDate(c.start_date)} – ${fmtDate(c.end_date)}<br>${H(dayLabel(c.meeting_days))} · ${fmtTime(c.start_time)}–${fmtTime(c.end_time)} · Room ${H(c.room||'—')}</p></button>`).join('')}</div>`:'<div class="summer-empty">No Summer School courses assigned.</div>'}</div></div>`;
    };
  }

})();