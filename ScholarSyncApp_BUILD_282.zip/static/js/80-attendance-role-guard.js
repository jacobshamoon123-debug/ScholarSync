/* STUDENT/PARENT ATTENDANCE PERMISSION FIX
   Students and parents get read-only attendance history. The roster editor is staff-only. */
(function(){
  async function studentAttendanceReadOnly(studentId){
    activePage='attendance'; ssActiveNav('attendance');
    const sid=Number(studentId||user?.student_id||0);
    if(!sid){
      $('#content').innerHTML=`<div class="pagebar"><div><h1>Attendance</h1><p>Read-only attendance history.</p></div></div><div class="panel"><div class="empty-modern">No student is linked to this account.</div></div>`;
      return;
    }
    const d=await api('/api/student-profile?id='+sid);
    const list=d.attendance||[];
    const norm=x=>normalizeAttendanceStatus(x.status);
    const present=list.filter(x=>norm(x)==='P').length;
    const tardy=list.filter(x=>['TE','TU'].includes(norm(x))).length;
    const absent=list.filter(x=>['AE','AU'].includes(norm(x))).length;
    $('#content').innerHTML=`
      <div class="pagebar"><div><h1>${role==='parent'?'Attendance':'My Attendance'}</h1><p>${esc(d.student?.name||'Student')} · Read-only attendance record</p></div></div>
      <div class="metric-strip">
        <div class="metric"><small>Attendance rate</small><strong>${d.metrics?.attendance_rate==null?'—':d.metrics.attendance_rate+'%'}</strong></div>
        <div class="metric"><small>Present</small><strong>${present}</strong></div>
        <div class="metric"><small>Tardy</small><strong>${tardy}</strong></div>
        <div class="metric"><small>Absent</small><strong>${absent}</strong></div>
      </div>
      <div class="panel"><div class="panel-head"><div><h3>Attendance History</h3><small>Teachers and administrators record attendance; students cannot edit it.</small></div></div>
      <div class="table-wrap"><table><thead><tr><th>Date</th><th>Class</th><th>Period</th><th>Status</th><th>Minutes tardy</th><th>Note</th></tr></thead><tbody>
      ${list.map(a=>{const code=norm(a);return `<tr><td>${esc(a.date)}</td><td>${esc(a.class_name||'')}</td><td>${esc(a.period||'')}</td><td><span class="badge ${['AE','AU'].includes(code)?'red':['TE','TU'].includes(code)?'warn':''}">${esc(attendanceName(code))}</span></td><td>${['TE','TU'].includes(code)?esc(a.minutes_late||0):'—'}</td><td>${esc(a.note||'')}</td></tr>`}).join('')||'<tr><td colspan="6" class="empty">No attendance records yet.</td></tr>'}
      </tbody></table></div></div>`;
  }
  window.studentAttendanceReadOnly=studentAttendanceReadOnly;

  // Staff-only roster editor. Student/parent navigation is always read-only.
  const staffAttendanceEditor=window.attendance;
  window.attendance=async function(){
    if(role==='student') return studentAttendanceReadOnly(user?.student_id);
    if(role==='parent'){
      const sid=cache.students?.[0]?.id||user?.student_id||0;
      return studentAttendanceReadOnly(sid);
    }
    if(!['admin','teacher'].includes(role)){
      $('#content').innerHTML=`<div class="pagebar"><div><h1>Attendance</h1></div></div><div class="error">You do not have permission to manage attendance.</div>`;
      return;
    }
    return staffAttendanceEditor();
  };

  // Centralized route registry replaces chained showPage wrappers.
  ssRegisterPageRoute('attendance',()=>window.attendance(),['admin','teacher','student','parent']);
})();
