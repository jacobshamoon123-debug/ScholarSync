/* ScholarSync Substitute Teacher Mode */
(function(){
  if(!window.NAV) return;
  NAV.substitute=[['SUBSTITUTE','dashboard','⌂','Today’s Coverage'],['SUBSTITUTE','substitutes','🧑‍🏫','Coverage Details']];
  ssAddNav('admin','OPERATIONS','substitutes','🧑‍🏫','Substitute Coverage','users');
  ssAddNav('teacher','TEACHING','substitutes','🧑‍🏫','Substitute Plans','learning');
  const oldDash=window.dashboard;
  window.dashboard=function(){ return role==='substitute'?substituteDashboard():oldDash(); };
  ssRegisterPageRoute('substitutes',()=>{ $('#crumb').textContent=role==='admin'?'Substitute Coverage':role==='teacher'?'Substitute Plans':'Coverage Details';return substituteCenter(); },['admin','teacher','substitute']);
  // Emergency is read-only for substitutes through their own dashboard instructions;
  // do not grant the broader emergency accountability APIs to this temporary role.

  const e=(v)=>esc(v==null?'':String(v));
  let subDate='', subDay=null;
  async function schoolDate(){try{const t=await api('/api/time-context');if(t&&t.date)return t.date}catch(_e){}return (typeof ssTodayISO==='function'?ssTodayISO():(()=>{const d=new Date(),y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');return `${y}-${m}-${day}`})())}
  function styles(){if($('#ssSubStyle'))return;const x=document.createElement('style');x.id='ssSubStyle';x.textContent=`.sub-hero{background:linear-gradient(135deg,#17283c,#31516d);color:#fff;border-radius:16px;padding:20px}.sub-hero h1{margin:0 0 5px}.sub-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(290px,1fr));gap:14px;margin-top:15px}.sub-class{background:#fff;border:1px solid var(--line);border-radius:13px;padding:15px}.sub-class h3{margin:3px 0}.sub-meta{display:flex;gap:7px;flex-wrap:wrap;margin:9px 0}.sub-plan{white-space:pre-wrap;line-height:1.55;background:#f7f9fb;border:1px solid var(--line);border-radius:10px;padding:12px;margin-top:10px}.sub-roster-row{display:grid;grid-template-columns:minmax(190px,1fr) 160px 90px minmax(130px,1fr);gap:8px;align-items:center;padding:9px 0;border-bottom:1px solid var(--line)}.sub-roster-row select,.sub-roster-row input{width:100%}.sub-assignment{border:1px solid var(--line);border-radius:12px;padding:14px;margin-bottom:10px;background:#fff}.sub-assignment.cancelled,.sub-assignment.expired{opacity:.62}.sub-status{font-weight:850}.sub-status.Active{color:#17683a}.sub-status.Upcoming{color:#225fa9}.sub-status.Expired,.sub-status.Cancelled{color:#687684}@media(max-width:760px){.sub-roster-row{grid-template-columns:1fr}}`;document.head.appendChild(x)}

  window.substituteDashboard=async function(){styles();subDate=await schoolDate();return renderSubDay(subDate,true)};
  window.substituteCenter=async function(){styles();if(role==='admin')return adminSubCenter();if(role==='teacher')return teacherSubCenter();if(!subDate)subDate=await schoolDate();return renderSubDay(subDate,false)};
  window.changeSubDate=async function(v){subDate=v||await schoolDate();renderSubDay(subDate,false)};
  async function renderSubDay(day,hero){subDay=await api('/api/substitute/day?date='+encodeURIComponent(day));const aa=subDay.assignments||[];$('#content').innerHTML=`${hero?`<div class="sub-hero"><small>SUBSTITUTE TEACHER PORTAL</small><h1>${aa.length?'Your coverage for today':'No coverage assigned today'}</h1><div>${e(day)}</div></div>`:`<div class="pagebar"><div><h1>Coverage Details</h1><p>Your access is limited to active substitute assignments.</p></div><input class="control" type="date" value="${e(day)}" onchange="changeSubDate(this.value)"></div>`}${aa.map(a=>`<section class="panel" style="margin-top:15px"><div class="panel-head"><div><h3>Covering for ${e(a.teacher_name)}</h3><small>${e(a.start_date)} through ${e(a.end_date)}${a.reason?' · '+e(a.reason):''}</small></div></div><div class="panel-body"><div class="sub-grid">${(a.classes||[]).map(c=>subClassCard(a,c,day)).join('')||'<div class="empty-modern">No classes meet on this selected date.</div>'}</div></div></section>`).join('')||`<div class="panel" style="margin-top:16px"><div class="panel-body"><div class="empty-cta"><h3>No active substitute assignment</h3><p>Only an administrator can assign coverage. Access automatically expires outside the assignment dates.</p></div></div></div>`}`}
  function subClassCard(a,c,day){return `<article class="sub-class"><span class="badge">Period ${e(c.period||'—')}</span><h3>${e(c.name)}</h3><div class="student-sub">${e(c.course_code||'')} · Room ${e(c.room||'—')}</div><div class="sub-meta"><span class="badge">${c.enrolled||0} students</span><span class="badge ${Number(c.attendance_completed)?'green':''}">${Number(c.attendance_completed)?'Attendance complete':(c.attendance_marked||0)+' marked'}</span></div>${c.lesson_plan?`<div class="sub-plan"><b>Lesson plan</b><br>${e(c.lesson_plan)}</div>`:''}${c.teacher_notes?`<div class="callout"><b>Teacher notes</b><br>${e(c.teacher_notes)}</div>`:''}<div class="row-actions" style="margin-top:12px"><button class="btn primary" onclick="openSubClass(${a.id},${c.id},'${e(day)}')">Open Class</button><button class="btn outline" onclick="subNotesForm(${a.id},${c.id},'${e(day)}','${e(c.substitute_notes||'').replace(/'/g,'&#39;')}')">Leave Notes</button></div></article>`}

  window.openSubClass=async function(aid,cid,day){const d=await api(`/api/substitute/class?assignment_id=${aid}&class_id=${cid}&date=${encodeURIComponent(day)}`);const cov=d.coverage||{},chart=d.seating_chart||{};$('#content').innerHTML=`<div class="pagebar"><div><button class="btn ghost" onclick="renderSubDay('${e(day)}',false)">← Coverage</button><h1>${e(d.class.name)}</h1><p>Period ${e(d.class.period||'—')} · Room ${e(d.class.room||'—')}</p></div><div class="page-actions"><button class="btn outline" onclick="showSubSeating(${aid},${cid},'${e(day)}')">Seating Chart</button>${role==='substitute'||role==='admin'?`<button class="btn success" onclick="saveSubAttendance(${aid},${cid},'${e(day)}')">Save Attendance</button>`:''}</div></div>${cov.lesson_plan?`<div class="panel"><div class="panel-head"><h3>Lesson Plan</h3></div><div class="panel-body"><div class="sub-plan">${e(cov.lesson_plan)}</div>${cov.lesson_links?`<div class="callout"><b>Links / resources</b><br>${e(cov.lesson_links)}</div>`:''}${cov.teacher_notes?`<div class="callout"><b>Teacher notes</b><br>${e(cov.teacher_notes)}</div>`:''}</div></div>`:''}<div class="panel" style="margin-top:14px"><div class="panel-head"><h3>Roster & Attendance</h3><small>${e(day)}</small></div><div class="panel-body" id="subRoster">${(d.roster||[]).map(r=>`<div class="sub-roster-row"><div><b>${e(r.student_name)}</b><span class="student-sub">${e(r.student_number)} · Grade ${e(r.grade||'—')}</span></div><select class="control sub-att" data-sid="${r.student_id}" ${role==='teacher'?'disabled':''}><option value="">Unmarked</option>${[['P','Present'],['TE','Tardy Excused'],['TU','Tardy Unexcused'],['AE','Absent Excused'],['AU','Absent Unexcused'],['SA','School Activity'],['N','Nurse']].map(([v,l])=>`<option value="${v}" ${r.attendance_status===v?'selected':''}>${l}</option>`).join('')}</select><input class="control sub-min" data-sid="${r.student_id}" type="number" min="0" value="${Number(r.minutes_late||0)}" ${role==='teacher'?'disabled':''} title="Minutes tardy"><input class="control sub-note" data-sid="${r.student_id}" value="${e(r.attendance_note||'')}" ${role==='teacher'?'disabled':''} placeholder="Note"></div>`).join('')}</div></div>${cov.substitute_notes?`<div class="panel" style="margin-top:14px"><div class="panel-head"><h3>Substitute Notes</h3></div><div class="panel-body"><div class="sub-plan">${e(cov.substitute_notes)}</div></div></div>`:''}`;window._subClassData=d};
  window.saveSubAttendance=async function(aid,cid,day){const rec=$$('.sub-att').map(s=>({student_id:+s.dataset.sid,status:s.value,minutes_late:+($(`.sub-min[data-sid="${s.dataset.sid}"]`)?.value||0),note:$(`.sub-note[data-sid="${s.dataset.sid}"]`)?.value||''}));await api('/api/substitute/attendance',{method:'POST',body:JSON.stringify({assignment_id:aid,class_id:cid,date:day,records:rec})});toastMsg('Attendance saved');openSubClass(aid,cid,day)};
  window.showSubSeating=function(aid,cid,day){const d=window._subClassData||{},chart=d.seating_chart||{},roster=d.roster||[];let layout=chart.layout||[];const names=Object.fromEntries(roster.map(r=>[r.student_id,r.student_name]));openModal('Seating Chart',`<div class="seat-grid" style="grid-template-columns:repeat(${Number(chart.columns_count||6)},minmax(90px,1fr))">${layout.length?layout.map((x,i)=>`<div class="seat-card"><span class="seat-number">${i+1}</span><b>${e(names[x.student_id||x.studentId]||x.name||'Empty')}</b></div>`).join(''):roster.map((r,i)=>`<div class="seat-card"><span class="seat-number">${i+1}</span><b>${e(r.student_name)}</b></div>`).join('')}</div>`)};
  window.subNotesForm=function(aid,cid,day,current=''){openModal('Substitute Notes',`<form class="form" onsubmit="saveSubNotes(event,${aid},${cid},'${e(day)}')"><label class="full"><span>Notes for the regular teacher</span><textarea name="substitute_notes" rows="7" placeholder="What was completed? Student concerns? Anything the teacher should know?">${e(current)}</textarea></label><div class="full"><button class="btn primary">Save Notes</button></div></form>`)};
  window.saveSubNotes=async function(ev,aid,cid,day){ev.preventDefault();await api('/api/substitute/coverage',{method:'POST',body:JSON.stringify({assignment_id:aid,class_id:cid,date:day,substitute_notes:ev.target.substitute_notes.value})});closeModal();toastMsg('Notes saved');renderSubDay(day,false)};

  async function adminSubCenter(){
    styles();
    const [as,staff,reqs]=await Promise.all([
      api('/api/substitute/assignments'),
      api('/api/staff'),
      api('/api/substitute/requests')
    ]);
    const subs=(staff||[]).filter(x=>['substitute','sub','substitute teacher'].includes(String(x.role||'').toLowerCase())||String(x.role||'').toLowerCase().includes('teacher'));
    const pending=(reqs||[]).filter(x=>String(x.status||'Pending')==='Pending');
    const reviewed=(reqs||[]).filter(x=>String(x.status||'Pending')!=='Pending').slice(0,20);
    window._subStaff=staff;
    window._subRequests=reqs;

    const requestCards=pending.map(r=>{
      let ids=[];try{ids=JSON.parse(r.selected_class_ids||'[]')}catch(_){}
      const scope=r.scope==='selected'?`${ids.length} selected class${ids.length===1?'':'es'}`:'All classes that day';
      return `<div class="sub-assignment" style="border-left:4px solid #d97706">
        <div class="pass-head">
          <div><b>${e(r.teacher_name||'Teacher')}</b><span class="student-sub">${e(r.request_date)} · ${e(r.reason||'Coverage request')} · ${e(scope)}</span></div>
          <span class="badge">Pending</span>
        </div>
        ${r.notes?`<div class="callout" style="margin-top:10px">${e(r.notes)}</div>`:''}
        <div class="row-actions" style="margin-top:12px">
          <button class="btn mini primary" onclick="openAdminSubRequest(${r.id})">Review & Assign</button>
          <button class="btn mini danger" onclick="denyAdminSubRequest(${r.id})">Deny</button>
        </div>
      </div>`;
    }).join('')||'<div class="empty-modern">No pending substitute requests.</div>';

    const history=reviewed.map(r=>`<div class="sub-assignment">
      <div class="pass-head"><div><b>${e(r.teacher_name||'Teacher')}</b><span class="student-sub">${e(r.request_date)} · ${e(r.reason||'Coverage request')}</span></div><span class="badge">${e(r.status)}</span></div>
      ${r.admin_note?`<div class="student-sub" style="margin-top:7px">Admin note: ${e(r.admin_note)}</div>`:''}
    </div>`).join('')||'<div class="empty-modern">No reviewed requests yet.</div>';

    $('#content').innerHTML=`<div class="pagebar">
      <div><h1>Substitute Coverage</h1><p>Review teacher requests, assign coverage, or create coverage directly.</p></div>
      <div class="page-actions"><button class="btn outline" onclick="newSubStaff()">+ Add Substitute Staff</button><button class="btn success" onclick="newSubAssignment()">+ Assign Without Request</button></div>
    </div>
    <div class="metric-strip">
      <div class="metric"><small>Pending requests</small><strong>${pending.length}</strong></div>
      <div class="metric"><small>Active / upcoming coverage</small><strong>${(as||[]).filter(x=>['Active','Upcoming'].includes(x.effective_status)).length}</strong></div>
      <div class="metric"><small>Available covering staff</small><strong>${subs.length}</strong></div>
    </div>
    <div class="panel"><div class="panel-head"><div><h3>Teacher Coverage Requests</h3><small>Approve and assign a substitute/available teacher, or deny the request.</small></div></div><div class="panel-body">${requestCards}</div></div>
    <div class="panel"><div class="panel-head"><h3>Coverage Assignments</h3></div><div class="panel-body">${(as||[]).map(a=>`<div class="sub-assignment ${e((a.effective_status||a.status).toLowerCase())}"><div class="pass-head"><div><b>${e(a.substitute_name)}</b> covering <b>${e(a.teacher_name)}</b><span class="student-sub">${e(a.start_date)} → ${e(a.end_date)}${a.reason?' · '+e(a.reason):''}${a.coverage_mode==='selected'?' · Selected periods':''}</span></div><span class="sub-status ${e(a.effective_status||a.status)}">${e(a.effective_status||a.status)}</span></div><div class="row-actions" style="margin-top:10px"><button class="btn mini outline" onclick="adminSubDay(${a.id},'${e(a.start_date)}')">Details</button>${a.status==='Active'?`<button class="btn mini danger" onclick="cancelSub(${a.id})">Cancel</button>`:''}</div></div>`).join('')||'<div class="empty-modern">No substitute coverage assignments yet.</div>'}</div></div>
    <div class="panel"><div class="panel-head"><h3>Request History</h3></div><div class="panel-body">${history}</div></div>`;
  }
  window.newSubStaff=function(){openModal('Add Substitute Teacher',`<form class="form" onsubmit="createSubStaff(event)"><label><span>Name *</span><input name="name" required></label><label><span>Employee number</span><input name="employee_number"></label><label><span>Email</span><input name="email" type="email"></label><label><span>Phone</span><input name="phone"></label><label><span>School</span><input name="school"></label><div class="full callout">This creates an active staff member with the Substitute Teacher role so they can be assigned coverage and use the Substitute portal.</div><div class="full"><button class="btn primary">Create Substitute</button></div></form>`)};
  window.createSubStaff=async function(ev){ev.preventDefault();const d=Object.fromEntries(new FormData(ev.target));d.role='Substitute Teacher';d.status='Active';await api('/api/staff',{method:'POST',body:JSON.stringify(d)});closeModal();toastMsg('Substitute teacher added');adminSubCenter()};
  window.newSubAssignment=async function(){const staff=window._subStaff||await api('/api/staff'),subs=staff.filter(x=>['substitute','sub','substitute teacher'].includes(String(x.role||'').toLowerCase())||String(x.role||'').toLowerCase().includes('teacher')),teachers=staff.filter(x=>String(x.role||'').toLowerCase().includes('teacher'));openModal('Assign Substitute',`<form class="form" onsubmit="createSubAssignment(event)"><label><span>Substitute *</span><select name="substitute_staff_id" required><option value="">Choose substitute</option>${subs.map(x=>`<option value="${x.id}">${e(x.name)}${String(x.role||'').toLowerCase().includes('teacher')&&!['substitute','sub','substitute teacher'].includes(String(x.role||'').toLowerCase())?' — Teacher':''}</option>`).join('')}</select></label><label><span>Teacher being covered *</span><select name="teacher_staff_id" required><option value="">Choose teacher</option>${teachers.map(x=>`<option value="${x.id}">${e(x.name)}</option>`).join('')}</select></label><label><span>Start date *</span><input name="start_date" type="date" required></label><label><span>End date *</span><input name="end_date" type="date" required></label><label class="full"><span>Reason</span><input name="reason" placeholder="Illness, conference, professional development..."></label><label class="full"><span>Administrative notes</span><textarea name="admin_notes" rows="3"></textarea></label><div class="full callout">Regular teachers can cover classes too. ScholarSync checks their own schedule and blocks conflicting coverage. Coverage access works only for the assigned dates/classes.</div><div class="full"><button class="btn primary">Create Coverage</button></div></form>`)};
  window.createSubAssignment=async function(ev){ev.preventDefault();const d=Object.fromEntries(new FormData(ev.target));await api('/api/substitute/assignments',{method:'POST',body:JSON.stringify(d)});closeModal();toastMsg('Substitute assigned');adminSubCenter()};
  window.cancelSub=async function(id){if(!confirm('Cancel this substitute assignment? Access will stop immediately.'))return;await api('/api/substitute/assignments',{method:'POST',body:JSON.stringify({action:'cancel',id})});toastMsg('Coverage cancelled');adminSubCenter()};
  window.adminSubDay=async function(id,day){const a=await api('/api/substitute/assignments?id='+id);subDate=day;const d=await api('/api/substitute/day?date='+encodeURIComponent(day));const match=(d.assignments||[]).find(x=>x.id===id);if(!match)return toastMsg('No active coverage on this date');$('#content').innerHTML=`<div class="pagebar"><div><button class="btn ghost" onclick="adminSubCenter()">← Coverage</button><h1>${e(a.substitute_name)} → ${e(a.teacher_name)}</h1><p>${e(day)}</p></div><input class="control" type="date" min="${e(a.start_date)}" max="${e(a.end_date)}" value="${e(day)}" onchange="adminSubDay(${id},this.value)"></div><div class="sub-grid">${(match.classes||[]).map(c=>`<article class="sub-class"><span class="badge">Period ${e(c.period||'—')}</span><h3>${e(c.name)}</h3><div class="student-sub">Room ${e(c.room||'—')}</div><div class="sub-meta"><span class="badge">${c.enrolled||0} students</span><span class="badge">${Number(c.attendance_completed)?'Attendance complete':'Attendance pending'}</span></div><div class="row-actions"><button class="btn outline" onclick="subPlanForm(${id},${c.id},'${e(day)}')">Lesson Plan</button><button class="btn primary" onclick="openSubClass(${id},${c.id},'${e(day)}')">View Class</button></div></article>`).join('')}</div>`};


  window.openAdminSubRequest=async function(id){
    const req=(window._subRequests||[]).find(x=>Number(x.id)===Number(id)) || (await api('/api/substitute/requests')).find(x=>Number(x.id)===Number(id));
    if(!req)return toastMsg('Request not found');
    const staff=window._subStaff||await api('/api/staff');
    const candidates=(staff||[]).filter(x=>['substitute','sub','substitute teacher'].includes(String(x.role||'').toLowerCase())||String(x.role||'').toLowerCase().includes('teacher'));
    const classes=await api('/api/substitute/request/classes?teacher_id='+encodeURIComponent(req.teacher_staff_id)+'&date='+encodeURIComponent(req.request_date));
    let selected=[];try{selected=JSON.parse(req.selected_class_ids||'[]').map(Number)}catch(_){}
    const chosen=req.scope==='selected'?(classes||[]).filter(c=>selected.includes(Number(c.id))):(classes||[]);
    const classHtml=chosen.map(c=>`<div class="sub-period-card" style="cursor:default"><span class="sub-period-main"><b>Period ${e(c.period||'—')} · ${e(c.name||c.course_name||'Class')}</b><small>${e(c.start_time||'')}–${e(c.end_time||'')}${c.room?' · Room '+e(c.room):''}</small></span></div>`).join('')||'<div class="empty-modern">No classes found for this request.</div>';

    openModal('Review Substitute Request',`<div class="sub-request-review">
      <div class="callout"><b>${e(req.teacher_name)}</b> requested coverage for <b>${e(req.request_date)}</b><br>${e(req.reason||'No reason provided')}${req.notes?`<br><span class="student-sub">${e(req.notes)}</span>`:''}</div>
      <div style="margin:14px 0"><b>Classes needing coverage</b><div class="sub-picker-list" style="margin-top:8px">${classHtml}</div></div>
      <form class="form" onsubmit="assignAdminSubRequest(event,${req.id})">
        <label class="full"><span>Assign substitute / available teacher *</span><select id="adminReqCandidate" name="substitute_staff_id" required onchange="checkAdminRequestCandidate(${req.id})"><option value="">Choose staff member</option>${candidates.map(x=>`<option value="${x.id}">${e(x.name)}${String(x.role||'').toLowerCase().includes('teacher')&&!['substitute','sub','substitute teacher'].includes(String(x.role||'').toLowerCase())?' — Teacher':''}</option>`).join('')}</select></label>
        <div class="full" id="adminReqAvailability"></div>
        <label class="full"><span>Admin note (optional)</span><textarea name="admin_note" rows="3" placeholder="Message shown to the requesting teacher"></textarea></label>
        <div class="full row-actions"><button type="button" class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn primary">Approve & Assign</button></div>
      </form>
    </div>`);
  };

  window.checkAdminRequestCandidate=async function(id){
    const req=(window._subRequests||[]).find(x=>Number(x.id)===Number(id));
    const candidate=document.getElementById('adminReqCandidate')?.value;
    const box=document.getElementById('adminReqAvailability');
    if(!req||!candidate||!box){if(box)box.innerHTML='';return;}
    let ids=[];try{ids=JSON.parse(req.selected_class_ids||'[]')}catch(_){}
    const q=new URLSearchParams({
      substitute_staff_id:candidate,
      teacher_staff_id:req.teacher_staff_id,
      date:req.request_date,
      coverage_mode:req.scope==='selected'?'selected':'all',
      class_ids:req.scope==='selected'?ids.join(','):''
    });
    try{
      const d=await api('/api/substitute/availability?'+q.toString());
      box.innerHTML=d.available?'<div class="callout" style="border-left-color:#16a34a"><b>Available</b> — no class conflict.</div>':`<div class="callout" style="border-left-color:#dc2626"><b>Unavailable</b> — ${e(d.reason||'This teacher has a class at that time.')}</div>`;
    }catch(err){box.innerHTML=`<div class="callout">${e(err?.message||'Could not check availability')}</div>`;}
  };

  window.assignAdminSubRequest=async function(ev,id){
    ev.preventDefault();
    const d=Object.fromEntries(new FormData(ev.target));
    d.request_id=id;
    try{
      await api('/api/substitute/request/assign',{method:'POST',body:JSON.stringify(d)});
      closeModal();toastMsg('Request approved and coverage assigned');adminSubCenter();
    }catch(err){toastMsg(err?.message||'Could not assign coverage');}
  };

  window.denyAdminSubRequest=function(id){
    openModal('Deny Substitute Request',`<form class="form" onsubmit="saveDeniedSubRequest(event,${id})"><div class="full callout">The teacher will see that this request was denied.</div><label class="full"><span>Reason / admin note (optional)</span><textarea name="admin_note" rows="4" placeholder="Explain why coverage was denied or ask the teacher to contact administration."></textarea></label><div class="full row-actions"><button type="button" class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn danger">Deny Request</button></div></form>`);
  };

  window.saveDeniedSubRequest=async function(ev,id){
    ev.preventDefault();
    const d=Object.fromEntries(new FormData(ev.target));d.request_id=id;
    try{
      await api('/api/substitute/request/deny',{method:'POST',body:JSON.stringify(d)});
      closeModal();toastMsg('Substitute request denied');adminSubCenter();
    }catch(err){toastMsg(err?.message||'Could not deny request');}
  };

  async function teacherSubCenter(){
    const as=await api('/api/substitute/assignments');
    const reqs=await api('/api/substitute/requests');
    const sid=Number((window.currentUser||window.USER||{}).staff_id||0);
    $('#content').innerHTML=`<div class="pagebar"><div><h1>Substitute Coverage</h1><p>Request coverage for a specific date/period, prepare plans for your absence, or open classes you are covering.</p></div><button class="btn primary" onclick="newTeacherSubRequest()">+ Request Substitute</button></div>
    <div class="panel"><div class="panel-head"><h3>My Coverage Requests</h3></div><div class="panel-body">${(reqs||[]).map(r=>`<div class="sub-assignment"><div class="pass-head"><div><b>${e(r.request_date)}</b><span class="student-sub">${e(r.reason||'Coverage request')} · ${r.scope==='selected'?'Selected periods/classes':'All classes that day'}</span></div><span class="badge">${e(r.status||'Pending')}</span></div>${r.admin_note?`<div class="callout" style="margin-top:8px">${e(r.admin_note)}</div>`:''}</div>`).join('')||'<div class="empty-modern">No substitute requests submitted.</div>'}</div></div>
    <div class="panel"><div class="panel-head"><h3>Scheduled Coverage</h3></div><div class="panel-body">${(as||[]).map(a=>{const covering=Number(a.substitute_staff_id)===sid&&Number(a.teacher_staff_id)!==sid;return `<div class="sub-assignment"><div class="pass-head"><div><b>${covering?'Covering '+e(a.teacher_name):'Coverage by '+e(a.substitute_name)}</b><span class="student-sub">${e(a.start_date)} → ${e(a.end_date)}${a.reason?' · '+e(a.reason):''}</span></div><span class="sub-status ${e(a.effective_status||a.status)}">${covering?'You are the substitute':e(a.effective_status||a.status)}</span></div><div class="row-actions" style="margin-top:10px"><button class="btn mini primary" onclick="${covering?`teacherActAsSub(${a.id},'${e(a.start_date)}')`:`teacherSubDay(${a.id},'${e(a.start_date)}')`}">${covering?'Open Coverage':'Prepare Plans'}</button></div></div>`}).join('')||'<div class="empty-modern">No substitute coverage is currently scheduled for you.</div>'}</div></div>`;
  }
  window.teacherSubCenter=teacherSubCenter;
  window.newTeacherSubRequest=async function(){
    const today=(window.ssSchoolDate||window.SCHOOL_DATE||'');
    openModal('Request Substitute Coverage', `<div class="sub-request-form">
      <div class="sub-request-intro"><b>Tell administration when you need coverage.</b><span>You can request your whole day or only the classes/periods you need covered.</span></div>
      <div class="sub-request-grid">
        <label class="sub-field"><span>Date</span><input id="tsr-date" class="control" type="date" value="${e(today)}" onchange="loadTeacherRequestClasses()"></label>
        <label class="sub-field"><span>Reason</span><select id="tsr-reason" class="control"><option>Meeting</option><option>Professional Development</option><option>Appointment</option><option>Illness</option><option>Personal</option><option>Other</option></select></label>
        <label class="sub-field sub-field-wide"><span>Coverage needed</span><select id="tsr-scope" class="control" onchange="toggleTeacherRequestScope()"><option value="all">All classes that day</option><option value="selected">Selected periods / classes</option></select></label>
      </div>
      <div id="tsr-classes" class="sub-class-picker" style="display:none"></div>
      <label class="sub-field sub-field-wide"><span>Notes <small>optional</small></span><textarea id="tsr-notes" class="control" rows="4" placeholder="Anything administration should know about the coverage request"></textarea></label>
      <div class="modal-actions sub-request-actions"><button class="btn ghost" type="button" onclick="closeModal()">Cancel</button><button class="btn primary" type="button" onclick="saveTeacherSubRequest()">Submit Request</button></div>
    </div>`);
  };
  window.toggleTeacherRequestScope=async function(){const sel=$('#tsr-scope')?.value==='selected';const box=$('#tsr-classes');if(box)box.style.display=sel?'block':'none';if(sel)await loadTeacherRequestClasses();};
  window.loadTeacherRequestClasses=async function(){const date=$('#tsr-date')?.value;if(!date)return;const rows=await api('/api/substitute/request/classes?date='+encodeURIComponent(date));const box=$('#tsr-classes');if(!box)return;box.innerHTML=`<div class="sub-picker-head"><div><b>Select periods/classes</b><span>Choose only the classes that need coverage.</span></div><button type="button" class="btn mini ghost" onclick="document.querySelectorAll('.tsr-class').forEach(x=>x.checked=true)">Select all</button></div><div class="sub-picker-list">${(rows||[]).map(c=>`<label class="sub-period-card"><input type="checkbox" class="tsr-class" value="${c.id}"><span class="sub-period-main"><b>${e(c.period||'Period')} · ${e(c.name||'Class')}</b><small>${c.start_time?`${e(c.start_time)}–${e(c.end_time||'')}`:'Time not set'}${c.room?` · Room ${e(c.room)}`:''}</small></span></label>`).join('')||'<div class="empty-modern">No classes meet on this date.</div>'}</div>`;};
  window.saveTeacherSubRequest=async function(){
    const btn=[...document.querySelectorAll('.modal-actions .btn.primary')].find(b=>b.textContent.includes('Submit Request'));
    const date=$('#tsr-date')?.value||'',scope=$('#tsr-scope')?.value||'all',selected=[...document.querySelectorAll('.tsr-class:checked')].map(x=>Number(x.value));
    if(!date){toastMsg('Choose a coverage date');return;}
    if(scope==='selected'&&!selected.length){toastMsg('Choose at least one period/class');return;}
    try{
      if(btn){btn.disabled=true;btn.textContent='Submitting…';}
      await api('/api/substitute/request',{method:'POST',body:JSON.stringify({date,scope,selected_class_ids:selected,reason:$('#tsr-reason')?.value||'',notes:$('#tsr-notes')?.value||''})});
      closeModal();toastMsg('Substitute request submitted');
      if(window.teacherSubCenter)await window.teacherSubCenter(); else showPage('teacher-substitute');
    }catch(err){toastMsg(err?.message||'Could not submit request');}
    finally{if(btn){btn.disabled=false;btn.textContent='Submit Request';}}
  };
  window.teacherActAsSub=async function(id,day){subDate=day;const d=await api('/api/substitute/day?date='+encodeURIComponent(day)),match=(d.assignments||[]).find(x=>x.id===id);if(!match)return toastMsg('No active coverage on this date');$('#content').innerHTML=`<div class="pagebar"><div><button class="btn ghost" onclick="substituteCenter()">← Coverage</button><h1>Covering ${e(match.teacher_name)}</h1><p>${e(day)}</p></div><input class="control" type="date" min="${e(match.start_date)}" max="${e(match.end_date)}" value="${e(day)}" onchange="teacherActAsSub(${id},this.value)"></div><div class="sub-grid">${(match.classes||[]).map(c=>`<article class="sub-class"><span class="badge">Period ${e(c.period||'—')}</span><h3>${e(c.name)}</h3><div class="student-sub">Room ${e(c.room||'—')}</div><div class="sub-meta"><span class="badge">${c.enrolled||0} students</span><span class="badge">${Number(c.attendance_completed)?'Attendance complete':'Attendance pending'}</span></div><div class="row-actions"><button class="btn primary" onclick="openSubClass(${id},${c.id},'${e(day)}')">Open Class</button></div></article>`).join('')||'<div class="empty-modern">No classes meet on this date.</div>'}</div>`};
  window.teacherSubDay=async function(id,day){const a=await api('/api/substitute/assignments?id='+id),d=await api('/api/substitute/day?date='+encodeURIComponent(day)),match=(d.assignments||[]).find(x=>x.id===id);if(!match)return toastMsg('No active coverage on this date');$('#content').innerHTML=`<div class="pagebar"><div><button class="btn ghost" onclick="substituteCenter()">← Substitute Plans</button><h1>Plans for ${e(a.substitute_name)}</h1><p>${e(day)}</p></div><input class="control" type="date" min="${e(a.start_date)}" max="${e(a.end_date)}" value="${e(day)}" onchange="teacherSubDay(${id},this.value)"></div><div class="sub-grid">${match.classes.map(c=>`<article class="sub-class"><span class="badge">Period ${e(c.period||'—')}</span><h3>${e(c.name)}</h3><div class="student-sub">Room ${e(c.room||'—')}</div>${c.lesson_plan?`<div class="sub-plan">${e(c.lesson_plan)}</div>`:'<div class="empty-modern">No lesson plan yet.</div>'}${c.substitute_notes?`<div class="callout"><b>Substitute note</b><br>${e(c.substitute_notes)}</div>`:''}<button class="btn primary" onclick="subPlanForm(${id},${c.id},'${e(day)}')">${c.lesson_plan?'Edit':'Add'} Lesson Plan</button></article>`).join('')}</div>`};
  window.subPlanForm=async function(aid,cid,day){const d=await api(`/api/substitute/class?assignment_id=${aid}&class_id=${cid}&date=${encodeURIComponent(day)}`),c=d.coverage||{};openModal('Lesson Plan — '+e(d.class.name),`<form class="form" onsubmit="saveSubPlan(event,${aid},${cid},'${e(day)}')"><label class="full"><span>Lesson plan / agenda</span><textarea name="lesson_plan" rows="7">${e(c.lesson_plan||'')}</textarea></label><label class="full"><span>Links / resources</span><textarea name="lesson_links" rows="3" placeholder="Links, file locations, textbook pages...">${e(c.lesson_links||'')}</textarea></label><label class="full"><span>Teacher notes for substitute</span><textarea name="teacher_notes" rows="4" placeholder="Class routines, important reminders, dismissal instructions...">${e(c.teacher_notes||'')}</textarea></label><div class="full"><button class="btn primary">Save Plan</button></div></form>`)};
  window.saveSubPlan=async function(ev,aid,cid,day){ev.preventDefault();const d=Object.fromEntries(new FormData(ev.target));Object.assign(d,{assignment_id:aid,class_id:cid,date:day});await api('/api/substitute/coverage',{method:'POST',body:JSON.stringify(d)});closeModal();toastMsg('Lesson plan saved');role==='teacher'?teacherSubDay(aid,day):adminSubDay(aid,day)};
})();


window.reviewSubRequest=async function(id,status){await api('/api/substitute/request/review',{method:'POST',body:JSON.stringify({id,status})});toastMsg('Request updated');substituteCenter();};
window.adminUseSubRequest=async function(id){
  const reqs=await api('/api/substitute/requests');
  const r=(reqs||[]).find(x=>Number(x.id)===Number(id));
  if(!r)return toastMsg('Request not found');
  window._pendingSubRequest=r;
  // Reuse the normal admin assignment builder, preloading teacher/date.
  if(typeof window.newSubAssignment==='function'){await window.newSubAssignment();setTimeout(async()=>{const t=document.querySelector('#sub-teacher,#sa-teacher,#subTeacher');if(t){t.value=String(r.teacher_staff_id);t.dispatchEvent(new Event('change'));}const d=document.querySelector('#sub-date,#sa-date,#sub-start');if(d){d.value=r.request_date;d.dispatchEvent(new Event('change'));}},50);}
  else toastMsg('Open New Substitute Assignment and use '+r.teacher_name+' on '+r.request_date);
};

