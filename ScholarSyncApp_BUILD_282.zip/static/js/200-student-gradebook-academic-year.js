/* ScholarSync: student per-class gradebooks + admin-defined exact academic-year dates */
(function(){
 const h=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const pct=(score,pts)=>score==null||!Number(pts)?null:Number(score)/Number(pts)*100;
 const gradeStatus=a=>String(a.grade_status||'').toUpperCase();
 const statusLabel=a=>{const s=gradeStatus(a);if(s==='MISSING')return 'Missing';if(s==='EXCUSED')return 'Excused';if(s==='DROPPED')return 'Dropped';if(a.score==null)return 'Not graded';return 'Graded'};
 const statusClass=a=>gradeStatus(a)==='MISSING'?'red':gradeStatus(a)==='EXCUSED'?'':'success';

 ssAddNav?.('admin','ACADEMICS','academic-year-settings','📅','Academic Year','scheduling');
 ssRegisterPageRoute?.('academic-year-settings',()=>academicYearSettingsPage(),['admin']);

 window.academicYearSettingsPage=async function(){
   const y=await api('/api/academic-year-settings'); activePage='academic-year-settings';
   $('#content').innerHTML=`<div class="pagebar"><div><h1>Academic Year</h1><p>Define the exact instructional-year boundaries used by schedules, calendar views, smart due dates, closures, and Summer School separation.</p></div></div>
   <div class="panel" style="max-width:900px"><div class="panel-head"><div><h3>Current Academic Year</h3><small>These dates are district-controlled. ScholarSync will not invent August–June boundaries.</small></div></div><div class="panel-body">
   <form class="form" onsubmit="saveAcademicYearSettings(event)"><label class="full"><span>School year name</span><input name="name" value="${h(y.name||'')}" placeholder="2026–2027 School Year" required></label><label><span>First day in school-year schedule</span><input type="date" name="start_date" value="${h(y.start_date||'')}" required></label><label><span>Last day in school-year schedule</span><input type="date" name="end_date" value="${h(y.end_date||'')}" required></label><div class="full callout"><b>What this controls</b><br>Student and teacher School Year views, normal-class generation, rotation-day calculations, smart assignment due dates, and when the regular schedule stops before Summer School.</div><div class="full"><button class="btn primary">Save Academic Year</button></div></form></div></div>`;
 };
 window.saveAcademicYearSettings=async function(ev){ev.preventDefault();const d=Object.fromEntries(new FormData(ev.target));await api('/api/academic-year-settings',{method:'POST',body:JSON.stringify(d)});toastMsg('Academic year updated');academicYearSettingsPage()};

 async function loadStudentGradeData(){
   await preload(); const sid=Number(user?.student_id||0); if(!sid)throw new Error('No student is linked to this account');
   return await api('/api/student-profile?id='+sid);
 }
 function classAssignments(d,cid){return (d.assignments||[]).filter(a=>Number(a.class_id)===Number(cid));}
 function earnedSummary(items){let earned=0,possible=0,missing=0,graded=0;items.forEach(a=>{if(Number(a.include_in_gradebook??1)===0)return;const s=gradeStatus(a);if(s==='EXCUSED'||s==='DROPPED')return;if(s==='MISSING'){possible+=Number(a.points||0);missing++;return}if(a.score!=null){earned+=Number(a.score||0);possible+=Number(a.points||0);graded++}});return{earned,possible,missing,graded,pct:possible?earned/possible*100:null}}
 function categoryRows(items,weights){
   const cats={};items.forEach(a=>{const k=a.category||'Uncategorized';(cats[k]??=[]).push(a)});
   return Object.entries(cats).map(([name,arr])=>{const s=earnedSummary(arr),w=Number(weights?.[name]??0);return{name,...s,weight:w}});
 }
 window.studentGradebookPage=async function(){
   const d=await loadStudentGradeData();activePage='gradebook';window.studentGradebookData=d;
   const classes=(d.classes||[]).filter(c=>Number(c.published??1)!==0);
   $('#content').innerHTML=`<div class="pagebar"><div><h1>My Gradebook</h1><p>Open any class to see exactly what is contributing to your grade.</p></div></div><div class="metric-strip"><div class="metric"><small>Current average</small><strong>${d.metrics?.current_average==null?'—':h(d.metrics.current_average)+'%'}</strong></div><div class="metric"><small>Classes</small><strong>${classes.length}</strong></div><div class="metric"><small>Published assignments</small><strong>${(d.assignments||[]).length}</strong></div><div class="metric"><small>Missing</small><strong>${(d.assignments||[]).filter(a=>gradeStatus(a)==='MISSING').length}</strong></div></div>
   <div class="activity-grid" style="margin-top:16px">${classes.map(c=>{const items=classAssignments(d,c.id),sm=earnedSummary(items),avg=c.average==null?sm.pct:c.average;return `<button class="activity-card student-class-grade-card" style="text-align:left;cursor:pointer" onclick="openStudentClassGradebook(${c.id})"><div class="detail-line"><div><span class="student-sub">${h(c.course_code||'')} · ${h(c.period||'')}</span><h3 style="margin:3px 0">${h(c.name)} ${h(c.section||'')}</h3><span class="student-sub">${h(c.teacher||'')} · ${items.length} assignments</span></div><div style="text-align:right"><b style="font-size:25px">${avg==null?'—':Number(avg).toFixed(1)+'%'}</b><span class="student-sub">${h(c.letter||'')}</span></div></div><div style="margin-top:12px"><span class="badge ${sm.missing?'red':''}">${sm.missing} missing</span> <span class="badge">${sm.graded} graded</span></div></button>`}).join('')||'<div class="panel"><div class="empty-modern">No published classes are available.</div></div>'}</div>`;
 };
 window.openStudentClassGradebook=async function(cid){
   const d=window.studentGradebookData||await loadStudentGradeData(),c=(d.classes||[]).find(x=>Number(x.id)===Number(cid));if(!c)return;
   const items=classAssignments(d,cid),settings=await api('/api/gradebook-settings?class_id='+cid),cats=categoryRows(items,settings.category_weights||{}),summary=earnedSummary(items),avg=c.average==null?summary.pct:c.average;
   $('#content').innerHTML=`<div class="pagebar"><div><button class="btn ghost" onclick="studentGradebookPage()">← My Gradebook</button><h1 style="margin-top:10px">${h(c.name)} ${h(c.section||'')}</h1><p>${h(c.teacher||'')} · ${h(c.period||'')} · ${h(c.term||'')}</p></div><div><div style="text-align:right"><small>Current grade</small><div style="font-size:34px;font-weight:900">${avg==null?'—':Number(avg).toFixed(1)+'%'}</div><b>${h(c.letter||'')}</b></div></div></div>
   <div class="metric-strip"><div class="metric"><small>Assignments</small><strong>${items.length}</strong></div><div class="metric"><small>Graded</small><strong>${summary.graded}</strong></div><div class="metric"><small>Missing</small><strong>${summary.missing}</strong></div><div class="metric"><small>Points shown</small><strong>${summary.possible?summary.earned.toFixed(1)+' / '+summary.possible.toFixed(1):'—'}</strong></div></div>
   <div class="panel" style="margin-top:16px"><div class="panel-head"><div><h3>Category Breakdown</h3><small>${Object.keys(settings.category_weights||{}).length?'Teacher category weights are shown below.':'No category weights have been configured for this class.'}</small></div></div><div class="table-wrap"><table><thead><tr><th>Category</th><th>Weight</th><th>Grade</th><th>Earned / Possible</th><th>Missing</th></tr></thead><tbody>${cats.map(x=>`<tr><td><b>${h(x.name)}</b></td><td>${x.weight?x.weight+'%':'—'}</td><td>${x.pct==null?'—':x.pct.toFixed(1)+'%'}</td><td>${x.possible?x.earned.toFixed(1)+' / '+x.possible.toFixed(1):'—'}</td><td>${x.missing||'—'}</td></tr>`).join('')||'<tr><td colspan="5" class="empty">No published assignments yet.</td></tr>'}</tbody></table></div></div>
   <div class="panel" style="margin-top:16px"><div class="panel-head"><div><h3>Assignments</h3><small>Every published assignment in this class</small></div></div><div class="table-wrap"><table><thead><tr><th>Assignment</th><th>Category</th><th>Due</th><th>Score</th><th>Percent</th><th>Status</th><th>Teacher Comment</th></tr></thead><tbody>${items.map(a=>{const p=pct(a.score,a.points);return `<tr><td><b>${h(a.title)}</b></td><td>${h(a.category||'—')}</td><td>${h(a.due_date||'—')}</td><td>${a.score==null?'—':h(a.score)+' / '+h(a.points)}</td><td>${p==null?'—':p.toFixed(1)+'%'}</td><td><span class="badge ${statusClass(a)}">${h(statusLabel(a))}</span></td><td>${h(a.comment||'')}</td></tr>`}).join('')||'<tr><td colspan="7" class="empty">No published assignments.</td></tr>'}</tbody></table></div></div>`;
 };

 // The student Gradebook nav now opens class-by-class gradebooks, not the report-card tab.
 const oldGradebook=window.gradebook;
 window.gradebook=function(){if(role==='student')return studentGradebookPage();return oldGradebook.apply(this,arguments)};

 // Add a direct gradebook button to each class in the student's Report Card tab.
 const oldRender=window.renderStudentProfileTab;
 window.renderStudentProfileTab=function(tab){oldRender(tab);if(tab==='grades'&&role==='student'){const b=document.querySelector('#profileTabBody .panel-head .btn');if(b){const open=document.createElement('button');open.className='btn primary';open.textContent='Open Class Gradebooks';open.onclick=studentGradebookPage;b.parentNode?.appendChild(open)}}};
})();
