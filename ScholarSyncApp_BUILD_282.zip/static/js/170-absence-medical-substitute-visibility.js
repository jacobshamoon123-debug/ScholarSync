/* ScholarSync absence review semantics + medical-note evidence + substitute navigation visibility */
(function(){
  const X=window.esc || (v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])));

  function moveNav(roleName,id,group,icon,label,afterId){
    const a=window.NAV?.[roleName]; if(!a)return;
    const old=a.findIndex(x=>x[1]===id); if(old>=0)a.splice(old,1);
    const i=afterId?a.findIndex(x=>x[1]===afterId):-1;
    a.splice(i>=0?i+1:a.length,0,[group,id,icon,label]);
  }
  // Keep substitute functionality obvious in the main admin/teacher navigation.
  moveNav('admin','substitutes','STAFF & SERVICES','🧑‍🏫','Substitute Coverage','staff');
  moveNav('teacher','substitutes','TEACHING','🧑‍🏫','Substitute Plans','attendance');
  if(window.NAV) NAV.substitute=[['SUBSTITUTE','dashboard','⌂','Today’s Coverage'],['SUBSTITUTE','substitutes','🧑‍🏫','Coverage Details']];

  if(typeof window.ssRegisterPageRoute==='function'){
    ssRegisterPageRoute('substitutes',()=>window.substituteCenter(),['admin','teacher','substitute']);
    ssRegisterPageRoute('absence-requests',()=>window.absenceRequestsPageV2(),['admin','parent']);
  }

  function displayDecision(x){
    if(x.attendance_decision)return x.attendance_decision;
    if(x.status==='Approved')return 'Excused';
    if(x.status==='Denied')return 'Unexcused';
    return '';
  }
  function displayStatus(x){return x.status==='Approved'||x.status==='Denied'?'Reviewed':x.status;}
  function card(x){
    const dec=displayDecision(x), status=displayStatus(x);
    return `<div class="request-card"><div class="request-head"><div><b>${X(x.student_name||'Student')}</b><span class="student-sub">${X(x.absence_date)} · ${X(x.reason)}</span></div><div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end"><span class="badge absence-status ${X(status)}">${X(status)}</span>${dec?`<span class="badge ${dec==='Excused'?'green':''}">${X(dec)}</span>`:''}</div></div>${x.details?`<div class="absence-note">${X(x.details)}</div>`:''}${Number(x.has_attachment)?`<div class="absence-note"><b>📎 Supporting medical document:</b> ${X(x.attachment_name||'Doctor note')} <button class="btn mini outline" onclick="viewAbsenceAttachment(${x.id})">View document</button></div>`:''}${x.decision_note?`<div class="student-sub" style="margin-top:7px"><b>School note:</b> ${X(x.decision_note)}</div>`:''}${role==='admin'&&status==='Pending'?`<div class="request-actions"><button class="btn success" onclick="reviewAbsenceV2(${x.id},'excused')">✓ Mark Excused</button><button class="btn outline" onclick="reviewAbsenceV2(${x.id},'unexcused')">Mark Unexcused</button></div>`:''}</div>`;
  }

  window.absenceRequestsPageV2=async function(){
    activePage='absence-requests'; window.ssActiveNav?.('absence-requests');
    const requests=await api('/api/absence-requests');
    if(role==='parent'){
      $('#crumb').textContent='Report an Absence';
      $('#content').innerHTML=`<div class="pagebar"><div><h1>Report an Absence</h1><p>Tell the attendance office why your child will be absent and optionally attach supporting documentation.</p></div><button class="btn primary" onclick="openParentAbsenceFormV2()">+ Report Absence</button></div><div class="absence-layout"><section><div class="panel"><div class="panel-head"><h3>My requests</h3></div><div class="panel-body">${requests.map(card).join('')||'<div class="empty-modern">You have not submitted any absence requests.</div>'}</div></div></section><aside class="panel"><div class="panel-head"><h3>How review works</h3></div><div class="panel-body"><div class="detail-line"><span>1. Family submits</span><b>Pending</b></div><div class="detail-line"><span>2. Attendance office reviews</span><b>Reviewed</b></div><div class="detail-line"><span>Attendance result</span><b>Excused or Unexcused</b></div><div class="absence-note"><b>Unexcused does not mean denied.</b> It means the school accepted the absence report but determined it does not qualify as an excused absence under school policy.</div></div></aside></div>`;return;
    }
    $('#crumb').textContent='Absence Center';
    const pending=requests.filter(x=>displayStatus(x)==='Pending'), exc=requests.filter(x=>displayDecision(x)==='Excused'), unexc=requests.filter(x=>displayDecision(x)==='Unexcused');
    $('#content').innerHTML=`<div class="pagebar"><div><h1>Absence Center</h1><p>Review family absence reports, supporting documentation, and determine whether attendance is excused or unexcused.</p></div><div class="page-actions"><button class="btn outline" onclick="dashboard()">Dashboard</button><button class="btn primary" onclick="openAdminDailyAbsence()">+ Set All-Day Absence</button></div></div><div class="metric-strip"><div class="metric"><small>Pending review</small><strong>${pending.length}</strong></div><div class="metric"><small>Reviewed · Excused</small><strong>${exc.length}</strong></div><div class="metric"><small>Reviewed · Unexcused</small><strong>${unexc.length}</strong></div></div><div class="absence-layout"><section class="panel"><div class="panel-head"><h3>Family absence reports</h3><span class="badge">${requests.length}</span></div><div class="panel-body">${requests.map(card).join('')||'<div class="empty-modern">No parent absence requests.</div>'}</div></section><aside class="panel"><div class="panel-head"><h3>Review standard</h3></div><div class="panel-body"><p class="student-sub">Choose <b>Excused</b> or <b>Unexcused</b> after reviewing the reason and any supporting document. Both choices mean the report was reviewed; neither is a denial of the report itself.</p><div class="absence-note">The selected result is applied to every scheduled class for that school day and appears pre-filled on teacher attendance rosters.</div></div></aside></div>`;
  };

  window.openParentAbsenceFormV2=function(){
    const kids=cache.students||[];
    openModal('Report Student Absence',`<form class="form" onsubmit="submitParentAbsenceV2(event)"><label class="full"><span>Student</span><select name="student_id" required>${kids.map(s=>`<option value="${s.id}">${X(s.name)}</option>`).join('')}</select></label><label><span>Absence date</span><input name="absence_date" type="date" required></label><label><span>Reason</span><select name="reason" required onchange="toggleMedicalNote(this.value)"><option value="">Choose…</option><option>Illness</option><option>Medical appointment</option><option>Injury</option><option>Hospital / emergency care</option><option>Family emergency</option><option>Bereavement</option><option>College visit</option><option>Religious observance</option><option>Other</option></select></label><label class="full"><span>Additional details</span><textarea name="details" rows="4" placeholder="Information for the attendance office"></textarea></label><label class="full" id="medicalNoteField" style="display:none"><span>Doctor's note / medical documentation (optional)</span><input name="medical_note" type="file" accept="application/pdf,image/png,image/jpeg,image/webp"><small class="student-sub">PDF or image, up to 5 MB. This is visible to authorized attendance administrators reviewing the request.</small></label><div class="full callout">Submitting an absence does not automatically make it excused. The attendance office reviews the reason and any documentation and marks the absence Excused or Unexcused.</div><div class="full"><button class="btn primary">Submit Absence</button></div></form>`);
  };
  window.toggleMedicalNote=function(reason){const el=document.getElementById('medicalNoteField');if(!el)return;el.style.display=/illness|medical|injury|hospital|doctor|sick|health/i.test(reason)?'block':'none'};
  window.submitParentAbsenceV2=async function(ev){
    ev.preventDefault();const fd=new FormData(ev.target), d={student_id:fd.get('student_id'),absence_date:fd.get('absence_date'),reason:fd.get('reason'),details:fd.get('details')||''};const f=fd.get('medical_note');
    if(f&&f.size){if(f.size>5*1024*1024)return toastMsg('Doctor note must be 5 MB or smaller');const bytes=new Uint8Array(await f.arrayBuffer());let bin='';for(let i=0;i<bytes.length;i+=0x8000)bin+=String.fromCharCode(...bytes.subarray(i,i+0x8000));d.attachment_name=f.name;d.attachment_type=f.type||'application/octet-stream';d.attachment_base64=btoa(bin)}
    await api('/api/absence-requests',{method:'POST',body:JSON.stringify(d)});closeModal();toastMsg('Absence submitted for review');absenceRequestsPageV2();
  };
  window.viewAbsenceAttachment=async function(id){const a=await api('/api/absence-requests/attachment?id='+id),bin=atob(a.file_base64||''),bytes=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);const url=URL.createObjectURL(new Blob([bytes],{type:a.file_type||'application/octet-stream'}));window.open(url,'_blank');setTimeout(()=>URL.revokeObjectURL(url),60000)};
  window.reviewAbsenceV2=function(id,decision){
    const exc=decision==='excused';openModal(exc?'Mark Absence Excused':'Mark Absence Unexcused',`<form class="form" onsubmit="finishAbsenceReviewV2(event,${id},'${decision}')"><div class="full callout">This request will be recorded as <b>Reviewed</b>. The student's attendance for every scheduled class that day will be marked <b>Absent — ${exc?'Excused':'Unexcused'}</b>.</div><label class="full"><span>Attendance office note (optional)</span><textarea name="decision_note" rows="3"></textarea></label><div class="full"><button class="btn ${exc?'success':'primary'}">Save ${exc?'Excused':'Unexcused'} Decision</button></div></form>`);
  };
  window.finishAbsenceReviewV2=async function(ev,id,action){ev.preventDefault();const d=Object.fromEntries(new FormData(ev.target));d.id=id;d.action=action;const r=await api('/api/absence-requests/review',{method:'POST',body:JSON.stringify(d)});closeModal();toastMsg(`${r.attendance_decision} absence applied across ${r.classes_marked} classes`);absenceRequestsPageV2()};
})();
