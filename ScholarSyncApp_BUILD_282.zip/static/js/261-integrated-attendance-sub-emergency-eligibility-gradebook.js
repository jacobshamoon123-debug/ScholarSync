/* ScholarSync Build 261 — deep workflow integrations */
(function(){
  const H=x=>typeof esc==='function'?esc(x):String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));

  /* ---------- Protected all-day absences in attendance UI ---------- */
  if(typeof openAttendance==='function'){
    const _openAttendance261=openAttendance;
    openAttendance=async function(cid,el){
      await _openAttendance261(cid,el);
      try{
        const date=document.querySelector('#attDate')?.value;
        if(!date)return;
        const recs=await api(`/api/attendance?class_id=${cid}&date=${encodeURIComponent(date)}`);
        const protectedMap=new Map((recs||[]).filter(x=>x.all_day_status).map(x=>[Number(x.student_id),x]));
        protectedMap.forEach((rec,sid)=>{
          const row=document.querySelector(`.att-row[data-student="${sid}"]`);
          if(!row)return;
          row.dataset.protected='1';
          row.classList.add('ss-protected-absence');
          row.querySelectorAll('.att-choice').forEach(b=>b.disabled=true);
          const first=row.firstElementChild;
          if(first&&!first.querySelector('.ss-protected-chip')){
            const chip=document.createElement('span');
            chip.className='ss-protected-chip';
            chip.textContent=(rec.all_day_status==='AE'?'All-day excused absence':'All-day unexcused absence')+' · locked';
            first.appendChild(chip);
          }
        });
      }catch(_){}
    };
  }
  if(typeof markAllPresent==='function'){
    markAllPresent=function(){
      document.querySelectorAll('.roster-line').forEach(r=>{
        if(r.dataset.protected==='1')return;
        r.querySelectorAll('.att-choice').forEach(x=>x.classList.remove('sel'));
        r.querySelector('[data-code=P]')?.classList.add('sel');
      });
      if(typeof updateAttCounts==='function')updateAttCounts();
    };
  }
  if(typeof clearAttendance==='function'){
    clearAttendance=function(){
      document.querySelectorAll('.roster-line').forEach(r=>{
        if(r.dataset.protected==='1')return;
        r.querySelectorAll('.att-choice').forEach(x=>x.classList.remove('sel'));
      });
      if(typeof updateAttCounts==='function')updateAttCounts();
    };
  }

  /* ---------- Teacher course eligibility on Staff accounts ---------- */
  if(typeof personForm==='function'){
    const _personForm261=personForm;
    personForm=async function(k,item=null){
      if(k!=='staff')return _personForm261(k,item);
      const courses=await api('/api/courses');
      let eligible=[];try{eligible=JSON.parse(item?.eligible_course_ids||'[]').map(Number)}catch(_){}
      const edit=!!item,v=(n,d='')=>H(item?.[n]??d);
      openModal(`${edit?'Edit':'Add'} Staff Member`,`<form class="form" onsubmit="savePerson(event,'staff',${edit?item.id:'null'})">
        <label><span>Employee ID</span><input name="employee_number" value="${v('employee_number')}"></label>
        <label><span>Name</span><input name="name" value="${v('name')}" required></label>
        <label><span>Role</span><select name="role"><option ${v('role','Teacher')==='Teacher'?'selected':''}>Teacher</option><option ${v('role')==='Substitute Teacher'?'selected':''}>Substitute Teacher</option><option ${v('role')==='Counselor'?'selected':''}>Counselor</option><option ${v('role')==='Nurse'?'selected':''}>Nurse</option><option ${v('role')==='Administrator'?'selected':''}>Administrator</option><option value="${v('role')}">${v('role')}</option></select></label>
        <label><span>School</span><input name="school" value="${v('school')}"></label>
        <label><span>Email</span><input name="email" type="email" value="${v('email')}"></label>
        <label><span>Phone</span><input name="phone" value="${v('phone')}"></label>
        <label><span>Status</span><select name="status"><option ${v('status','Active')==='Active'?'selected':''}>Active</option><option ${v('status')==='Inactive'?'selected':''}>Inactive</option></select></label>
        <div class="full ss-eligibility-box"><div class="ss-eligibility-head"><div><b>Teaching Eligibility</b><small>Choose the courses this teacher is qualified/allowed to teach. The Master Schedule will only assign this teacher to these courses.</small></div><button type="button" class="btn mini outline" onclick="document.querySelectorAll('.ss-course-elig').forEach(x=>x.checked=true)">Select All</button></div>
        <div class="ss-course-grid">${(courses||[]).map(c=>`<label class="ss-course-option"><input class="ss-course-elig" type="checkbox" value="${c.id}" ${eligible.includes(Number(c.id))?'checked':''}><span><b>${H(c.code||'')} ${H(c.name)}</b><small>${H(c.department||'')}</small></span></label>`).join('')||'<div class="empty-modern">No courses have been created yet.</div>'}</div></div>
        <div class="full"><button class="btn primary">${edit?'Save Changes':'Save Staff Member'}</button></div>
      </form>`);
    };

    if(typeof savePerson==='function'){
      const _savePerson261=savePerson;
      savePerson=async function(e,k,id=null){
        if(k!=='staff')return _savePerson261(e,k,id);
        e.preventDefault();
        const fd=new FormData(e.target),d=Object.fromEntries(fd);
        d.eligible_course_ids=[...e.target.querySelectorAll('.ss-course-elig:checked')].map(x=>Number(x.value));
        if(id)d.id=id;
        await api('/api/'+k+(id?'/update':''),{method:'POST',body:JSON.stringify(d)});
        closeModal();cache.staff=[];toastMsg(id?'Staff member updated':'Staff member created');peoplePage(k);
      };
    }
  }

  /* ---------- Assignment: include/exclude from gradebook ---------- */
  if(typeof assignmentForm==='function'){
    const _assignmentForm261=assignmentForm;
    assignmentForm=function(cid,id=0){
      _assignmentForm261(cid,id);
      setTimeout(async()=>{
        const form=document.querySelector('#modal form');
        if(!form)return;
        let source={};
        try{
          if(id){
            const classAssignments=await api('/api/assignments?class_id='+encodeURIComponent(cid));
            source=(classAssignments||[]).find(x=>Number(x.id)===Number(id))||{};
          }
          if(!source.id&&typeof assignmentCenterData!=='undefined')source=(assignmentCenterData||[]).find(x=>Number(x.id)===Number(id))||{};
          if(!source.id&&window.currentGradeExport?.assign)source=window.currentGradeExport.assign.find(x=>Number(x.id)===Number(id))||{};
        }catch(_){}
        const include=Number(source.include_in_gradebook??1)!==0;
        let select=form.querySelector('[name="include_in_gradebook"]');
        if(!select){
          const label=document.createElement('label');
          label.className='full ss-gradebook-inclusion';
          label.innerHTML=`<span>Gradebook calculation</span><select name="include_in_gradebook"><option value="1">Include in gradebook and class average</option><option value="0">Do NOT include in gradebook / class average</option></select><small>Students can still see the assignment if it is published. Scores may still be entered, but this assignment will not change their course grade.</small>`;
          const actions=form.querySelector('.full[style*="display:flex"]')||form.lastElementChild;
          form.insertBefore(label,actions);
          select=label.querySelector('select');
        }
        if(select)select.value=include?'1':'0';
      },0);
    };
  }

  /* ---------- Teacher schedule: show substitute/out-of-class status ---------- */
  if(typeof window.teacherScheduleDay==='function'){
    const _teacherScheduleDay261=window.teacherScheduleDay;
    window.teacherScheduleDay=async function(ds){
      await _teacherScheduleDay261(ds);
      try{
        const d=await api('/api/teacher-schedule?date='+encodeURIComponent(ds));
        const affected=(d.classes||[]).filter(c=>c.teacher_out||c.is_substitute_coverage);
        if(!affected.length)return;
        const view=document.querySelector('#teacherScheduleView');
        if(!view)return;
        const box=document.createElement('div');
        box.className='panel ss-sub-schedule-panel';
        box.innerHTML=`<div class="panel-head"><div><h3>Substitute Coverage</h3><small>Coverage changes for this date</small></div></div><div class="panel-body">${affected.map(c=>c.is_substitute_coverage?`<div class="ss-sub-schedule-row covering"><div><b>Covering ${H(c.covering_for_name)}</b><span>${H(c.course_code||'')} ${H(c.name)} · Period ${H(c.period||'—')} · ${H(c.start_time||'')}–${H(c.end_time||'')}</span></div><span class="badge">You are the substitute</span></div>`:`<div class="ss-sub-schedule-row out"><div><b>${H(c.course_code||'')} ${H(c.name)}</b><span>Period ${H(c.period||'—')} · You are out of class</span></div><span class="badge">Covered by ${H(c.substitute_name||'Substitute')}</span></div>`).join('')}</div>`;
        view.prepend(box);
      }catch(_){}
    };
  }


  /* Refresh teacher class scope when opening academic tools so newly assigned
     substitute classes appear immediately without signing out/reloading. */
  try{
    if(typeof role!=='undefined'&&role==='teacher'&&typeof cache!=='undefined'){
      if(typeof gradebook==='function'){
        const _gradebook261=gradebook;
        gradebook=async function(){cache.classes=[];return _gradebook261.apply(this,arguments);};
      }
      if(typeof attendance==='function'){
        const _attendance261=attendance;
        attendance=async function(){cache.classes=[];return _attendance261.apply(this,arguments);};
      }
      if(typeof assignmentCenter==='function'){
        const _assignmentCenter261=assignmentCenter;
        assignmentCenter=async function(){cache.classes=[];return _assignmentCenter261.apply(this,arguments);};
      }
    }
  }catch(_){}

  /* ---------- Emergency alert on EVERY portal/page ---------- */
  let lastEmergencyId=null;
  async function syncEmergencyOverlay(){
    try{
      // Do not poll protected emergency endpoints until a ScholarSync session is active.
      // This prevents repeated 401 console errors on the login screen / during portal startup.
      if(!user || !role) return;
      const list=await api('/api/emergency/incidents');
      const active=(list||[]).find(x=>String(x.status||'').toLowerCase()==='active');
      let el=document.getElementById('ssGlobalEmergencyAlert');
      if(!active){if(el)el.remove();lastEmergencyId=null;return}
      if(!el){el=document.createElement('div');el.id='ssGlobalEmergencyAlert';document.body.appendChild(el)}
      el.className='ss-global-emergency '+(Number(active.is_drill)?'drill':'real');
      el.innerHTML=`<div class="ss-global-emergency-inner"><div class="ss-global-emergency-icon">${Number(active.is_drill)?'🟡':'🚨'}</div><div class="ss-global-emergency-copy"><b>${Number(active.is_drill)?'EMERGENCY DRILL':'ACTIVE SCHOOL EMERGENCY'} — ${H(active.title||active.incident_type||'Emergency')}</b><span>${H(active.instructions||'Open Emergency Status for official instructions.')}</span></div><button class="btn ${Number(active.is_drill)?'outline':'danger'}" onclick="showPage('emergency')">Open Emergency</button></div>`;
      if(lastEmergencyId!==active.id){
        lastEmergencyId=active.id;
        if(typeof toastMsg==='function')toastMsg(Number(active.is_drill)?'Emergency drill is active':'ACTIVE EMERGENCY — open Emergency Status');
      }
    }catch(_){}
  }
  setTimeout(syncEmergencyOverlay,1200);
  setInterval(syncEmergencyOverlay,5000);

  /* ---------- Styling ---------- */
  if(!document.getElementById('ssBuild261Styles')){
    const st=document.createElement('style');st.id='ssBuild261Styles';st.textContent=`
      .ss-protected-absence{background:color-mix(in srgb,#b42318 5%,transparent)}.ss-protected-chip{display:block;margin-top:5px;font-size:11px;font-weight:800;color:#b42318}.ss-protected-absence .att-choice:disabled{opacity:.42;cursor:not-allowed}
      .ss-eligibility-box{border:1px solid var(--border);border-radius:14px;padding:14px}.ss-eligibility-head{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:10px}.ss-eligibility-head small{display:block;color:var(--muted);margin-top:4px}.ss-course-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;max-height:320px;overflow:auto}.ss-course-option{display:flex;gap:9px;align-items:flex-start;border:1px solid var(--border);padding:10px;border-radius:10px}.ss-course-option small{display:block;color:var(--muted)}
      .ss-gradebook-inclusion{border:1px solid #d0d5dd;border-radius:12px;padding:12px;background:color-mix(in srgb,var(--panel) 94%,#1570ef 6%)}.ss-gradebook-inclusion small{display:block;color:var(--muted);margin-top:5px}
      .ss-sub-schedule-panel{border-left:4px solid #1570ef}.ss-sub-schedule-row{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border)}.ss-sub-schedule-row:last-child{border-bottom:0}.ss-sub-schedule-row span:not(.badge){display:block;color:var(--muted);font-size:12px;margin-top:3px}.ss-sub-schedule-row.out{border-left:3px solid #d92d20;padding-left:10px}.ss-sub-schedule-row.covering{border-left:3px solid #1570ef;padding-left:10px}
      .ss-global-emergency{position:fixed;left:0;right:0;top:0;z-index:999999;padding:10px 16px;box-shadow:0 8px 24px rgba(0,0,0,.28)}.ss-global-emergency.real{background:#b42318;color:#fff}.ss-global-emergency.drill{background:#fdb022;color:#3b2b00}.ss-global-emergency-inner{max-width:1500px;margin:auto;display:flex;align-items:center;gap:14px}.ss-global-emergency-icon{font-size:26px}.ss-global-emergency-copy{flex:1;min-width:0}.ss-global-emergency-copy b,.ss-global-emergency-copy span{display:block}.ss-global-emergency-copy span{margin-top:3px;font-size:12px}.ss-global-emergency.real .btn{background:#fff;color:#8a1010;border-color:#fff}
      @media(max-width:700px){.ss-course-grid{grid-template-columns:1fr}.ss-global-emergency-inner{align-items:flex-start;flex-wrap:wrap}.ss-global-emergency .btn{width:100%}.ss-sub-schedule-row{align-items:flex-start;flex-direction:column}}
    `;document.head.appendChild(st);
  }
})();