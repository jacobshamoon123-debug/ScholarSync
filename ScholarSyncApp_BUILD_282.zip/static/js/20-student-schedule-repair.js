/* Student portal schedule + assignment detail repair */
function studentRotationLabel(c){
  const custom=String(c.day_label||c.rotation_label||'').trim();
  if(custom)return custom;
  const day=Number(c.cycle_day||c.rotation_day||1);
  return day===2?'Day B':day===1?'Day A':`Rotation ${day}`;
}
function studentPeriodSort(c){
  const raw=String(c.period||'');
  const m=raw.match(/\d+/);
  return m?Number(m[0]):999;
}
scheduleSummaryTable=function(d){
  const classes=[...(d.classes||[])];
  const groups=[];
  classes.forEach(c=>{
    const key=studentRotationLabel(c);
    let g=groups.find(x=>x.key===key);
    if(!g){g={key,day:Number(c.cycle_day||1),items:[]};groups.push(g)}
    g.items.push(c);
  });
  groups.sort((a,b)=>a.day-b.day||a.key.localeCompare(b.key));
  if(!groups.length)return '<div class="empty-modern">No schedule has been released yet.</div>';
  return `<div class="student-rotation-schedule">${groups.map(g=>`<section class="panel rotation-schedule-card"><div class="panel-head"><div><h3>${esc(g.key)}</h3><small>${g.items.length} scheduled classes</small></div><span class="badge">Rotation</span></div><div class="table-wrap"><table><thead><tr><th>Period</th><th>Class</th><th>Teacher</th><th>Room</th></tr></thead><tbody>${g.items.sort((a,b)=>studentPeriodSort(a)-studentPeriodSort(b)).map(c=>`<tr><td><b>${esc(c.period)}</b></td><td><b>${esc(c.course_code||'')} ${esc(c.name)} ${esc(c.section||'')}</b></td><td>${esc(c.teacher||'—')}</td><td>${esc(c.room||'—')}</td></tr>`).join('')}</tbody></table></div></section>`).join('')}</div>`;
};
const _renderStudentProfileTabStudentFix=renderStudentProfileTab;
renderStudentProfileTab=function(tab){
  if(tab!=='assignments')return _renderStudentProfileTabStudentFix(tab);
  const d=profileData,body=$('#profileTabBody');if(!body)return;
  body.innerHTML=`<div class="panel"><div class="panel-head"><div><h3>Assignments</h3><small>Open an assignment to see its description, instructions, rubric, resources, submission, and teacher feedback.</small></div><button class="btn outline" onclick="exportStudentAssignments()">Export assignments</button></div><div class="assignment-card-list">${(d.assignments||[]).map(a=>{let links=[];try{links=JSON.parse(a.links_json||'[]')}catch(e){};const resources=(a.attachment_name?1:0)+links.length;return `<article class="student-assignment-card" onclick="viewStudentAssignment(${a.id})"><div class="student-assignment-main"><div class="student-assignment-title"><span class="badge">${esc(a.class_name)} ${esc(a.section||'')}</span><h3>${esc(a.title)}</h3><p>${esc(a.description||'No description was provided.')}</p></div><div class="student-assignment-meta"><span><b>Due</b>${esc(a.due_date||'No due date')}</span><span><b>Points</b>${esc(a.points)}</span><span><b>Resources</b>${resources}</span><span><b>Status</b>${esc(a.submission_status||gradeStatusName(a.grade_status)||(a.score==null?'Not graded':'Graded'))}</span></div></div><div class="student-assignment-actions"><button class="btn outline" onclick="event.stopPropagation();viewStudentAssignment(${a.id})">Open Details</button>${Number(a.accept_submissions)?`<button class="btn primary" onclick="event.stopPropagation();submitAssignmentFile(${a.id})">${a.submission_status?'Replace Submission':'Submit'}</button>`:''}</div></article>`}).join('')||'<div class="empty-modern">No published assignments.</div>'}</div></div>`;
};
