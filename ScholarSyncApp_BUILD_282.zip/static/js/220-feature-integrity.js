/* ScholarSync cumulative feature-surface integrity layer.
   Loaded last so later cumulative updates cannot accidentally hide existing pages. */
(function(){
  if(!window.NAV) return;
  const ensure=(r,g,id,ico,label,after)=>{
    if(!NAV[r]) NAV[r]=[];
    if(NAV[r].some(x=>x[1]===id)) return;
    if(typeof window.ssAddNav==='function') return ssAddNav(r,g,id,ico,label,after);
    const i=after?NAV[r].findIndex(x=>x[1]===after):-1;
    NAV[r].splice(i>=0?i+1:NAV[r].length,0,[g,id,ico,label]);
  };
  const expected={
    admin:[
      ['CORE','dashboard','⌂','Control Center'],['CORE','students','👤','Students'],['CORE','staff','🧑‍🏫','Staff'],['CORE','courses','📘','Courses'],['CORE','classes','🏫','Classes & Sections'],['CORE','enrollment','➕','Enrollment'],
      ['ACADEMICS','gradebook','📊','Gradebook'],['ACADEMICS','assignment-center','🗂️','Assignment Center'],['ACADEMICS','attendance','✅','Attendance'],['ACADEMICS','absence-requests','🗓️','Absence Requests'],['ACADEMICS','scheduling','🗓️','Scheduling'],['ACADEMICS','academic-year-settings','📅','Academic Year'],['ACADEMICS','summer-school','☀️','Summer School'],['ACADEMICS','academic-planning','🎓','Academic Planning'],['ACADEMICS','course-requests','📝','Course Requests'],['ACADEMICS','gpa-settings','⚖️','GPA Settings'],['ACADEMICS','class-pages','📌','Class Pages'],
      ['STUDENT SERVICES','activities','⚽','Activities & Sports'],['STUDENT SERVICES','hallpasses','🚶','Hall Passes'],['STUDENT SERVICES','behavior','⚖️','Behavior'],['STUDENT SERVICES','health','🏥','Health'],['STUDENT SERVICES','counseling','🎓','Counseling'],['STUDENT SERVICES','special','🧩','Special Programs'],['STUDENT SERVICES','clubs','🎭','Clubs & Activities'],['STUDENT SERVICES','emergency','🚨','Emergency Command'],
      ['OPERATIONS','calendar','📅','Calendar'],['OPERATIONS','notifications','🔔','Notifications'],['OPERATIONS','communication','💬','Communication'],['OPERATIONS','formscenter','📝','Forms Center'],['OPERATIONS','assets','💻','Devices & Lockers'],['OPERATIONS','conferences','📅','Parent-Teacher Conferences'],['OPERATIONS','substitutes','🧑‍🏫','Substitute Coverage'],['OPERATIONS','campus-id-parking','🪪','IDs & Parking'],['OPERATIONS','campus-communications','📣','Announcements'],['OPERATIONS','campus-library','📚','Library'],['OPERATIONS','campus-inventory','📦','Inventory'],['OPERATIONS','campus-analytics','📉','Analytics Plus'],['OPERATIONS','campus-finance','💵','Fees & Payments'],['OPERATIONS','campus-transportation','🚌','Bus Routes'],['OPERATIONS','campus-meals','🥗','Meal Accounts'],['OPERATIONS','workflow','🔁','Workflow'],['OPERATIONS','reporting','📈','Reports & Analytics'],['OPERATIONS','users','🔐','User Accounts'],['OPERATIONS','security','🛡️','Security'],['OPERATIONS','district','🏛️','District Setup'],['OPERATIONS','enterprise','⚙️','Enterprise Operations'],['OPERATIONS','audit','📋','Audit Log'],['OPERATIONS','feature-directory','🧭','Feature Directory']
    ],
    teacher:[
      ['TEACHING','dashboard','⌂','Control Center'],['TEACHING','teacher-schedule','🗓️','Schedule'],['TEACHING','gradebook','📊','Gradebook'],['TEACHING','assignment-center','🗂️','Assignment Center'],['TEACHING','attendance','✅','Attendance'],['TEACHING','hallpasses','🚶','Hall Passes'],['TEACHING','learning','📚','Learning Suite'],['TEACHING','class-pages','📌','Class Pages'],['TEACHING','courses','📘','Course Catalog'],['TEACHING','course-requests','📝','Course Requests'],['TEACHING','formscenter','📝','Forms Center'],['TEACHING','conferences','📅','Conferences'],['TEACHING','clubs','🎭','Clubs & Activities'],['TEACHING','substitutes','🧑‍🏫','Substitute Plans'],['TEACHING','emergency','🚨','Emergency'],['TEACHING','campus-communications','📣','Announcements'],['TEACHING','calendar','📅','Calendar'],['TEACHING','notifications','🔔','Notifications'],['TEACHING','behavior','⚖️','Behavior'],['TEACHING','communication','💬','Communication']
    ],
    student:[
      ['MY SCHOOL','dashboard','⌂','Dashboard'],['MY SCHOOL','gradebook','📊','Gradebook'],['MY SCHOOL','attendance','✅','Attendance'],['MY SCHOOL','scheduling','🗓️','Schedule'],['MY SCHOOL','academic-planning','🎓','Academic Planning'],['MY SCHOOL','course-requests','📝','Course Requests'],['MY SCHOOL','learning','📚','Learning'],['MY SCHOOL','calendar','📅','Calendar'],['MY SCHOOL','notifications','🔔','Notifications'],['MY SCHOOL','hallpasses','🚶','Hall Pass'],['MY SCHOOL','activities','⚽','Activities & Sports'],['MY SCHOOL','clubs','🎭','Clubs & Activities'],['MY SCHOOL','formscenter','📝','Forms'],['MY SCHOOL','assets','💻','My Devices & Locker'],['MY SCHOOL','emergency','🚨','Emergency Status'],['MY SCHOOL','campus-id-parking','🪪','ID & Parking'],['MY SCHOOL','campus-communications','📣','Announcements'],['MY SCHOOL','campus-library','📚','Library'],['MY SCHOOL','campus-finance','💵','Fees'],['MY SCHOOL','campus-transportation','🚌','Bus'],['MY SCHOOL','campus-meals','🥗','Meals'],['MY SCHOOL','communication','💬','Messages']
    ],
    parent:[
      ['FAMILY','dashboard','⌂','Overview'],['FAMILY','gradebook','📊','Grades'],['FAMILY','attendance','✅','Attendance'],['FAMILY','absence-requests','📝','Report an Absence'],['FAMILY','scheduling','🗓️','Schedule'],['FAMILY','academic-planning','🎓','Academic Planning'],['FAMILY','registration','📝','Registration'],['FAMILY','calendar','📅','Calendar'],['FAMILY','notifications','🔔','Notifications'],['FAMILY','formscenter','📝','Forms'],['FAMILY','conferences','📅','Conferences'],['FAMILY','clubs','🎭','Clubs & Activities'],['FAMILY','emergency','🚨','Emergency Status'],['FAMILY','campus-id-parking','🪪','ID & Parking'],['FAMILY','campus-communications','📣','Announcements'],['FAMILY','campus-library','📚','Library'],['FAMILY','campus-finance','💵','Fees'],['FAMILY','campus-transportation','🚌','Bus'],['FAMILY','campus-meals','🥗','Meals'],['FAMILY','finance','💳','Fees'],['FAMILY','food','🍽️','Food Service'],['FAMILY','communication','💬','Messages']
    ],
    counselor:[
      ['COUNSELING','dashboard','⌂','Dashboard'],['COUNSELING','students','👤','Students'],['COUNSELING','scheduling','🗓️','Scheduling'],['COUNSELING','academic-planning','🎓','Academic Planning'],['COUNSELING','course-requests','📝','Course Requests'],['COUNSELING','hallpasses','🚶','Hall Passes'],['COUNSELING','counseling','🎓','Counseling'],['COUNSELING','special','🧩','Special Programs'],['COUNSELING','clubs','🎭','Clubs & Activities'],['COUNSELING','formscenter','📝','Forms Center'],['COUNSELING','assets','💻','Devices & Lockers'],['COUNSELING','emergency','🚨','Emergency'],['COUNSELING','campus-communications','📣','Announcements'],['COUNSELING','campus-analytics','📉','Analytics Plus'],['COUNSELING','calendar','📅','Calendar'],['COUNSELING','registration','📝','Registration'],['COUNSELING','reporting','📈','Reports']
    ],
    nurse:[['HEALTH','dashboard','⌂','Dashboard'],['HEALTH','students','👤','Students'],['HEALTH','health','🏥','Health Office'],['HEALTH','emergency','🚨','Emergency']],
    finance:[['FINANCE','dashboard','⌂','Dashboard'],['FINANCE','students','👤','Students'],['FINANCE','finance','💳','Fees & Payments'],['FINANCE','campus-finance','💵','Fees Plus'],['FINANCE','campus-analytics','📉','Analytics Plus'],['FINANCE','reporting','📈','Reports']],
    transportation:[['TRANSPORTATION','dashboard','⌂','Dashboard'],['TRANSPORTATION','students','👤','Students'],['TRANSPORTATION','transportation','🚌','Transportation'],['TRANSPORTATION','campus-transportation','🚌','Routes & Assignments']],
    food:[['FOOD SERVICE','dashboard','⌂','Dashboard'],['FOOD SERVICE','students','👤','Students'],['FOOD SERVICE','food','🍽️','Food Service'],['FOOD SERVICE','campus-meals','🥗','Meal Accounts']],
    coach:[['TEAM','dashboard','⌂','Team Dashboard'],['TEAM','activities','⚽','My Team']],
    substitute:[['SUBSTITUTE','dashboard','⌂','Today’s Coverage'],['SUBSTITUTE','substitutes','🧑‍🏫','Coverage Details']]
  };
  Object.entries(expected).forEach(([r,items])=>items.forEach(x=>ensure(r,...x)));
  // Remove duplicate page IDs after enforcing the complete surface.
  Object.keys(NAV).forEach(r=>{const seen=new Set();NAV[r]=NAV[r].filter(x=>!seen.has(x[1])&&(seen.add(x[1])||true));});

  const directory=[
    ['Academics','Students, staff, courses, sections, enrollment, gradebook, assignments, attendance, academic planning, course requests, GPA settings, custom academic year, Summer School, master scheduling and custom special-day periods.'],
    ['Student services','Hall passes, behavior/referrals, counseling, health, special programs, clubs/activities, athletics registration/team cuts and emergency accountability/reunification.'],
    ['Family workflows','Parent attendance reporting, medical/doctor-note attachments, excused/unexcused review, conferences, forms, fees, meals, transportation and announcements.'],
    ['Operations','Forms Center, devices, lockers, IDs, parking, library, inventory, announcements, analytics, finance, bus routes, meal accounts, substitute coverage and audit/security tools.'],
    ['Schedule intelligence','School closures, persistent closure alerts, teacher full-year schedule, student school-year schedule, Summer School enrollment, smart assignment due dates and custom special-day period/time builders.'],
    ['Emergency','Real incidents or drills, whole-class teacher accountability, automatic absent carryover, staff accountability and verified reunification release.']
  ];
  window.featureDirectoryPage=function(){
    activePage='feature-directory';
    const rows=(NAV.admin||[]).filter(x=>x[1]!=='feature-directory').map(x=>`<button class="activity-card" style="text-align:left;cursor:pointer" onclick="showPage('${String(x[1]).replace(/'/g,"\\'")}')"><span class="student-sub">${x[0]}</span><h3 style="margin:5px 0">${x[2]} ${x[3]}</h3><span class="student-sub">Open this ScholarSync area →</span></button>`).join('');
    $('#content').innerHTML=`<div class="pagebar"><div><h1>Feature Directory</h1><p>Complete cumulative ScholarSync feature surface. Use this page to verify and open every administrator area.</p></div><span class="badge success">${(NAV.admin||[]).length-1} admin pages visible</span></div><div class="activity-grid">${directory.map(x=>`<div class="activity-card"><h3>${x[0]}</h3><p>${x[1]}</p></div>`).join('')}</div><div class="panel" style="margin-top:16px"><div class="panel-head"><div><h3>All Admin Pages</h3><small>If a feature is in the cumulative build, it is surfaced here.</small></div></div><div class="panel-body"><div class="activity-grid">${rows}</div></div></div>`;
  };
  if(typeof ssRegisterPageRoute==='function') ssRegisterPageRoute('feature-directory',()=>featureDirectoryPage(),['admin']);

  // Rebuild nav once at the end of module loading so newly restored entries appear immediately.
  if(window.user && typeof window.buildNav==='function') buildNav();
})();
