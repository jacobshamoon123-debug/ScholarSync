// Reliability repair: final grades, grading scale, and seating chart.
function showFeatureError(message){const el=document.querySelector('#modalContent');if(el){let box=el.querySelector('.feature-error');if(!box){box=document.createElement('div');box.className='feature-error';el.prepend(box)}box.textContent=message||'Something went wrong'}else toastMsg(message||'Something went wrong')}

async function openGradingScaleSetup(){
  if(role!=='admin')return toastMsg('Only an administrator can change the district grading scale');
  try{
    const r=await api('/api/grading-scale');
    window.editScale={name:r.name||'A-F with +/-',mode:r.mode||'plus_minus',scale:JSON.parse(JSON.stringify(r.scale||[]))};
    renderGradingScaleSetup();
  }catch(e){openModal('District Grading Scale',`<div class="feature-error">${esc(e.message||'Could not load grading scale')}</div>`)}
}
function renderGradingScaleSetup(){
  const x=window.editScale||{name:'A-F',mode:'af',scale:[]};
  openModal('District Grading Scale',`<div class="callout"><b>School-wide grading scale.</b> This controls gradebook letters, final grades, report cards, and transcripts.</div>
  <div class="scale-preset-grid"><button class="btn outline" onclick="presetScale('af')">A–F</button><button class="btn outline" onclick="presetScale('plus_minus')">A–F with +/−</button><button class="btn outline" onclick="presetScale('pass_fail')">Pass / Fail</button><button class="btn outline" onclick="window.editScale.mode='custom';renderGradingScaleSetup()">Custom</button></div>
  <div class="form"><label class="full"><span>Scale name</span><input value="${esc(x.name)}" oninput="window.editScale.name=this.value"></label></div>
  <div style="margin-top:14px"><div class="scale-row"><b>Grade</b><b>Minimum %</b><b>GPA points</b><span></span></div>${(x.scale||[]).map((r,i)=>`<div class="scale-row"><input class="control" value="${esc(r.letter)}" oninput="window.editScale.scale[${i}].letter=this.value"><input class="control" type="number" min="0" max="100" step=".01" value="${Number(r.min)}" oninput="window.editScale.scale[${i}].min=Number(this.value)"><input class="control" type="number" step=".01" value="${Number(r.gpa||0)}" oninput="window.editScale.scale[${i}].gpa=Number(this.value)"><button class="btn mini danger" onclick="window.editScale.scale.splice(${i},1);renderGradingScaleSetup()">×</button></div>`).join('')}</div>
  <div id="scaleSaveError"></div><div class="row-actions"><button class="btn outline" onclick="window.editScale.scale.push({letter:'New',min:0,gpa:0});renderGradingScaleSetup()">+ Grade band</button><button id="saveScaleBtn" class="btn success" onclick="saveGradingScaleSetup()">Save Grading Scale</button></div>`)
}
async function saveGradingScaleSetup(){
  const btn=$('#saveScaleBtn');if(btn){btn.disabled=true;btn.textContent='Saving…'}
  try{
    const r=await api('/api/grading-scale',{method:'POST',body:JSON.stringify(window.editScale)});
    window.gradingScaleRows=r.scale||[];toastMsg('District grading scale saved');closeModal();
    if(window.currentGradeExport&&window.gradeCid)await openGrade(window.gradeCid,$(`.class-row[data-id="${window.gradeCid}"]`));
  }catch(e){showFeatureError(e.message||'Could not save grading scale');if(btn){btn.disabled=false;btn.textContent='Save Grading Scale'}}
}

async function openFinalizeGrades(){
  const cid=Number(window.gradeCid||gradeCid||0);
  if(!cid||!window.currentGradeExport)return toastMsg('Open a class first');
  try{
    const [cfg,existing]=await Promise.all([api('/api/grading-config?class_id='+cid),api('/api/final-grades?class_id='+cid)]);
    window.finalizeConfig=cfg.config&&cfg.config.semesters?cfg.config:defaultGradingConfig();
    window.finalizeExisting=existing||[];window.finalizePeriod=window.finalizePeriod&&window.finalizeConfig.semesters.some(x=>x.key===window.finalizePeriod)?window.finalizePeriod:(window.finalizeConfig.semesters[0]?.key||'');
    renderFinalizeGrades();
  }catch(e){openModal('Finalize Grades',`<div class="feature-error">${esc(e.message||'Could not load final grades')}</div>`)}
}
function renderFinalizeGrades(){
  const sem=window.finalizeConfig?.semesters?.find(x=>x.key===window.finalizePeriod)||window.finalizeConfig?.semesters?.[0];
  if(!sem)return openModal('Finalize Grades','<div class="feature-error">Set up at least one grading period first.</div>');
  const roster=window.currentGradeExport?.roster||[],totals=window.currentGradeExport?.totals||[];
  openModal('Finalize Grades',`<div class="error"><b>Important:</b> Finalized grades become visible to students and parents and appear on report cards.</div>
  <div class="form"><label class="full"><span>Grading period</span><select onchange="window.finalizePeriod=this.value;renderFinalizeGrades()">${window.finalizeConfig.semesters.map(x=>`<option value="${esc(x.key)}" ${x.key===sem.key?'selected':''}>${esc(x.name)}</option>`).join('')}</select></label></div>
  <div class="table-wrap final-grade-table"><table><thead><tr><th>Student</th>${sem.components.map(c=>`<th>${esc(c.name)}<span class="student-sub">${Number(c.weight)}%</span></th>`).join('')}<th>Calculated</th><th>Override</th><th>Status</th></tr></thead><tbody>${roster.map(st=>{const t=totals.find(x=>Number(x.id)===Number(st.id)),old=(window.finalizeExisting||[]).find(x=>Number(x.student_id)===Number(st.id)&&x.grading_key===sem.key),base=t?.pct==null?'':Number(t.pct).toFixed(2);return `<tr data-final-student="${st.id}"><td><b>${esc(st.name)}</b><span class="student-sub">${esc(st.student_number||'')}</span></td>${sem.components.map(c=>`<td><input class="control final-component" data-key="${esc(c.key)}" data-weight="${Number(c.weight)}" type="number" min="0" max="100" step=".01" value="${old?.component_grades?.[c.key]??(c.key==='final_exam'?'':base)}" oninput="recalculateFinalRow(this.closest('tr'))"></td>`).join('')}<td><b class="calculated-final">—</b></td><td><input class="control final-override" type="number" min="0" max="100" step=".01" value="${old?.final_grade??''}" placeholder="Optional"></td><td><span class="badge ${old?.status==='Final'?'':'warn'}">${esc(old?.status||'Draft')}</span></td></tr>`}).join('')}</tbody></table></div>
  <div id="finalizeError"></div><div class="finalize-actions" style="margin-top:14px"><span class="final-status-note">${roster.length} student grades ready for review.</span><div class="row-actions"><button class="btn outline" onclick="previewFinalGradeReport()">Preview Report Card</button>${role==='admin'?`<button class="btn outline" onclick="reopenFinalGrades('${esc(sem.key)}')">Reopen</button>`:''}<button id="finalizeMainBtn" class="btn primary" onclick="confirmFinalizeGrades('${esc(sem.key)}','${esc(sem.name).replace(/'/g,"\\'")}')">Finalize ${esc(sem.name)}</button></div></div>`);
  $$('[data-final-student]').forEach(recalculateFinalRow)
}
function collectFinalGradeRows(){return $$('[data-final-student]').map(r=>{const comps={};r.querySelectorAll('.final-component').forEach(i=>comps[i.dataset.key]=i.value===''?null:Number(i.value));const exam=[...r.querySelectorAll('.final-component')].find(i=>i.dataset.key==='final_exam');const calculated=r.dataset.calculated===''?null:Number(r.dataset.calculated);const override=r.querySelector('.final-override').value;return {student_id:Number(r.dataset.finalStudent),component_grades:comps,final_exam_grade:exam&&exam.value!==''?Number(exam.value):null,calculated_grade:calculated,final_grade:override!==''?Number(override):calculated}})}
function confirmFinalizeGrades(key,name){
  const rows=collectFinalGradeRows();if(!rows.length)return toastMsg('No student grades were found to finalize');
  window.pendingFinalization={key,name,rows};
  openModal('Confirm Finalization',`<div class="error"><b>Finalize grades for ${esc(name)}?</b><p>${rows.length} student grades will be locked and published to students, parents, report cards, and transcripts.</p></div><div id="confirmFinalizeError"></div><div class="row-actions"><button class="btn outline" onclick="renderFinalizeGrades()">Cancel</button><button id="confirmFinalizeBtn" class="btn danger" onclick="submitFinalGrades()">Yes, Finalize ${esc(name)}</button></div>`)
}
async function submitFinalGrades(){
  const state=window.pendingFinalization;if(!state?.rows?.length)return toastMsg('No grades to finalize');
  const btn=$('#confirmFinalizeBtn');if(btn){btn.disabled=true;btn.textContent='Finalizing…'}
  try{
    const r=await api('/api/final-grades/finalize',{method:'POST',body:JSON.stringify({class_id:Number(window.gradeCid||gradeCid),grading_key:state.key,grading_name:state.name,rows:state.rows})});
    window.pendingFinalization=null;toastMsg(`${r.finalized||state.rows.length} grades finalized`);window.finalizePeriod=state.key;await openFinalizeGrades();
  }catch(e){showFeatureError(e.message||'Could not finalize grades');if(btn){btn.disabled=false;btn.textContent='Try Finalization Again'}}
}

async function openSeatingChart(){
  let cid=Number(window.attCid||0);
  if(!cid){const first=(cache.classes||[])[0];cid=Number(first?.id||0);if(!cid)return toastMsg('No class sections are available');window.attCid=cid}
  try{
    const date=$('#attDate')?.value||(typeof ssTodayISO==='function'?ssTodayISO():new Date().toLocaleDateString('en-CA'));
    const [chart,roster,recs]=await Promise.all([api('/api/seating-chart?class_id='+cid),api('/api/roster?class_id='+cid),api(`/api/attendance?class_id=${cid}&date=${date}`)]);
    const recMap=Object.fromEntries((recs||[]).map(x=>[Number(x.student_id),x.status]));const saved=(chart.layout||[]).map(Number),ids=(roster||[]).map(x=>Number(x.id));
    seatingState={class_id:cid,date,rows_count:Number(chart.rows_count||5),columns_count:Number(chart.columns_count||6),order:[...saved.filter(x=>ids.includes(x)),...ids.filter(x=>!saved.includes(x))],roster:Object.fromEntries((roster||[]).map(x=>[Number(x.id),x])),statuses:recMap};renderSeatingChart();
  }catch(e){openModal('Seating Chart',`<div class="feature-error">${esc(e.message||'Could not load seating chart')}</div>`)}
}
function renderSeatingChart(){const s=seatingState;openModal('Seating Chart',`<div class="att-toolbar"><div class="row-actions"><label>Rows <input class="control small-number" type="number" min="1" max="12" value="${s.rows_count}" onchange="seatingState.rows_count=Number(this.value);renderSeatingChart()"></label><label>Columns <input class="control small-number" type="number" min="1" max="12" value="${s.columns_count}" onchange="seatingState.columns_count=Number(this.value);renderSeatingChart()"></label></div><div class="row-actions"><button class="btn outline" onclick="randomizeSeating()">Randomize</button><button class="btn outline" onclick="printSeatingChart()">Print</button><button id="saveSeatBtn" class="btn success" onclick="saveSeatingChart(true)">Save Chart & Attendance</button></div></div><div id="seatGrid" class="seat-grid" style="grid-template-columns:repeat(${s.columns_count},minmax(120px,1fr))">${s.order.map((id,i)=>{const st=s.roster[id],status=s.statuses[id]||'';return `<div class="seat-card" draggable="true" data-id="${id}" ondragstart="seatDragStart(event)" ondragover="event.preventDefault()" ondrop="seatDrop(event)"><span class="seat-number">Seat ${i+1}</span><b>${esc(st.name)}</b><small>${esc(st.student_number||'')}</small><select onchange="seatingState.statuses[${id}]=this.value"><option value="" ${!status?'selected':''}>Unmarked</option><option value="P" ${status==='P'?'selected':''}>Present</option><option value="TE" ${status==='TE'?'selected':''}>Tardy — Excused</option><option value="TU" ${status==='TU'?'selected':''}>Tardy — Unexcused</option><option value="AE" ${status==='AE'?'selected':''}>Absent — Excused</option><option value="AU" ${status==='AU'?'selected':''}>Absent — Unexcused</option><option value="SA" ${status==='SA'?'selected':''}>School Activity</option><option value="N" ${status==='N'?'selected':''}>Nurse</option></select></div>`}).join('')}</div><p class="grade-help">Attendance → choose a class → Seating Chart. Drag cards to move students.</p>`)}
async function saveSeatingChart(saveAttendanceToo=false){const btn=$('#saveSeatBtn');if(btn){btn.disabled=true;btn.textContent='Saving…'}try{await api('/api/seating-chart',{method:'POST',body:JSON.stringify({class_id:seatingState.class_id,rows_count:seatingState.rows_count,columns_count:seatingState.columns_count,layout:seatingState.order})});if(saveAttendanceToo){const records=seatingState.order.map(id=>({student_id:id,status:seatingState.statuses[id]||'',minutes_late:0,note:''}));await api('/api/attendance',{method:'POST',body:JSON.stringify({class_id:seatingState.class_id,date:seatingState.date,records})})}toastMsg('Seating chart and attendance saved');closeModal();if(window.attCid)await openAttendance(window.attCid,$(`.class-row[data-id="${window.attCid}"]`))}catch(e){showFeatureError(e.message||'Could not save seating chart');if(btn){btn.disabled=false;btn.textContent='Save Chart & Attendance'}}}

// Make all three tools unmissable and available from their correct pages.
const __reliableGradebook=gradebook;gradebook=async function(){await ensureGradingScale();await __reliableGradebook();const tools=$('.gradebook-main-tools');if(tools&&role==='admin'&&!tools.querySelector('[data-scale-v2]'))tools.insertAdjacentHTML('afterbegin','<button data-scale-v2 class="btn outline" onclick="openGradingScaleSetup()">Grading Scale</button>')};
const __reliableOpenGrade=openGrade;openGrade=async function(cid,el){window.gradeCid=Number(cid);await ensureGradingScale();await __reliableOpenGrade(cid,el);const actions=$('#gradeArea .gradebook-toolbar .page-actions');if(actions&&role==='admin'&&!actions.querySelector('[data-scale-v2]'))actions.insertAdjacentHTML('afterbegin','<button data-scale-v2 class="btn outline" onclick="openGradingScaleSetup()">Grading Scale</button>')};
const __reliableAttendance=attendance;attendance=async function(){await __reliableAttendance();const actions=$('.pagebar .page-actions');if(actions&&!actions.querySelector('[data-seat-page]'))actions.insertAdjacentHTML('afterbegin','<button data-seat-page class="btn primary" onclick="openSeatingChart()">Seating Chart</button>')};
const __reliableOpenAttendance=openAttendance;openAttendance=async function(cid,el){window.attCid=Number(cid);await __reliableOpenAttendance(cid,el);const q=$('#attRoster .att-quick-actions');if(q&&!q.querySelector('[data-seat-v2]'))q.insertAdjacentHTML('afterbegin','<button data-seat-v2 class="btn primary" onclick="openSeatingChart()">Seating Chart</button>')};
