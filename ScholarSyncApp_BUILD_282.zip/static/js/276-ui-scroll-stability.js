/* ScholarSync Build 276 - UI scroll stability
   Prevents toolbar/modal actions from inheriting stale scroll positions. */
(()=>{
  const q=s=>document.querySelector(s);
  let heldContentScroll=null;

  function resetModalScroll(){
    const box=q('#modal .modal-box');
    const body=q('#modalContent');
    if(box) box.scrollTop=0;
    if(body) body.scrollTop=0;
  }

  // Every newly opened dialog must start at its top, never where the previous dialog was scrolled.
  if(typeof window.openModal==='function'){
    const originalOpen=window.openModal;
    window.openModal=function(title,body){
      originalOpen(title,body);
      resetModalScroll();
      requestAnimationFrame(resetModalScroll);
    };
  }
  if(typeof window.closeModal==='function'){
    const originalClose=window.closeModal;
    window.closeModal=function(){
      originalClose();
      resetModalScroll();
    };
  }

  // Toolbar/action buttons should not move the page just because they open/close a dialog
  // or redraw a workspace. Navigation buttons are intentionally excluded.
  document.addEventListener('pointerdown',e=>{
    const b=e.target.closest('button');
    const content=q('#content');
    if(!b||!content) return;
    if(b.closest('#nav') || b.dataset.page) return;
    heldContentScroll=content.scrollTop;
  },true);
  document.addEventListener('click',e=>{
    const b=e.target.closest('button');
    if(!b || b.closest('#nav') || b.dataset.page || heldContentScroll===null) return;
    const y=heldContentScroll;
    heldContentScroll=null;
    requestAnimationFrame(()=>{
      const content=q('#content');
      if(content) content.scrollTop=y;
    });
  },true);

  // Changing major pages should always begin at the top of the workspace.
  if(typeof window.showPage==='function'){
    const originalShowPage=window.showPage;
    window.showPage=async function(...args){
      const content=q('#content');
      if(content) content.scrollTop=0;
      const result=await originalShowPage.apply(this,args);
      if(content) content.scrollTop=0;
      return result;
    };
  }
})();
