/* ScholarSync Refactor Phase 3 — canonical core academic page routes.
   These routes bypass the legacy chained showPage wrappers for the highest-use
   academic pages. The page functions themselves remain unchanged in this phase. */
(function(){
  if(typeof ssRegisterPageRoute!=='function') return;

  let navigationToken=0;
  const runPage=(id,handler)=>async function(){
    const token=++navigationToken;
    activePage=id;
    ssActiveNav?.(id);
    const nav=(NAV[role]||[]).find(x=>x[1]===id);
    const crumb=document.querySelector('#crumb');
    if(crumb) crumb.textContent=nav?.[3]||id;
    try{
      const result=await handler();
      // A slower earlier navigation must never steal active navigation state.
      if(token===navigationToken){ activePage=id; ssActiveNav?.(id); }
      return result;
    }catch(e){
      if(token===navigationToken){
        const content=document.querySelector('#content');
        if(content) content.innerHTML=`<div class="pagebar"><div><h1>Could not open page</h1></div></div><div class="error">${esc(e?.message||'Unexpected error')}</div>`;
      }
    }
  };

  ssRegisterPageRoute('dashboard',runPage('dashboard',()=>{ ssDashboardHTMLReady=false; return window.dashboard(); }),
    ['admin','teacher','student','parent','counselor','nurse','finance','transportation','food','coach','substitute']);
  ssRegisterPageRoute('classes',runPage('classes',()=>window.classesPage()),['admin']);
  ssRegisterPageRoute('gradebook',runPage('gradebook',()=>window.gradebook()),['admin','teacher','student','parent']);
  ssRegisterPageRoute('scheduling',runPage('scheduling',()=>window.scheduler()),['admin','student','parent','counselor']);
  ssRegisterPageRoute('academic-planning',runPage('academic-planning',()=>window.academicPlanningPage()),['admin','counselor','student','parent']);

  // Attendance is registered by the role-guard module loaded after this file.
  window.SS_ACADEMIC_ROUTE_VERSION='phase3';
})();
