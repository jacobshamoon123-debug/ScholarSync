/* ScholarSync Build 273 — Smart Course Change Scheduling Engine */
(function(){
 const E=x=>typeof esc==='function'?esc(x):String(x??'');
 window.ss273CourseOptions=[];
 function ensurePreview(form){
   let box=document.getElementById('ss273SmartFitPreview');
   if(box)return box;
   const sel=form?.to_class_id;if(!sel)return null;
   box=document.createElement('div');box.id='ss273SmartFitPreview';box.className='full callout';
   box.style.marginTop='8px';box.innerHTML='<b>Smart schedule check</b><br>Select a requested class to see schedule fit, seats, and prerequisites.';
   const label=sel.closest('label');if(label)label.insertAdjacentElement('afterend',box);else sel.parentElement?.appendChild(box);
   return box;
 }
 function renderFit(form){
   const box=ensurePreview(form);if(!box)return;
   const id=Number(form?.to_class_id?.value||0),c=(window.ss273CourseOptions||[]).find(x=>Number(x.id)===id);
   if(!c){box.innerHTML='<b>Smart schedule check</b><br>Select a requested class to see schedule fit, seats, and prerequisites.';return}
   const good=!!c.viable,conflict=c.schedule_conflict?`⚠ Conflicts with ${E(c.conflict_class||'another class')}`:'✓ No schedule conflicts';
   const seats=Number(c.seats_remaining||0)>0?`✓ ${Number(c.seats_remaining)} seat${Number(c.seats_remaining)===1?'':'s'} remaining`:'⚠ Class is full';
   const prereq=c.prerequisites_ok?'✓ Prerequisites met':'⚠ Prerequisite not met';
   const period=c.same_period?'✓ Same period — minimal schedule disruption':`Period ${E(c.period||'—')}`;
   box.innerHTML=`<div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start"><div><b>${good?'Recommended schedule fit':'Needs review'}</b><div style="margin-top:5px">${conflict} · ${seats} · ${prereq}</div><div style="margin-top:4px">${period}</div>${(c.blockers||[]).length?`<div style="margin-top:5px;color:var(--red)">${E((c.blockers||[]).join(' · '))}</div>`:''}</div><span class="badge ${good?'success':'danger'}">${E(c.fit_label||'Fit')} · ${Number(c.fit_score||0)}/100</span></div>`;
 }
 window.ss272RefreshCourseChangeOptions=async function(form,sid){
   if(!form)return;
   const type=form.request_type?.value||'Level Change',from=form.from_class_id?.value||'',to=form.to_class_id;
   if(!to)return;if(type==='Drop Course')return;
   if((type==='Level Change'||type==='Transfer')&&!from){to.disabled=false;to.innerHTML='<option value="">Select a current class first</option>';window.ss273CourseOptions=[];renderFit(form);return}
   to.disabled=true;to.innerHTML='<option value="">Analyzing schedule, seats, and prerequisites…</option>';
   try{
     const url='/api/course-change-options?student_id='+encodeURIComponent(sid)+'&request_type='+encodeURIComponent(type)+'&from_class_id='+encodeURIComponent(from||'');
     const options=await api(url);window.ss273CourseOptions=Array.isArray(options)?options:[];to.disabled=false;
     if(!window.ss273CourseOptions.length){to.innerHTML='<option value="">No matching classes are currently available</option>';renderFit(form);return}
     to.innerHTML='<option value="">Choose requested class</option>'+window.ss273CourseOptions.map(c=>{
       const icon=c.viable?(c.fit_label==='Best fit'?'★':'✓'):'⚠';
       const status=c.viable?`${c.fit_label} · ${Number(c.seats_remaining||0)} seats`:`Blocked · ${(c.blockers||[]).join(', ')}`;
       return `<option value="${c.id}" ${c.viable?'':'disabled'}>${icon} ${E(status)} · ${E(c.term||'')} · ${E(c.course_code||'')} ${E(c.name||c.course_name||'')} ${E(c.section||'')} · ${E(c.course_level||'Regular')} · ${E(c.period||'')}</option>`
     }).join('');
     to.onchange=()=>renderFit(form);ensurePreview(form);renderFit(form);
   }catch(err){to.disabled=false;to.innerHTML='<option value="">Could not load matching classes</option>';toastMsg(err.message||'Could not load matching classes')}
 };
 const priorType=window.ss272CourseChangeTypeChanged;
 window.ss272CourseChangeTypeChanged=async function(form,sid){
   if(typeof priorType==='function')await priorType(form,sid);else await ss272RefreshCourseChangeOptions(form,sid);
   ensurePreview(form);renderFit(form);
 };
 // Add the preview immediately when the student request page is rendered.
 const priorCenter=window.courseTransferCenter;
 if(typeof priorCenter==='function')window.courseTransferCenter=async function(...args){const r=await priorCenter(...args);setTimeout(()=>{const f=document.getElementById('ss272CourseChangeForm');if(f){ensurePreview(f);ss272RefreshCourseChangeOptions(f,args[0]||user?.student_id||0)}},0);return r};
})();
