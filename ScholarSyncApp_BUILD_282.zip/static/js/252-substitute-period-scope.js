(function(){
  function esc(v){ return typeof e==='function'?e(v??''):String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

  window.newSubAssignment=async function(){
    const staff=(window._subStaff&&window._subStaff.length)?window._subStaff:await api('/api/substitute/staff');
    const subs=(staff||[]).filter(x=>['substitute','sub','substitute teacher'].includes(String(x.role||'').toLowerCase())||String(x.role||'').toLowerCase().includes('teacher'));
    const teachers=(staff||[]).filter(x=>String(x.role||'').toLowerCase().includes('teacher'));
    const today=(typeof window.ssSchoolDate==='string'&&window.ssSchoolDate)?window.ssSchoolDate:new Date().toLocaleDateString('en-CA');
    openModal('Assign Substitute',`<form class="form" id="ssSubAssignForm" onsubmit="createSubAssignment(event)">
      <label><span>Substitute / covering teacher *</span><select name="substitute_staff_id" id="ssSubCandidate" required onchange="ssCheckSubCandidateAvailability()"><option value="">Choose staff member</option>${subs.map(x=>`<option value="${x.id}">${esc(x.name)}${String(x.role||'').toLowerCase().includes('teacher')&&!['substitute','sub','substitute teacher'].includes(String(x.role||'').toLowerCase())?' — Teacher':''}</option>`).join('')}</select></label>
      <label><span>Teacher being covered *</span><select name="teacher_staff_id" id="ssSubTeacher" required onchange="ssLoadSubCoverageClasses()"><option value="">Choose teacher</option>${teachers.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join('')}</select></label>
      <label><span>Coverage date *</span><input name="start_date" id="ssSubDate" type="date" value="${esc(today)}" required onchange="ssLoadSubCoverageClasses()"></label>
      <label><span>Coverage</span><select name="coverage_mode" id="ssSubScope" onchange="ssToggleSubScope()"><option value="all">All classes that day</option><option value="selected">Selected classes / periods</option></select></label>
      <label class="full" id="ssSubEndWrap"><span>Continue through (optional)</span><input name="end_date" id="ssSubEnd" type="date"><small>Leave blank for one day. Multi-day coverage uses all classes each day.</small></label>
      <div class="full" id="ssSubClassPicker" style="display:none"></div>
      <label class="full"><span>Reason</span><input name="reason" placeholder="Meeting, appointment, illness, conference..."></label>
      <label class="full"><span>Administrative notes</span><textarea name="admin_notes" rows="3"></textarea></label>
      <div class="full" id="ssSubAvailability"></div><div class="full callout">Choose <b>Selected classes / periods</b> when the teacher only needs coverage for part of the day. Regular teachers cannot be assigned if one of their own classes overlaps a selected coverage period.</div>
      <div class="full"><button class="btn primary">Create Coverage</button></div>
    </form>`);
  };

  window.ssToggleSubScope=function(){
    const scope=document.getElementById('ssSubScope')?.value||'all';
    const picker=document.getElementById('ssSubClassPicker');
    const endWrap=document.getElementById('ssSubEndWrap');
    if(picker) picker.style.display=scope==='selected'?'block':'none';
    if(endWrap) endWrap.style.display=scope==='selected'?'none':'block';
    if(scope==='selected'){
      const end=document.getElementById('ssSubEnd'); if(end) end.value='';
      ssLoadSubCoverageClasses();
      ssCheckSubCandidateAvailability();
    }
  };

  window.ssLoadSubCoverageClasses=async function(){
    const teacher=document.getElementById('ssSubTeacher')?.value;
    const day=document.getElementById('ssSubDate')?.value;
    const picker=document.getElementById('ssSubClassPicker');
    if(!picker||!teacher||!day) return;
    picker.innerHTML='<div class="empty-modern">Loading classes for this date…</div>';
    try{
      const d=await api(`/api/substitute/teacher-day?teacher_staff_id=${encodeURIComponent(teacher)}&date=${encodeURIComponent(day)}`);
      const classes=d.classes||[];
      picker.innerHTML=`<div class="panel" style="margin:0"><div class="panel-head"><div><h3>Classes meeting ${esc(day)}</h3><small>Select one or several periods.</small></div>${classes.length?'<button class="btn mini outline" type="button" onclick="document.querySelectorAll(\'.ss-sub-class-check\').forEach(x=>x.checked=true)">Select all</button>':''}</div><div class="panel-body">${classes.map(c=>`<label style="display:flex;gap:12px;align-items:center;padding:11px 4px;border-bottom:1px solid var(--border,#e6e8ec);cursor:pointer"><input class="ss-sub-class-check" type="checkbox" value="${c.id}" onchange="ssCheckSubCandidateAvailability()" style="width:18px;height:18px"><div><b>Period ${esc(c.period||'—')} — ${esc(c.name||c.course_name||'Class')}</b><div class="student-sub">${esc(c.start_time||'')}–${esc(c.end_time||'')}${c.room?' · Room '+esc(c.room):''}</div></div></label>`).join('')||'<div class="empty-modern">This teacher has no classes scheduled on this date.</div>'}</div></div>`;
    }catch(err){ picker.innerHTML=`<div class="callout">Could not load classes: ${esc(err?.message||err)}</div>`; }
  };

  window.ssCheckSubCandidateAvailability=async function(){
    const candidate=document.getElementById('ssSubCandidate')?.value;
    const teacher=document.getElementById('ssSubTeacher')?.value;
    const day=document.getElementById('ssSubDate')?.value;
    const box=document.getElementById('ssSubAvailability');
    if(!box) return;
    if(!candidate||!teacher||!day){ box.innerHTML=''; return; }
    const scope=document.getElementById('ssSubScope')?.value||'all';
    const ids=scope==='selected'?[...document.querySelectorAll('.ss-sub-class-check:checked')].map(x=>Number(x.value)):[];
    try{
      const q=new URLSearchParams({substitute_staff_id:candidate,teacher_staff_id:teacher,date:day,coverage_mode:scope,class_ids:ids.join(',')});
      const d=await api('/api/substitute/availability?'+q.toString());
      box.innerHTML=d.available?'<div class="callout" style="border-left-color:#16a34a"><b>Available</b> — no class conflict for this coverage.</div>':`<div class="callout" style="border-left-color:#dc2626"><b>Unavailable</b> — ${esc(d.reason||'This teacher has a class at that time.')}</div>`;
    }catch(err){ box.innerHTML=''; }
  };

  window.createSubAssignment=async function(ev){
    ev.preventDefault();
    const fd=new FormData(ev.target), d=Object.fromEntries(fd);
    d.end_date=d.end_date||d.start_date;
    if((d.coverage_mode||'all')==='selected'){
      d.selected_class_ids=[...document.querySelectorAll('.ss-sub-class-check:checked')].map(x=>Number(x.value));
      if(!d.selected_class_ids.length){ toastMsg('Choose at least one class/period'); return; }
      d.end_date=d.start_date;
    }else d.selected_class_ids=[];
    try{
      await api('/api/substitute/assignments',{method:'POST',body:JSON.stringify(d)});
      closeModal(); toastMsg(d.coverage_mode==='selected'?'Period-specific substitute assigned':'Substitute assigned'); adminSubCenter();
    }catch(err){ toastMsg(err?.message||'Could not create substitute coverage'); }
  };

  // A regular teacher assigned as the covering substitute should have the same
  // class/attendance controls as a dedicated substitute for that assignment.
  window.openSubClass=async function(aid,cid,day){
    const d=await api(`/api/substitute/class?assignment_id=${aid}&class_id=${cid}&date=${encodeURIComponent(day)}`),cov=d.coverage||{},a=d.assignment||{};
    const sid=Number(currentUser?.staff_id||0), actingSub=role==='substitute'||role==='admin'||(role==='teacher'&&Number(a.substitute_staff_id)===sid&&Number(a.teacher_staff_id)!==sid);
    $('#content').innerHTML=`<div class="pagebar"><div><button class="btn ghost" onclick="${role==='teacher'&&actingSub?'substituteCenter()':`renderSubDay('${esc(day)}',false)`}">← Coverage</button><h1>${esc(d.class.name)}</h1><p>Period ${esc(d.class.period||'—')} · Room ${esc(d.class.room||'—')}</p></div><div class="page-actions"><button class="btn outline" onclick="showSubSeating(${aid},${cid},'${esc(day)}')">Seating Chart</button>${actingSub?`<button class="btn success" onclick="saveSubAttendance(${aid},${cid},'${esc(day)}')">Save Attendance</button>`:''}</div></div>${cov.lesson_plan?`<div class="panel"><div class="panel-head"><h3>Lesson Plan</h3></div><div class="panel-body"><div class="sub-plan">${esc(cov.lesson_plan)}</div>${cov.lesson_links?`<div class="callout"><b>Links / resources</b><br>${esc(cov.lesson_links)}</div>`:''}${cov.teacher_notes?`<div class="callout"><b>Teacher notes</b><br>${esc(cov.teacher_notes)}</div>`:''}</div></div>`:''}<div class="panel" style="margin-top:14px"><div class="panel-head"><h3>Roster & Attendance</h3><small>${esc(day)}</small></div><div class="panel-body" id="subRoster">${(d.roster||[]).map(r=>`<div class="sub-roster-row"><div><b>${esc(r.student_name)}</b><span class="student-sub">${esc(r.student_number)} · Grade ${esc(r.grade||'—')}</span></div><select class="control sub-att" data-sid="${r.student_id}" ${actingSub?'':'disabled'}><option value="">Unmarked</option>${[['P','Present'],['TE','Tardy Excused'],['TU','Tardy Unexcused'],['AE','Absent Excused'],['AU','Absent Unexcused'],['SA','School Activity'],['N','Nurse']].map(([v,l])=>`<option value="${v}" ${r.attendance_status===v?'selected':''}>${l}</option>`).join('')}</select><input class="control sub-min" data-sid="${r.student_id}" type="number" min="0" value="${Number(r.minutes_late||0)}" ${actingSub?'':'disabled'} title="Minutes tardy"><input class="control sub-note" data-sid="${r.student_id}" value="${esc(r.attendance_note||'')}" ${actingSub?'':'disabled'} placeholder="Note"></div>`).join('')}</div></div>${cov.substitute_notes?`<div class="panel" style="margin-top:14px"><div class="panel-head"><h3>Substitute Notes</h3></div><div class="panel-body"><div class="sub-plan">${esc(cov.substitute_notes)}</div></div></div>`:''}`;
  };
})();
