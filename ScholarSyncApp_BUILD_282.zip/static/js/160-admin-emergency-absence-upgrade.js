/* ScholarSync Admin Dashboard + Emergency Accountability + Daily Absence Workflow */
(function(){
  const escX = window.esc || (v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])));
  function addStyles(){
    if(document.getElementById('ss-att-emg-upgrade-css'))return;
    const st=document.createElement('style');st.id='ss-att-emg-upgrade-css';st.textContent=`
      .admin-hero{background:linear-gradient(135deg,#10263b,#214969 68%,#2e6a83);color:#fff;border-radius:22px;padding:24px;display:grid;grid-template-columns:minmax(0,1.6fr) minmax(250px,.7fr);gap:18px;align-items:center;margin-bottom:16px;box-shadow:0 18px 40px #10263b25}.admin-hero h1{font-size:30px;margin:4px 0}.admin-hero p{color:#d9e6ef;margin:0}.admin-live{display:flex;gap:9px;flex-wrap:wrap;margin-top:16px}.admin-live span{padding:7px 10px;background:#ffffff14;border:1px solid #ffffff25;border-radius:999px;font-size:11px;font-weight:800}.admin-hero-side{background:#ffffff10;border:1px solid #ffffff22;border-radius:16px;padding:16px}.admin-hero-side strong{font-size:28px;display:block}.admin-kpis{display:grid;grid-template-columns:repeat(6,minmax(120px,1fr));gap:10px;margin-bottom:16px}.admin-kpi{background:#fff;border:1px solid var(--line);border-radius:15px;padding:14px;min-height:103px}.admin-kpi small{color:var(--muted);font-weight:800}.admin-kpi strong{display:block;font-size:25px;margin:5px 0}.admin-kpi.alert{border-color:#efc3c6;background:#fffafa}.admin-kpi.warn{border-color:#ead9a7;background:#fffdf6}.admin-workgrid{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(300px,.7fr);gap:14px}.admin-action-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.admin-action{border:1px solid var(--line);background:#fff;border-radius:13px;padding:14px;text-align:left;cursor:pointer}.admin-action:hover{border-color:#9db8ca;box-shadow:0 8px 20px #14324b12}.admin-action b,.admin-action span{display:block}.admin-action span{font-size:11px;color:var(--muted);margin-top:4px}.attention-row{display:flex;justify-content:space-between;gap:12px;align-items:center;padding:11px 0;border-bottom:1px solid var(--line)}.attention-row:last-child{border-bottom:0}.absence-status{font-weight:850}.absence-status.Pending{color:#9a6700}.absence-status.Approved{color:#087443}.absence-status.Denied{color:#b42318}.all-day-absence-row{background:#fff7f7!important}.all-day-lock{display:inline-flex;margin-top:5px;padding:4px 7px;border-radius:999px;background:#ffe3e3;color:#a42f36;font-size:10px;font-weight:900}.emergency-class-tools{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:9px}.emergency-class-card{border:1px solid var(--line);border-radius:12px;background:#fff;padding:12px}.emergency-class-card b,.emergency-class-card span{display:block}.emergency-class-card span{font-size:11px;color:var(--muted);margin:3px 0 9px}.absence-layout{display:grid;grid-template-columns:minmax(0,1fr) 310px;gap:14px}.request-card{border:1px solid var(--line);background:#fff;border-radius:13px;padding:14px;margin-bottom:9px}.request-head{display:flex;justify-content:space-between;gap:10px}.request-actions{display:flex;gap:7px;flex-wrap:wrap;margin-top:10px}.absence-note{background:#eef6fb;border:1px solid #cee0ec;border-radius:10px;padding:10px;margin-top:8px;font-size:12px}.emergency-auto-note{background:#fff2d6;border:1px solid #ecd18d;border-radius:10px;padding:10px;margin-bottom:10px;font-size:12px}
      @media(max-width:1100px){.admin-kpis{grid-template-columns:repeat(3,1fr)}.admin-action-grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:800px){.admin-hero,.admin-workgrid,.absence-layout{grid-template-columns:1fr}.admin-kpis{grid-template-columns:repeat(2,1fr)}.admin-action-grid{grid-template-columns:1fr}}
    `;document.head.appendChild(st);
  }
  addStyles();

  // Navigation for the parent request workflow and the admin review queue.
  if(typeof ssAddNav==='function'){
    ssAddNav('admin','ACADEMICS','absence-requests','🗓️','Absence Requests','attendance');
    ssAddNav('parent','FAMILY','absence-requests','📝','Report an Absence','attendance');
  }
  if(typeof ssRegisterPageRoute==='function') ssRegisterPageRoute('absence-requests',()=>absenceRequestsPage(),['admin','parent']);

  const priorDashboard=window.dashboard;
  window.dashboard=async function(){
    if(role!=='admin') return priorDashboard();
    addStyles();activePage='dashboard';ssActiveNav?.('dashboard');
    const d=await api('/api/admin-dashboard');
    const emergency=d.emergency;
    const attTotal=(d.present||0)+(d.absent||0)+(d.tardy||0);
    const attPct=attTotal?Math.round((d.present||0)/attTotal*100):0;
    $('#content').innerHTML=`
      <div class="admin-hero">
        <div><small style="font-weight:900;letter-spacing:1.5px">DISTRICT COMMAND CENTER</small><h1>Good ${new Date().getHours()<12?'morning':new Date().getHours()<17?'afternoon':'evening'}, ${escX(user.display_name||user.username)}</h1><p>${new Date(d.date+'T12:00:00').toLocaleDateString([],{weekday:'long',month:'long',day:'numeric',year:'numeric'})} · Live school operations at a glance.</p><div class="admin-live"><span>● ${d.students} active students</span><span>${d.classes} published sections</span><span>${d.staff} active staff</span>${emergency?`<span style="background:${emergency.is_drill?'#a36a00':'#8f1d28'}">${emergency.is_drill?'🟡 DRILL':'🚨 ACTIVE'} ${escX(emergency.incident_type)}</span>`:'<span>✓ No active emergency</span>'}</div></div>
        <div class="admin-hero-side"><small>Attendance snapshot</small><strong>${attPct}%</strong><span>${d.present} present · ${d.absent} absent · ${d.tardy} tardy</span><div style="margin-top:12px"><button class="btn success" onclick="showPage('attendance')">Open Attendance</button></div></div>
      </div>
      ${emergency?`<div class="callout" style="border-color:#d96a72;background:#fff2f3"><b>${emergency.is_drill?'🟡 DRILL:':'🚨'} ${escX(emergency.title)}</b> ${emergency.is_drill?'is running as a drill.':'is active.'} <button class="btn mini danger" onclick="showPage('emergency')">Open Emergency Command</button></div>`:''}
      <div class="admin-kpis">
        <div class="admin-kpi"><small>All-day absences</small><strong>${d.daily_absent}</strong><span class="student-sub">Declared today</span></div>
        <div class="admin-kpi ${d.absence_pending?'warn':''}" onclick="showPage('absence-requests')" style="cursor:pointer"><small>Absence requests</small><strong>${d.absence_pending}</strong><span class="student-sub">Awaiting review</span></div>
        <div class="admin-kpi ${d.hallpasses_open?'warn':''}" onclick="showPage('hallpasses')" style="cursor:pointer"><small>Open hall passes</small><strong>${d.hallpasses_open}</strong><span class="student-sub">Requested / active</span></div>
        <div class="admin-kpi ${d.behavior_open?'alert':''}" onclick="showPage('behavior')" style="cursor:pointer"><small>Behavior cases</small><strong>${d.behavior_open}</strong><span class="student-sub">Open referrals</span></div>
        <div class="admin-kpi ${d.fees_open?'warn':''}" onclick="showPage('fees-payments')" style="cursor:pointer"><small>Open fees</small><strong>${d.fees_open}</strong><span class="student-sub">Student charges</span></div>
        <div class="admin-kpi ${d.library_overdue?'alert':''}" onclick="showPage('library')" style="cursor:pointer"><small>Library overdue</small><strong>${d.library_overdue}</strong><span class="student-sub">Items past due</span></div>
      </div>
      <div class="admin-workgrid">
        <section class="panel"><div class="panel-head"><div><h3>Administrator shortcuts</h3><small>Jump directly into the workflows that need daily attention.</small></div></div><div class="panel-body"><div class="admin-action-grid">
          <button class="admin-action" onclick="showPage('students')"><b>👤 Students</b><span>Profiles, enrollment and records</span></button>
          <button class="admin-action" onclick="showPage('attendance')"><b>✅ Attendance</b><span>Class rosters and daily attendance</span></button>
          <button class="admin-action" onclick="showPage('absence-requests')"><b>📝 Absence Center</b><span>Parent requests and all-day absences</span></button>
          <button class="admin-action" onclick="showPage('scheduling')"><b>🗓️ Scheduling</b><span>Periods, sections and conflicts</span></button>
          <button class="admin-action" onclick="showPage('emergency')"><b>🚨 Emergency Command</b><span>Accountability and reunification</span></button>
          <button class="admin-action" onclick="showPage('reporting')"><b>📈 Analytics</b><span>School performance and operations</span></button>
          <button class="admin-action" onclick="showPage('campus-communications')"><b>📣 Announcements</b><span>Target school communications</span></button>
          <button class="admin-action" onclick="showPage('substitutes')"><b>🧑‍🏫 Substitute Coverage</b><span>Daily staff coverage</span></button>
          <button class="admin-action" onclick="showPage('campus-id-parking')"><b>🪪 IDs & Parking</b><span>Permits and student identification</span></button>
        </div></div></section>
        <aside><section class="panel"><div class="panel-head"><h3>Needs attention</h3><button class="btn mini outline" onclick="dashboard()">Refresh</button></div><div class="panel-body">
          <div class="attention-row"><span>Parent absence requests</span><b>${d.absence_pending}</b></div><div class="attention-row"><span>Parking applications</span><b>${d.parking_pending}</b></div><div class="attention-row"><span>Open student fees</span><b>${d.fees_open}</b></div><div class="attention-row"><span>Overdue library items</span><b>${d.library_overdue}</b></div>
        </div></section><section class="panel" style="margin-top:14px"><div class="panel-head"><h3>Recent absence requests</h3></div><div class="panel-body">${(d.recent_absence_requests||[]).map(x=>`<div class="attention-row"><div><b>${escX(x.student_name)}</b><span class="student-sub">${escX(x.absence_date)} · ${escX(x.reason)}</span></div><span class="badge">${escX(x.status)}</span></div>`).join('')||'<div class="empty-modern">No absence requests yet.</div>'}</div></section></aside>
      </div>`;
  };

  window.absenceRequestsPage=async function(){
    addStyles();activePage='absence-requests';ssActiveNav?.('absence-requests');
    const requests=await api('/api/absence-requests');
    if(role==='parent'){
      $('#content').innerHTML=`<div class="pagebar"><div><h1>Report an Absence</h1><p>Submit an absence for one of your linked students. School administration reviews each request.</p></div><button class="btn primary" onclick="openParentAbsenceForm()">+ Report Absence</button></div>
      <div class="absence-layout"><section><div class="panel"><div class="panel-head"><h3>My requests</h3></div><div class="panel-body">${requests.map(requestCard).join('')||'<div class="empty-modern">You have not submitted any absence requests.</div>'}</div></div></section><aside class="panel"><div class="panel-head"><h3>How it works</h3></div><div class="panel-body"><div class="detail-line"><span>1. Parent submits</span><b>Pending</b></div><div class="detail-line"><span>2. School approves</span><b>Excused</b></div><div class="detail-line"><span>Or school denies</span><b>Unexcused</b></div><div class="absence-note">Once reviewed, ScholarSync applies the attendance decision to every scheduled class for that school day.</div></div></aside></div>`;
      return;
    }
    const pending=requests.filter(x=>x.status==='Pending');
    $('#content').innerHTML=`<div class="pagebar"><div><h1>Absence Center</h1><p>Review family absence requests or declare an all-day absence directly.</p></div><div class="page-actions"><button class="btn outline" onclick="dashboard()">Dashboard</button><button class="btn primary" onclick="openAdminDailyAbsence()">+ Set All-Day Absence</button></div></div>
      <div class="metric-strip"><div class="metric"><small>Pending review</small><strong>${pending.length}</strong></div><div class="metric"><small>Approved</small><strong>${requests.filter(x=>x.status==='Approved').length}</strong></div><div class="metric"><small>Denied</small><strong>${requests.filter(x=>x.status==='Denied').length}</strong></div></div>
      <div class="absence-layout"><section class="panel"><div class="panel-head"><h3>Parent absence requests</h3><span class="badge">${requests.length}</span></div><div class="panel-body">${requests.map(requestCard).join('')||'<div class="empty-modern">No parent absence requests.</div>'}</div></section><aside class="panel"><div class="panel-head"><h3>Attendance behavior</h3></div><div class="panel-body"><p class="student-sub">Approved requests are marked <b>Absent — Excused</b> for every scheduled class that day. Denied requests are marked <b>Absent — Unexcused</b>.</p><div class="absence-note">Teachers see all-day absences already filled in and locked on their attendance roster, so they do not have to mark the student again.</div></div></aside></div>`;
  };
  function requestCard(x){return `<div class="request-card"><div class="request-head"><div><b>${escX(x.student_name||'Student')}</b><span class="student-sub">${escX(x.absence_date)} · ${escX(x.reason)}</span></div><span class="badge absence-status ${escX(x.status)}">${escX(x.status)}</span></div>${x.details?`<div class="absence-note">${escX(x.details)}</div>`:''}${x.decision_note?`<div class="student-sub" style="margin-top:7px"><b>School note:</b> ${escX(x.decision_note)}</div>`:''}${role==='admin'&&x.status==='Pending'?`<div class="request-actions"><button class="btn success" onclick="reviewAbsence(${x.id},'approve')">Approve · Excused</button><button class="btn danger" onclick="reviewAbsence(${x.id},'deny')">Deny · Unexcused</button></div>`:''}</div>`}
  window.openParentAbsenceForm=function(){
    const kids=cache.students||[];
    openModal('Report Student Absence',`<form class="form" onsubmit="submitParentAbsence(event)"><label class="full"><span>Student</span><select name="student_id" required>${kids.map(s=>`<option value="${s.id}">${escX(s.name)}</option>`).join('')}</select></label><label><span>Absence date</span><input name="absence_date" type="date" required></label><label><span>Reason</span><select name="reason" required><option value="">Choose…</option><option>Illness</option><option>Medical appointment</option><option>Family emergency</option><option>Bereavement</option><option>College visit</option><option>Religious observance</option><option>Other</option></select></label><label class="full"><span>Additional details</span><textarea name="details" rows="4" placeholder="Optional details for the attendance office"></textarea></label><div class="full callout">Submitting this form does not automatically excuse the absence. An administrator will review it.</div><div class="full"><button class="btn primary">Submit Absence Request</button></div></form>`);
  };
  window.submitParentAbsence=async function(e){e.preventDefault();const d=Object.fromEntries(new FormData(e.target));await api('/api/absence-requests',{method:'POST',body:JSON.stringify(d)});closeModal();toastMsg('Absence request submitted');absenceRequestsPage()};
  window.reviewAbsence=async function(id,action){
    openModal(action==='approve'?'Approve Absence':'Deny Absence',`<form class="form" onsubmit="finishAbsenceReview(event,${id},'${action}')"><div class="full callout">${action==='approve'?'This will mark every scheduled class that day Absent — Excused.':'This will mark every scheduled class that day Absent — Unexcused.'}</div><label class="full"><span>Decision note (optional)</span><textarea name="decision_note" rows="3"></textarea></label><div class="full"><button class="btn ${action==='approve'?'success':'danger'}">${action==='approve'?'Approve & Excuse':'Deny & Mark Unexcused'}</button></div></form>`);
  };
  window.finishAbsenceReview=async function(e,id,action){e.preventDefault();const d=Object.fromEntries(new FormData(e.target));d.id=id;d.action=action;const r=await api('/api/absence-requests/review',{method:'POST',body:JSON.stringify(d)});closeModal();toastMsg(`Attendance updated across ${r.classes_marked} classes`);absenceRequestsPage()};
  window.openAdminDailyAbsence=function(){
    openModal('Set All-Day Absence',`<form class="form" onsubmit="saveAdminDailyAbsence(event)"><label class="full"><span>Student</span><select name="student_id" required><option value="">Choose student…</option>${(cache.students||[]).map(s=>`<option value="${s.id}">${escX(s.name)} · ${escX(s.student_number||'')}</option>`).join('')}</select></label><label><span>Date</span><input name="absence_date" type="date" required></label><label><span>Attendance status</span><select name="status"><option value="AE">Absent — Excused</option><option value="AU">Absent — Unexcused</option></select></label><label class="full"><span>Reason</span><input name="reason" placeholder="Illness, family notification, etc."></label><label class="full"><span>Internal note</span><textarea name="note" rows="3"></textarea></label><div class="full callout">ScholarSync will pre-mark this student absent in every scheduled class that day.</div><div class="full"><button class="btn primary">Apply All-Day Absence</button></div></form>`);
  };
  window.saveAdminDailyAbsence=async function(e){e.preventDefault();const d=Object.fromEntries(new FormData(e.target));const r=await api('/api/daily-absences',{method:'POST',body:JSON.stringify(d)});closeModal();toastMsg(`All-day absence applied to ${r.classes_marked} classes`);absenceRequestsPage()};

  // All-day absence declarations are shown as pre-filled, locked teacher attendance rows.
  const priorOpenAttendance=window.openAttendance;
  window.openAttendance=async function(cid,el){
    const result=await priorOpenAttendance(cid,el);
    const recs=window.currentAttendanceExport?.recs||[];
    recs.filter(r=>r.all_day_status).forEach(r=>{
      const row=document.querySelector(`.att-row[data-student="${r.student_id}"]`);if(!row)return;
      row.classList.add('all-day-absence-row');
      row.querySelectorAll('.att-choice').forEach(b=>{b.disabled=true;b.title='This student has an all-day absence entered by the attendance office.'});
      const name=row.firstElementChild;if(name&&!name.querySelector('.all-day-lock'))name.insertAdjacentHTML('beforeend',`<span class="all-day-lock">ALL-DAY ${r.all_day_status==='AE'?'EXCUSED':'UNEXCUSED'} ABSENCE</span>`);
    });
    return result;
  };

  // Teacher one-click whole-class emergency accountability.
  const priorEmergencyCenter=window.emergencyCenter;
  window.emergencyCenter=async function(){
    const out=await priorEmergencyCenter();
    if(role!=='teacher')return out;
    const incidents=await api('/api/emergency/incidents?active=1');
    const active=Array.isArray(incidents)?incidents[0]:incidents;if(!active)return out;
    const tc=await api('/api/time-context');const day=await api('/api/teacher-day?date='+encodeURIComponent(tc.date));
    const studentsPanel=document.getElementById('emergencyStudents');if(!studentsPanel)return out;
    const box=document.createElement('div');box.className='panel';box.style.marginBottom='14px';box.innerHTML=`<div class="panel-head"><div><h3>Account for a Whole Class</h3><small>One click marks every student in that class Accounted, except students ScholarSync already knows are absent/off campus.</small></div></div><div class="panel-body"><div class="emergency-auto-note">Students already marked absent in attendance before the emergency are automatically listed as <b>Absent</b> and are skipped by the whole-class button.</div><div class="emergency-class-tools">${(day.classes||[]).map(c=>`<div class="emergency-class-card"><b>${escX(c.period)} · ${escX(c.name)} ${escX(c.section||'')}</b><span>${c.enrolled} students · Room ${escX(c.room||'—')}</span><button class="btn success" onclick="accountWholeClass(${active.id},${c.id},'${escX(c.room||'').replace(/'/g,"\\'")}')">✓ Account for Entire Class</button></div>`).join('')||'<div class="empty-modern">No classes are scheduled for you today.</div>'}</div></div>`;studentsPanel.parentNode.insertBefore(box,studentsPanel);
    return out;
  };
  window.accountWholeClass=async function(iid,cid,location){if(!confirm('Mark every eligible student in this class Accounted?'))return;const r=await api('/api/emergency/accountability/bulk',{method:'POST',body:JSON.stringify({incident_id:iid,class_id:cid,location})});toastMsg(`${r.updated} students accounted for`);emergencyCenter()};
})();
