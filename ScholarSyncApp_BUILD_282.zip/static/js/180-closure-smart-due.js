/* ScholarSync School Closure Alerts + Schedule-Aware Assignment Due Dates */
(function(){
  const ex=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function styles(){if(document.getElementById('ss-closure-smart-css'))return;const s=document.createElement('style');s.id='ss-closure-smart-css';s.textContent=`
  #schoolClosureBanner{margin:0 0 16px;border:1px solid #c92f3d;background:linear-gradient(135deg,#8f1d28,#c53743);color:white;border-radius:17px;padding:17px 19px;box-shadow:0 12px 28px #8f1d2825;display:flex;justify-content:space-between;gap:16px;align-items:center}#schoolClosureBanner h2{margin:2px 0 4px;font-size:21px}#schoolClosureBanner p{margin:0;color:#ffe8ea}#schoolClosureBanner .closure-label{font-size:11px;font-weight:950;letter-spacing:.13em}.closure-reason{display:inline-flex;margin-top:9px;padding:5px 9px;border-radius:999px;background:#ffffff1d;border:1px solid #ffffff32;font-size:11px;font-weight:850}.smart-due-box{border:1px solid #cbdde9;background:#f5faff;border-radius:13px;padding:12px}.smart-due-grid{display:flex;gap:7px;flex-wrap:wrap;margin-top:8px}.smart-due-grid button{border:1px solid #bfd1df;background:#fff;border-radius:9px;padding:8px 10px;font-size:11px;font-weight:800;cursor:pointer}.smart-due-grid button:hover{border-color:#5687a8;background:#eef7fc}.smart-due-resolved{margin-top:8px;font-size:11px;color:var(--muted);font-weight:700}.closure-form-note{background:#fff3f4;border:1px solid #efc5c9;border-radius:11px;padding:10px;font-size:12px}.calendar-cell.closure-day{background:#fff0f1!important;border-color:#dc8e95!important}.calendar-cell.closure-day .date-num{color:#a91f2c}.closure-chip{background:#a91f2c;color:#fff;border-radius:999px;padding:4px 8px;font-size:10px;font-weight:900}@media(max-width:700px){#schoolClosureBanner{align-items:flex-start;flex-direction:column}}
  `;document.head.appendChild(s)}
  styles();

  window.refreshSchoolClosureBanner=async function(){
    if(!window.user||!document.getElementById('content'))return;
    let d;try{d=await api('/api/closure-status')}catch(e){return}
    let old=document.getElementById('schoolClosureBanner');if(old)old.remove();if(!d.active)return;
    const c=d.closure||{},box=document.createElement('div');box.id='schoolClosureBanner';
    box.innerHTML=`<div><div class="closure-label">⚠ SCHOOL CLOSURE</div><h2>${ex(c.title||'School is closed today')}</h2><p>${ex(c.closure_message||c.details||'Classes will not meet today.')}</p><span class="closure-reason">${ex(c.closure_reason||'School Closure')}</span>${Number(c.cancel_activities)?'<span class="closure-reason">Activities & athletics canceled</span>':''}</div><div><b>${new Date(d.date+'T12:00:00').toLocaleDateString([],{weekday:'long',month:'long',day:'numeric'})}</b></div>`;
    const content=document.getElementById('content');content.insertBefore(box,content.firstChild);
  };
  const oldShow=window.showPage;window.showPage=function(){const r=oldShow.apply(this,arguments);Promise.resolve(r).finally(()=>setTimeout(refreshSchoolClosureBanner,40));return r};
  const oldDash=window.dashboard;window.dashboard=function(){const r=oldDash.apply(this,arguments);Promise.resolve(r).finally(()=>setTimeout(refreshSchoolClosureBanner,40));return r};
  setInterval(()=>{if(window.user)refreshSchoolClosureBanner()},60000);

  window.schoolDayForm=function(x={}){
    const isClosure=['School Closure','Closed','No School'].includes(x.day_type);
    openModal(x.id?'Edit Calendar Day':'Add Calendar Day',`<form class="form" onsubmit="saveSchoolDay(event)"><input type="hidden" name="id" value="${x.id||''}">
    <label><span>Date</span><input name="date" type="date" value="${ex(x.date||'')}" required></label><label><span>Type</span><select name="day_type" onchange="toggleClosureFields(this.value)"><option>School Day</option><option>School Closure</option><option>Holiday</option><option>Assembly</option><option>Special Schedule</option></select></label>
    <label><span>Title</span><input name="title" value="${ex(x.title||'')}" placeholder="Snow Day" required></label>
    <div id="closureFields" class="full" style="display:${isClosure?'block':'none'}"><div class="closure-form-note"><b>School Closure Alert</b><br>This creates a prominent alert across student, parent, teacher, and staff portals. Classes and attendance are suppressed for this date.</div><div class="form" style="margin-top:10px"><label><span>Reason</span><select name="closure_reason"><option>Snow / Ice</option><option>Extreme Cold</option><option>Extreme Heat</option><option>Power Outage</option><option>Building Issue</option><option>Emergency</option><option>Other</option></select></label><label class="checkbox-line"><input name="cancel_activities" type="checkbox" ${Number(x.cancel_activities)?'checked':''}><span>Cancel athletics & extracurriculars</span></label><label class="full"><span>Message shown to school community</span><textarea name="closure_message" rows="4" placeholder="School is closed today because of hazardous road conditions.">${ex(x.closure_message||'')}</textarea></label><label class="checkbox-line full"><input name="alert_enabled" type="checkbox" checked><span>Show prominent closure alert</span></label></div></div>
    <label><span>Start time</span><input name="start_time" type="time" value="${ex(x.start_time||'')}"></label><label><span>End time</span><input name="end_time" type="time" value="${ex(x.end_time||'')}"></label><label class="full"><span>Internal details</span><textarea name="details">${ex(x.details||'')}</textarea></label><div class="full row-actions"><button class="btn primary">Save Day</button>${x.id?`<button type="button" class="btn danger" onclick="deleteSchoolDay(${x.id})">Delete</button>`:''}</div></form>`);
    setTimeout(()=>{const t=document.querySelector('[name="day_type"]');if(t)t.value=x.day_type||'School Day';const r=document.querySelector('[name="closure_reason"]');if(r&&x.closure_reason)r.value=x.closure_reason},0)
  };
  window.toggleClosureFields=function(v){const b=document.getElementById('closureFields');if(b)b.style.display=v==='School Closure'?'block':'none'};
  const priorSaveDay=window.saveSchoolDay;window.saveSchoolDay=async function(e){e.preventDefault();const fd=new FormData(e.target),d=Object.fromEntries(fd);d.cancel_activities=fd.has('cancel_activities');d.alert_enabled=fd.has('alert_enabled');await api('/api/school-calendar',{method:'POST',body:JSON.stringify(d)});closeModal();toastMsg(d.day_type==='School Closure'?'School closure published':'School calendar updated');if(typeof calendarPage==='function')calendarPage();setTimeout(refreshSchoolClosureBanner,50)};

  const priorAssignmentForm=window.assignmentForm;
  window.assignmentForm=function(cid,id=0){
    priorAssignmentForm(cid,id);setTimeout(()=>installSmartDue(cid),0);
  };
  async function installSmartDue(cid){
    const due=document.querySelector('#modalContent input[name="due_date"]');if(!due)return;
    let d;try{d=await api('/api/class-due-options?class_id='+cid)}catch(e){return}
    const wrap=document.createElement('div');wrap.className='full smart-due-box';wrap.innerHTML=`<b>⚡ Smart due date</b><div class="student-sub">Based on this section's actual meeting schedule. Closures, holidays, weekends, and rotation days are skipped.</div><div class="smart-due-grid">${(d.options||[]).map(o=>`<button type="button" data-value="${ex(o.value)}" data-label="${ex(o.label)}">${ex(o.label)}</button>`).join('')}<button type="button" data-value="">Custom Date & Time</button></div><div class="smart-due-resolved">Choose an option to automatically set the exact date and time.</div>`;
    due.closest('label').after(wrap);
    wrap.querySelectorAll('button').forEach(b=>b.onclick=()=>{if(!b.dataset.value){due.focus();return}due.value=b.dataset.value;const dt=new Date(b.dataset.value);wrap.querySelector('.smart-due-resolved').textContent=`${b.dataset.label} → ${dt.toLocaleDateString([],{weekday:'long',month:'long',day:'numeric'})} at ${dt.toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})}`});
  }
})();
