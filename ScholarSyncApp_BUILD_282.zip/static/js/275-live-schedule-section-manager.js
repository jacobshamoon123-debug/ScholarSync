// ScholarSync Build 275 — Live Schedule Section Manager
// Adds/activates sections after the master schedule has already been generated.
(function(){
  const E=(v)=>typeof esc==='function'?esc(v??''):String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const originalScheduler=window.scheduler;
  if(typeof originalScheduler==='function'){
    window.scheduler=async function(){
      await originalScheduler.apply(this,arguments);
      setTimeout(ss275EnhanceScheduler,0);
    };
  }

  function ss275EnhanceScheduler(){
    if(role!=='admin') return;
    const actions=document.querySelector('.pagebar .page-actions');
    if(actions && !document.getElementById('ss275LiveSectionBtn')){
      const b=document.createElement('button');
      b.id='ss275LiveSectionBtn'; b.className='btn primary'; b.textContent='+ Add Midyear Section';
      b.onclick=()=>ss275LiveScheduleManager();
      actions.insertBefore(b,actions.firstChild);
    }
    const target=document.querySelector('.scheduler-workspace') || document.querySelector('.schedule-layout');
    if(target && !document.getElementById('ss275LiveScheduleCard')){
      const card=document.createElement('div');
      card.id='ss275LiveScheduleCard'; card.className='panel'; card.style.marginBottom='16px';
      card.innerHTML='<div class="panel-head"><div><h3>Live Schedule Changes</h3><small>Add a class after scheduling is finished without rebuilding the master schedule.</small></div><button class="btn outline" onclick="ss275LiveScheduleManager()">Manage Live Sections</button></div><div class="panel-body"><div class="callout">Use this for a forgotten course, a new midyear section, or a class created after the original schedule. Activating it makes the class appear on student and teacher schedules while keeping gradebook and attendance connected.</div></div>';
      target.parentNode.insertBefore(card,target);
    }
  }

  window.ss275LiveScheduleManager=async function(){
    await preload();
    const d=await api('/api/scheduler/live-section-data');
    window.ss275LiveData=d;
    const live=(d.classes||[]).filter(c=>Number(c.published||0)===1);
    const hidden=(d.classes||[]).filter(c=>Number(c.published||0)!==1);
    openModal('Live Schedule Manager',`<div class="callout"><b>No full schedule regeneration required.</b> Create a new section or activate an existing section. Once live, enrolled students see it on their schedule and the assigned teacher gets the same roster in attendance and gradebook.</div>
      <div class="page-actions" style="margin:14px 0"><button class="btn primary" onclick="ss275LiveSectionForm()">+ Create & Add Live Section</button></div>
      <div style="max-height:520px;overflow:auto">
        <h3 style="margin:14px 0 8px">Created but not on the schedule</h3>
        ${hidden.length?hidden.map(c=>`<div class="setup-row"><div><b>${E(c.course_code)} ${E(c.name)} ${E(c.section||'')}</b><span class="student-sub">${E(c.term||'Term —')} · ${E(c.period||'No period')} · ${E(c.teacher||'Unassigned')} · ${Number(c.enrolled||0)} students</span></div><button class="btn mini success" onclick="ss275LiveSectionForm(${c.id})">Add to Live Schedule</button></div>`).join(''):'<div class="empty-modern">Every existing section is already live.</div>'}
        <h3 style="margin:18px 0 8px">Currently live</h3>
        ${live.length?live.map(c=>`<div class="setup-row"><div><b>${E(c.course_code)} ${E(c.name)} ${E(c.section||'')}</b><span class="student-sub">Day ${Number(c.cycle_day||1)} · ${E(c.period||'—')} · ${E(c.teacher||'Unassigned')} · ${E(c.room||'Room —')} · ${Number(c.enrolled||0)}/${Number(c.capacity||30)}</span></div><div><button class="btn mini outline" onclick="ss275LiveSectionForm(${c.id})">Edit Placement</button> <button class="btn mini danger" onclick="ss275Unpublish(${c.id})">Remove from Schedule</button></div></div>`).join(''):'<div class="empty-modern">No live sections.</div>'}
      </div>`);
  };

  window.ss275LiveSectionForm=function(classId=0){
    const d=window.ss275LiveData||{classes:[],students:[],periods:[],rooms:[]};
    const item=(d.classes||[]).find(c=>Number(c.id)===Number(classId))||null;
    const courses=cache.courses||[], staff=(cache.staff||[]).filter(s=>String(s.role||'').toLowerCase().includes('teacher')&&String(s.status||'Active')==='Active');
    const selectedCourse=Number(item?.course_id||courses[0]?.id||0);
    const day=Number(item?.cycle_day||1);
    const periodNames=[...new Set((d.periods||[]).filter(p=>Number(p.cycle_day||1)===day).map(p=>p.name))];
    const roomNames=[...new Set((d.rooms||[]).map(r=>r.name))];
    openModal(item?'Place Section on Live Schedule':'Create Live Schedule Section',`<form class="form" onsubmit="ss275SaveLiveSection(event,${item?item.id:0})">
      <label><span>Course</span><select name="course_id" onchange="ss275CoursePicked(this)">${courses.map(c=>`<option value="${c.id}" data-name="${E(c.name)}" ${Number(c.id)===selectedCourse?'selected':''}>${E(c.code)} — ${E(c.name)}</option>`).join('')}</select></label>
      <label><span>Class / section name</span><input name="name" value="${E(item?.name||courses.find(c=>Number(c.id)===selectedCourse)?.name||'')}" required></label>
      <label><span>Section number</span><input name="section" value="${E(item?.section||'')}" placeholder="G01"></label>
      <label><span>School year / term</span><input name="term" value="${E(item?.term||'')}" placeholder="2026-2027 S2" required></label>
      <label><span>Rotation day</span><select name="cycle_day" onchange="ss275CycleChanged(this)">${[1,2,3,4,5].map(n=>`<option value="${n}" ${day===n?'selected':''}>Day ${String.fromCharCode(64+n)}</option>`).join('')}</select></label>
      <label><span>Period</span><input name="period" list="ss275PeriodOptions" value="${E(item?.period||'')}" required><datalist id="ss275PeriodOptions">${periodNames.map(x=>`<option value="${E(x)}">`).join('')}</datalist></label>
      <label><span>Teacher</span><select name="teacher_id"><option value="">Unassigned</option>${staff.map(s=>`<option value="${s.id}" ${Number(item?.teacher_id)===Number(s.id)?'selected':''}>${E(s.name)}</option>`).join('')}</select></label>
      <label><span>Room</span><input name="room" list="ss275RoomOptions" value="${E(item?.room||'')}"><datalist id="ss275RoomOptions">${roomNames.map(x=>`<option value="${E(x)}">`).join('')}</datalist></label>
      <label><span>Capacity</span><input name="capacity" type="number" min="1" value="${Number(item?.capacity||30)}" required></label>
      <label><span>School</span><input name="school" value="${E(item?.school||'')}"></label>
      <div class="full"><span style="display:block;font-weight:700;margin-bottom:7px">Enroll students now (optional)</span><input id="ss275StudentSearch" class="control" style="width:100%;margin-bottom:8px" placeholder="Search students" oninput="ss275FilterStudents(this.value)"><div id="ss275StudentList" style="max-height:190px;overflow:auto;border:1px solid var(--border);border-radius:10px;padding:8px">${(d.students||[]).map(s=>`<label class="checkbox-line ss275-student" data-search="${E((s.first_name+' '+s.last_name+' '+(s.student_number||'')+' '+(s.grade||'')).toLowerCase())}"><input type="checkbox" name="student_ids" value="${s.id}"><span><b>${E(s.first_name)} ${E(s.last_name)}</b> <small>${E(s.student_number||'')} · Grade ${E(s.grade||'—')}</small></span></label>`).join('')}</div></div>
      <div class="full callout">ScholarSync checks teacher, room, student-period conflicts, and capacity before adding this to the live schedule. The section immediately becomes available to student schedules, teacher attendance, and gradebook.</div>
      <div class="full"><button class="btn success">${item?'Save & Activate on Schedule':'Create & Add to Schedule'}</button></div>
    </form>`);
  };

  window.ss275CoursePicked=function(sel){const opt=sel.options[sel.selectedIndex];const f=sel.form;if(f && f.name && !f.name.value.trim())f.name.value=opt?.dataset?.name||'';};
  window.ss275CycleChanged=function(sel){/* Period remains editable so custom schools are supported. */};
  window.ss275FilterStudents=function(q){q=String(q||'').toLowerCase();document.querySelectorAll('.ss275-student').forEach(x=>x.style.display=(x.dataset.search||'').includes(q)?'flex':'none');};

  window.ss275SaveLiveSection=async function(e,classId=0){
    e.preventDefault();
    const f=e.target, fd=new FormData(f), body=Object.fromEntries(fd.entries());
    body.action=classId?'activate':'create'; if(classId)body.class_id=classId;
    body.student_ids=[...f.querySelectorAll('input[name="student_ids"]:checked')].map(x=>Number(x.value));
    try{
      const r=await api('/api/scheduler/live-section',{method:'POST',body:JSON.stringify(body)});
      closeModal(); cache.classes=[]; await preload();
      const skipped=r.conflicts||[];
      if(skipped.length){
        alert(`Section is live. ${r.enrolled.length} student(s) enrolled. ${skipped.length} student(s) were not enrolled because of schedule/capacity conflicts:\n\n`+skipped.slice(0,12).map(x=>`${x.student_name}: ${x.reason}`).join('\n'));
      }else toastMsg(classId?'Section added to the live schedule':'Live section created');
      scheduler();
    }catch(err){alert(err.message||'Unable to add this section to the live schedule.');}
  };

  window.ss275Unpublish=async function(classId){
    if(!confirm('Remove this section from the live schedule? The class, roster, gradebook, attendance history, and enrollments will stay saved; it will simply stop appearing as a scheduled class until reactivated.'))return;
    await api('/api/scheduler/live-section',{method:'POST',body:JSON.stringify({action:'unpublish',class_id:classId})});
    closeModal();cache.classes=[];await preload();toastMsg('Section removed from live schedule');scheduler();
  };
})();
