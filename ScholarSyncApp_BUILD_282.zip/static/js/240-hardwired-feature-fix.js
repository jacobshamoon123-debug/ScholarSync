/* ScholarSync hardwired feature visibility fix - build 2026.09.01.240 */
(function(){
  window.SCHOLARSYNC_BUILD='282';
  function bind(){
    if(typeof window.ssAuthoritativeSchoolDayForm==='function') window.schoolDayForm=window.ssAuthoritativeSchoolDayForm;
    if(typeof window.ssRegisterPageRoute==='function'){
      if(typeof window.ssAuthoritativeAcademicYearPage==='function') window.ssRegisterPageRoute('academic-year-settings',()=>window.ssAuthoritativeAcademicYearPage(),['admin']);
      if(typeof window.ssStudentClassGradebooks==='function') window.ssRegisterPageRoute('gradebook',()=>window.role==='student'?window.ssStudentClassGradebooks():window.gradebook(),['admin','teacher','student','parent']);
    }
    try{
      if(window.NAV?.admin&&!window.NAV.admin.some(x=>x[1]==='academic-year-settings')) window.NAV.admin.splice(Math.max(0,window.NAV.admin.findIndex(x=>x[1]==='scheduling')+1),0,['ACADEMICS','academic-year-settings','📅','Academic Year']);
      const st=window.NAV?.student?.find(x=>x[1]==='gradebook'); if(st) st[3]='My Gradebook';
      if(typeof window.buildNav==='function'&&window.user) window.buildNav();
    }catch(_){ }
    const existing=document.getElementById('ss-build-chip');
    if(existing) existing.textContent='ScholarSync Build 282';
    if(!existing){
      const chip=document.createElement('div');chip.id='ss-build-chip';chip.textContent='ScholarSync Build 282';
      chip.style.cssText='position:fixed;right:12px;bottom:10px;z-index:99999;background:#111827;color:white;padding:5px 8px;border-radius:7px;font:700 10px system-ui;opacity:.72;pointer-events:none';
      document.body.appendChild(chip);
    }
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',bind,{once:true}); else bind();
  setTimeout(bind,0);setTimeout(bind,300);
})();
