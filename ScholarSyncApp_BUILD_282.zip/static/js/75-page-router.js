/* ScholarSync Refactor Phase 2: centralized navigation registry and page dispatcher. */
(function(){
  const baseShowPage=window.showPage;
  const routes=Object.create(null);
  window.SS_PAGE_ROUTES=routes;
  window.ssBaseShowPage=baseShowPage;
  window.ssAddNav=function(roleName,group,id,icon,label,afterId){
    const a=NAV[roleName]; if(!a||a.some(x=>x[1]===id)) return;
    const i=afterId?a.findIndex(x=>x[1]===afterId):-1;
    a.splice(i>=0?i+1:a.length,0,[group,id,icon,label]);
  };
  window.ssRegisterPageRoute=function(id,handler,allowedRoles){
    routes[id]={handler,allowedRoles:Array.isArray(allowedRoles)?allowedRoles:null};
  };
  window.showPage=async function(id){
    const route=routes[id];
    if(route){
      if(route.allowedRoles && !route.allowedRoles.includes(role)){
        activePage=id; ssActiveNav?.(id);
        $('#content').innerHTML=`<div class="pagebar"><div><h1>Access Restricted</h1></div></div><div class="error">You do not have permission to open this page.</div>`;
        return;
      }
      activePage=id; ssActiveNav?.(id);
      return route.handler(id);
    }
    return baseShowPage(id);
  };
})();
