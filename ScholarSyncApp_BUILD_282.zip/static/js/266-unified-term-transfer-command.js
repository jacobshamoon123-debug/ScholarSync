/* ScholarSync Build 266 — unified term compatibility, course transfers, summer command center */
(function(){
 const E=x=>typeof esc==='function'?esc(x):String(x??'');
 function styles(){if(document.getElementById('ss266css'))return;let s=document.createElement('style');s.id='ss266css';s.textContent=`.ss266-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.ss266-risk{display:grid;grid-template-columns:1.2fr 1fr 1fr auto;gap:12px;align-items:center;padding:12px;border-bottom:1px solid var(--border)}.ss266-integrations{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.ss266-integration{border:1px solid var(--border);border-radius:13px;padding:13px;background:var(--panel)}@media(max-width:900px){.ss266-grid,.ss266-integrations{grid-template-columns:repeat(2,1fr)}.ss266-risk{grid-template-columns:1fr}}`;document.head.appendChild(s)}styles();

 window.courseTransferCenter=async function(studentId=0){
  await preload();
  let sid=Number(studentId||user?.student_id||academicState?.student||0);

  // Students/parents REQUEST a course change. They never call the staff-only
  // transfer history/preview/execute endpoints.
  if(role==='student'||role==='parent'){
    if(!sid){
      $('#content').innerHTML=`<div class="pagebar"><div><h1>Course Change Request</h1><p>No student is linked to this account.</p></div></div>`;
      return;
    }
    let academic=academicState?.student===sid&&academicState?.data?academicState.data:await api('/api/academic-planning?student_id='+sid);
    let requests=await api('/api/schedule-change');
    requests=(requests||[]).filter(x=>Number(x.student_id)===sid);
    let current=(academic?.classes||[]).filter(c=>c.class_id||c.id);
    $('#content').innerHTML=`<div class="pagebar"><div><h1>Course Change Request</h1><p>Request a level change, course transfer, add, or drop. ScholarSync automatically narrows the requested-class choices to the right course category.</p></div><button class="btn outline" onclick="academicPlanningPage(${sid})">Back to Academic Planning</button></div>
      <div class="panel"><div class="panel-head"><div><h3>Request a Change</h3><small>This is a request — it does not immediately change your schedule.</small></div></div><div class="panel-body">
      <form id="ss272CourseChangeForm" class="form" onsubmit="ss270SubmitStudentCourseChange(event,${sid})">
        <label><span>Request type</span><select name="request_type" onchange="ss272CourseChangeTypeChanged(this.form,${sid})"><option>Level Change</option><option>Transfer</option><option>Add Course</option><option>Drop Course</option><option>Other</option></select></label>
        <label><span>Current class</span><select name="from_class_id" onchange="ss272RefreshCourseChangeOptions(this.form,${sid})"><option value="">Choose current class</option>${current.map(c=>`<option value="${c.class_id||c.id}">${E(c.term||'')} · ${E(c.course_code||'')} ${E(c.course_name||c.name||'')}</option>`).join('')}</select></label>
        <label class="full"><span>Requested class</span><select name="to_class_id"><option value="">Select a current class first</option></select><small id="ss272CourseChangeHint">For a level change, ScholarSync will only show another level of the same course.</small></label>
        <label class="full"><span>Why are you requesting this change?</span><textarea name="reason" rows="4" required placeholder="Example: Honors Algebra 1 is moving too quickly and I would like to move to regular Algebra 1."></textarea></label>
        <div class="full callout"><b>Smart matching:</b> Level Change uses the course's department, course family, level, and term. For example, selecting <b>Honors Algebra 1</b> will offer <b>Algebra 1</b> at another available level — not unrelated courses.</div>
        <div class="full callout"><b>What happens next:</b> your counselor/admin reviews the request, checks prerequisites, class capacity and schedule conflicts, then approves or denies it. Your current schedule stays unchanged until approval.</div>
        <div class="full"><button class="btn primary">Submit Course Change Request</button></div>
      </form></div></div>
      <div class="panel" style="margin-top:14px"><div class="panel-head"><h3>My Requests</h3></div><div class="table-wrap"><table><thead><tr><th>Submitted</th><th>Type</th><th>From</th><th>To</th><th>Status</th><th>Reason</th></tr></thead><tbody>${requests.map(x=>`<tr><td>${E(String(x.created_at||'').slice(0,16))}</td><td>${E(x.request_type||'')}</td><td>${E(x.from_name||'—')}</td><td>${E(x.to_name||'—')}</td><td><span class="badge ${x.status==='Completed'?'success':x.status==='Denied'?'danger':'warn'}">${E(x.status||'Pending')}</span></td><td>${E(x.reason||'')}</td></tr>`).join('')||'<tr><td colspan="6" class="empty">No course-change requests yet.</td></tr>'}</tbody></table></div></div>`;
    return;
  }

  // Admin/counselor retain the direct, audited transfer workflow.
  let students=cache.students||[];
  let active=cache.classes||[];
  if(!sid)sid=Number(students[0]?.id||0);
  let history=sid?await api('/api/course-transfer/history?student_id='+sid):[];
  $('#content').innerHTML=`<div class="pagebar"><div><h1>Course Transfers</h1><p>Move a student between regular-year or Summer School classes without losing historical records.</p></div></div><div class="panel"><div class="panel-head"><h3>Transfer Student</h3></div><div class="panel-body"><form class="form" onsubmit="ss266Transfer(event)"><label class="full"><span>Student</span><select name="student_id" onchange="courseTransferCenter(this.value)">${students.map(s=>`<option value="${s.id}" ${Number(s.id)===sid?'selected':''}>${E(s.last_name)}, ${E(s.first_name)} · ${E(s.student_number)}</option>`).join('')}</select></label><label><span>Current class</span><select name="from_class_id" required><option value="">Choose current class</option>${active.map(c=>`<option value="${c.id}">${E(c.term)} · ${E(c.course_code)} ${E(c.name)} ${E(c.section||'')}</option>`).join('')}</select></label><label><span>Transfer into</span><select name="to_class_id" required><option value="">Choose destination</option>${active.map(c=>`<option value="${c.id}">${E(c.term)} · ${E(c.course_code)} ${E(c.name)} ${E(c.section||'')} · ${c.enrolled}/${c.capacity||30}</option>`).join('')}</select></label><label><span>Effective date</span><input type="date" name="effective_date" value="${typeof ssTodayISO==='function'?ssTodayISO():''}" required></label><label><span>Prior grade handling</span><select name="grade_policy"><option value="historical">Preserve old course only (recommended)</option><option value="carry_current">Carry current cumulative %</option><option value="copy_matching">Copy grades for matching assignments</option></select></label><label class="full"><span>Reason</span><input name="reason" placeholder="Example: Moving from Honors Algebra 2 to Algebra 2"></label><label class="full"><span>Internal notes</span><textarea name="notes" rows="2"></textarea></label><div class="full callout"><b>Safe transfer:</b> old attendance, grades, submissions and history stay attached to the old class. The student's future schedule and destination roster update on the effective date. Capacity, prerequisites and schedule conflicts are checked before the move.</div><div class="full"><button class="btn primary">Review & Transfer</button></div></form></div></div><div class="panel" style="margin-top:14px"><div class="panel-head"><h3>Transfer History</h3></div><div class="table-wrap"><table><thead><tr><th>Date</th><th>From</th><th>To</th><th>Grade handling</th><th>Reason</th></tr></thead><tbody>${history.map(x=>`<tr><td>${E(x.effective_date)}</td><td>${E(x.from_name)}</td><td>${E(x.to_name)}</td><td>${E(x.grade_policy)}</td><td>${E(x.reason||'')}</td></tr>`).join('')||'<tr><td colspan="5" class="empty">No course transfers yet.</td></tr>'}</tbody></table></div></div>`;
 };

 window.ss272CourseChangeTypeChanged=async function(form,sid){
   const type=form?.request_type?.value||'Level Change';
   const from=form?.from_class_id;
   const to=form?.to_class_id;
   const hint=document.getElementById('ss272CourseChangeHint');
   if(!from||!to)return;
   if(type==='Add Course'){
     from.value='';from.disabled=true;to.disabled=false;
     if(hint)hint.textContent='Add Course shows available published classes you are not already taking.';
   }else if(type==='Drop Course'){
     from.disabled=false;to.disabled=true;to.innerHTML='<option value="">No requested class needed for a drop</option>';
     if(hint)hint.textContent='Choose the class you want to drop. No destination class is required.';
     return;
   }else{
     from.disabled=false;to.disabled=false;
     if(hint)hint.textContent=type==='Level Change'?'ScholarSync will only show another level of the same course.':type==='Transfer'?'ScholarSync will show classes in the same subject/category and term.':'ScholarSync will show available published classes.';
   }
   await ss272RefreshCourseChangeOptions(form,sid);
 };
 window.ss272RefreshCourseChangeOptions=async function(form,sid){
   if(!form)return;
   const type=form.request_type?.value||'Level Change';
   const from=form.from_class_id?.value||'';
   const to=form.to_class_id;
   if(!to)return;
   if(type==='Drop Course')return;
   if((type==='Level Change'||type==='Transfer')&&!from){
     to.disabled=false;to.innerHTML='<option value="">Select a current class first</option>';return;
   }
   to.disabled=true;to.innerHTML='<option value="">Finding matching classes…</option>';
   try{
     const url='/api/course-change-options?student_id='+encodeURIComponent(sid)+'&request_type='+encodeURIComponent(type)+'&from_class_id='+encodeURIComponent(from||'');
     const options=await api(url);
     to.disabled=false;
     if(!Array.isArray(options)||!options.length){
       to.innerHTML='<option value="">No matching classes are currently available</option>';
       return;
     }
     to.innerHTML='<option value="">Choose requested class</option>'+options.map(c=>`<option value="${c.id}">${E(c.term||'')} · ${E(c.course_code||'')} ${E(c.name||c.course_name||'')} ${E(c.section||'')} · ${E(c.course_level||'Regular')} · ${Number(c.enrolled||0)}/${Number(c.capacity||30)}</option>`).join('');
   }catch(err){
     to.disabled=false;to.innerHTML='<option value="">Could not load matching classes</option>';toastMsg(err.message||'Could not load matching classes');
   }
 };

 window.ss270SubmitStudentCourseChange=async function(ev,sid){
   ev.preventDefault();
   const d=Object.fromEntries(new FormData(ev.target));
   d.student_id=sid;
   d.action='request';
   try{
     await api('/api/schedule-change',{method:'POST',body:JSON.stringify(d)});
     toastMsg('Course-change request submitted');
     courseTransferCenter(sid);
   }catch(e){toastMsg(e.message||'Could not submit request')}
 };
 window.ss266Transfer=async function(ev){ev.preventDefault();let d=Object.fromEntries(new FormData(ev.target));let p=await api(`/api/course-transfer/preview?student_id=${d.student_id}&from_class_id=${d.from_class_id}&to_class_id=${d.to_class_id}&effective_date=${d.effective_date}`);if(p.error)return toastMsg(p.error);if(p.conflict)return toastMsg('Schedule conflict with '+p.conflict.name);openModal('Confirm Course Transfer',`<div class="callout"><b>${E(p.student.first_name)} ${E(p.student.last_name)}</b><br>${E(p.from_class.course_code)} ${E(p.from_class.name)} → <b>${E(p.to_class.course_code)} ${E(p.to_class.name)}</b><br>Effective ${E(d.effective_date)}</div><div style="margin-top:12px"><b>What ScholarSync will do</b><p>End the old enrollment, preserve its history, add the destination class to the student's schedule, update both teacher rosters, and log the transfer.</p></div><div class="row-actions"><button class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn primary" id="ss266Confirm">Complete Transfer</button></div>`);$('#ss266Confirm').onclick=async()=>{try{await api('/api/course-transfer',{method:'POST',body:JSON.stringify(d)});closeModal();toastMsg('Course transfer completed');courseTransferCenter(Number(d.student_id))}catch(e){toastMsg(e.message||'Transfer failed')}}};

 window.summerCommandCenter=async function(){let d=await api('/api/summer-school/command'),m=d.metrics||{};$('#content').innerHTML=`<div class="pagebar"><div><h1>☀️ Summer School Command Center</h1><p>Today's summer operation, progress monitoring and existing ScholarSync systems in one place.</p></div><div class="page-actions"><button class="btn outline" onclick="summerRiskRules()">At-Risk Rules</button><button class="btn primary" onclick="summerSchoolPage()">Manage Courses</button></div></div><div class="ss266-grid"><div class="metric"><small>Active courses</small><strong>${m.active_courses||0}</strong></div><div class="metric"><small>Summer students</small><strong>${m.students||0}</strong></div><div class="metric"><small>Needs attention</small><strong>${m.at_risk||0}</strong></div><div class="metric"><small>Waitlisted</small><strong>${m.waitlisted||0}</strong></div></div><div class="panel" style="margin-top:14px"><div class="panel-head"><div><h3>Today's Classes</h3><small>${E(d.today)}</small></div></div><div class="table-wrap"><table><thead><tr><th>Course</th><th>Time</th><th>Teacher</th><th>Room</th><th>Enrollment</th></tr></thead><tbody>${(d.today_courses||[]).map(c=>`<tr><td><b>${E(c.course_code)} ${E(c.name)}</b></td><td>${E(c.start_time)}–${E(c.end_time)}</td><td>${E(c.teacher_name)}</td><td>${E(c.room||'—')}</td><td>${c.enrolled}/${c.capacity||30}</td></tr>`).join('')||'<tr><td colspan="5">No Summer School classes meet today.</td></tr>'}</tbody></table></div></div><div class="panel" style="margin-top:14px"><div class="panel-head"><div><h3>Progress & Intervention</h3><small>Uses the existing gradebook, missing work and attendance data.</small></div></div><div class="panel-body">${(d.risks||[]).map(r=>`<div class="ss266-risk"><div><b>${E(r.student_name)}</b><span class="student-sub">${E(r.class_name)} · ${E(r.student_number)}</span></div><span class="badge ${r.level==='Critical'?'danger':'warn'}">${E(r.level)}</span><span>${E((r.reasons||[]).join(' · '))}</span><button class="btn mini outline" onclick="studentProfile(${r.student_id})">Student</button></div>`).join('')||'<div class="summer-empty">No students currently meet the at-risk thresholds.</div>'}</div></div><div class="panel" style="margin-top:14px"><div class="panel-head"><h3>Summer-Compatible Existing Systems</h3></div><div class="panel-body"><div class="ss266-integrations">${[['📅','Calendar','Use the existing calendar for Summer instructional days, closures and special dates.','calendar'],['📣','Announcements','Target Summer School or a specific summer course from Communications.','campus-communications'],['🚌','Transportation','Existing routes can use a Summer term/date range.','campus-transportation'],['🥗','Meals','Existing meal accounts remain the student account; transactions can be tagged Summer.','campus-meals'],['👨‍🏫','Substitutes','Summer classes use the same substitute workflow and linked class access.','substitute'],['🎓','Grades & Credits','Linked classes already feed report cards, transcripts and graduation credit.','academic-planning']].map(x=>`<div class="ss266-integration"><b>${x[0]} ${x[1]}</b><p>${x[2]}</p><button class="btn mini outline" onclick="showPage('${x[3]}')">Open Existing ${E(x[1])}</button></div>`).join('')}</div></div></div>`};
 window.summerRiskRules=async function(){let d=await api('/api/summer-school/command'),r=d.rules||{};openModal('Summer At-Risk Rules',`<form class="form" onsubmit="saveSummerRiskRules(event)"><label><span>At-risk after absences</span><input name="absence_warning" type="number" min="1" value="${r.absence_warning||2}"></label><label><span>Critical after absences</span><input name="absence_critical" type="number" min="1" value="${r.absence_critical||3}"></label><label><span>At-risk grade below</span><input name="grade_warning" type="number" value="${r.grade_warning||75}"></label><label><span>Critical grade below</span><input name="grade_critical" type="number" value="${r.grade_critical||65}"></label><label><span>Missing-work warning</span><input name="missing_warning" type="number" value="${r.missing_warning||2}"></label><div class="full"><button class="btn primary">Save Rules</button></div></form>`)};
 window.saveSummerRiskRules=async function(e){e.preventDefault();await api('/api/summer-school/rules',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});closeModal();toastMsg('Summer intervention rules saved');summerCommandCenter()};

 // Extend the existing Summer School page instead of creating more summer-only modules.
 const oldSummer=window.summerSchoolPage;window.summerSchoolPage=async function(){await oldSummer();let bar=document.querySelector('#content .summer-hero');if(bar){let actions=bar.lastElementChild?.parentElement===bar?bar.lastElementChild:null;let b=document.createElement('button');b.className='btn outline';b.textContent='Command Center';b.onclick=summerCommandCenter;if(actions&&actions.tagName==='BUTTON')actions.before(b);else bar.appendChild(b)}};
 // Add closeout to the existing Summer Course Manager rather than a separate closeout section.
 const oldManager=window.summerCourseManager;if(typeof oldManager==='function')window.summerCourseManager=async function(id,tab='overview'){await oldManager(id,tab);setTimeout(()=>{let head=document.querySelector('#modal .summer-manager-head .row-actions');if(head&&!document.getElementById('ss266Closeout')){let b=document.createElement('button');b.id='ss266Closeout';b.className='btn outline';b.textContent='Close Out Course';b.onclick=()=>ss266Closeout(id);head.prepend(b)}},0)};
 window.ss266Closeout=function(id){openModal('Summer Course Closeout',`<div class="callout"><b>Close the Summer School course?</b><br>Finalized grades remain in report cards/transcripts and earned course credit remains in Academic Planning. Historical attendance, assignments and submissions are preserved.</div><label class="form-question"><span>Closeout notes</span><textarea id="ss266CloseNotes"></textarea></label><div class="row-actions"><button class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn primary" onclick="ss266DoCloseout(${id})">Finalize Summer Course</button></div>`)};
 window.ss266DoCloseout=async function(id){await api('/api/summer-school/closeout',{method:'POST',body:JSON.stringify({class_id:id,status:'Closed',notes:$('#ss266CloseNotes')?.value||''})});closeModal();toastMsg('Summer course closed out');summerSchoolPage()};

 // Course Transfers belongs to the existing Academic Planning workflow for the entire year.
 const oldAcademic=window.academicPlanningPage;if(typeof oldAcademic==='function')window.academicPlanningPage=async function(...a){let out=await oldAcademic(...a);setTimeout(()=>{let pb=document.querySelector('#content .pagebar .page-actions')||document.querySelector('#content .pagebar');if(pb&&!document.getElementById('ss266TransferBtn')){let b=document.createElement('button');b.id='ss266TransferBtn';b.className='btn outline';b.textContent=(role==='student'||role==='parent')?'Request Course Change':'Course Transfer';b.onclick=()=>courseTransferCenter(a[0]||user?.student_id||0);pb.appendChild(b)}},0);return out};
 // Existing modules get a Summer compatibility option in-place; no duplicate sidebar sections.
 const termPages={'calendar':'Calendar','campus-communications':'Announcements','campus-transportation':'Transportation','campus-meals':'Meals','substitute':'Substitutes','academic-planning':'Grades & Credits'};
 const priorShow=window.showPage;window.showPage=async function(id){let r=await priorShow(id);setTimeout(()=>ss266AddTermOption(id),30);return r};
 function ss266AddTermOption(id){if(role==='student'||role==='parent')return;if(!termPages[id])return;let bar=document.querySelector('#content .pagebar .page-actions')||document.querySelector('#content .pagebar');if(!bar||document.getElementById('ss266TermOption'))return;let b=document.createElement('button');b.id='ss266TermOption';b.className='btn outline';b.textContent='☀️ Summer Compatibility';b.onclick=()=>ss266TermOptions(id);bar.appendChild(b)}
 window.ss266TermOptions=async function(page){if(role==='student'||role==='parent')return toastMsg('Summer settings are managed by school staff.');let d=await api('/api/term-services'),name=termPages[page]||page,service=page.replace('campus-','');openModal(name+' — Summer Compatibility',`<div class="callout">This uses the existing <b>${E(name)}</b> system. It does not create a separate Summer School module.</div><form class="form" onsubmit="ss266SaveTermOption(event,'${service}')"><label><span>Term</span><select name="term_scope"><option>Regular</option><option selected>Summer</option><option>All</option></select></label><label><span>Summer course</span><select name="summer_class_id"><option value="">All Summer School</option>${(d.summer_classes||[]).map(c=>`<option value="${c.id}">${E(c.name)} · ${E(c.start_date)}–${E(c.end_date)}</option>`).join('')}</select></label><label class="full"><span>Enabled</span><select name="enabled"><option value="1">Yes — include Summer School</option><option value="0">No</option></select></label><div class="full"><button class="btn primary">Save Compatibility</button></div></form>`)};
 window.ss266SaveTermOption=async function(e,service){e.preventDefault();let d=Object.fromEntries(new FormData(e.target));d.service=service;d.enabled=d.enabled==='1';await api('/api/term-services',{method:'POST',body:JSON.stringify(d)});closeModal();toastMsg('Summer compatibility saved in the existing system')};

})();
