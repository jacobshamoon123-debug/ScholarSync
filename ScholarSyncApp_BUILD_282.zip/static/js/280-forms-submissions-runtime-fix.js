/* ScholarSync Build 249: restore and harden form submissions visibility. */
(function(){
  const oldFormsCenter = window.formsCenter;
  function staffFormsRole(){ return ['admin','teacher','counselor'].includes(role); }
  function addSubmissionNav(){
    if(!window.NAV) return;
    const defs={admin:['OPERATIONS','forms-submissions','📥','Form Submissions'],teacher:['TEACHING','forms-submissions','📥','Form Submissions'],counselor:['COUNSELING','forms-submissions','📥','Form Submissions']};
    const d=defs[role]; if(!d) return;
    const a=window.NAV[role]||[];
    if(!a.some(x=>x[1]==='forms-submissions')){
      const idx=a.findIndex(x=>x[1]==='formscenter');
      a.splice(idx>=0?idx+1:a.length,0,d);
      try{ buildNav(); }catch(_e){}
    }
  }
  addSubmissionNav();

  async function loadForms(){
    const forms=await api('/api/forms');
    return Array.isArray(forms)?forms:[];
  }
  function formStaffCard(f){
    const n=Number(f.response_count||0);
    return `<div class="form-card"><div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start"><div><h3>${esc(f.title)}</h3><div class="student-sub">${esc(f.audience||'')} · ${esc(f.status||'')}${f.close_date?' · closes '+esc(f.close_date):''}</div></div><span class="badge">${n} submission${n===1?'':'s'}</span></div><p>${esc(f.description||'')}</p><div class="row-actions"><button class="btn mini primary" onclick="openFormSubmissionsPage(${Number(f.id)})">View Submissions</button>${role==='admin'?`<button class="btn mini outline" onclick="editSchoolForm(${Number(f.id)})">Edit</button><button class="btn mini danger" onclick="deleteSchoolForm(${Number(f.id)})">Delete</button>`:''}</div></div>`;
  }

  window.formsCenter=async function(){
    if(!staffFormsRole()) return oldFormsCenter();
    const forms=await loadForms();
    const total=forms.reduce((a,x)=>a+Number(x.response_count||0),0);
    $('#content').innerHTML=`<div class="pagebar"><div><h1>Forms Center</h1><p>Create forms and review every submitted response.</p></div><div class="page-actions"><button class="btn outline" onclick="showPage('forms-submissions')">📥 Form Submissions</button>${role==='admin'?'<button class="btn success" onclick="editSchoolForm()">+ Create Form</button>':''}</div></div><div class="metric-strip"><div class="metric"><small>Total forms</small><strong>${forms.length}</strong></div><div class="metric"><small>Published</small><strong>${forms.filter(x=>x.status==='Published').length}</strong></div><div class="metric"><small>Total submissions</small><strong>${total}</strong></div></div><div class="panel"><div class="panel-head"><h3>School Forms</h3></div><div class="panel-body" style="display:grid;gap:10px">${forms.map(formStaffCard).join('')||'<div class="empty-modern">No forms yet.</div>'}</div></div>`;
    try{ssActiveNav('formscenter')}catch(_e){}
  };

  function answerRows(def,response){
    let answers={};
    try{answers=JSON.parse(response.answers_json||'{}')}catch(_e){}
    const rows=(def.questions||[]).map(q=>{
      let v=answers[q.id]; if(v===undefined) v=answers[String(q.id)];
      if(Array.isArray(v)) v=v.join(', ');
      return `<div class="response-answer"><b>${esc(q.question_text)}</b><div>${esc(v==null||v===''?'—':String(v))}</div></div>`;
    }).join('');
    return rows+(response.signature_name?`<div class="response-answer"><b>Signature</b><div>${esc(response.signature_name)}</div></div>`:'');
  }

  window.openFormSubmissionsPage=function(fid){
    window._formsSubmissionSelected=Number(fid||0);
    return showPage('forms-submissions');
  };
  window.formSubmissionsPage=async function(){
    if(!staffFormsRole()) return showPage('formscenter');
    const forms=await loadForms();
    let selected=Number(window._formsSubmissionSelected||0);
    if(!selected && forms.length) selected=Number(forms[0].id);
    if(selected && !forms.some(f=>Number(f.id)===selected)) selected=forms.length?Number(forms[0].id):0;
    let def=null,responses=[];
    if(selected){
      [def,responses]=await Promise.all([api('/api/forms?id='+selected),api('/api/forms/responses?form_id='+selected)]);
      if(!Array.isArray(responses)) responses=[];
    }
    const total=forms.reduce((a,x)=>a+Number(x.response_count||0),0);
    $('#content').innerHTML=`<div class="pagebar"><div><h1>Form Submissions</h1><p>Review submitted forms, answers, signatures, and submission timestamps.</p></div><div class="page-actions"><button class="btn outline" onclick="showPage('formscenter')">Forms Center</button>${selected?`<button class="btn outline" onclick="exportFormResponses(${selected})">Export CSV</button>`:''}</div></div><div class="metric-strip"><div class="metric"><small>Forms</small><strong>${forms.length}</strong></div><div class="metric"><small>Total submissions</small><strong>${total}</strong></div><div class="metric"><small>Selected form submissions</small><strong>${responses.length}</strong></div></div><div class="panel"><div class="panel-head"><h3>Select a form</h3></div><div class="panel-body"><select class="control" onchange="window._formsSubmissionSelected=Number(this.value);formSubmissionsPage()"><option value="">Choose a form</option>${forms.map(f=>`<option value="${Number(f.id)}" ${Number(f.id)===selected?'selected':''}>${esc(f.title)} — ${Number(f.response_count||0)} submission${Number(f.response_count||0)===1?'':'s'}</option>`).join('')}</select></div></div>${!selected?'<div class="panel"><div class="empty-modern">Choose a form to see its submissions.</div></div>':`<div class="panel"><div class="panel-head"><div><h3>${esc(def?.title||'Form')}</h3><div class="student-sub">${responses.length} submitted response${responses.length===1?'':'s'}</div></div></div><div class="panel-body" style="display:grid;gap:12px">${responses.map((r,i)=>`<details class="form-card" ${i===0?'open':''}><summary style="cursor:pointer"><b>${esc(r.student_name||'Parent / family response')}</b><span class="student-sub" style="margin-left:10px">${esc(r.student_number||'')} · ${esc(r.submitted_at||'')}</span></summary><div style="margin-top:14px">${answerRows(def,r)}</div></details>`).join('')||'<div class="empty-modern">No submissions have been received for this form yet.</div>'}</div></div>`}`;
    try{ssActiveNav('forms-submissions')}catch(_e){}
  };

  window.viewFormResponses=function(fid){ return openFormSubmissionsPage(fid); };
  if(window.ssRegisterPageRoute){
    window.ssRegisterPageRoute('forms-submissions',()=>{ $('#crumb').textContent='Form Submissions'; return formSubmissionsPage(); },['admin','teacher','counselor']);
  }
})();
