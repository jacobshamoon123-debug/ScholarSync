/* ScholarSync Build 277 — Automated Email Notification Engine */
(function(){
  const E=v=>typeof esc==='function'?esc(v==null?'':String(v)):String(v==null?'':v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const modeOptions=v=>['Immediate','Daily summary','Off'].map(x=>`<option ${x===v?'selected':''}>${x}</option>`).join('');
  const statusBadge=s=>{s=String(s||'Queued');const c=s==='Sent'?'ok':s==='Failed'?'danger':s==='Digest'?'warn':'';return `<span class="badge ${c}">${E(s)}</span>`};

  window.ss277EmailPreferences=async function(){
    const p=await api('/api/email-notifications/preferences');
    const defaultEmail=p.inferred_email||'';
    openModal('Email Notification Preferences',`<form class="form" onsubmit="ss277SaveEmailPreferences(event)">
      <div class="full callout"><b>Automated ScholarSync email</b><br>Choose which updates should be emailed and how often. In-app notifications still remain available.</div>
      <label class="full"><span>Delivery email</span><input name="email_address" type="email" value="${E(p.email_address||'')}" placeholder="${E(defaultEmail||'you@example.com')}"><small>${defaultEmail?`Leave blank to use ${E(defaultEmail)}.`:'Enter the email address where ScholarSync should send notifications.'}</small></label>
      <label class="checkbox-line full"><input name="enabled" type="checkbox" ${Number(p.enabled)!==0?'checked':''}> Enable automated email notifications</label>
      <label><span>Grades posted / changed</span><select name="grade_mode">${modeOptions(p.grade_mode)}</select></label>
      <label><span>New assignments</span><select name="assignment_mode">${modeOptions(p.assignment_mode)}</select></label>
      <label><span>Missing work</span><select name="missing_mode">${modeOptions(p.missing_mode)}</select></label>
      <label><span>Attendance exceptions</span><select name="attendance_mode">${modeOptions(p.attendance_mode)}</select></label>
      <label><span>Schedule / course changes</span><select name="schedule_mode">${modeOptions(p.schedule_mode)}</select></label>
      ${['teacher','admin','counselor','substitute'].includes(role)?`<label><span>Teacher workflow updates</span><select name="teacher_mode">${modeOptions(p.teacher_mode)}</select></label>`:''}
      <div class="full callout"><b>Immediate</b> sends as soon as ScholarSync records the event. <b>Daily summary</b> combines updates and sends them after 5 PM school time. <b>Off</b> disables email for that category.</div>
      <div class="full"><button class="btn primary">Save Email Preferences</button></div>
    </form>`);
  };

  window.ss277SaveEmailPreferences=async function(e){
    e.preventDefault();const f=e.target;
    const body={enabled:f.enabled.checked,email_address:f.email_address.value.trim()};
    ['grade_mode','assignment_mode','missing_mode','attendance_mode','schedule_mode','teacher_mode'].forEach(k=>{if(f[k])body[k]=f[k].value});
    await api('/api/email-notifications/preferences',{method:'POST',body:JSON.stringify(body)});
    closeModal();toastMsg('Email notification preferences saved');
    if(activePage==='notifications')notificationsPage();
  };

  window.ss277EmailDeliveryCenter=async function(){
    const d=await api('/api/email-notifications/admin');const s=d.settings||{},stats=d.stats||{};
    openModal('Automated Email Delivery',`<div class="ss277-email-admin">
      <div class="metrics compact-metrics" style="margin-bottom:14px">
        <div><span>Total</span><b>${Number(stats.total||0)}</b></div><div><span>Sent</span><b>${Number(stats.sent||0)}</b></div><div><span>Queued</span><b>${Number(stats.queued||0)}</b></div><div><span>Failed</span><b>${Number(stats.failed||0)}</b></div>
      </div>
      <form class="form" onsubmit="ss277SaveEmailSettings(event)">
        <label class="checkbox-line full"><input name="enabled" type="checkbox" ${s.enabled?'checked':''}> Turn on real email delivery</label>
        <label><span>SMTP host</span><input name="host" value="${E(s.host||'')}" placeholder="smtp.office365.com"></label>
        <label><span>SMTP port</span><input name="port" type="number" value="${E(s.port||587)}"></label>
        <label><span>Security</span><select name="security"><option ${s.security==='STARTTLS'?'selected':''}>STARTTLS</option><option ${s.security==='SSL'?'selected':''}>SSL</option><option ${s.security==='None'?'selected':''}>None</option></select></label>
        <label><span>SMTP username</span><input name="username" value="${E(s.username||'')}"></label>
        <label><span>SMTP password</span><input name="password" type="password" placeholder="${s.password_configured?'Password already saved — leave blank to keep it':'Enter password / app password'}"></label>
        <label><span>From email</span><input name="from_address" type="email" value="${E(s.from_address||'')}"></label>
        <label><span>From name</span><input name="from_name" value="${E(s.from_name||'ScholarSync')}"></label>
        <label class="full"><span>Reply-to (optional)</span><input name="reply_to" type="email" value="${E(s.reply_to||'')}"></label>
        <div class="full callout">You can use district Microsoft 365/Outlook, Google Workspace SMTP, SendGrid, Mailgun, Amazon SES, or another SMTP provider. If delivery is off, events remain safely queued instead of being lost.</div>
        <div class="full page-actions"><button class="btn primary">Save Delivery Settings</button><button type="button" class="btn outline" onclick="ss277TestEmail()">Send Test Email</button><button type="button" class="btn outline" onclick="ss277RetryEmails()">Retry Queue</button></div>
      </form>
      <div class="panel" style="margin-top:16px"><div class="panel-head"><h3>Recent email activity</h3></div><div class="table-wrap"><table><thead><tr><th>When</th><th>Type</th><th>To</th><th>Subject</th><th>Status</th><th></th></tr></thead><tbody>${(d.recent||[]).map(x=>`<tr><td>${E((x.created_at||'').replace('T',' '))}</td><td>${E(x.event_type)}</td><td>${E(x.email_to)}</td><td>${E(x.subject)}</td><td>${statusBadge(x.status)}${x.last_error?`<small style="display:block;color:var(--muted);max-width:260px">${E(x.last_error)}</small>`:''}</td><td>${x.status!=='Sent'?`<button type="button" class="btn mini outline" onclick="ss277RetryEmail(${Number(x.id)})">Retry</button>`:''}</td></tr>`).join('')||'<tr><td colspan="6">No automated email events yet.</td></tr>'}</tbody></table></div></div>
    </div>`);
  };

  window.ss277SaveEmailSettings=async function(e){
    e.preventDefault();const f=e.target;
    await api('/api/email-notifications/admin',{method:'POST',body:JSON.stringify({action:'settings',enabled:f.enabled.checked,host:f.host.value.trim(),port:f.port.value,security:f.security.value,username:f.username.value.trim(),password:f.password.value,from_address:f.from_address.value.trim(),from_name:f.from_name.value.trim(),reply_to:f.reply_to.value.trim()})});
    toastMsg('Email delivery settings saved');ss277EmailDeliveryCenter();
  };
  window.ss277TestEmail=async function(){
    const email=prompt('Send a ScholarSync test email to:');if(!email)return;
    try{await api('/api/email-notifications/admin',{method:'POST',body:JSON.stringify({action:'test',email:email.trim()})});toastMsg('Test email sent');}
    catch(e){toastMsg(e.message||'Test email failed')}
  };
  window.ss277RetryEmail=async function(id){await api('/api/email-notifications/admin',{method:'POST',body:JSON.stringify({action:'retry',id})});toastMsg('Retry complete');ss277EmailDeliveryCenter()};
  window.ss277RetryEmails=async function(){await api('/api/email-notifications/admin',{method:'POST',body:JSON.stringify({action:'retry'})});toastMsg('Queued emails processed');ss277EmailDeliveryCenter()};

  const oldNotifications=window.notificationsPage;
  if(typeof oldNotifications==='function'){
    window.notificationsPage=async function(){
      await oldNotifications();
      const page=document.querySelector('#content');if(!page)return;
      const bar=page.querySelector('.pagebar .page-actions')||page.querySelector('.pagebar');
      if(bar&&!document.getElementById('ss277EmailPrefsBtn')){
        const b=document.createElement('button');b.id='ss277EmailPrefsBtn';b.className='btn outline';b.textContent='✉ Email Preferences';b.onclick=ss277EmailPreferences;bar.appendChild(b);
        if(role==='admin'){const a=document.createElement('button');a.className='btn primary';a.textContent='⚙ Email Delivery';a.onclick=ss277EmailDeliveryCenter;bar.appendChild(a)}
      }
      try{
        const log=await api('/api/email-notifications/log');
        const panel=document.createElement('div');panel.className='panel';panel.style.marginTop='16px';
        panel.innerHTML=`<div class="panel-head"><div><h3>Email delivery activity</h3><small>Automated emails generated by grades, assignments, attendance, scheduling, and teacher workflows.</small></div></div><div class="panel-body">${(log||[]).slice(0,8).map(x=>`<div class="notification-row"><div class="notification-icon">✉</div><div><b>${E(x.subject)}</b><span>${E(x.email_to)}</span><small>${E(x.created_at||'')}</small></div>${statusBadge(x.status)}</div>`).join('')||'<div class="empty-modern">No automated email activity yet.</div>'}</div>`;
        page.appendChild(panel);
      }catch(_){ }
    };
  }
})();
