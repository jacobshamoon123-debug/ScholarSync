
(function(){
  async function reqs(){return await api('/api/substitute/requests');}
  window.ssOpenTeacherSubRequests=async function(){if(typeof substituteCenter==='function')return substituteCenter();};
  const oldNew=window.newSubAssignment;
  if(typeof oldNew==='function'){
    window.newSubAssignment=async function(){
      const out=await oldNew.apply(this,arguments);
      const r=window._pendingSubRequest;
      if(r){
        setTimeout(()=>{
          const teacher=document.querySelector('#sub-teacher,#sa-teacher,#subTeacher,[name="teacher_staff_id"]');
          const date=document.querySelector('#sub-date,#sa-date,#sub-start,[name="date"],[name="start_date"]');
          if(teacher){teacher.value=String(r.teacher_staff_id);teacher.dispatchEvent(new Event('change',{bubbles:true}));}
          if(date){date.value=r.request_date;date.dispatchEvent(new Event('change',{bubbles:true}));}
          setTimeout(()=>{
            if(r.scope==='selected'){
              let ids=[];try{ids=JSON.parse(r.selected_class_ids||'[]')}catch(e){}
              document.querySelectorAll('input[type=checkbox][value]').forEach(cb=>{if(ids.includes(Number(cb.value)))cb.checked=true;});
            }
          },250);
        },100);
      }
      return out;
    };
  }
})();
