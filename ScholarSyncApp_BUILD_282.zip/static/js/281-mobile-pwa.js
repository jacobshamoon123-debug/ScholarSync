/* ScholarSync Build 282 — iPhone / Mobile PWA */
(function(){
 window.SCHOLARSYNC_BUILD='282';
 function mark(){let e=document.getElementById('ss-build-chip');if(e)e.textContent='ScholarSync Build 282';}
 function setup(){
   mark();
   const top=document.querySelector('.top');
   if(top&&!document.getElementById('ss-mobile-menu')){const b=document.createElement('button');b.id='ss-mobile-menu';b.className='ss-mobile-menu';b.type='button';b.setAttribute('aria-label','Open navigation');b.textContent='☰';b.onclick=()=>document.body.classList.toggle('ss-nav-open');top.prepend(b);}
   document.querySelectorAll('.nav button').forEach(b=>b.addEventListener('click',()=>document.body.classList.remove('ss-nav-open')));
   if('serviceWorker' in navigator && (location.protocol==='https:'||location.hostname==='localhost'||location.hostname==='127.0.0.1')) navigator.serviceWorker.register('sw.js?v=281').catch(()=>{});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setup,{once:true});else setup();
 setTimeout(mark,100);setTimeout(mark,700);
})();