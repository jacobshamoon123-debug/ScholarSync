@echo off
cd /d "%~dp0"
python server.py --portal teacher
pause
