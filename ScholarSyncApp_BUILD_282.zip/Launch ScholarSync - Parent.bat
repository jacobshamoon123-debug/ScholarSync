@echo off
cd /d "%~dp0"
python server.py --portal parent
pause
